<?php
/**
 * 跨點點工費管理 Model
 */
class InterBranchModel
{
    /** @var PDO */
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * 取得清單
     */
    public function getList(array $branchIds, array $filters = array())
    {
        $where = array();
        $params = array();

        // 據點篩選
        if (!empty($branchIds)) {
            $ph = implode(',', array_fill(0, count($branchIds), '?'));
            $where[] = "(ibs.from_branch_id IN ($ph) OR ibs.to_branch_id IN ($ph))";
            $params = array_merge($branchIds, $branchIds);
        }

        // 月份篩選
        if (!empty($filters['month'])) {
            $startDate = $filters['month'] . '-01';
            $endDate = date('Y-m-t', strtotime($startDate));
            $where[] = 'ibs.support_date BETWEEN ? AND ?';
            $params[] = $startDate;
            $params[] = $endDate;
        }

        // 據點篩選（特定）
        if (!empty($filters['branch_id'])) {
            $where[] = '(ibs.from_branch_id = ? OR ibs.to_branch_id = ?)';
            $params[] = (int)$filters['branch_id'];
            $params[] = (int)$filters['branch_id'];
        }

        // 結算狀態
        if ($filters['settled'] !== '' && isset($filters['settled'])) {
            $where[] = 'ibs.settled = ?';
            $params[] = (int)$filters['settled'];
        }

        $whereStr = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare("
            SELECT ibs.*,
                   u.real_name AS user_name,
                   bf.name AS from_branch_name,
                   bt.name AS to_branch_name
            FROM inter_branch_support ibs
            JOIN users u ON ibs.user_id = u.id
            JOIN branches bf ON ibs.from_branch_id = bf.id
            JOIN branches bt ON ibs.to_branch_id = bt.id
            $whereStr
            ORDER BY ibs.support_date DESC, ibs.id DESC
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 取得單筆
     */
    public function getById($id)
    {
        $stmt = $this->db->prepare("
            SELECT ibs.*,
                   u.real_name AS user_name,
                   bf.name AS from_branch_name,
                   bt.name AS to_branch_name
            FROM inter_branch_support ibs
            JOIN users u ON ibs.user_id = u.id
            JOIN branches bf ON ibs.from_branch_id = bf.id
            JOIN branches bt ON ibs.to_branch_id = bt.id
            WHERE ibs.id = ?
        ");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /**
     * 新增
     */
    public function create(array $data)
    {
        $stmt = $this->db->prepare("
            INSERT INTO inter_branch_support (user_id, from_branch_id, to_branch_id, support_date, charge_type, hours, schedule_id, note)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute(array(
            (int)$data['user_id'],
            (int)$data['from_branch_id'],
            (int)$data['to_branch_id'],
            $data['support_date'],
            $data['charge_type'],
            $data['charge_type'] === 'hourly' ? ($data['hours'] ?: null) : null,
            !empty($data['schedule_id']) ? (int)$data['schedule_id'] : null,
            $data['note'] ?: null,
        ));
        return $this->db->lastInsertId();
    }

    /**
     * 更新
     */
    public function update($id, array $data)
    {
        $stmt = $this->db->prepare("
            UPDATE inter_branch_support
            SET user_id = ?, from_branch_id = ?, to_branch_id = ?, support_date = ?,
                charge_type = ?, hours = ?, note = ?
            WHERE id = ? AND settled = 0
        ");
        $stmt->execute(array(
            (int)$data['user_id'],
            (int)$data['from_branch_id'],
            (int)$data['to_branch_id'],
            $data['support_date'],
            $data['charge_type'],
            $data['charge_type'] === 'hourly' ? ($data['hours'] ?: null) : null,
            $data['note'] ?: null,
            (int)$id,
        ));
    }

    /**
     * 刪除（僅未結算）
     */
    public function delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM inter_branch_support WHERE id = ? AND settled = 0");
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

    /**
     * 月結：標記指定月份的記錄為已結算
     */
    public function settleMonth($month, array $branchIds)
    {
        $startDate = $month . '-01';
        $endDate = date('Y-m-t', strtotime($startDate));
        $ph = implode(',', array_fill(0, count($branchIds), '?'));

        $params = array_merge(array($month), $branchIds, array($startDate, $endDate));

        $stmt = $this->db->prepare("
            UPDATE inter_branch_support
            SET settled = 1, settle_month = ?
            WHERE (from_branch_id IN ($ph) OR to_branch_id IN ($ph))
              AND support_date BETWEEN ? AND ?
              AND settled = 0
        ");

        // 需要兩份 branchIds for OR 條件
        $allParams = array($month);
        $allParams = array_merge($allParams, $branchIds, $branchIds);
        $allParams[] = $startDate;
        $allParams[] = $endDate;

        $stmt->execute($allParams);
        return $stmt->rowCount();
    }

    /**
     * 月結摘要
     */
    public function getSettleSummary($month, array $branchIds)
    {
        $startDate = $month . '-01';
        $endDate = date('Y-m-t', strtotime($startDate));
        $ph = implode(',', array_fill(0, count($branchIds), '?'));

        $params = array_merge($branchIds, $branchIds, array($startDate, $endDate));

        $stmt = $this->db->prepare("
            SELECT bf.name AS from_branch, bt.name AS to_branch,
                   COUNT(*) AS support_count,
                   SUM(CASE WHEN ibs.charge_type = 'full_day' THEN 1 ELSE 0 END) AS full_days,
                   SUM(CASE WHEN ibs.charge_type = 'half_day' THEN 1 ELSE 0 END) AS half_days,
                   SUM(CASE WHEN ibs.charge_type = 'hourly' THEN COALESCE(ibs.hours, 0) ELSE 0 END) AS total_hours,
                   SUM(ibs.settled) AS settled_count
            FROM inter_branch_support ibs
            JOIN branches bf ON ibs.from_branch_id = bf.id
            JOIN branches bt ON ibs.to_branch_id = bt.id
            WHERE (ibs.from_branch_id IN ($ph) OR ibs.to_branch_id IN ($ph))
              AND ibs.support_date BETWEEN ? AND ?
            GROUP BY bf.name, bt.name
            ORDER BY bf.name, bt.name
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 取得所有據點
     */
    public function getAllBranches()
    {
        $stmt = $this->db->query("SELECT * FROM branches WHERE is_active = 1 ORDER BY code");
        return $stmt->fetchAll();
    }

    /**
     * 取得工程師
     */
    public function getEngineers(array $branchIds = array())
    {
        if (empty($branchIds)) {
            $stmt = $this->db->query("SELECT id, real_name, branch_id FROM users WHERE is_active = 1 AND is_engineer = 1 ORDER BY real_name");
            return $stmt->fetchAll();
        }
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $stmt = $this->db->prepare("SELECT id, real_name, branch_id FROM users WHERE is_active = 1 AND is_engineer = 1 AND branch_id IN ($ph) ORDER BY real_name");
        $stmt->execute($branchIds);
        return $stmt->fetchAll();
    }

    /**
     * 計費類型標籤
     */
    public static function chargeTypeLabel($type)
    {
        $labels = array(
            'full_day' => '整日',
            'half_day' => '半日',
            'hourly'   => '時數',
        );
        return isset($labels[$type]) ? $labels[$type] : $type;
    }
}
