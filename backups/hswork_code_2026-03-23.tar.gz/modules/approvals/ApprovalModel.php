<?php
/**
 * 通用簽核引擎
 * 支援：報價單、支出單、請購單、請假單、加班單等
 */
class ApprovalModel
{
    /** @var PDO */
    private $db;

    private static $moduleLabels = array(
        'quotations' => '報價單',
        'expenses'   => '支出單',
        'purchases'  => '請購單',
        'leaves'     => '請假單',
        'overtime'   => '加班單',
    );

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public static function moduleLabel($module)
    {
        return isset(self::$moduleLabels[$module]) ? self::$moduleLabels[$module] : $module;
    }

    // ===== 簽核規則管理 =====

    /**
     * 取得簽核規則列表
     */
    public function getRules($module = null)
    {
        $where = '1=1';
        $params = array();
        if ($module) {
            $where .= ' AND r.module = ?';
            $params[] = $module;
        }
        $stmt = $this->db->prepare("
            SELECT r.*, u.real_name as approver_name
            FROM approval_rules r
            LEFT JOIN users u ON r.approver_id = u.id
            WHERE $where
            ORDER BY r.module, r.level_order, r.min_amount
        ");
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 取得單一規則
     */
    public function getRuleById($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM approval_rules WHERE id = ?");
        $stmt->execute(array($id));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * 儲存規則（新增或更新）
     */
    public function saveRule($data)
    {
        if (!empty($data['id'])) {
            $stmt = $this->db->prepare("
                UPDATE approval_rules SET
                    module = ?, rule_name = ?, min_amount = ?, max_amount = ?,
                    min_profit_rate = ?, approver_role = ?, approver_id = ?,
                    level_order = ?, is_active = ?
                WHERE id = ?
            ");
            $stmt->execute(array(
                $data['module'],
                $data['rule_name'],
                $data['min_amount'] ?: 0,
                $data['max_amount'] ?: null,
                $data['min_profit_rate'] ?: null,
                $data['approver_role'] ?: null,
                $data['approver_id'] ?: null,
                $data['level_order'] ?: 1,
                isset($data['is_active']) ? $data['is_active'] : 1,
                $data['id'],
            ));
            return (int)$data['id'];
        } else {
            $stmt = $this->db->prepare("
                INSERT INTO approval_rules (module, rule_name, min_amount, max_amount,
                    min_profit_rate, approver_role, approver_id, level_order, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute(array(
                $data['module'],
                $data['rule_name'],
                $data['min_amount'] ?: 0,
                $data['max_amount'] ?: null,
                $data['min_profit_rate'] ?: null,
                $data['approver_role'] ?: null,
                $data['approver_id'] ?: null,
                $data['level_order'] ?: 1,
                isset($data['is_active']) ? $data['is_active'] : 1,
            ));
            return (int)$this->db->lastInsertId();
        }
    }

    /**
     * 刪除規則
     */
    public function deleteRule($id)
    {
        $this->db->prepare("DELETE FROM approval_rules WHERE id = ?")->execute(array($id));
    }

    // ===== 簽核流程 =====

    /**
     * 判斷是否需要簽核
     * @return array|false  需要簽核時回傳匹配的規則陣列，不需要回傳 false
     */
    public function needsApproval($module, $amount, $profitRate = null)
    {
        $stmt = $this->db->prepare("
            SELECT * FROM approval_rules
            WHERE module = ? AND is_active = 1
            ORDER BY level_order, min_amount
        ");
        $stmt->execute(array($module));
        $rules = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($rules)) return false; // 沒設定規則 = 不需簽核

        $matched = array();
        foreach ($rules as $rule) {
            $amountMatch = true;
            if ($rule['min_amount'] > 0 && $amount < $rule['min_amount']) $amountMatch = false;
            if ($rule['max_amount'] !== null && $amount > $rule['max_amount']) $amountMatch = false;

            // 利潤率檢查（如果有設定）
            $profitMatch = true;
            if ($rule['min_profit_rate'] !== null && $profitRate !== null) {
                if ($profitRate < $rule['min_profit_rate']) $profitMatch = false;
            }

            if ($amountMatch && $profitMatch) {
                $matched[] = $rule;
            }
        }

        return !empty($matched) ? $matched : false;
    }

    /**
     * 送簽核
     * @return array  建立的 flow 記錄
     */
    public function submitForApproval($module, $targetId, $amount, $profitRate = null, $submittedBy = null)
    {
        if (!$submittedBy) $submittedBy = Auth::id();

        // 先清除舊的 pending 記錄（重新送簽時）
        $this->db->prepare("DELETE FROM approval_flows WHERE module = ? AND target_id = ? AND status = 'pending'")
            ->execute(array($module, $targetId));

        $matchedRules = $this->needsApproval($module, $amount, $profitRate);

        if (!$matchedRules) {
            // 不需簽核，直接通過
            return array('auto_approved' => true);
        }

        $flows = array();
        foreach ($matchedRules as $rule) {
            // 找出簽核人
            $approverId = $rule['approver_id'];

            // 如果指定角色而非指定人，找該角色的人
            if (!$approverId && $rule['approver_role']) {
                $stmt = $this->db->prepare("SELECT id FROM users WHERE role = ? AND is_active = 1 LIMIT 1");
                $stmt->execute(array($rule['approver_role']));
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($user) $approverId = $user['id'];
            }

            if (!$approverId) continue; // 找不到簽核人就跳過

            $stmt = $this->db->prepare("
                INSERT INTO approval_flows (module, target_id, rule_id, level_order, approver_id, status, submitted_by)
                VALUES (?, ?, ?, ?, ?, 'pending', ?)
            ");
            $stmt->execute(array($module, $targetId, $rule['id'], $rule['level_order'], $approverId, $submittedBy));
            $flows[] = array(
                'id' => (int)$this->db->lastInsertId(),
                'approver_id' => $approverId,
                'level_order' => $rule['level_order'],
            );
        }

        return $flows;
    }

    /**
     * 核准
     */
    public function approve($flowId, $approverId, $comment = null)
    {
        $stmt = $this->db->prepare("
            UPDATE approval_flows SET status = 'approved', comment = ?, decided_at = NOW()
            WHERE id = ? AND approver_id = ? AND status = 'pending'
        ");
        $stmt->execute(array($comment, $flowId, $approverId));
        return $stmt->rowCount() > 0;
    }

    /**
     * 退回
     */
    public function reject($flowId, $approverId, $comment = null)
    {
        $stmt = $this->db->prepare("
            UPDATE approval_flows SET status = 'rejected', comment = ?, decided_at = NOW()
            WHERE id = ? AND approver_id = ? AND status = 'pending'
        ");
        $stmt->execute(array($comment, $flowId, $approverId));
        return $stmt->rowCount() > 0;
    }

    /**
     * 查詢某單據的簽核狀態
     * @return array  含 flows 和 overall_status
     */
    public function getFlowStatus($module, $targetId)
    {
        $stmt = $this->db->prepare("
            SELECT af.*, u.real_name as approver_name, sub.real_name as submitter_name
            FROM approval_flows af
            LEFT JOIN users u ON af.approver_id = u.id
            LEFT JOIN users sub ON af.submitted_by = sub.id
            WHERE af.module = ? AND af.target_id = ?
            ORDER BY af.level_order, af.submitted_at DESC
        ");
        $stmt->execute(array($module, $targetId));
        $flows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($flows)) {
            return array('flows' => array(), 'overall' => 'none');
        }

        $hasPending = false;
        $hasRejected = false;
        $allApproved = true;

        foreach ($flows as $f) {
            if ($f['status'] === 'pending') { $hasPending = true; $allApproved = false; }
            if ($f['status'] === 'rejected') { $hasRejected = true; $allApproved = false; }
        }

        $overall = 'pending';
        if ($hasRejected) $overall = 'rejected';
        elseif ($allApproved) $overall = 'approved';

        return array('flows' => $flows, 'overall' => $overall);
    }

    /**
     * 是否全部簽核通過
     */
    public function isFullyApproved($module, $targetId)
    {
        $status = $this->getFlowStatus($module, $targetId);
        return $status['overall'] === 'approved';
    }

    /**
     * 取得待簽核清單（給某個簽核人）
     */
    public function getPendingList($approverId)
    {
        $stmt = $this->db->prepare("
            SELECT af.*, sub.real_name as submitter_name
            FROM approval_flows af
            LEFT JOIN users sub ON af.submitted_by = sub.id
            WHERE af.approver_id = ? AND af.status = 'pending'
            ORDER BY af.submitted_at DESC
        ");
        $stmt->execute(array($approverId));
        $flows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 補充各模組的單據資訊
        foreach ($flows as &$f) {
            $f['target_info'] = $this->getTargetInfo($f['module'], $f['target_id']);
        }
        unset($f);

        return $flows;
    }

    /**
     * 取得待簽核數量
     */
    public function getPendingCount($approverId)
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM approval_flows WHERE approver_id = ? AND status = 'pending'");
        $stmt->execute(array($approverId));
        return (int)$stmt->fetchColumn();
    }

    /**
     * 取得單據資訊（各模組）
     */
    private function getTargetInfo($module, $targetId)
    {
        switch ($module) {
            case 'quotations':
                $stmt = $this->db->prepare("SELECT id, quotation_number, customer_name, total_amount, status, quote_date FROM quotations WHERE id = ?");
                $stmt->execute(array($targetId));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row) {
                    $row['label'] = $row['quotation_number'] . ' - ' . $row['customer_name'];
                    $row['url'] = '/quotations.php?action=view&id=' . $targetId;
                    $row['amount'] = $row['total_amount'];
                }
                return $row ?: array();
            default:
                return array('label' => $module . ' #' . $targetId, 'url' => '#');
        }
    }

    /**
     * 取得可當簽核人的使用者列表
     */
    public function getApprovers()
    {
        $stmt = $this->db->query("
            SELECT id, real_name, role FROM users
            WHERE is_active = 1 AND role IN ('boss','sales_manager','eng_manager','eng_deputy')
            ORDER BY FIELD(role,'boss','sales_manager','eng_manager','eng_deputy'), real_name
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 角色中文
     */
    public static function roleLabel($role)
    {
        $map = array(
            'boss' => '老闆/總經理',
            'sales_manager' => '業務經理',
            'eng_manager' => '工程主管',
            'eng_deputy' => '工程副主管',
            'sales' => '業務',
            'sales_assistant' => '業務助理',
            'admin_staff' => '行政人員',
        );
        return isset($map[$role]) ? $map[$role] : $role;
    }
}
