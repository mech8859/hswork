<?php
/**
 * 報表資料模型
 */
class ReportModel
{
    /** @var PDO */
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * 案件利潤分析
     */
    public function getCaseProfitReport(array $branchIds, string $startDate, string $endDate): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $params = array_merge($branchIds, [$startDate, $endDate]);

        $stmt = $this->db->prepare("
            SELECT c.id, c.case_number, c.title, c.case_type, c.status,
                   b.name AS branch_name,
                   COALESCE(p.total_paid, 0) AS total_paid,
                   COALESCE(s.work_days, 0) AS work_days,
                   COALESCE(s.engineer_count, 0) AS total_engineer_days
            FROM cases c
            JOIN branches b ON c.branch_id = b.id
            LEFT JOIN (
                SELECT case_id, SUM(amount) AS total_paid
                FROM payments
                GROUP BY case_id
            ) p ON p.case_id = c.id
            LEFT JOIN (
                SELECT s2.case_id,
                       COUNT(DISTINCT s2.id) AS work_days,
                       COUNT(se.id) AS engineer_count
                FROM schedules s2
                LEFT JOIN schedule_engineers se ON se.schedule_id = s2.id
                WHERE s2.status != 'cancelled'
                GROUP BY s2.case_id
            ) s ON s.case_id = c.id
            WHERE c.branch_id IN ($ph)
              AND c.created_at BETWEEN ? AND ?
            ORDER BY c.created_at DESC
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 員工產值統計
     */
    public function getStaffProductivityReport(array $branchIds, string $startDate, string $endDate): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $params = array_merge($branchIds, [$startDate, $endDate]);

        $stmt = $this->db->prepare("
            SELECT u.id, u.real_name, b.name AS branch_name,
                   COUNT(DISTINCT se.schedule_id) AS schedule_count,
                   COUNT(DISTINCT s.case_id) AS case_count,
                   COUNT(DISTINCT wl.id) AS worklog_count,
                   SUM(CASE WHEN wl.arrival_time IS NOT NULL AND wl.departure_time IS NOT NULL
                       THEN TIMESTAMPDIFF(MINUTE, wl.arrival_time, wl.departure_time) ELSE 0 END) AS total_minutes
            FROM users u
            JOIN branches b ON u.branch_id = b.id
            LEFT JOIN schedule_engineers se ON se.user_id = u.id
            LEFT JOIN schedules s ON se.schedule_id = s.id AND s.status != 'cancelled'
                AND s.schedule_date BETWEEN ? AND ?
            LEFT JOIN work_logs wl ON wl.user_id = u.id AND wl.work_date BETWEEN ? AND ?
            WHERE u.branch_id IN ($ph) AND u.is_engineer = 1 AND u.is_active = 1
            GROUP BY u.id, u.real_name, b.name
            ORDER BY schedule_count DESC
        ");
        $allParams = array_merge([$startDate, $endDate, $startDate, $endDate], $branchIds);
        $stmt->execute($allParams);
        return $stmt->fetchAll();
    }

    /**
     * 跨點點工費月結報表
     */
    public function getInterBranchMonthlyReport(array $branchIds, string $month): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $startDate = $month . '-01';
        $endDate = date('Y-m-t', strtotime($startDate));
        $params = array_merge($branchIds, [$startDate, $endDate]);

        $stmt = $this->db->prepare("
            SELECT bf.name AS from_branch, bt.name AS to_branch,
                   COUNT(*) AS support_count,
                   SUM(CASE WHEN ibs.charge_type = 'full_day' THEN 1 ELSE 0 END) AS full_days,
                   SUM(CASE WHEN ibs.charge_type = 'half_day' THEN 1 ELSE 0 END) AS half_days,
                   SUM(CASE WHEN ibs.charge_type = 'hourly' THEN COALESCE(ibs.hours, 0) ELSE 0 END) AS total_hours,
                   SUM(ibs.settled) AS settled_count
            FROM inter_branch_support ibs
            JOIN branches bf ON ibs.from_branch_id = bf.id
            JOIN branches bt ON ibs.to_branch_id = bt.id
            WHERE ibs.from_branch_id IN ($ph)
              AND ibs.support_date BETWEEN ? AND ?
            GROUP BY bf.name, bt.name
            ORDER BY bf.name, bt.name
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 案件綜合分析
     */
    public function getCaseAnalysis(array $branchIds, $year)
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $yearStart = $year . '-01-01';
        $yearEnd   = $year . '-12-31';
        $closedStatuses = array('已成交', '跨月成交', '現簽', '電話報價成交');

        // 取得所有可存取的分公司名稱（即使沒有案件也列出）
        $stmt = $this->db->prepare("SELECT id, name FROM branches WHERE id IN ($ph) ORDER BY id");
        $stmt->execute($branchIds);
        $allBranches = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $allBranches[$row['id']] = $row['name'];
        }

        // 取得該年度所有月份
        $stmt = $this->db->prepare("
            SELECT DISTINCT DATE_FORMAT(created_at, '%Y-%m') AS m
            FROM cases WHERE branch_id IN ($ph) AND created_at BETWEEN ? AND ?
            ORDER BY m
        ");
        $stmt->execute(array_merge($branchIds, array($yearStart, $yearEnd)));
        $months = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $months[] = $row['m'];
        }
        if (empty($months)) {
            return array('year' => $year, 'months' => array());
        }

        // 一次性取出該年度所有案件的關鍵欄位
        $stmt = $this->db->prepare("
            SELECT c.id, DATE_FORMAT(c.created_at, '%Y-%m') AS month,
                   c.sub_status, c.status, c.case_type, c.case_source,
                   c.branch_id,
                   b.name AS branch_name,
                   u.real_name AS sales_name,
                   COALESCE(c.quote_amount, 0) AS quote_amount,
                   COALESCE(c.deal_amount, 0) AS deal_amount,
                   COALESCE(c.total_amount, 0) AS total_amount,
                   COALESCE(c.deposit_amount, 0) AS deposit_amount,
                   COALESCE(c.balance_amount, 0) AS balance_amount,
                   COALESCE(c.completion_amount, 0) AS completion_amount,
                   COALESCE(c.total_collected, 0) AS total_collected
            FROM cases c
            JOIN branches b ON c.branch_id = b.id
            LEFT JOIN users u ON c.sales_id = u.id
            WHERE c.branch_id IN ($ph) AND c.created_at BETWEEN ? AND ?
            ORDER BY c.created_at
        ");
        $stmt->execute(array_merge($branchIds, array($yearStart, $yearEnd)));
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // PHP 端做 pivot 彙整
        $result = array(
            'year' => $year,
            'months' => $months,
            'total_cases' => count($rows),
        );

        // 初始化
        $monthlyEntry = array(); $monthlyClosed = array();
        $monthlyAmounts = array();
        $branchMonthly = array(); $branchMonthlyAmounts = array();
        $statusMonthly = array();
        $progressMonthly = array(); $sourceMonthly = array();
        $salesCases = array(); $salesAmount = array(); $salesClosed = array();
        $salesStats = array();

        // 預填所有分公司，確保即使沒案件也會出現
        foreach ($allBranches as $bid => $bname) {
            $branchMonthly[$bname] = array();
            $branchMonthlyAmounts[$bname] = array();
        }

        foreach ($rows as $r) {
            $m = $r['month'];
            $isClosed = in_array($r['sub_status'], $closedStatuses);

            // 1. 月度進件/成交
            if (!isset($monthlyEntry[$m])) $monthlyEntry[$m] = 0;
            $monthlyEntry[$m]++;
            if ($isClosed) {
                if (!isset($monthlyClosed[$m])) $monthlyClosed[$m] = 0;
                $monthlyClosed[$m]++;
            }

            // 2. 金額
            if (!isset($monthlyAmounts[$m])) {
                $monthlyAmounts[$m] = array('total_amount' => 0, 'quote_amount' => 0, 'deposit_amount' => 0, 'completion_amount' => 0, 'balance_amount' => 0, 'total_collected' => 0);
            }
            if ($isClosed) $monthlyAmounts[$m]['total_amount'] += $r['total_amount'];
            $monthlyAmounts[$m]['quote_amount'] += $r['quote_amount'];
            $monthlyAmounts[$m]['deposit_amount'] += $r['deposit_amount'];
            $monthlyAmounts[$m]['completion_amount'] += $r['completion_amount'];
            $monthlyAmounts[$m]['balance_amount'] += $r['balance_amount'];
            $monthlyAmounts[$m]['total_collected'] += $r['total_collected'];

            // 3. 分公司進件數
            $bn = $r['branch_name'] ?: '(未設定)';
            if (!isset($branchMonthly[$bn])) $branchMonthly[$bn] = array();
            if (!isset($branchMonthly[$bn][$m])) $branchMonthly[$bn][$m] = 0;
            $branchMonthly[$bn][$m]++;

            // 3b. 分公司成交金額
            if ($isClosed && $r['total_amount'] > 0) {
                if (!isset($branchMonthlyAmounts[$bn])) $branchMonthlyAmounts[$bn] = array();
                if (!isset($branchMonthlyAmounts[$bn][$m])) $branchMonthlyAmounts[$bn][$m] = 0;
                $branchMonthlyAmounts[$bn][$m] += $r['total_amount'];
            }

            // 4. 狀態(sub_status)
            $ss = $r['sub_status'] ?: '(空)';
            if (!isset($statusMonthly[$ss])) $statusMonthly[$ss] = array();
            if (!isset($statusMonthly[$ss][$m])) $statusMonthly[$ss][$m] = 0;
            $statusMonthly[$ss][$m]++;

            // 5. 進度(status/progress)
            $pg = $r['status'] ?: '(空)';
            if (!isset($progressMonthly[$pg])) $progressMonthly[$pg] = array();
            if (!isset($progressMonthly[$pg][$m])) $progressMonthly[$pg][$m] = 0;
            $progressMonthly[$pg][$m]++;

            // 6. 來源（轉換為中文標籤）
            $srcRaw = $r['case_source'] ?: '';
            $src = $this->getSourceLabel($srcRaw);
            if (!isset($sourceMonthly[$src])) $sourceMonthly[$src] = array();
            if (!isset($sourceMonthly[$src][$m])) $sourceMonthly[$src][$m] = 0;
            $sourceMonthly[$src][$m]++;

            // 7-9. 業務
            $sn = $r['sales_name'] ?: '(未指定)';
            if (!isset($salesCases[$sn])) $salesCases[$sn] = array();
            if (!isset($salesCases[$sn][$m])) $salesCases[$sn][$m] = 0;
            $salesCases[$sn][$m]++;

            if ($isClosed && $r['total_amount'] > 0) {
                if (!isset($salesAmount[$sn])) $salesAmount[$sn] = array();
                if (!isset($salesAmount[$sn][$m])) $salesAmount[$sn][$m] = 0;
                $salesAmount[$sn][$m] += $r['total_amount'];
            }
            if ($isClosed) {
                if (!isset($salesClosed[$sn])) $salesClosed[$sn] = array();
                if (!isset($salesClosed[$sn][$m])) $salesClosed[$sn][$m] = 0;
                $salesClosed[$sn][$m]++;
            }

            // 10. 業務績效
            if (!isset($salesStats[$sn])) {
                $salesStats[$sn] = array('total' => 0, 'closed' => 0, 'amount' => 0, 'branch' => $r['branch_name']);
            }
            $salesStats[$sn]['total']++;
            if ($isClosed) {
                $salesStats[$sn]['closed']++;
                $salesStats[$sn]['amount'] += $r['total_amount'];
            }
        }

        // 排序 pivots by total desc
        $sortByTotal = function ($a, $b) use ($months) {
            $ta = 0; $tb = 0;
            foreach ($months as $m) { $ta += isset($a[$m]) ? $a[$m] : 0; $tb += isset($b[$m]) ? $b[$m] : 0; }
            return $tb - $ta;
        };
        uasort($branchMonthly, $sortByTotal);
        uasort($branchMonthlyAmounts, $sortByTotal);
        uasort($statusMonthly, $sortByTotal);
        uasort($progressMonthly, $sortByTotal);
        uasort($sourceMonthly, $sortByTotal);
        uasort($salesCases, $sortByTotal);
        uasort($salesAmount, $sortByTotal);
        uasort($salesClosed, $sortByTotal);

        // 業務排名(按金額降序)
        uasort($salesStats, function ($a, $b) { return $b['amount'] - $a['amount']; });

        $result['monthly_entry'] = $monthlyEntry;
        $result['monthly_closed'] = $monthlyClosed;
        $result['monthly_amounts'] = $monthlyAmounts;
        $result['branch_monthly'] = $branchMonthly;
        $result['branch_monthly_amounts'] = $branchMonthlyAmounts;
        $result['status_monthly'] = $statusMonthly;
        $result['progress_monthly'] = $progressMonthly;
        $result['source_monthly'] = $sourceMonthly;
        $result['sales_cases'] = $salesCases;
        $result['sales_amount'] = $salesAmount;
        $result['sales_closed'] = $salesClosed;
        $result['sales_ranking'] = $salesStats;

        // 十一、業務各月收款金額（從收款單 receipts 取）
        $receiptSql = "
            SELECT u.real_name AS sales_name,
                   DATE_FORMAT(r.deposit_date, '%Y-%m') AS month,
                   SUM(r.subtotal) AS amt,
                   COUNT(*) AS cnt
            FROM receipts r
            LEFT JOIN users u ON r.sales_id = u.id
            WHERE r.deposit_date BETWEEN ? AND ?
              AND r.status = '已收款'
            GROUP BY u.real_name, DATE_FORMAT(r.deposit_date, '%Y-%m')
            ORDER BY u.real_name, month
        ";
        $stmt = $this->db->prepare($receiptSql);
        $stmt->execute(array($yearStart, $yearEnd));
        $receiptRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $salesReceipt = array();
        $salesReceiptCount = array();
        foreach ($receiptRows as $rr) {
            $sn = $rr['sales_name'] ?: '(未指定)';
            $m = $rr['month'];
            if (!isset($salesReceipt[$sn])) $salesReceipt[$sn] = array();
            $salesReceipt[$sn][$m] = (int)$rr['amt'];
            if (!isset($salesReceiptCount[$sn])) $salesReceiptCount[$sn] = array();
            $salesReceiptCount[$sn][$m] = (int)$rr['cnt'];
        }
        uasort($salesReceipt, $sortByTotal);
        uasort($salesReceiptCount, $sortByTotal);

        $result['sales_receipt'] = $salesReceipt;
        $result['sales_receipt_count'] = $salesReceiptCount;

        return $result;
    }

    /**
     * 案件來源英文代碼轉中文
     */
    private function getSourceLabel($src)
    {
        static $map = null;
        if ($map === null) {
            $map = array(
                // CaseModel::caseSourceOptions() 的 key
                'phone'        => '電話',
                'headquarters' => '總公司',
                'sales_dev'    => '業務開發',
                'referral'     => '老客戶介紹',
                'internet'     => '網路',
                'builder'      => '建商配合',
                'cross_biz'    => '異業合作',
                'other'        => '其他',
                // 舊系統匯入的代碼
                'existing'     => '老客戶',
                'hq'           => '總公司',
                'line'         => 'LINE',
                'website'      => '網站',
                'private'      => '自行開發',
                'store'        => '門市',
                'facebook'     => 'Facebook',
                'email'        => 'Email',
            );
        }
        if (empty($src)) return '(未設定)';
        return isset($map[$src]) ? $map[$src] : $src;
    }

    /**
     * 案件狀態彙總
     */
    public function getCaseStatusSummary(array $branchIds, $year = null): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $params = $branchIds;
        $dateFilter = '';
        if ($year) {
            $dateFilter = ' AND created_at BETWEEN ? AND ?';
            $params[] = $year . '-01-01';
            $params[] = $year . '-12-31';
        }
        $stmt = $this->db->prepare("
            SELECT status, COUNT(*) AS cnt
            FROM cases
            WHERE branch_id IN ($ph){$dateFilter}
            GROUP BY status
            ORDER BY FIELD(status, 'pending','ready','scheduled','in_progress','completed','cancelled')
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getCaseStatusSummaryByMonth(array $branchIds, $yearMonth)
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $params = $branchIds;
        $params[] = $yearMonth . '-01';
        $params[] = date('Y-m-t', strtotime($yearMonth . '-01'));
        $stmt = $this->db->prepare("
            SELECT status, COUNT(*) AS cnt
            FROM cases
            WHERE branch_id IN ($ph) AND created_at BETWEEN ? AND ?
            GROUP BY status
            ORDER BY FIELD(status, 'pending','ready','scheduled','in_progress','completed','cancelled')
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 帳務綜合分析（對應 Google Sheets 帳務分析腳本）
     */
    public function getFinanceAnalysis($year)
    {
        $yearStart = $year . '-01-01';
        $yearEnd   = $year . '-12-31';
        $branches = array('潭子分公司','員林分公司','清水分公司','東區電子鎖','清水電子鎖','中區專案部','中區管理處');

        // ── 收款單（已入帳）──
        $stmt = $this->db->prepare("
            SELECT r.deposit_date, r.total_amount, b.name AS branch_name
            FROM receipts r
            LEFT JOIN branches b ON r.branch_id = b.id
            WHERE r.status IN ('已收款','已入帳','已收待查資料','預收待查')
              AND r.deposit_date BETWEEN ? AND ?
            ORDER BY r.deposit_date
        ");
        $stmt->execute(array($yearStart, $yearEnd));
        $recvRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // ── 付款單 + 分公司拆帳 ──
        $stmt = $this->db->prepare("
            SELECT po.payment_date, po.total_amount AS po_total,
                   pob.amount AS branch_amount, b.name AS branch_name
            FROM payments_out po
            LEFT JOIN payment_out_branches pob ON pob.payment_out_id = po.id
            LEFT JOIN branches b ON pob.branch_id = b.id
            WHERE po.payment_date BETWEEN ? AND ?
            ORDER BY po.payment_date
        ");
        $stmt->execute(array($yearStart, $yearEnd));
        $payRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // ── 現金明細 ──
        $stmt = $this->db->prepare("
            SELECT cd.transaction_date, cd.income_amount, cd.expense_amount, b.name AS branch_name
            FROM cash_details cd
            LEFT JOIN branches b ON cd.branch_id = b.id
            WHERE cd.transaction_date BETWEEN ? AND ?
            ORDER BY cd.transaction_date
        ");
        $stmt->execute(array($yearStart, $yearEnd));
        $cashRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // ── 銀行帳戶最新餘額 ──
        // 動態取得所有銀行帳戶的最新餘額
        $stmt = $this->db->query("SELECT DISTINCT bank_account FROM bank_transactions WHERE bank_account IS NOT NULL ORDER BY bank_account");
        $bankAccounts = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $bankLatest = array();
        foreach ($bankAccounts as $acct) {
            // 最新餘額
            $stmt = $this->db->prepare("
                SELECT balance FROM bank_transactions
                WHERE bank_account = ?
                ORDER BY transaction_date DESC, id DESC LIMIT 1
            ");
            $stmt->execute(array($acct));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $bal = $row ? (float)$row['balance'] : 0;
            // 轉入轉出合計
            $stmt = $this->db->prepare("
                SELECT COALESCE(SUM(credit_amount),0) AS total_in,
                       COALESCE(SUM(debit_amount),0) AS total_out
                FROM bank_transactions WHERE bank_account = ?
            ");
            $stmt->execute(array($acct));
            $io = $stmt->fetch(PDO::FETCH_ASSOC);
            // 簡化名稱
            $shortName = $acct;
            if (strpos($acct, '中國信託') !== false && strpos($acct, '政遠') === false) $shortName = '中國信託';
            elseif (strpos($acct, '彰化銀行') !== false) $shortName = '彰化銀行';
            elseif (strpos($acct, '富邦') !== false) $shortName = '富邦銀行';
            elseif (strpos($acct, '政遠') !== false) $shortName = '政遠企業';
            $bankLatest[] = array(
                'name' => $shortName,
                'balance' => $bal,
                'total_in' => (float)$io['total_in'],
                'total_out' => (float)$io['total_out'],
            );
        }
        $bankTotal = 0;
        foreach ($bankLatest as $bl) { $bankTotal += $bl['balance']; }

        // ── 零用金餘額（各分公司）──
        $pettyBranches = array(
            1 => '潭子分公司', 3 => '員林分公司', 2 => '清水分公司', 4 => '東區電子鎖'
        );
        $pettyBalance = array();
        $pettyTotal = 0;
        foreach ($pettyBranches as $bid => $bname) {
            $stmt = $this->db->prepare("
                SELECT COALESCE(SUM(income_amount),0) AS inc,
                       COALESCE(SUM(expense_amount),0) AS exp
                FROM petty_cash WHERE branch_id = ?
            ");
            $stmt->execute(array($bid));
            $r = $stmt->fetch(PDO::FETCH_ASSOC);
            $net = (float)$r['inc'] - (float)$r['exp'];
            $pettyBalance[] = array('branch' => $bname, 'income' => (float)$r['inc'], 'expense' => (float)$r['exp'], 'net' => $net);
            $pettyTotal += $net;
        }

        // ── 備用金 ──
        $stmt = $this->db->query("SELECT COALESCE(SUM(income_amount),0) AS inc, COALESCE(SUM(expense_amount),0) AS exp FROM reserve_fund");
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        $reserveIn = (float)$r['inc'];
        $reserveOut = (float)$r['exp'];
        $reserveNet = $reserveIn - $reserveOut;

        // ── 現金淨額 ──
        $stmt = $this->db->query("SELECT COALESCE(SUM(income_amount),0) AS inc, COALESCE(SUM(expense_amount),0) AS exp FROM cash_details");
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        $cashIn = (float)$r['inc'];
        $cashOut = (float)$r['exp'];
        $cashNet = $cashIn - $cashOut;

        // 週轉金
        $weeklyFund = 4517368;

        $grandTotal = $bankTotal + $weeklyFund + $pettyTotal + $reserveNet + $cashNet;

        // ── 月份清單 ──
        $monthSet = array();
        foreach ($recvRows as $r) {
            $m = substr($r['deposit_date'], 0, 7);
            $monthSet[$m] = true;
        }
        foreach ($payRows as $r) {
            if (!empty($r['payment_date'])) {
                $m = substr($r['payment_date'], 0, 7);
                $monthSet[$m] = true;
            }
        }
        $months = array_keys($monthSet);
        sort($months);

        // ── 收款 pivot: branch × month ──
        $recvPivot = array();
        foreach ($recvRows as $r) {
            $bn = !empty($r['branch_name']) ? $r['branch_name'] : '(未設定)';
            $m = substr($r['deposit_date'], 0, 7);
            if (!isset($recvPivot[$bn])) $recvPivot[$bn] = array();
            if (!isset($recvPivot[$bn][$m])) $recvPivot[$bn][$m] = 0;
            $recvPivot[$bn][$m] += (float)$r['total_amount'];
        }

        // ── 付款 pivot: branch × month ──
        $payPivot = array();
        foreach ($payRows as $r) {
            if (empty($r['payment_date'])) continue;
            $bn = !empty($r['branch_name']) ? $r['branch_name'] : '(未設定)';
            $m = substr($r['payment_date'], 0, 7);
            $amt = (float)$r['branch_amount'];
            if (!isset($payPivot[$bn])) $payPivot[$bn] = array();
            if (!isset($payPivot[$bn][$m])) $payPivot[$bn][$m] = 0;
            $payPivot[$bn][$m] += $amt;
        }

        // ── 現金月別 ──
        $cashMonthly = array();
        foreach ($cashRows as $r) {
            if (empty($r['transaction_date'])) continue;
            $m = substr($r['transaction_date'], 0, 7);
            $bn = !empty($r['branch_name']) ? $r['branch_name'] : '(未設定)';
            if (!isset($cashMonthly[$m])) $cashMonthly[$m] = array();
            if (!isset($cashMonthly[$m][$bn])) $cashMonthly[$m][$bn] = array('in' => 0, 'out' => 0);
            $cashMonthly[$m][$bn]['in'] += (float)$r['income_amount'];
            $cashMonthly[$m][$bn]['out'] += (float)$r['expense_amount'];
        }

        // ── 每日收支差額 ──
        $dailyNet = array();
        foreach ($recvRows as $r) {
            $d = $r['deposit_date'];
            $bn = !empty($r['branch_name']) ? $r['branch_name'] : '(未設定)';
            if (!isset($dailyNet[$d])) $dailyNet[$d] = array('recv' => array(), 'pay' => array(), 'bank' => null, 'weekly_fund' => null);
            if (!isset($dailyNet[$d]['recv'][$bn])) $dailyNet[$d]['recv'][$bn] = 0;
            $dailyNet[$d]['recv'][$bn] += (float)$r['total_amount'];
        }
        foreach ($payRows as $r) {
            if (empty($r['payment_date'])) continue;
            $d = $r['payment_date'];
            $bn = !empty($r['branch_name']) ? $r['branch_name'] : '(未設定)';
            if (!isset($dailyNet[$d])) $dailyNet[$d] = array('recv' => array(), 'pay' => array(), 'bank' => null, 'weekly_fund' => null);
            if (!isset($dailyNet[$d]['pay'][$bn])) $dailyNet[$d]['pay'][$bn] = 0;
            $dailyNet[$d]['pay'][$bn] += (float)$r['branch_amount'];
        }
        // 銀行每日餘額
        $stmt = $this->db->prepare("
            SELECT transaction_date, SUM(balance) AS total_balance
            FROM (
                SELECT transaction_date, bank_account, balance
                FROM bank_transactions
                WHERE transaction_date BETWEEN ? AND ?
                ORDER BY transaction_date, id
            ) sub
            GROUP BY transaction_date
        ");
        $stmt->execute(array($yearStart, $yearEnd));
        while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $d = $r['transaction_date'];
            if (isset($dailyNet[$d])) {
                $dailyNet[$d]['bank'] = (float)$r['total_balance'];
            }
        }
        ksort($dailyNet);

        $recvCount = count($recvRows);
        $payCount = count($payRows);

        return array(
            'year'           => $year,
            'months'         => $months,
            'recv_count'     => $recvCount,
            'pay_count'      => $payCount,
            'grand_total'    => $grandTotal,
            'bank_total'     => $bankTotal,
            'weekly_fund'    => $weeklyFund,
            'petty_total'    => $pettyTotal,
            'reserve_net'    => $reserveNet,
            'cash_net'       => $cashNet,
            'bank_latest'    => $bankLatest,
            'petty_balance'  => $pettyBalance,
            'reserve_in'     => $reserveIn,
            'reserve_out'    => $reserveOut,
            'cash_in'        => $cashIn,
            'cash_out'       => $cashOut,
            'recv_pivot'     => $recvPivot,
            'pay_pivot'      => $payPivot,
            'cash_monthly'   => $cashMonthly,
            'daily_net'      => $dailyNet,
            'branches'       => $branches,
        );
    }

    /**
     * 月度排工統計
     */
    public function getMonthlyScheduleStats(array $branchIds, string $month): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $startDate = $month . '-01';
        $endDate = date('Y-m-t', strtotime($startDate));
        $params = array_merge($branchIds, [$startDate, $endDate]);

        $stmt = $this->db->prepare("
            SELECT s.schedule_date, COUNT(DISTINCT s.id) AS schedule_count,
                   COUNT(DISTINCT se.user_id) AS engineer_count
            FROM schedules s
            JOIN cases c ON s.case_id = c.id
            LEFT JOIN schedule_engineers se ON se.schedule_id = s.id
            WHERE c.branch_id IN ($ph)
              AND s.schedule_date BETWEEN ? AND ?
              AND s.status != 'cancelled'
            GROUP BY s.schedule_date
            ORDER BY s.schedule_date
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
