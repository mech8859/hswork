<?php
/**
 * 下拉選單選項管理 Model
 */
class DropdownModel
{
    /** @var PDO */
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * 取得某分類的所有啟用選項
     */
    public function getOptions($category)
    {
        $stmt = $this->db->prepare(
            'SELECT id, label FROM dropdown_options WHERE category = ? AND is_active = 1 ORDER BY sort_order, label'
        );
        $stmt->execute(array($category));
        return $stmt->fetchAll();
    }

    /**
     * 取得某分類的所有選項（含停用，管理用）
     */
    public function getAllOptions($category)
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM dropdown_options WHERE category = ? ORDER BY sort_order, label'
        );
        $stmt->execute(array($category));
        return $stmt->fetchAll();
    }

    /**
     * 取得所有分類
     */
    public function getCategories()
    {
        return array(
            'customer_demand' => '客戶需求',
            'system_type'     => '系統別',
            'deposit_method'  => '訂金支付方式',
        );
    }

    /**
     * 新增選項
     */
    public function addOption($category, $label)
    {
        $maxSort = $this->db->prepare('SELECT MAX(sort_order) FROM dropdown_options WHERE category = ?');
        $maxSort->execute(array($category));
        $nextSort = (int)$maxSort->fetchColumn() + 1;

        $stmt = $this->db->prepare(
            'INSERT INTO dropdown_options (category, label, sort_order) VALUES (?, ?, ?)'
        );
        $stmt->execute(array($category, $label, $nextSort));
        return (int)$this->db->lastInsertId();
    }

    /**
     * 更新選項
     */
    public function updateOption($id, $label)
    {
        $stmt = $this->db->prepare('UPDATE dropdown_options SET label = ? WHERE id = ?');
        $stmt->execute(array($label, $id));
    }

    /**
     * 停用選項（不刪除，保留歷史資料完整性）
     */
    public function deactivateOption($id)
    {
        $stmt = $this->db->prepare('UPDATE dropdown_options SET is_active = 0 WHERE id = ?');
        $stmt->execute(array($id));
    }

    /**
     * 啟用選項
     */
    public function activateOption($id)
    {
        $stmt = $this->db->prepare('UPDATE dropdown_options SET is_active = 1 WHERE id = ?');
        $stmt->execute(array($id));
    }

    /**
     * 更新排序
     */
    public function updateSortOrder($id, $sortOrder)
    {
        $stmt = $this->db->prepare('UPDATE dropdown_options SET sort_order = ? WHERE id = ?');
        $stmt->execute(array($sortOrder, $id));
    }

    /**
     * 取得單一選項
     */
    public function getById($id)
    {
        $stmt = $this->db->prepare('SELECT * FROM dropdown_options WHERE id = ?');
        $stmt->execute(array($id));
        return $stmt->fetch();
    }

    // ============================================================
    // 單號設定
    // ============================================================

    public function getNumberSequences()
    {
        return $this->db->query('SELECT * FROM number_sequences ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateNumberSequence($id, $data)
    {
        $stmt = $this->db->prepare(
            'UPDATE number_sequences SET prefix = ?, date_format = ?, `separator` = ?, seq_digits = ?, updated_at = NOW() WHERE id = ?'
        );
        $stmt->execute(array(
            $data['prefix'],
            $data['date_format'],
            $data['separator'],
            (int)$data['seq_digits'],
            $id,
        ));
    }
}
