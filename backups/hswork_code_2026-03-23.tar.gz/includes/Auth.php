<?php
/**
 * 認證與權限管理
 */
class Auth
{
    /** 連續失敗幾次鎖定 */
    const MAX_LOGIN_ATTEMPTS = 5;

    /** 鎖定時間（分鐘） */
    const LOCKOUT_MINUTES = 15;

    /**
     * 登入驗證（含鎖定檢查）
     * @return string|true  true=成功, string=錯誤訊息
     */
    public static function attempt(string $username, string $password)
    {
        $db = Database::getInstance();

        // 查詢使用者（含鎖定欄位）
        $stmt = $db->prepare('
            SELECT u.*, b.name AS branch_name, b.code AS branch_code
            FROM users u
            JOIN branches b ON u.branch_id = b.id
            WHERE u.username = ?
            LIMIT 1
        ');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        // 檢查帳號是否被鎖定
        if ($user && !empty($user['locked_until'])) {
            if (strtotime($user['locked_until']) > time()) {
                $remaining = ceil((strtotime($user['locked_until']) - time()) / 60);
                self::recordFailedAttempt($username);
                return "帳號已被鎖定，請於 {$remaining} 分鐘後再試";
            }
            // 鎖定已過期，清除鎖定
            $db->prepare('UPDATE users SET locked_until = NULL, failed_login_count = 0 WHERE id = ?')
               ->execute([$user['id']]);
            $user['locked_until'] = null;
            $user['failed_login_count'] = 0;
        }

        // 帳號不存在或已停用
        if (!$user || !$user['is_active']) {
            self::recordFailedAttempt($username);
            return '帳號或密碼錯誤';
        }

        // 密碼驗證
        if (!password_verify($password, $user['password_hash'])) {
            self::recordFailedAttempt($username);
            $newCount = ($user['failed_login_count'] ?? 0) + 1;

            // 累計失敗次數
            if ($newCount >= self::MAX_LOGIN_ATTEMPTS) {
                // 鎖定帳號
                $lockUntil = date('Y-m-d H:i:s', time() + self::LOCKOUT_MINUTES * 60);
                $db->prepare('UPDATE users SET failed_login_count = ?, locked_until = ? WHERE id = ?')
                   ->execute([$newCount, $lockUntil, $user['id']]);
                return '登入失敗次數過多，帳號已鎖定 ' . self::LOCKOUT_MINUTES . ' 分鐘';
            } else {
                $db->prepare('UPDATE users SET failed_login_count = ? WHERE id = ?')
                   ->execute([$newCount, $user['id']]);
                $remaining = self::MAX_LOGIN_ATTEMPTS - $newCount;
                return "帳號或密碼錯誤（還剩 {$remaining} 次嘗試機會）";
            }
        }

        // 登入成功 - 清除失敗記錄
        $db->prepare('UPDATE users SET last_login_at = NOW(), failed_login_count = 0, locked_until = NULL WHERE id = ?')
           ->execute([$user['id']]);

        // 清除 login_attempts 記錄
        $db->prepare('DELETE FROM login_attempts WHERE username = ?')
           ->execute([$username]);

        // 載入權限
        $appConfig = require __DIR__ . '/../config/app.php';
        $permissions = $appConfig['permissions'][$user['role']] ?? [];

        // 個人權限覆蓋（boss 不受限）
        if ($user['role'] !== 'boss' && !empty($user['custom_permissions'])) {
            $custom = json_decode($user['custom_permissions'], true);
            if (is_array($custom)) {
                $modulePermMap = array(
                    'cases' => array('cases.manage', 'cases.view', 'cases.own', 'cases.assist'),
                    'schedule' => array('schedule.manage', 'schedule.view'),
                    'repairs' => array('repairs.manage', 'repairs.view', 'repairs.own'),
                    'staff' => array('staff.manage', 'staff.view'),
                    'leaves' => array('leaves.manage', 'leaves.view', 'leaves.own'),
                    'inter_branch' => array('inter_branch.manage', 'inter_branch.view'),
                    'reports' => array('reports.view'),
                    'products' => array('products.view', 'products.manage'),
                    'vehicles' => array('vehicles.view', 'vehicles.manage'),
                    'worklog' => array('worklog.manage', 'worklog.view'),
                    'attendance' => array('attendance.view'),
                    'quotations' => array('quotations.manage', 'quotations.view', 'quotations.own'),
                    'customers' => array('customers.manage', 'customers.view', 'customers.own'),
                    'business_calendar' => array('business_calendar.manage', 'business_calendar.view'),
                    'business_tracking' => array('business_tracking.manage', 'business_tracking.view', 'business_tracking.own'),
                    'settings' => array('settings.manage'),
                );
                // 覆蓋模組權限
                foreach ($custom as $module => $value) {
                    if (!isset($modulePermMap[$module])) continue;
                    $allPermsForMod = $modulePermMap[$module];
                    // 先移除該模組所有權限
                    $permissions = array_values(array_diff($permissions, $allPermsForMod));
                    // 如果有指定權限（非 false/off），加入該權限
                    if ($value !== false && $value !== 'off' && is_string($value)) {
                        $permissions[] = $value;
                    }
                    // 相容舊格式：true 表示不覆蓋（保留角色預設）
                    if ($value === true) {
                        $rolePermsForMod = array_intersect($allPermsForMod, $appConfig['permissions'][$user['role']] ?? array());
                        foreach ($rolePermsForMod as $rp) {
                            $permissions[] = $rp;
                        }
                    }
                }
                // 存到 session 供側邊選單用
                Session::set('custom_permissions', $custom);
            }
        }

        // 案件編輯區域權限
        $sectionDefaults = isset($appConfig['case_section_defaults'][$user['role']])
            ? $appConfig['case_section_defaults'][$user['role']]
            : array('basic');
        // boss/manager 給全部
        $isAllPerm = in_array('all', $permissions);
        if ($isAllPerm) {
            $sectionDefaults = array('basic','finance','schedule','attach','site','contacts','skills','delete');
        }
        // 個別覆蓋（boss/manager 不覆蓋，永遠全開）
        if (!$isAllPerm && !empty($user['custom_permissions'])) {
            $custom = is_array($custom) ? $custom : json_decode($user['custom_permissions'], true);
            if (is_array($custom) && isset($custom['case_sections']) && is_array($custom['case_sections'])) {
                $sectionDefaults = $custom['case_sections'];
            }
        }

        // 報表權限
        $reportDefaults = isset($appConfig['report_defaults'][$user['role']])
            ? $appConfig['report_defaults'][$user['role']]
            : array();
        if ($isAllPerm) {
            $reportDefaults = array_keys($appConfig['report_labels']);
        }
        if (!$isAllPerm && !empty($user['custom_permissions'])) {
            $custom = is_array($custom) ? $custom : json_decode($user['custom_permissions'], true);
            if (is_array($custom) && isset($custom['report_access']) && is_array($custom['report_access'])) {
                $reportDefaults = $custom['report_access'];
            }
        }

        // 儲存到 Session
        unset($user['password_hash'], $user['locked_until'], $user['failed_login_count']);
        Session::set('user_id', (int)$user['id']);
        Session::set('user', $user);
        Session::set('permissions', $permissions);
        Session::set('case_sections', $sectionDefaults);
        Session::set('report_access', $reportDefaults);

        // 重新產生 session ID 防止 session fixation
        session_regenerate_id(true);

        return true;
    }

    /**
     * 記錄登入失敗
     */
    private static function recordFailedAttempt(string $username): void
    {
        $db = Database::getInstance();
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $db->prepare('INSERT INTO login_attempts (username, ip_address) VALUES (?, ?)')
           ->execute([$username, $ip]);
    }

    /**
     * 登出
     */
    public static function logout(): void
    {
        Session::destroy();
    }

    /**
     * 確認已登入，否則導向登入頁
     */
    public static function requireLogin(): void
    {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
    }

    /**
     * 確認角色權限
     */
    public static function requireRole(string ...$roles): void
    {
        self::requireLogin();
        $user = Session::getUser();
        if (!in_array($user['role'], $roles)) {
            http_response_code(403);
            require __DIR__ . '/../templates/layouts/403.php';
            exit;
        }
    }

    /**
     * 檢查是否有特定權限
     */
    public static function hasPermission(string $permission): bool
    {
        $permissions = Session::get('permissions', []);
        return in_array('all', $permissions) || in_array($permission, $permissions);
    }

    /**
     * 檢查是否可編輯案件區域
     */
    public static function canEditSection($section)
    {
        // boss/manager 自動有所有區域權限
        $user = Session::getUser();
        if ($user && in_array($user['role'], array('boss', 'manager'))) {
            return true;
        }
        $sections = Session::get('case_sections', array());
        return in_array($section, $sections);
    }

    /**
     * 取得所有可編輯區域
     */
    public static function editableSections()
    {
        // boss/manager 回傳所有區域
        $user = Session::getUser();
        if ($user && in_array($user['role'], array('boss', 'manager'))) {
            $config = require __DIR__ . '/../config/app.php';
            return array_keys($config['case_section_labels'] ?? array());
        }
        return Session::get('case_sections', array());
    }

    /**
     * 檢查是否可存取報表
     */
    public static function canAccessReport($reportKey)
    {
        $reports = Session::get('report_access', array());
        return in_array($reportKey, $reports);
    }

    /**
     * 確認有特定權限
     */
    public static function requirePermission(string $permission): void
    {
        self::requireLogin();
        if (!self::hasPermission($permission)) {
            http_response_code(403);
            require __DIR__ . '/../templates/layouts/403.php';
            exit;
        }
    }

    /**
     * 取得目前使用者可查看的據點ID清單
     */
    public static function getAccessibleBranchIds(): array
    {
        $user = Session::getUser();
        if (!$user) return [];

        // boss/manager 或勾選全區 → 全部分公司
        if ($user['can_view_all_branches'] || in_array($user['role'], array('boss', 'manager'))) {
            $db = Database::getInstance();
            $stmt = $db->query('SELECT id FROM branches WHERE is_active = 1');
            return array_column($stmt->fetchAll(), 'id');
        }

        // 有指定可查看分公司
        $viewable = array();
        if (!empty($user['viewable_branches'])) {
            $decoded = is_array($user['viewable_branches']) ? $user['viewable_branches'] : json_decode($user['viewable_branches'], true);
            if (is_array($decoded)) {
                $viewable = array_map('intval', $decoded);
            }
        }

        // 確保包含自己的分公司
        $ownBranch = (int)$user['branch_id'];
        if (!in_array($ownBranch, $viewable)) {
            $viewable[] = $ownBranch;
        }

        return $viewable;
    }

    /**
     * 目前使用者
     */
    public static function user(): ?array
    {
        return Session::getUser();
    }

    /**
     * 目前使用者ID
     */
    public static function id(): ?int
    {
        return Session::getUserId();
    }
}
