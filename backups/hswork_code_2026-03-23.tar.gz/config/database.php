<?php
/**
 * 資料庫設定
 * 部署時請修改為實際的資料庫連線資訊
 */
return [
    'host'     => 'localhost',
    'port'     => '3306',
    'dbname'   => 'vhost158992',
    'username' => 'vhost158992',
    'password' => 'Kss9227456',
    'charset'  => 'utf8mb4',
    'options'  => [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ],
];
