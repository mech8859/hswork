<?php
/**
 * 一次性修復：將 case_type = 'other' 改為空字串
 */
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();

$db = Database::getInstance();

// 統計筆數
$stmt = $db->prepare("SELECT COUNT(*) FROM cases WHERE case_type = 'other'");
$stmt->execute();
$count = $stmt->fetchColumn();

echo "<h2>修復 case_type = 'other'</h2>";
echo "<p>找到 <strong>{$count}</strong> 筆 case_type = 'other' 的案件</p>";

if ($count > 0) {
    $update = $db->prepare("UPDATE cases SET case_type = '' WHERE case_type = 'other'");
    $update->execute();
    $affected = $update->rowCount();
    echo "<p style='color:green;'>已更新 <strong>{$affected}</strong> 筆案件，case_type 改為空字串。</p>";
} else {
    echo "<p>無需修復。</p>";
}

echo "<p><a href='/cases.php'>返回案件管理</a></p>";
