<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
$db = Database::getInstance();
$success = array();
$errors = array();

$cols = array(
    'tax_free' => "ALTER TABLE quotations ADD COLUMN tax_free TINYINT(1) NOT NULL DEFAULT 0 COMMENT '未稅不開發票' AFTER hide_model_on_print",
    'has_discount' => "ALTER TABLE quotations ADD COLUMN has_discount TINYINT(1) NOT NULL DEFAULT 0 COMMENT '有優惠價' AFTER tax_free",
    'discount_amount' => "ALTER TABLE quotations ADD COLUMN discount_amount DECIMAL(12,0) DEFAULT NULL COMMENT '優惠價金額' AFTER has_discount",
);

foreach ($cols as $col => $sql) {
    try {
        $db->exec($sql);
        $success[] = "$col 欄位已新增";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            $success[] = "$col 已存在，跳過";
        } else {
            $errors[] = "$col 失敗: " . $e->getMessage();
        }
    }
}

echo "<h2>Migration 040 - 報價單未稅 + 優惠價</h2>";
if ($success) { echo "<ul>"; foreach ($success as $s) echo "<li style='color:green'>$s</li>"; echo "</ul>"; }
if ($errors) { echo "<ul>"; foreach ($errors as $e) echo "<li style='color:red'>$e</li>"; echo "</ul>"; }
echo "<p><a href='/quotations.php'>← 報價管理</a></p>";
