<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requirePermission('settings.manage');
require_once __DIR__ . '/../modules/settings/DropdownModel.php';

$model = new DropdownModel();
$action = isset($_GET['action']) ? $_GET['action'] : 'list';

switch ($action) {
    case 'list':
        $tab = isset($_GET['tab']) ? $_GET['tab'] : 'dropdown';

        if ($tab === 'numbering') {
            $sequences = $model->getNumberSequences();
            $pageTitle = '選單管理 - 單號設定';
            $currentPage = 'dropdown_options';
            require __DIR__ . '/../templates/layouts/header.php';
            require __DIR__ . '/../templates/settings/numbering.php';
            require __DIR__ . '/../templates/layouts/footer.php';
        } else {
            $category = isset($_GET['category']) ? $_GET['category'] : 'customer_demand';
            $categories = $model->getCategories();
            if (!isset($categories[$category])) {
                $category = 'customer_demand';
            }
            $options = $model->getAllOptions($category);
            $pageTitle = '選單管理 - 下拉選項';
            $currentPage = 'dropdown_options';
            require __DIR__ . '/../templates/layouts/header.php';
            require __DIR__ . '/../templates/settings/dropdown_list.php';
            require __DIR__ . '/../templates/layouts/footer.php';
        }
        break;

    case 'add':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/dropdown_options.php');
        }
        if (!verify_csrf()) {
            Session::flash('error', '安全驗證失敗');
            redirect('/dropdown_options.php');
        }
        $category = isset($_POST['category']) ? $_POST['category'] : '';
        $label = isset($_POST['label']) ? trim($_POST['label']) : '';
        if ($category && $label) {
            $model->addOption($category, $label);
            Session::flash('success', '已新增選項');
        }
        redirect('/dropdown_options.php?category=' . urlencode($category));
        break;

    case 'update':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $label = isset($_POST['label']) ? trim($_POST['label']) : '';
        if ($id && $label) {
            $model->updateOption($id, $label);
            json_response(array('success' => true));
        }
        json_response(array('error' => '缺少參數'));
        break;

    case 'toggle':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $active = isset($_POST['active']) ? (int)$_POST['active'] : 0;
        if ($id) {
            if ($active) {
                $model->activateOption($id);
            } else {
                $model->deactivateOption($id);
            }
            json_response(array('success' => true));
        }
        json_response(array('error' => '缺少參數'));
        break;

    case 'save_numbering':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
            Session::flash('error', '安全驗證失敗');
            redirect('/dropdown_options.php?tab=numbering');
        }
        $ids = isset($_POST['seq_id']) ? $_POST['seq_id'] : array();
        $prefixes = isset($_POST['seq_prefix']) ? $_POST['seq_prefix'] : array();
        $dateFormats = isset($_POST['seq_date_format']) ? $_POST['seq_date_format'] : array();
        $separators = isset($_POST['seq_separator']) ? $_POST['seq_separator'] : array();
        $digits = isset($_POST['seq_digits']) ? $_POST['seq_digits'] : array();

        foreach ($ids as $i => $id) {
            $model->updateNumberSequence((int)$id, array(
                'prefix'      => isset($prefixes[$i]) ? $prefixes[$i] : '',
                'date_format' => isset($dateFormats[$i]) ? $dateFormats[$i] : '',
                'separator'   => isset($separators[$i]) ? $separators[$i] : '-',
                'seq_digits'  => isset($digits[$i]) ? (int)$digits[$i] : 3,
            ));
        }
        Session::flash('success', '單號設定已儲存');
        redirect('/dropdown_options.php?tab=numbering');
        break;

    default:
        redirect('/dropdown_options.php');
}
