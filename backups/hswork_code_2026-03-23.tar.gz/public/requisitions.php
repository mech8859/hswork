<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/procurement/ProcurementModel.php';

$model = new ProcurementModel();
$action = !empty($_GET['action']) ? $_GET['action'] : 'list';
$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    case 'list':
        $filters = array(
            'branch_id' => !empty($_GET['branch_id']) ? $_GET['branch_id'] : '',
            'status'    => !empty($_GET['status']) ? $_GET['status'] : '',
            'keyword'   => !empty($_GET['keyword']) ? $_GET['keyword'] : '',
            'date_from' => !empty($_GET['date_from']) ? $_GET['date_from'] : '',
            'date_to'   => !empty($_GET['date_to']) ? $_GET['date_to'] : '',
        );
        $records = $model->getRequisitions($filters);
        $branches = $model->getBranches($branchIds);

        $pageTitle = '請購單';
        $currentPage = 'requisitions';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/requisitions/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'create':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/requisitions.php');
            }

            $userId = Session::getUser()['id'];
            $data = array(
                'requisition_date' => !empty($_POST['requisition_date']) ? $_POST['requisition_date'] : date('Y-m-d'),
                'requester_name'   => !empty($_POST['requester_name']) ? $_POST['requester_name'] : null,
                'branch_id'        => !empty($_POST['branch_id']) ? $_POST['branch_id'] : null,
                'sales_name'       => !empty($_POST['sales_name']) ? $_POST['sales_name'] : null,
                'urgency'          => !empty($_POST['urgency']) ? $_POST['urgency'] : '一般件',
                'case_name'        => !empty($_POST['case_name']) ? $_POST['case_name'] : null,
                'quotation_number' => !empty($_POST['quotation_number']) ? $_POST['quotation_number'] : null,
                'vendor_name'      => !empty($_POST['vendor_name']) ? $_POST['vendor_name'] : null,
                'expected_date'    => !empty($_POST['expected_date']) ? $_POST['expected_date'] : null,
                'status'           => !empty($_POST['status']) ? $_POST['status'] : '簽核中',
                'approval_user'    => !empty($_POST['approval_user']) ? $_POST['approval_user'] : null,
                'approval_date'    => !empty($_POST['approval_date']) ? $_POST['approval_date'] : null,
                'approval_note'    => !empty($_POST['approval_note']) ? $_POST['approval_note'] : null,
                'note'             => !empty($_POST['note']) ? $_POST['note'] : null,
                'created_by'       => $userId,
            );

            $reqId = $model->createRequisition($data);

            if (!empty($_POST['items'])) {
                $model->saveRequisitionItems($reqId, $_POST['items']);
            }

            Session::flash('success', '請購單已新增');
            redirect('/requisitions.php?action=edit&id=' . $reqId);
        }

        $record = null;
        $items = array();
        $branches = $model->getBranches($branchIds);

        $pageTitle = '新增請購單';
        $currentPage = 'requisitions';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/requisitions/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'edit':
        $id = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
        $record = $model->getRequisition($id);
        if (!$record) {
            Session::flash('error', '請購單不存在');
            redirect('/requisitions.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/requisitions.php?action=edit&id=' . $id);
            }

            $userId = Session::getUser()['id'];
            $data = array(
                'requisition_date' => !empty($_POST['requisition_date']) ? $_POST['requisition_date'] : date('Y-m-d'),
                'requester_name'   => !empty($_POST['requester_name']) ? $_POST['requester_name'] : null,
                'branch_id'        => !empty($_POST['branch_id']) ? $_POST['branch_id'] : null,
                'sales_name'       => !empty($_POST['sales_name']) ? $_POST['sales_name'] : null,
                'urgency'          => !empty($_POST['urgency']) ? $_POST['urgency'] : '一般件',
                'case_name'        => !empty($_POST['case_name']) ? $_POST['case_name'] : null,
                'quotation_number' => !empty($_POST['quotation_number']) ? $_POST['quotation_number'] : null,
                'vendor_name'      => !empty($_POST['vendor_name']) ? $_POST['vendor_name'] : null,
                'expected_date'    => !empty($_POST['expected_date']) ? $_POST['expected_date'] : null,
                'status'           => !empty($_POST['status']) ? $_POST['status'] : '簽核中',
                'approval_user'    => !empty($_POST['approval_user']) ? $_POST['approval_user'] : null,
                'approval_date'    => !empty($_POST['approval_date']) ? $_POST['approval_date'] : null,
                'approval_note'    => !empty($_POST['approval_note']) ? $_POST['approval_note'] : null,
                'note'             => !empty($_POST['note']) ? $_POST['note'] : null,
                'updated_by'       => $userId,
            );

            $model->updateRequisition($id, $data);

            if (isset($_POST['items'])) {
                $model->saveRequisitionItems($id, $_POST['items']);
            }

            Session::flash('success', '請購單已更新');
            redirect('/requisitions.php?action=edit&id=' . $id);
        }

        $items = $model->getRequisitionItems($record['id']);
        $branches = $model->getBranches($branchIds);

        $pageTitle = '編輯請購單 - ' . $record['requisition_number'];
        $currentPage = 'requisitions';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/requisitions/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'delete':
        $id = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
        if ($id > 0) {
            $model->deleteRequisition($id);
            Session::flash('success', '請購單已刪除');
        }
        redirect('/requisitions.php');
        break;

    default:
        redirect('/requisitions.php');
        break;
}
