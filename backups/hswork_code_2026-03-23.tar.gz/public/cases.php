<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/cases/CaseModel.php';

$model = new CaseModel();
$action = $_GET['action'] ?? 'list';
$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    // ---- 案件清單 ----
    case 'list':
        $filters = [
            'status'     => $_GET['status'] ?? '',
            'case_type'  => $_GET['case_type'] ?? '',
            'sub_status' => $_GET['sub_status'] ?? '',
            'keyword'    => $_GET['keyword'] ?? '',
            'branch_id'  => $_GET['branch_id'] ?? '',
            'sales_id'   => $_GET['sales_id'] ?? '',
        ];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = $model->getList($branchIds, $filters, $page);
        $branches = $model->getAllBranches();
        $salesUsers = $model->getSalesUsers($branchIds);

        $pageTitle = '案件管理';
        $currentPage = 'cases';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/cases/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 新增案件 ----
    case 'create':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/cases.php');
            }
            $caseId = $model->create($_POST);
            AuditLog::log('cases', 'create', $caseId, ($_POST['title'] ?? ''));
            $model->updateReadiness($caseId, $_POST);
            $model->updateSiteConditions($caseId, $_POST);
            if (!empty($_POST['contacts'])) {
                $model->saveContacts($caseId, $_POST['contacts']);
            }
            if (!empty($_POST['required_skills'])) {
                $model->saveRequiredSkills($caseId, $_POST['required_skills']);
            }
            Session::flash('success', '案件已新增');
            redirect('/cases.php?action=view&id=' . $caseId);
        }

        $case = null;
        $branches = $model->getAllBranches();
        $skills = $model->getAllSkills();
        $salesUsers = $model->getSalesUsers($branchIds);
        $customerDemandOptions = $model->getDropdownOptions('customer_demand');
        $systemTypeOptions = $model->getDropdownOptions('system_type');
        $depositMethodOptions = $model->getDropdownOptions('deposit_method');

        $pageTitle = '新增案件';
        $currentPage = 'cases';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/cases/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 編輯案件 ----
    case 'edit':
        $id = (int)($_GET['id'] ?? 0);
        $case = $model->getById($id);
        if (!$case) {
            Session::flash('error', '案件不存在');
            redirect('/cases.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/cases.php?action=edit&id=' . $id);
            }
            try {
                // 依區域權限過濾可更新欄位
                $data = $_POST;
                $basicFields = array('title','branch_id','case_type','status','sub_status','description','system_type','address','sales_id','difficulty','estimated_hours','total_visits','max_engineers','notes','ragic_id');
                $financeFields = array('quote_amount','deal_amount','is_tax_included','tax_amount','total_amount','deposit_amount','deposit_method','deposit_payment_date','balance_amount','completion_amount','total_collected');
                $scheduleFields = array('planned_start_date','planned_end_date','urgency','work_time_start','work_time_end','customer_break_time','has_time_restriction','allow_night_work','is_flexible','is_large_project');

                if (!Auth::canEditSection('basic')) {
                    foreach ($basicFields as $f) { unset($data[$f]); }
                }
                if (!Auth::canEditSection('finance')) {
                    foreach ($financeFields as $f) { unset($data[$f]); }
                }
                if (!Auth::canEditSection('schedule')) {
                    foreach ($scheduleFields as $f) { unset($data[$f]); }
                }

                // 記錄變更
                $oldCase = $model->getById($id);
                $model->update($id, $data);
                if ($oldCase) {
                    AuditLog::logChange('cases', $id, $oldCase['case_number'] . ' ' . $oldCase['title'], $oldCase, $data);
                }
                if (Auth::canEditSection('finance') || Auth::canEditSection('attach')) {
                    $model->updateReadiness($id, $data);
                }
                if (Auth::canEditSection('site')) {
                    $model->updateSiteConditions($id, $data);
                }
                if (isset($data['contacts']) && Auth::canEditSection('contacts')) {
                    $model->saveContacts($id, $data['contacts']);
                }
                if (isset($data['required_skills']) && Auth::canEditSection('skills')) {
                    $model->saveRequiredSkills($id, $data['required_skills']);
                }
                Session::flash('success', '案件已更新');
                redirect('/cases.php?action=view&id=' . $id);
            } catch (Exception $ex) {
                Session::flash('error', '更新失敗: ' . $ex->getMessage());
                redirect('/cases.php?action=edit&id=' . $id);
            }
        }

        $branches = $model->getAllBranches();
        $skills = $model->getAllSkills();
        $salesUsers = $model->getSalesUsers($branchIds);
        $customerDemandOptions = $model->getDropdownOptions('customer_demand');
        $systemTypeOptions = $model->getDropdownOptions('system_type');
        $depositMethodOptions = $model->getDropdownOptions('deposit_method');

        // 施工回報資料
        $worklogTimeline = array();
        if ($case) {
            require_once __DIR__ . '/../modules/schedule/WorklogModel.php';
            $wlModel = new WorklogModel();
            $worklogTimeline = $wlModel->getCaseTimeline($case['id']);
        }

        $pageTitle = '編輯案件';
        $currentPage = 'cases';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/cases/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 案件詳情 ----
    case 'view':
        // 直接導向編輯頁面（一頁式）
        redirect('/cases.php?action=edit&id=' . (int)($_GET['id'] ?? 0));
        break;

    // ---- 刪除案件 ----
    case 'delete':
        if (!Auth::canEditSection('delete')) {
            Session::flash('error', '權限不足，無法刪除案件');
            redirect('/cases.php');
        }
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
            Session::flash('error', '安全驗證失敗');
            redirect('/cases.php');
        }
        $id = (int)($_POST['id'] ?? 0);
        $case = $model->getById($id);
        if (!$case) {
            Session::flash('error', '案件不存在');
            redirect('/cases.php');
        }
        AuditLog::log('cases', 'delete', $id, $case['case_number'] . ' ' . $case['title']);
        $model->deleteCase($id);
        Session::flash('success', '案件 ' . $case['case_number'] . ' 已刪除');
        redirect('/cases.php');
        break;

    // ---- 上傳附件 (AJAX) ----
    case 'upload_attachment':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $caseId = (int)($_GET['id'] ?? $_POST['case_id'] ?? 0);
        $fileType = $_POST['file_type'] ?? 'other';
        if (!$caseId || empty($_FILES['file'])) {
            json_response(array('error' => '缺少參數'));
        }
        $file = $_FILES['file'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            json_response(array('error' => '上傳失敗'));
        }
        if ($file['size'] > 20 * 1024 * 1024) {
            json_response(array('error' => '檔案過大（上限20MB）'));
        }

        $uploadDir = __DIR__ . '/uploads/cases/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $newName = $caseId . '_' . $fileType . '_' . time() . '.' . $ext;
        $dest = $uploadDir . $newName;
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            $attId = $model->saveAttachment($caseId, $fileType, $file['name'], '/uploads/cases/' . $newName);
            json_response(array('success' => true, 'id' => $attId, 'file_name' => $file['name'], 'file_path' => '/uploads/cases/' . $newName, 'file_type' => $fileType));
        } else {
            json_response(array('error' => '儲存失敗'));
        }
        break;

    // ---- 刪除附件 (AJAX) ----
    case 'delete_attachment':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $attId = (int)($_POST['attachment_id'] ?? 0);
        if (!$attId) {
            json_response(array('error' => '缺少 attachment_id'));
        }
        $model->deleteAttachment($attId);
        json_response(array('success' => true));
        break;

    // ---- 新增帳款交易 (AJAX) ----
    case 'add_payment':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $caseId = (int)($_POST['case_id'] ?? 0);
        if (!$caseId) { json_response(array('error' => '缺少 case_id')); }

        $db = Database::getInstance();
        $imagePath = null;

        // 處理圖片上傳
        if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = __DIR__ . '/uploads/case_payments/' . $caseId;
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $newName = date('Ymd_His') . '_' . mt_rand(1000,9999) . '.' . $ext;
            $dest = $uploadDir . '/' . $newName;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                $imagePath = 'uploads/case_payments/' . $caseId . '/' . $newName;
            }
        }

        $stmt = $db->prepare("INSERT INTO case_payments (case_id, payment_date, payment_type, transaction_type, amount, note, image_path, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(array(
            $caseId,
            $_POST['payment_date'] ?? date('Y-m-d'),
            $_POST['payment_type'] ?? null,
            $_POST['transaction_type'] ?? null,
            (int)($_POST['amount'] ?? 0),
            $_POST['note'] ?? null,
            $imagePath,
            Auth::id()
        ));
        json_response(array('success' => true, 'id' => $db->lastInsertId()));
        break;

    // ---- 刪除帳款交易 (AJAX) ----
    case 'delete_payment':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $payId = (int)($_POST['payment_id'] ?? 0);
        if (!$payId) { json_response(array('error' => '缺少 payment_id')); }

        $db = Database::getInstance();
        // 刪除圖片
        $stmt = $db->prepare("SELECT image_path FROM case_payments WHERE id = ?");
        $stmt->execute(array($payId));
        $img = $stmt->fetchColumn();
        if ($img && file_exists(__DIR__ . '/' . $img)) {
            unlink(__DIR__ . '/' . $img);
        }
        $db->prepare("DELETE FROM case_payments WHERE id = ?")->execute(array($payId));
        json_response(array('success' => true));
        break;

    // ---- 新增施工回報 (AJAX) ----
    case 'add_worklog':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        if (!Auth::canEditSection('worklog')) {
            json_response(array('error' => '權限不足'), 403);
        }
        $caseId = (int)($_POST['case_id'] ?? 0);
        if (!$caseId) { json_response(array('error' => '缺少 case_id')); }

        $db = Database::getInstance();

        // 處理照片
        $photoPaths = array();
        if (!empty($_FILES['photos'])) {
            $uploadDir = __DIR__ . '/uploads/case_worklogs/' . $caseId;
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $files = $_FILES['photos'];
            $count = is_array($files['name']) ? count($files['name']) : 0;
            for ($i = 0; $i < $count; $i++) {
                if ($files['error'][$i] !== UPLOAD_ERR_OK) continue;
                $ext = strtolower(pathinfo($files['name'][$i], PATHINFO_EXTENSION));
                if (!in_array($ext, array('jpg','jpeg','png','gif','webp'))) continue;
                $newName = date('Ymd_His') . '_' . mt_rand(1000,9999) . '.' . $ext;
                $dest = $uploadDir . '/' . $newName;
                if (move_uploaded_file($files['tmp_name'][$i], $dest)) {
                    $photoPaths[] = 'uploads/case_worklogs/' . $caseId . '/' . $newName;
                }
            }
        }

        $stmt = $db->prepare("INSERT INTO case_work_logs (case_id, work_date, work_content, equipment_used, cable_used, photo_paths, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(array(
            $caseId,
            $_POST['work_date'] ?? date('Y-m-d'),
            $_POST['work_content'] ?? '',
            $_POST['equipment_used'] ?? null,
            $_POST['cable_used'] ?? null,
            !empty($photoPaths) ? json_encode($photoPaths) : null,
            Auth::id()
        ));
        json_response(array('success' => true, 'id' => $db->lastInsertId()));
        break;

    // ---- 刪除施工回報 (AJAX) ----
    case 'delete_worklog':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        if (!Auth::canEditSection('worklog')) {
            json_response(array('error' => '權限不足'), 403);
        }
        $wlId = (int)($_POST['worklog_id'] ?? 0);
        if (!$wlId) { json_response(array('error' => '缺少 worklog_id')); }

        $db = Database::getInstance();
        $db->prepare("DELETE FROM case_work_logs WHERE id = ?")->execute(array($wlId));
        json_response(array('success' => true));
        break;

    // ---- 客戶搜尋 AJAX ----
    case 'ajax_search_customer':
        require_once __DIR__ . '/../modules/customers/CustomerModel.php';
        $keyword = $_GET['keyword'] ?? '';
        $custModel = new CustomerModel();
        $results = $custModel->search($keyword, 10);
        // 附加聯絡人
        $db = Database::getInstance();
        foreach ($results as &$r) {
            $r['contacts'] = array();
            try {
                $ccStmt = $db->prepare('SELECT contact_name, phone, mobile, role FROM customer_contacts WHERE customer_id = ?');
                $ccStmt->execute(array($r['id']));
                $r['contacts'] = $ccStmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) {}
            // 如果 customer_contacts 表不存在或無資料，用舊欄位
            if (empty($r['contacts']) && !empty($r['contact_person'])) {
                $r['contacts'] = array(array(
                    'contact_name' => $r['contact_person'],
                    'phone' => $r['phone'],
                    'mobile' => $r['mobile'],
                    'role' => '',
                ));
            }
        }
        unset($r);
        header('Content-Type: application/json');
        echo json_encode($results);
        break;

    // ---- 快速新增客戶 AJAX ----
    case 'ajax_create_customer':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_response(array('error' => '無效請求')); break; }
        if (!verify_csrf()) { json_response(array('error' => '安全驗證失敗')); break; }
        require_once __DIR__ . '/../modules/customers/CustomerModel.php';
        $custModel = new CustomerModel();
        $custData = array(
            'name' => $_POST['name'] ?? '',
            'contact_person' => $_POST['contact_person'] ?? '',
            'phone' => $_POST['phone'] ?? '',
            'mobile' => $_POST['mobile'] ?? '',
            'site_address' => $_POST['address'] ?? '',
        );
        if (empty($custData['name'])) {
            json_response(array('error' => '客戶名稱為必填'));
            break;
        }
        $custId = $custModel->create($custData);
        // 建立聯絡人
        if (!empty($custData['contact_person'])) {
            $db = Database::getInstance();
            try {
                $db->prepare('INSERT INTO customer_contacts (customer_id, contact_name, phone, mobile) VALUES (?, ?, ?, ?)')
                    ->execute(array($custId, $custData['contact_person'], $custData['phone'], $custData['mobile']));
            } catch (Exception $e) {}
        }
        $customer = $custModel->getById($custId);
        $customer['contacts'] = array();
        if (!empty($custData['contact_person'])) {
            $customer['contacts'] = array(array(
                'contact_name' => $custData['contact_person'],
                'phone' => $custData['phone'],
                'mobile' => $custData['mobile'],
                'role' => '',
            ));
        }
        json_response(array('success' => true, 'customer' => $customer));
        break;

    default:
        redirect('/cases.php');
}
