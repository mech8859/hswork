<?php
require __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requirePermission('staff.manage');

$db = Database::getInstance();
$action = $_GET['action'] ?? 'list';
$type = $_GET['type'] ?? 'dispatch'; // dispatch or outsource

// ========== 外包廠商 ==========
if ($type === 'vendor') {
    switch ($action) {
        case 'list':
            $vendors = $db->query("SELECT ov.*, (SELECT COUNT(*) FROM dispatch_workers dw WHERE dw.vendor_id = ov.id AND dw.is_active = 1) as worker_count FROM outsource_vendors ov ORDER BY ov.is_active DESC, ov.name")->fetchAll();
            $pageTitle = '外包廠商管理';
            $currentPage = 'staff';
            require __DIR__ . '/../templates/layouts/header.php';
            require __DIR__ . '/../templates/dispatch_workers/vendor_list.php';
            require __DIR__ . '/../templates/layouts/footer.php';
            break;

        case 'create':
        case 'edit':
            $vendor = null;
            if ($action === 'edit') {
                $id = (int)($_GET['id'] ?? 0);
                $stmt = $db->prepare("SELECT * FROM outsource_vendors WHERE id = ?");
                $stmt->execute(array($id));
                $vendor = $stmt->fetch();
                if (!$vendor) { Session::flash('error', '廠商不存在'); redirect('/dispatch_workers.php?type=vendor'); }
            }

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/dispatch_workers.php?type=vendor'); }
                $data = array(
                    trim($_POST['name'] ?? ''),
                    trim($_POST['contact_person'] ?? ''),
                    trim($_POST['phone'] ?? ''),
                    trim($_POST['address'] ?? ''),
                    trim($_POST['tax_id'] ?? ''),
                    trim($_POST['note'] ?? ''),
                    isset($_POST['is_active']) ? 1 : 0,
                );

                if ($action === 'edit') {
                    $db->prepare("UPDATE outsource_vendors SET name=?, contact_person=?, phone=?, address=?, tax_id=?, note=?, is_active=? WHERE id=?")->execute(array_merge($data, array($vendor['id'])));
                    Session::flash('success', '廠商已更新');
                } else {
                    $db->prepare("INSERT INTO outsource_vendors (name, contact_person, phone, address, tax_id, note, is_active) VALUES (?,?,?,?,?,?,?)")->execute($data);
                    Session::flash('success', '廠商已新增');
                }
                redirect('/dispatch_workers.php?type=vendor');
            }

            $pageTitle = $action === 'edit' ? '編輯廠商' : '新增廠商';
            $currentPage = 'staff';
            require __DIR__ . '/../templates/layouts/header.php';
            require __DIR__ . '/../templates/dispatch_workers/vendor_form.php';
            require __DIR__ . '/../templates/layouts/footer.php';
            break;
    }
    exit;
}

// ========== 點工人員 ==========
switch ($action) {
    case 'list':
        $where = "WHERE dw.worker_type = ?";
        $params = array($type === 'outsource' ? 'outsource' : 'dispatch');
        
        $keyword = trim($_GET['keyword'] ?? '');
        if ($keyword) {
            $where .= " AND (dw.name LIKE ? OR dw.phone LIKE ?)";
            $params[] = "%{$keyword}%";
            $params[] = "%{$keyword}%";
        }

        $stmt = $db->prepare("SELECT dw.*, ov.name as vendor_name FROM dispatch_workers dw LEFT JOIN outsource_vendors ov ON dw.vendor_id = ov.id $where ORDER BY dw.is_active DESC, dw.status ASC, dw.name");
        $stmt->execute($params);
        $workers = $stmt->fetchAll();

        $vendors = $db->query("SELECT id, name FROM outsource_vendors WHERE is_active = 1 ORDER BY name")->fetchAll();

        $pageTitle = $type === 'outsource' ? '外包人員管理' : '點工人員管理';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/dispatch_workers/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'create':
    case 'edit':
        $worker = null;
        if ($action === 'edit') {
            $id = (int)($_GET['id'] ?? 0);
            $stmt = $db->prepare("SELECT * FROM dispatch_workers WHERE id = ?");
            $stmt->execute(array($id));
            $worker = $stmt->fetch();
            if (!$worker) { Session::flash('error', '人員不存在'); redirect('/dispatch_workers.php'); }

            // 附件
            $fstmt = $db->prepare("SELECT * FROM dispatch_worker_files WHERE worker_id = ? ORDER BY file_type, created_at");
            $fstmt->execute(array($id));
            $worker['files'] = $fstmt->fetchAll();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/dispatch_workers.php'); }
            
            $wType = $_POST['worker_type'] ?? 'dispatch';
            $data = array(
                $wType,
                trim($_POST['name'] ?? ''),
                trim($_POST['id_number'] ?? ''),
                trim($_POST['phone'] ?? ''),
                trim($_POST['address'] ?? ''),
                !empty($_POST['birth_date']) ? $_POST['birth_date'] : null,
                trim($_POST['specialty'] ?? ''),
                $_POST['status'] ?? 'primary',
                (int)($_POST['daily_rate'] ?? 0),
                trim($_POST['emergency_contact'] ?? ''),
                trim($_POST['emergency_phone'] ?? ''),
                !empty($_POST['vendor_id']) ? (int)$_POST['vendor_id'] : null,
                trim($_POST['note'] ?? ''),
                isset($_POST['is_active']) ? 1 : 0,
            );

            if ($action === 'edit') {
                $db->prepare("UPDATE dispatch_workers SET worker_type=?, name=?, id_number=?, phone=?, address=?, birth_date=?, specialty=?, status=?, daily_rate=?, emergency_contact=?, emergency_phone=?, vendor_id=?, note=?, is_active=? WHERE id=?")->execute(array_merge($data, array($worker['id'])));
                $workerId = $worker['id'];
                Session::flash('success', '人員已更新');
            } else {
                $db->prepare("INSERT INTO dispatch_workers (worker_type, name, id_number, phone, address, birth_date, specialty, status, daily_rate, emergency_contact, emergency_phone, vendor_id, note, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)")->execute($data);
                $workerId = (int)$db->lastInsertId();
                Session::flash('success', '人員已新增');
            }

            // 處理附件上傳
            if (!empty($_FILES['files']['name'][0])) {
                $fileTypes = $_POST['file_types'] ?? array();
                $uploadDir = __DIR__ . '/uploads/dispatch_workers/' . $workerId;
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

                foreach ($_FILES['files']['name'] as $i => $fname) {
                    if ($_FILES['files']['error'][$i] !== UPLOAD_ERR_OK) continue;
                    $safeName = date('Ymd_His') . '_' . mt_rand(1000,9999) . '_' . preg_replace('/[^a-zA-Z0-9._\-]/', '_', $fname);
                    $dest = $uploadDir . '/' . $safeName;
                    if (move_uploaded_file($_FILES['files']['tmp_name'][$i], $dest)) {
                        $relPath = 'uploads/dispatch_workers/' . $workerId . '/' . $safeName;
                        $fType = isset($fileTypes[$i]) ? $fileTypes[$i] : 'other';
                        $db->prepare("INSERT INTO dispatch_worker_files (worker_id, file_type, file_name, file_path, file_size, uploaded_by) VALUES (?,?,?,?,?,?)")->execute(array(
                            $workerId, $fType, $fname, $relPath, filesize($dest), Auth::id()
                        ));
                    }
                }
            }

            redirect('/dispatch_workers.php?action=edit&id=' . $workerId);
        }

        $vendors = $db->query("SELECT id, name FROM outsource_vendors WHERE is_active = 1 ORDER BY name")->fetchAll();

        $pageTitle = $action === 'edit' ? '編輯人員' : '新增人員';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/dispatch_workers/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'delete_file':
        $fileId = (int)($_GET['file_id'] ?? 0);
        $stmt = $db->prepare("SELECT * FROM dispatch_worker_files WHERE id = ?");
        $stmt->execute(array($fileId));
        $file = $stmt->fetch();
        if ($file) {
            @unlink(__DIR__ . '/' . $file['file_path']);
            $db->prepare("DELETE FROM dispatch_worker_files WHERE id = ?")->execute(array($fileId));
        }
        redirect('/dispatch_workers.php?action=edit&id=' . ($file['worker_id'] ?? 0));
        break;
}
