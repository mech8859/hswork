<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/finance/FinanceModel.php';

$model = new FinanceModel();

$filters = array(
    'branch_id' => !empty($_GET['branch_id']) ? $_GET['branch_id'] : '',
    'type'      => !empty($_GET['type']) ? $_GET['type'] : '',
    'keyword'   => !empty($_GET['keyword']) ? $_GET['keyword'] : '',
);
$branchIds = Auth::getAccessibleBranchIds();
$branches = $model->getBranches($branchIds);
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$result = $model->getPettyCashList($filters, $page);
$records = $result['data'];

$pageTitle = '零用金管理';
$currentPage = 'petty_cash';
require __DIR__ . '/../templates/layouts/header.php';
require __DIR__ . '/../templates/petty_cash/list.php';
require __DIR__ . '/../templates/layouts/footer.php';
