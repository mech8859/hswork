<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/finance/FinanceModel.php';

$model = new FinanceModel();

$filters = array(
    'branch_id' => !empty($_GET['branch_id']) ? $_GET['branch_id'] : '',
    'type'      => !empty($_GET['type']) ? $_GET['type'] : '',
);
$branchIds = Auth::getAccessibleBranchIds();
$branches = $model->getBranches($branchIds);
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$result = $model->getReserveFundList($filters, $page);
$records = $result['data'];

$pageTitle = '備用金管理';
$currentPage = 'reserve_fund';
require __DIR__ . '/../templates/layouts/header.php';
require __DIR__ . '/../templates/reserve_fund/list.php';
require __DIR__ . '/../templates/layouts/footer.php';
