<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/inter_branch/InterBranchModel.php';

$model = new InterBranchModel();
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    // ---- 清單 ----
    case 'list':
        Auth::requirePermission('inter_branch.view');
        $filters = array(
            'month'     => isset($_GET['month']) ? $_GET['month'] : date('Y-m'),
            'branch_id' => isset($_GET['branch_id']) ? $_GET['branch_id'] : '',
            'settled'   => isset($_GET['settled']) ? $_GET['settled'] : '',
        );
        $records = $model->getList($branchIds, $filters);
        $branches = $model->getAllBranches();

        $pageTitle = '點工費管理';
        $currentPage = 'inter_branch';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/inter_branch/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 新增 ----
    case 'create':
        Auth::requirePermission('inter_branch.manage');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/inter_branch.php'); }
            $model->create($_POST);
            Session::flash('success', '點工記錄已新增');
            redirect('/inter_branch.php');
        }
        $branches = $model->getAllBranches();
        $engineers = $model->getEngineers();
        $record = null;

        $pageTitle = '新增點工記錄';
        $currentPage = 'inter_branch';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/inter_branch/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 編輯 ----
    case 'edit':
        Auth::requirePermission('inter_branch.manage');
        $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
        $record = $model->getById($id);
        if (!$record) { Session::flash('error', '記錄不存在'); redirect('/inter_branch.php'); }
        if ($record['settled']) { Session::flash('error', '已結算記錄不可編輯'); redirect('/inter_branch.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/inter_branch.php?action=edit&id='.$id); }
            $model->update($id, $_POST);
            Session::flash('success', '點工記錄已更新');
            redirect('/inter_branch.php');
        }
        $branches = $model->getAllBranches();
        $engineers = $model->getEngineers();

        $pageTitle = '編輯點工記錄';
        $currentPage = 'inter_branch';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/inter_branch/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 刪除 ----
    case 'delete':
        Auth::requirePermission('inter_branch.manage');
        if (verify_csrf()) {
            $id = (int)$_GET['id'];
            if ($model->delete($id)) {
                Session::flash('success', '點工記錄已刪除');
            } else {
                Session::flash('error', '無法刪除（已結算）');
            }
        }
        redirect('/inter_branch.php');
        break;

    // ---- 月結 ----
    case 'settle':
        Auth::requirePermission('inter_branch.manage');
        $month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/inter_branch.php?action=settle&month='.$month); }
            $count = $model->settleMonth($month, $branchIds);
            Session::flash('success', "已結算 {$count} 筆記錄");
            redirect('/inter_branch.php?action=settle&month=' . $month);
        }

        $summary = $model->getSettleSummary($month, $branchIds);
        $branches = $model->getAllBranches();

        $pageTitle = '月結確認';
        $currentPage = 'inter_branch';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/inter_branch/settle.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    default:
        redirect('/inter_branch.php');
}
