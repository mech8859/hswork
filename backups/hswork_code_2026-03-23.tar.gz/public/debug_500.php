<?php
/**
 * 500 錯誤診斷（不需登入）
 * 用完請刪除此檔案
 */
ini_set('display_errors', '1');
error_reporting(E_ALL);

echo "<h2>500 Error Diagnostic</h2>";
echo "<hr>";

// Step 1: Bootstrap
try {
    echo "1. Loading bootstrap... ";
    require_once __DIR__ . '/../includes/bootstrap.php';
    echo "<b style='color:green'>OK</b><br>";
} catch (Throwable $e) {
    echo "<b style='color:red'>FAIL: " . $e->getMessage() . "</b><br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
    exit;
}

// Step 2: Database connection
try {
    echo "2. Database connection... ";
    $db = Database::getInstance();
    echo "<b style='color:green'>OK</b><br>";
} catch (Throwable $e) {
    echo "<b style='color:red'>FAIL: " . $e->getMessage() . "</b><br>";
    exit;
}

// Step 3: Check tables exist
$tables = ['branches', 'users', 'cases', 'schedules', 'vehicles', 'login_attempts',
           'user_certifications', 'certifications', 'skills', 'user_skills'];
echo "3. Checking tables:<br>";
foreach ($tables as $t) {
    try {
        $count = $db->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
        echo "&nbsp;&nbsp;&nbsp;$t: <b style='color:green'>OK ($count rows)</b><br>";
    } catch (Throwable $e) {
        echo "&nbsp;&nbsp;&nbsp;$t: <b style='color:red'>MISSING - " . $e->getMessage() . "</b><br>";
    }
}

// Step 4: Check users table columns
echo "4. Checking users columns:<br>";
try {
    $cols = $db->query("SHOW COLUMNS FROM users")->fetchAll();
    foreach ($cols as $col) {
        echo "&nbsp;&nbsp;&nbsp;" . $col['Field'] . " (" . $col['Type'] . ")<br>";
    }
} catch (Throwable $e) {
    echo "<b style='color:red'>FAIL: " . $e->getMessage() . "</b><br>";
}

// Step 5: Test the index.php queries
echo "<hr><h3>5. Testing index.php queries:</h3>";

try {
    echo "5a. Cases query... ";
    $stmt = $db->prepare("SELECT status, COUNT(*) as cnt FROM cases WHERE branch_id IN (?) GROUP BY status");
    $stmt->execute([1]);
    echo "<b style='color:green'>OK</b><br>";
} catch (Throwable $e) {
    echo "<b style='color:red'>FAIL: " . $e->getMessage() . "</b><br>";
}

try {
    echo "5b. Schedules+vehicles query... ";
    $stmt = $db->prepare("
        SELECT s.*, c.title as case_title, c.address, c.case_number,
               v.plate_number, v.vehicle_type
        FROM schedules s
        JOIN cases c ON s.case_id = c.id
        LEFT JOIN vehicles v ON s.vehicle_id = v.id
        WHERE c.branch_id IN (?) AND s.schedule_date = CURDATE()
        ORDER BY s.created_at ASC
        LIMIT 20
    ");
    $stmt->execute([1]);
    echo "<b style='color:green'>OK</b><br>";
} catch (Throwable $e) {
    echo "<b style='color:red'>FAIL: " . $e->getMessage() . "</b><br>";
}

try {
    echo "5c. Certifications query... ";
    $stmt = $db->prepare("
        SELECT uc.expiry_date, u.real_name, cert.name as cert_name
        FROM user_certifications uc
        JOIN users u ON uc.user_id = u.id
        JOIN certifications cert ON uc.certification_id = cert.id
        WHERE u.branch_id IN (?)
          AND uc.expiry_date IS NOT NULL
          AND uc.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
        ORDER BY uc.expiry_date ASC
        LIMIT 10
    ");
    $stmt->execute([1]);
    echo "<b style='color:green'>OK</b><br>";
} catch (Throwable $e) {
    echo "<b style='color:red'>FAIL: " . $e->getMessage() . "</b><br>";
}

// Step 6: Test header/footer templates
echo "<hr><h3>6. Testing templates:</h3>";
try {
    echo "6a. header.php exists: ";
    $headerPath = __DIR__ . '/../templates/layouts/header.php';
    echo file_exists($headerPath) ? "<b style='color:green'>YES</b>" : "<b style='color:red'>NO</b>";
    echo "<br>";

    echo "6b. footer.php exists: ";
    $footerPath = __DIR__ . '/../templates/layouts/footer.php';
    echo file_exists($footerPath) ? "<b style='color:green'>YES</b>" : "<b style='color:red'>NO</b>";
    echo "<br>";
} catch (Throwable $e) {
    echo "<b style='color:red'>FAIL: " . $e->getMessage() . "</b><br>";
}

echo "<hr><h3>7. PHP Info:</h3>";
echo "PHP Version: " . phpversion() . "<br>";
echo "Server: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'unknown') . "<br>";
echo "<br><b style='color:orange'>診斷完成，請刪除此檔案！</b>";
