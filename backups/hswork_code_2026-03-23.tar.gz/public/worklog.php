<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/schedule/WorklogModel.php';

$model = new WorklogModel();
$action = $_GET['action'] ?? 'today';
$userId = Auth::id();

switch ($action) {
    // ---- 今日排工 (手機首頁) ----
    case 'today':
        $todaySchedules = $model->getTodaySchedules($userId);

        // 未完成回報提醒
        $reminders = array();
        $branchIds = Auth::getAccessibleBranchIds();
        if (Auth::hasPermission('schedule.manage')) {
            $reminders = $model->getIncompleteReports($branchIds);
        }

        $pageTitle = '今日施工';
        $currentPage = 'worklog';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/schedule/worklog_today.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 打卡到場 ----
    case 'checkin':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $scheduleId = (int)$_POST['schedule_id'];
            $worklogId = $model->checkIn($scheduleId, $userId);
            Session::flash('success', '已打卡到場');
            redirect('/worklog.php?action=report&id=' . $worklogId);
        }
        redirect('/worklog.php');
        break;

    // ---- 打卡離場 ----
    case 'checkout':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $worklogId = (int)$_POST['worklog_id'];
            $model->checkOut($worklogId);
            Session::flash('success', '已打卡離場');
            redirect('/worklog.php?action=report&id=' . $worklogId);
        }
        redirect('/worklog.php');
        break;

    // ---- 施工回報 ----
    case 'report':
        $id = (int)($_GET['id'] ?? 0);
        $worklog = $model->getWorklog($id);
        if (!$worklog || $worklog['user_id'] != $userId) {
            if (!Auth::hasPermission('schedule.manage')) {
                Session::flash('error', '無權限');
                redirect('/worklog.php');
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $model->saveReport($id, $_POST);
            if (isset($_POST['materials'])) {
                $model->saveMaterials($id, $_POST['materials']);
            }

            // 照片上傳
            if (!empty($_FILES['photos']) && !empty($_FILES['photos']['name'][0])) {
                $uploadDir = __DIR__ . '/uploads/worklogs/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                foreach ($_FILES['photos']['name'] as $idx => $name) {
                    if ($_FILES['photos']['error'][$idx] !== UPLOAD_ERR_OK) continue;
                    if ($_FILES['photos']['size'][$idx] > 10 * 1024 * 1024) continue;

                    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                    if (!in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp'))) continue;

                    $newName = $id . '_' . time() . '_' . $idx . '.' . $ext;
                    $dest = $uploadDir . $newName;
                    if (move_uploaded_file($_FILES['photos']['tmp_name'][$idx], $dest)) {
                        $model->savePhoto($id, '/uploads/worklogs/' . $newName, $_POST['photo_captions'][$idx] ?? null);
                    }
                }
            }

            Session::flash('success', '回報已儲存');
            redirect('/worklog.php?action=report&id=' . $id);
        }

        $pageTitle = '施工回報';
        $currentPage = 'worklog';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/schedule/worklog_report.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 刪除照片 (AJAX) ----
    case 'delete_photo':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $input = json_decode(file_get_contents('php://input'), true);
        $photoId = (int)($input['photo_id'] ?? 0);
        if (!$photoId) {
            json_response(array('error' => '缺少 photo_id'));
        }
        $model->deletePhoto($photoId);
        json_response(array('success' => true));
        break;

    // ---- 歷史記錄（時間軸式）----
    case 'history':
        $history = $model->getHistory($userId);
        $pageTitle = '施工記錄';
        $currentPage = 'worklog';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/schedule/worklog_history.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    default:
        redirect('/worklog.php');
}
