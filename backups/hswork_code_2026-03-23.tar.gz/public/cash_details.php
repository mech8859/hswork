<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/finance/FinanceModel.php';

$model = new FinanceModel();

$filters = array(
    'branch_id' => !empty($_GET['branch_id']) ? $_GET['branch_id'] : '',
    'date_from' => !empty($_GET['date_from']) ? $_GET['date_from'] : '',
    'date_to'   => !empty($_GET['date_to']) ? $_GET['date_to'] : '',
    'keyword'   => !empty($_GET['keyword']) ? $_GET['keyword'] : '',
);
$branchIds = Auth::getAccessibleBranchIds();
$branches = $model->getBranches($branchIds);
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$result = $model->getCashDetails($filters, $page);
$records = $result['data'];

$pageTitle = '現金明細';
$currentPage = 'cash_details';
require __DIR__ . '/../templates/layouts/header.php';
require __DIR__ . '/../templates/cash_details/list.php';
require __DIR__ . '/../templates/layouts/footer.php';
