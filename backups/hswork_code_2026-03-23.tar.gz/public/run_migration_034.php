<?php
require __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
$db = Database::getInstance();

echo '<h2>Migration 034: 可查看分公司多選</h2>';
try {
    $cols = array_column($db->query("SHOW COLUMNS FROM users")->fetchAll(), 'Field');
    if (!in_array('viewable_branches', $cols)) {
        $db->exec("ALTER TABLE users ADD COLUMN viewable_branches TEXT DEFAULT NULL COMMENT 'JSON陣列-可查看的分公司ID'");
        echo '<p style="color:green">✓ users.viewable_branches 已新增</p>';
    } else {
        echo '<p>已存在</p>';
    }
} catch (Exception $e) {
    echo '<p style="color:red">✗ ' . htmlspecialchars($e->getMessage()) . '</p>';
}
echo '<br><a href="/staff.php">返回人員管理</a>';
