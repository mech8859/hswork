<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();

$db = Database::getInstance();
$errors = array();
$success = array();

// 1. inventory 增加 min_qty 欄位
try {
    $cols = array_column($db->query("SHOW COLUMNS FROM inventory")->fetchAll(), 'Field');
    if (!in_array('min_qty', $cols)) {
        $db->exec("ALTER TABLE inventory ADD COLUMN min_qty INT DEFAULT 0 COMMENT '安全庫存量' AFTER display_qty");
        $success[] = 'inventory 新增 min_qty 欄位';
    } else {
        $success[] = 'inventory.min_qty 已存在，跳過';
    }
} catch (PDOException $e) {
    $errors[] = 'inventory.min_qty: ' . $e->getMessage();
}

// 2. inventory 增加 created_at
try {
    $cols = array_column($db->query("SHOW COLUMNS FROM inventory")->fetchAll(), 'Field');
    if (!in_array('created_at', $cols)) {
        $db->exec("ALTER TABLE inventory ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER locked");
        $success[] = 'inventory 新增 created_at 欄位';
    } else {
        $success[] = 'inventory.created_at 已存在，跳過';
    }
} catch (PDOException $e) {
    $errors[] = 'inventory.created_at: ' . $e->getMessage();
}

// 3. inventory_transactions 增加 qty_after
try {
    $cols = array_column($db->query("SHOW COLUMNS FROM inventory_transactions")->fetchAll(), 'Field');
    if (!in_array('qty_after', $cols)) {
        $db->exec("ALTER TABLE inventory_transactions ADD COLUMN qty_after DECIMAL(10,2) DEFAULT NULL COMMENT '異動後數量' AFTER quantity");
        $success[] = 'inventory_transactions 新增 qty_after 欄位';
    } else {
        $success[] = 'inventory_transactions.qty_after 已存在，跳過';
    }
} catch (PDOException $e) {
    $errors[] = 'inventory_transactions.qty_after: ' . $e->getMessage();
}

// 4. stocktakes 表
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS stocktakes (
          id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          stocktake_number VARCHAR(30) NOT NULL COMMENT 'INV-yyyymmdd-nnn',
          stocktake_date DATE NOT NULL,
          warehouse_id INT UNSIGNED NOT NULL,
          status VARCHAR(20) DEFAULT '盤點中',
          note TEXT,
          created_by INT UNSIGNED DEFAULT NULL,
          completed_by INT UNSIGNED DEFAULT NULL,
          completed_at DATETIME DEFAULT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          INDEX idx_st_number (stocktake_number),
          FOREIGN KEY (warehouse_id) REFERENCES warehouses(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盤點單'
    ");
    $success[] = 'stocktakes 表建立成功';
} catch (PDOException $e) {
    $errors[] = 'stocktakes: ' . $e->getMessage();
}

// 5. stocktake_items 表
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS stocktake_items (
          id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          stocktake_id INT UNSIGNED NOT NULL,
          product_id INT UNSIGNED NOT NULL,
          system_qty INT DEFAULT 0,
          actual_qty INT DEFAULT NULL,
          diff_qty INT DEFAULT NULL,
          note VARCHAR(200) DEFAULT NULL,
          FOREIGN KEY (stocktake_id) REFERENCES stocktakes(id) ON DELETE CASCADE,
          FOREIGN KEY (product_id) REFERENCES products(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盤點明細'
    ");
    $success[] = 'stocktake_items 表建立成功';
} catch (PDOException $e) {
    $errors[] = 'stocktake_items: ' . $e->getMessage();
}

echo '<h2>Migration 036: 庫存管理完整功能</h2>';
if (!empty($success)) {
    echo '<h3 style="color:green">成功:</h3><ul>';
    foreach ($success as $s) echo '<li>' . htmlspecialchars($s) . '</li>';
    echo '</ul>';
}
if (!empty($errors)) {
    echo '<h3 style="color:red">錯誤:</h3><ul>';
    foreach ($errors as $err) echo '<li>' . htmlspecialchars($err) . '</li>';
    echo '</ul>';
}
if (empty($errors)) {
    echo '<p style="color:green;font-weight:bold">Migration 036 完成！</p>';
}
echo '<p><a href="/inventory.php">返回庫存管理</a></p>';
