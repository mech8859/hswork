<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
if (!Auth::hasPermission('finance.manage') && !Auth::hasPermission('finance.view')) {
    Session::flash('error', '無權限查看此頁面');
    redirect('/');
}
require_once __DIR__ . '/../modules/finance/FinanceModel.php';

$model = new FinanceModel();
$action = !empty($_GET['action']) ? $_GET['action'] : 'list';

switch ($action) {
    // ---- 清單 ----
    case 'list':
        $filters = array(
            'status'        => !empty($_GET['status']) ? $_GET['status'] : '',
            'main_category' => !empty($_GET['main_category']) ? $_GET['main_category'] : '',
            'keyword'       => !empty($_GET['keyword']) ? $_GET['keyword'] : '',
        );
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $result = $model->getPaymentsOut($filters, $page);
        $records = $result['data'];

        $pageTitle = '付款單';
        $currentPage = 'payments_out';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/payments_out/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 新增 ----
    case 'create':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/payments_out.php');
            }
            $user = Session::getUser();
            $data = array(
                'create_date'    => !empty($_POST['create_date']) ? $_POST['create_date'] : null,
                'payment_date'   => !empty($_POST['payment_date']) ? $_POST['payment_date'] : null,
                'vendor_name'    => !empty($_POST['vendor_name']) ? $_POST['vendor_name'] : null,
                'payment_method' => !empty($_POST['payment_method']) ? $_POST['payment_method'] : null,
                'payment_type'   => !empty($_POST['payment_type']) ? $_POST['payment_type'] : null,
                'payment_terms'  => !empty($_POST['payment_terms']) ? $_POST['payment_terms'] : null,
                'status'         => !empty($_POST['status']) ? $_POST['status'] : '待付款',
                'main_category'  => !empty($_POST['main_category']) ? $_POST['main_category'] : null,
                'sub_category'   => !empty($_POST['sub_category']) ? $_POST['sub_category'] : null,
                'subtotal'       => !empty($_POST['subtotal']) ? $_POST['subtotal'] : 0,
                'tax'            => !empty($_POST['tax']) ? $_POST['tax'] : 0,
                'remittance_fee' => !empty($_POST['remittance_fee']) ? $_POST['remittance_fee'] : 0,
                'total_amount'   => !empty($_POST['total_amount']) ? $_POST['total_amount'] : 0,
                'note'           => !empty($_POST['note']) ? $_POST['note'] : null,
                'created_by'     => $user['id'],
                'updated_by'     => $user['id'],
            );
            $id = $model->createPaymentOut($data);

            // 儲存分公司拆帳
            if (!empty($_POST['branches'])) {
                $model->savePaymentOutBranches($id, $_POST['branches']);
            }
            // 儲存憑證明細
            if (!empty($_POST['vouchers'])) {
                $model->savePaymentOutVouchers($id, $_POST['vouchers']);
            }

            Session::flash('success', '付款單已建立');
            redirect('/payments_out.php?action=edit&id=' . $id);
        }

        $record = null;
        $branchIds = Auth::getAccessibleBranchIds();
        $branches = $model->getBranches($branchIds);
        $branchItems = array();
        $voucherItems = array();

        $pageTitle = '新增付款單';
        $currentPage = 'payments_out';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/payments_out/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 編輯 ----
    case 'edit':
        $id = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
        $record = $model->getPaymentOut($id);
        if (!$record) {
            Session::flash('error', '付款單不存在');
            redirect('/payments_out.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/payments_out.php?action=edit&id=' . $id);
            }
            $user = Session::getUser();
            $data = array(
                'create_date'    => !empty($_POST['create_date']) ? $_POST['create_date'] : null,
                'payment_date'   => !empty($_POST['payment_date']) ? $_POST['payment_date'] : null,
                'vendor_name'    => !empty($_POST['vendor_name']) ? $_POST['vendor_name'] : null,
                'payment_method' => !empty($_POST['payment_method']) ? $_POST['payment_method'] : null,
                'payment_type'   => !empty($_POST['payment_type']) ? $_POST['payment_type'] : null,
                'payment_terms'  => !empty($_POST['payment_terms']) ? $_POST['payment_terms'] : null,
                'status'         => !empty($_POST['status']) ? $_POST['status'] : '待付款',
                'main_category'  => !empty($_POST['main_category']) ? $_POST['main_category'] : null,
                'sub_category'   => !empty($_POST['sub_category']) ? $_POST['sub_category'] : null,
                'subtotal'       => !empty($_POST['subtotal']) ? $_POST['subtotal'] : 0,
                'tax'            => !empty($_POST['tax']) ? $_POST['tax'] : 0,
                'remittance_fee' => !empty($_POST['remittance_fee']) ? $_POST['remittance_fee'] : 0,
                'total_amount'   => !empty($_POST['total_amount']) ? $_POST['total_amount'] : 0,
                'note'           => !empty($_POST['note']) ? $_POST['note'] : null,
                'updated_by'     => $user['id'],
            );
            $model->updatePaymentOut($id, $data);

            // 儲存分公司拆帳
            $branchData = !empty($_POST['branches']) ? $_POST['branches'] : array();
            $model->savePaymentOutBranches($id, $branchData);

            // 儲存憑證明細
            $voucherData = !empty($_POST['vouchers']) ? $_POST['vouchers'] : array();
            $model->savePaymentOutVouchers($id, $voucherData);

            Session::flash('success', '付款單已更新');
            redirect('/payments_out.php?action=edit&id=' . $id);
        }

        $branchIds = Auth::getAccessibleBranchIds();
        $branches = $model->getBranches($branchIds);
        $branchItems = $model->getPaymentOutBranches($record['id']);
        $voucherItems = $model->getPaymentOutVouchers($record['id']);

        $pageTitle = '編輯付款單 - ' . (!empty($record['payment_number']) ? $record['payment_number'] : $record['id']);
        $currentPage = 'payments_out';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/payments_out/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 刪除 ----
    case 'delete':
        if (verify_csrf()) {
            $id = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
            $model->deletePaymentOut($id);
            Session::flash('success', '付款單已刪除');
        }
        redirect('/payments_out.php');
        break;

    default:
        redirect('/payments_out.php');
}
