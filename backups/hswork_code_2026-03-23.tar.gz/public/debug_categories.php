<?php
require __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
$db = Database::getInstance();
header('Content-Type: text/plain; charset=utf-8');

// 頂層分類
$cats = $db->query("SELECT id, name, parent_id FROM product_categories WHERE parent_id IS NULL OR parent_id = 0 ORDER BY name")->fetchAll();
echo "頂層分類: " . count($cats) . "\n";
foreach ($cats as $c) {
    $sub = $db->prepare("SELECT COUNT(*) FROM product_categories WHERE parent_id = ?");
    $sub->execute(array($c['id']));
    $subCount = $sub->fetchColumn();
    $prod = $db->prepare("SELECT COUNT(*) FROM products WHERE category_id = ? AND is_active = 1");
    $prod->execute(array($c['id']));
    $prodCount = $prod->fetchColumn();
    echo "  ID={$c['id']}: {$c['name']} (子分類:{$subCount}, 直屬產品:{$prodCount})\n";
}

// 測試 ajax_categories 回傳
echo "\n=== ajax_categories 回傳 ===\n";
$cats2 = $db->query("SELECT id, name, parent_id FROM product_categories WHERE parent_id IS NULL OR parent_id = 0 ORDER BY name")->fetchAll();
echo json_encode(array_slice($cats2, 0, 5), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

// 測試選分類後查產品
echo "\n\n=== 測試第一個分類的產品 ===\n";
if (!empty($cats[0])) {
    $catId = $cats[0]['id'];
    $catIds = array($catId);
    $subStmt = $db->prepare("SELECT id FROM product_categories WHERE parent_id = ?");
    $subStmt->execute(array($catId));
    foreach ($subStmt->fetchAll() as $sub) { $catIds[] = (int)$sub['id']; }
    
    $placeholders = implode(',', array_fill(0, count($catIds), '?'));
    $prodStmt = $db->prepare("SELECT p.id, p.name, p.model_number FROM products p WHERE p.category_id IN ($placeholders) AND p.is_active = 1 LIMIT 5");
    $prodStmt->execute($catIds);
    $prods = $prodStmt->fetchAll();
    echo "分類 {$cats[0]['name']} (IDs: " . implode(',', $catIds) . ") 有 " . count($prods) . " 個產品\n";
    foreach ($prods as $p) {
        echo "  {$p['id']}: {$p['name']} {$p['model_number']}\n";
    }
}

// inventory 表是否存在
echo "\n=== inventory 表 ===\n";
try {
    $invCount = $db->query("SELECT COUNT(*) FROM inventory")->fetchColumn();
    echo "inventory 表有 {$invCount} 筆\n";
} catch (Exception $e) {
    echo "inventory 表錯誤: " . $e->getMessage() . "\n";
}
