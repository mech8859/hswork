<?php
require __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
$db = Database::getInstance();

echo '<h2>Migration 033: 會計科目</h2>';

try {
    $db->exec("CREATE TABLE IF NOT EXISTS chart_of_accounts (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(20) NOT NULL COMMENT '科目編號',
        name VARCHAR(100) NOT NULL COMMENT '四階科目名稱',
        level1 VARCHAR(50) DEFAULT NULL COMMENT '一階科目',
        level2 VARCHAR(50) DEFAULT NULL COMMENT '二階科目',
        level3 VARCHAR(50) DEFAULT NULL COMMENT '三階科目',
        level3_code VARCHAR(10) DEFAULT NULL COMMENT '三階科目編號',
        is_active TINYINT(1) DEFAULT 1 COMMENT '是否使用',
        ragic_id INT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_code (code),
        INDEX idx_level1 (level1),
        INDEX idx_level3_code (level3_code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    echo '<p style="color:green">✓ chart_of_accounts 表已建立</p>';
} catch (Exception $e) {
    echo '<p style="color:red">✗ ' . htmlspecialchars($e->getMessage()) . '</p>';
}

// 匯入 Ragic 資料
echo '<h3>匯入 Ragic 會計科目</h3>';
$API_KEY = 'dGhmNTRyZk9uMlRUS2c3MjhhQytMZjlZdCtQc1lUMVJHYzVCNlA0dFFVZm1tREk0MFVxU0JibnRmNGV3TElEMA==';

$allData = array();
$offset = 0;
while (true) {
    $ch = curl_init("https://ap15.ragic.com/hstcc/ragicforms8/20015?api&limit=100&offset={$offset}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Basic ' . $API_KEY));
    $response = curl_exec($ch);
    curl_close($ch);
    
    $data = json_decode($response, true);
    if (!$data || count($data) === 0) break;
    $allData = array_merge($allData, $data);
    $offset += 100;
    if (count($data) < 100) break;
}

echo '<p>取得 ' . count($allData) . ' 筆會計科目</p>';

$stmt = $db->prepare("INSERT INTO chart_of_accounts (code, name, level1, level2, level3, level3_code, is_active, ragic_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), level1=VALUES(level1), level2=VALUES(level2), level3=VALUES(level3), level3_code=VALUES(level3_code), is_active=VALUES(is_active)");

$imported = 0;
foreach ($allData as $rid => $record) {
    $code = trim($record['科目編號'] ?? '');
    $name = trim($record['四階科目'] ?? '');
    if (empty($code) || empty($name)) continue;

    $stmt->execute(array(
        $code,
        $name,
        trim($record['一階科目'] ?? ''),
        trim($record['二階科目'] ?? ''),
        trim($record['三階科目'] ?? ''),
        trim($record['三階科目編號'] ?? ''),
        ($record['是否使用'] ?? 'Yes') === 'Yes' ? 1 : 0,
        (int)$rid,
    ));
    $imported++;
}

echo '<p style="color:green">✓ 匯入 ' . $imported . ' 筆會計科目</p>';

// 統計
$stats = $db->query("SELECT level1, COUNT(*) as cnt FROM chart_of_accounts GROUP BY level1 ORDER BY level1")->fetchAll();
echo '<h3>分類統計</h3>';
echo '<table border="1" cellpadding="4"><tr><th>一階科目</th><th>筆數</th></tr>';
foreach ($stats as $s) {
    echo '<tr><td>' . htmlspecialchars($s['level1']) . '</td><td>' . $s['cnt'] . '</td></tr>';
}
echo '</table>';

echo '<br><a href="/chart_of_accounts.php">查看會計科目管理</a>';
