<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
if (!Auth::hasPermission('customers.manage') && !Auth::hasPermission('customers.view') && !Auth::hasPermission('customers.own')) {
    Session::flash('error', '無權限查看此頁面');
    redirect('/');
}
require_once __DIR__ . '/../modules/customers/CustomerModel.php';

$model = new CustomerModel();
$action = $_GET['action'] ?? 'list';
$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    // ---- 客戶列表 ----
    case 'list':
        $filters = array(
            'keyword'  => $_GET['keyword'] ?? '',
            'category' => $_GET['category'] ?? '',
            'sales_id' => $_GET['sales_id'] ?? '',
            'has_cases' => $_GET['has_cases'] ?? '',
            'import_source' => $_GET['import_source'] ?? '',
        );
        $hasSearch = !empty($filters['keyword']) || !empty($filters['category']) || !empty($filters['sales_id']) || !empty($filters['has_cases']) || !empty($filters['import_source']);
        $salespeople = $model->getSalespeople();
        $perPage = 100;
        $currentPageNum = max(1, (int)($_GET['page'] ?? 1));

        if ($hasSearch) {
            $totalCount = $model->getListCount($filters);
            $totalPages = max(1, ceil($totalCount / $perPage));
            $currentPageNum = min($currentPageNum, $totalPages);
            $customers = $model->getList($filters, $perPage, $currentPageNum);
        } else {
            $customers = array();
            $totalCount = 0;
            $totalPages = 0;
        }

        $dashboardStats = $model->getDashboardStats();

        $pageTitle = '客戶管理';
        $currentPage = 'customers';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/customers/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 新增客戶 ----
    case 'create':
        Auth::requirePermission('customers.manage');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/customers.php'); }
            $id = $model->create($_POST);
            if (!empty($_POST['contacts'])) {
                $model->saveContacts($id, $_POST['contacts']);
            }
            AuditLog::log('customers', 'create', $id, $_POST['name'] ?? '');
            Session::flash('success', '客戶已新增');
            redirect('/customers.php?action=view&id=' . $id);
        }
        $salespeople = $model->getSalespeople();
        $customer = null;

        $pageTitle = '新增客戶';
        $currentPage = 'customers';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/customers/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 編輯客戶 ----
    case 'edit':
        Auth::requirePermission('customers.manage');
        $id = (int)($_GET['id'] ?? 0);
        $customer = $model->getById($id);
        if (!$customer) { Session::flash('error', '客戶不存在'); redirect('/customers.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/customers.php?action=edit&id='.$id); }
            AuditLog::logChange('customers', $id, $customer['name'], $customer, $_POST, array('name','category','contact_person','phone','mobile','email','address','tax_id','invoice_title'));
            $model->update($id, $_POST);
            if (isset($_POST['contacts'])) {
                $model->saveContacts($id, $_POST['contacts']);
            }
            Session::flash('success', '客戶已更新');
            redirect('/customers.php?action=view&id=' . $id);
        }
        $salespeople = $model->getSalespeople();

        $pageTitle = '編輯客戶';
        $currentPage = 'customers';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/customers/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 客戶詳情 ----
    case 'view':
        $id = (int)($_GET['id'] ?? 0);
        $customer = $model->getById($id);
        if (!$customer) { Session::flash('error', '客戶不存在'); redirect('/customers.php'); }

        $cases = $model->getCases($id);
        $deals = $model->getDeals($id);
        $transactions = $model->getTransactions($id);
        $files = $model->getFiles($id);

        $pageTitle = $customer['name'] . ' - 客戶資料';
        $currentPage = 'customers';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/customers/view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 停用/啟用 ----
    case 'toggle':
        Auth::requirePermission('customers.manage');
        if (verify_csrf()) {
            $model->toggleActive((int)$_GET['id']);
            Session::flash('success', '客戶狀態已更新');
        }
        redirect('/customers.php');
        break;

    // ---- AJAX搜尋 ----
    case 'ajax_search':
        header('Content-Type: application/json');
        $keyword = $_GET['q'] ?? '';
        if (strlen($keyword) < 1) { echo '[]'; exit; }
        echo json_encode($model->search($keyword));
        exit;

    // ---- 上傳文件 ----
    case 'upload_file':
        Auth::requirePermission('customers.manage');
        $customerId = (int)($_POST['customer_id'] ?? 0);
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $customer = $model->getById($customerId);
            if (!$customer) { Session::flash('error', '客戶不存在'); redirect('/customers.php'); }

            if (!empty($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = '/uploads/customers/' . $customerId . '/';
                $realDir = __DIR__ . $uploadDir;
                if (!is_dir($realDir)) { mkdir($realDir, 0755, true); }

                $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
                $allowed = array('jpg','jpeg','png','gif','pdf','doc','docx','xls','xlsx');
                if (!in_array($ext, $allowed)) {
                    Session::flash('error', '不支援的檔案格式');
                    redirect('/customers.php?action=view&id=' . $customerId . '&tab=files');
                }

                $fileName = $_FILES['file']['name'];
                $saveName = date('Ymd_His') . '_' . mt_rand(1000,9999) . '.' . $ext;
                $savePath = $uploadDir . $saveName;

                if (move_uploaded_file($_FILES['file']['tmp_name'], $realDir . $saveName)) {
                    $model->addFile($customerId, array(
                        'file_type' => $_POST['file_type'] ?: 'other',
                        'file_name' => $fileName,
                        'file_path' => $savePath,
                        'file_size' => $_FILES['file']['size'],
                        'note'      => $_POST['note'] ?: null,
                    ));
                    Session::flash('success', '文件已上傳');
                } else {
                    Session::flash('error', '上傳失敗');
                }
            } else {
                Session::flash('error', '請選擇檔案');
            }
        }
        redirect('/customers.php?action=view&id=' . $customerId . '&tab=files');
        break;

    // ---- 刪除文件 ----
    case 'delete_file':
        Auth::requirePermission('customers.manage');
        if (verify_csrf()) {
            $fileId = (int)($_GET['file_id'] ?? 0);
            $customerId = (int)($_GET['customer_id'] ?? 0);
            $model->deleteFile($fileId);
            Session::flash('success', '文件已刪除');
        }
        redirect('/customers.php?action=view&id=' . (int)($_GET['customer_id'] ?? 0) . '&tab=files');
        break;

    default:
        redirect('/customers.php');
}
