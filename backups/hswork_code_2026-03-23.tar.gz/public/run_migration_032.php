<?php
require __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
$db = Database::getInstance();

echo '<h2>Migration 032: 車輛管理擴充</h2>';

try {
    $cols = array_column($db->query("SHOW COLUMNS FROM vehicles")->fetchAll(), 'Field');
    
    $adds = array();
    if (!in_array('vehicle_number', $cols)) $adds[] = "ADD COLUMN vehicle_number VARCHAR(20) DEFAULT NULL COMMENT '車輛編號'";
    if (!in_array('leasing_company', $cols)) $adds[] = "ADD COLUMN leasing_company VARCHAR(100) DEFAULT NULL COMMENT '租賃公司'";
    if (!in_array('contract_months', $cols)) $adds[] = "ADD COLUMN contract_months INT DEFAULT NULL COMMENT '合約期數'";
    if (!in_array('contract_start', $cols)) $adds[] = "ADD COLUMN contract_start DATE DEFAULT NULL COMMENT '合約開始日'";
    if (!in_array('contract_end', $cols)) $adds[] = "ADD COLUMN contract_end DATE DEFAULT NULL COMMENT '合約到期日'";
    if (!in_array('monthly_rent', $cols)) $adds[] = "ADD COLUMN monthly_rent DECIMAL(10,0) DEFAULT NULL COMMENT '月租金含稅'";
    if (!in_array('maintenance_mileage', $cols)) $adds[] = "ADD COLUMN maintenance_mileage INT DEFAULT NULL COMMENT '保養日期里程數'";
    if (!in_array('next_maintenance_mileage', $cols)) $adds[] = "ADD COLUMN next_maintenance_mileage INT DEFAULT NULL COMMENT '下次保養里程數'";
    if (!in_array('maintenance_address', $cols)) $adds[] = "ADD COLUMN maintenance_address VARCHAR(200) DEFAULT NULL COMMENT '保養地址'";
    if (!in_array('maintenance_contact', $cols)) $adds[] = "ADD COLUMN maintenance_contact VARCHAR(100) DEFAULT NULL COMMENT '保養聯絡窗口'";
    if (!in_array('inspection_date', $cols)) $adds[] = "ADD COLUMN inspection_date DATE DEFAULT NULL COMMENT '驗車日'";
    if (!in_array('inspection_contact', $cols)) $adds[] = "ADD COLUMN inspection_contact VARCHAR(100) DEFAULT NULL COMMENT '驗車窗口'";
    if (!in_array('custodian_id', $cols)) $adds[] = "ADD COLUMN custodian_id INT UNSIGNED DEFAULT NULL COMMENT '車輛管理人'";
    if (!in_array('last_maintenance_date', $cols)) $adds[] = "ADD COLUMN last_maintenance_date DATE DEFAULT NULL COMMENT '保養日期'";
    if (!in_array('note', $cols)) $adds[] = "ADD COLUMN note TEXT DEFAULT NULL";

    if (!empty($adds)) {
        $sql = "ALTER TABLE vehicles " . implode(', ', $adds);
        $db->exec($sql);
        echo '<p style="color:green">✓ vehicles 表已擴充 ' . count($adds) . ' 個欄位</p>';
    } else {
        echo '<p>vehicles 已是最新</p>';
    }

    // 確保 vehicle_files 表存在
    $db->exec("CREATE TABLE IF NOT EXISTS vehicle_files (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        vehicle_id INT UNSIGNED NOT NULL,
        file_type VARCHAR(30) DEFAULT 'other' COMMENT 'license_front/license_back/insurance/other',
        file_name VARCHAR(255) NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        file_size INT DEFAULT 0,
        uploaded_by INT UNSIGNED DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_vehicle (vehicle_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    echo '<p style="color:green">✓ vehicle_files 表已建立</p>';

} catch (Exception $e) {
    echo '<p style="color:red">✗ ' . htmlspecialchars($e->getMessage()) . '</p>';
}

// ========== 匯入 Ragic 車輛資料 ==========
echo '<h3>匯入 Ragic 車輛資料</h3>';

$API_KEY = 'dGhmNTRyZk9uMlRUS2c3MjhhQytMZjlZdCtQc1lUMVJHYzVCNlA0dFFVZm1tREk0MFVxU0JibnRmNGV3TElEMA==';
$ch = curl_init('https://ap15.ragic.com/hstcc/connect-form/8?api&limit=100');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Basic ' . $API_KEY));
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
if (!$data) {
    echo '<p style="color:red">✗ 無法取得 Ragic 資料</p>';
    exit;
}

echo '<p>取得 ' . count($data) . ' 筆車輛資料</p>';

// 取人員對照表
$users = $db->query("SELECT id, real_name FROM users")->fetchAll(PDO::FETCH_KEY_PAIR);
$userByName = array_flip($users);

$imported = 0;
$updated = 0;
$errors = array();

foreach ($data as $rid => $record) {
    $plate = trim($record['車牌號碼'] ?? '');
    if (empty($plate)) continue;

    // 查是否已存在
    $stmt = $db->prepare("SELECT id FROM vehicles WHERE plate_number = ?");
    $stmt->execute(array($plate));
    $existing = $stmt->fetch();

    // 找車輛管理人
    $custodianName = trim($record['車輛管理人'] ?? '');
    $custodianId = null;
    if ($custodianName && isset($userByName[$custodianName])) {
        $custodianId = $userByName[$custodianName];
    }

    // 日期轉換
    $contractStart = !empty($record['合約開始日']) ? str_replace('/', '-', $record['合約開始日']) : null;
    $contractEnd = !empty($record['合約到期日']) ? str_replace('/', '-', $record['合約到期日']) : null;
    $maintenanceDate = !empty($record['保養日期']) ? str_replace('/', '-', $record['保養日期']) : null;
    $inspectionDate = !empty($record['驗車日']) ? str_replace('/', '-', $record['驗車日']) : null;

    $vData = array(
        trim($record['車輛編號'] ?? ''),
        $plate,
        trim($record['租賃公司'] ?? ''),
        !empty($record['合約期數']) ? (int)$record['合約期數'] : null,
        $contractStart,
        $contractEnd,
        !empty($record['月租金(含稅)']) ? (int)str_replace(array('$',','), '', $record['月租金(含稅)']) : null,
        $custodianId,
        $maintenanceDate,
        !empty($record['保養日期里程數']) ? (int)$record['保養日期里程數'] : null,
        !empty($record['下次保養里程數']) ? (int)$record['下次保養里程數'] : null,
        trim($record['保養地址'] ?? ''),
        trim($record['聯絡窗口'] ?? ''),
        $inspectionDate,
        trim($record['驗車窗口'] ?? ''),
    );

    if ($existing) {
        $db->prepare("UPDATE vehicles SET vehicle_number=?, plate_number=?, leasing_company=?, contract_months=?, contract_start=?, contract_end=?, monthly_rent=?, custodian_id=?, last_maintenance_date=?, maintenance_mileage=?, next_maintenance_mileage=?, maintenance_address=?, maintenance_contact=?, inspection_date=?, inspection_contact=? WHERE id=?")->execute(array_merge($vData, array($existing['id'])));
        $updated++;
        echo '<p>↻ 更新: ' . htmlspecialchars($plate) . '</p>';
    } else {
        // 新增 - 需要 branch_id，預設用 1
        $db->prepare("INSERT INTO vehicles (vehicle_number, plate_number, leasing_company, contract_months, contract_start, contract_end, monthly_rent, custodian_id, last_maintenance_date, maintenance_mileage, next_maintenance_mileage, maintenance_address, maintenance_contact, inspection_date, inspection_contact, branch_id, vehicle_type, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 1, '公務車', 1)")->execute($vData);
        $imported++;
        echo '<p style="color:green">✓ 新增: ' . htmlspecialchars($plate) . ' (' . htmlspecialchars($record['車輛編號'] ?? '') . ')</p>';
    }
}

echo '<hr>';
echo '<p><strong>結果：新增 ' . $imported . ' / 更新 ' . $updated . ' / 總共 ' . count($data) . '</strong></p>';
echo '<a href="/vehicles.php" class="btn btn-primary">查看車輛管理</a>';
