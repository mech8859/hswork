<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/products/ProductModel.php';

$model = new ProductModel();
$action = $_GET['action'] ?? 'list';

switch ($action) {
    // ---- 產品列表 ----
    case 'list':
        $filters = array(
            'keyword'     => trim($_GET['keyword'] ?? ''),
            'category_id' => (int)($_GET['category_id'] ?? 0),
            'supplier'    => trim($_GET['supplier'] ?? ''),
        );
        $page = max(1, (int)($_GET['page'] ?? 1));

        $result = $model->getList($filters, $page, 24);
        $categories = $model->getTopCategories();
        $suppliers = $model->getSuppliers();

        $pageTitle = '產品目錄';
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 產品詳情 ----
    case 'view':
        $id = (int)($_GET['id'] ?? 0);
        $product = $model->getById($id);
        if (!$product) {
            Session::flash('error', '產品不存在');
            redirect('/products.php');
        }

        $pageTitle = $product['name'];
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 修改價格 ----
    case 'edit_price':
        if (!Auth::hasPermission('admin')) {
            Session::flash('error', '權限不足');
            redirect('/products.php');
        }

        $id = (int)($_GET['id'] ?? 0);
        $product = $model->getById($id);
        if (!$product) {
            Session::flash('error', '產品不存在');
            redirect('/products.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/products.php?action=edit_price&id=' . $id);
            }
            $model->updatePrice($id, $_POST);
            Session::flash('success', '價格已更新');
            redirect('/products.php?action=view&id=' . $id);
        }

        $pageTitle = '修改價格 - ' . $product['name'];
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/edit_price.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 新增產品 ----
    case 'create':
        if (!Auth::hasPermission('products.manage') && !in_array(Auth::user()['role'], array('boss','manager'))) {
            Session::flash('error', '權限不足'); redirect('/products.php');
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/products.php'); }
            $db = Database::getInstance();
            $stmt = $db->prepare("INSERT INTO products (name, model, brand, supplier, description, specifications, warranty_text, unit, price, cost, retail_price, labor_cost, category_id, stock, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute(array(
                trim($_POST['name'] ?? ''),
                trim($_POST['model'] ?? ''),
                trim($_POST['brand'] ?? ''),
                trim($_POST['supplier'] ?? ''),
                trim($_POST['description'] ?? ''),
                trim($_POST['specifications'] ?? ''),
                trim($_POST['warranty_text'] ?? ''),
                trim($_POST['unit'] ?? '台'),
                (int)($_POST['price'] ?? 0),
                (int)($_POST['cost'] ?? 0),
                (int)($_POST['retail_price'] ?? 0),
                (int)($_POST['labor_cost'] ?? 0),
                !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null,
                (int)($_POST['stock'] ?? 0),
                isset($_POST['is_active']) ? 1 : 1,
            ));
            $newId = (int)$db->lastInsertId();
            AuditLog::log('products', 'create', $newId, $_POST['name'] ?? '');
            Session::flash('success', '產品已新增');
            redirect('/products.php?action=view&id=' . $newId);
        }
        $product = null;
        $categories = $model->getTopCategories();
        $allCategories = $model->getAllCategoriesFlat();
        $pageTitle = '新增產品';
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 編輯產品 ----
    case 'edit':
        if (!Auth::hasPermission('products.manage') && !in_array(Auth::user()['role'], array('boss','manager'))) {
            Session::flash('error', '權限不足'); redirect('/products.php');
        }
        $id = (int)($_GET['id'] ?? 0);
        $product = $model->getById($id);
        if (!$product) { Session::flash('error', '產品不存在'); redirect('/products.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/products.php?action=edit&id='.$id); }
            $db = Database::getInstance();
            $oldProduct = $product;
            $db->prepare("UPDATE products SET name=?, model=?, brand=?, supplier=?, description=?, specifications=?, warranty_text=?, unit=?, price=?, cost=?, retail_price=?, labor_cost=?, category_id=?, is_active=? WHERE id=?")->execute(array(
                trim($_POST['name'] ?? ''),
                trim($_POST['model'] ?? ''),
                trim($_POST['brand'] ?? ''),
                trim($_POST['supplier'] ?? ''),
                trim($_POST['description'] ?? ''),
                trim($_POST['specifications'] ?? ''),
                trim($_POST['warranty_text'] ?? ''),
                trim($_POST['unit'] ?? '台'),
                (int)($_POST['price'] ?? 0),
                (int)($_POST['cost'] ?? 0),
                (int)($_POST['retail_price'] ?? 0),
                (int)($_POST['labor_cost'] ?? 0),
                !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null,
                isset($_POST['is_active']) ? 1 : 0,
                $id,
            ));
            AuditLog::logChange('products', $id, $product['name'], $oldProduct, $_POST, array('name','model','price','cost','category_id'));
            Session::flash('success', '產品已更新');
            redirect('/products.php?action=view&id=' . $id);
        }
        $categories = $model->getTopCategories();
        $allCategories = $model->getAllCategoriesFlat();
        $pageTitle = '編輯產品 - ' . $product['name'];
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- AJAX: 產品搜尋（施工回報材料用）----
    case 'ajax_search':
        $keyword = trim($_GET['keyword'] ?? '');
        if (mb_strlen($keyword) < 2) {
            json_response(array('data' => array()));
        }
        $result = $model->getList(array('keyword' => $keyword), 1, 10);
        $items = array();
        foreach ($result['data'] as $p) {
            $items[] = array(
                'id' => $p['id'],
                'name' => $p['name'],
                'model_number' => $p['model_number'] ?? '',
                'price' => $p['price'] ?? 0,
                'unit' => $p['unit'] ?? '',
            );
        }
        json_response(array('data' => $items));
        break;

    // ---- 分類管理 ----
    case 'categories':
        if (!Auth::hasPermission('products.manage') && !in_array(Auth::user()['role'], array('boss','manager'))) {
            Session::flash('error', '權限不足'); redirect('/products.php');
        }
        $allCategories = $model->getAllCategoriesFlat();
        $categoriesTree = $model->getAllCategoriesTree();

        $pageTitle = '產品分類管理';
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/categories.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'category_save':
        if (!Auth::hasPermission('products.manage') && !in_array(Auth::user()['role'], array('boss','manager'))) {
            Session::flash('error', '權限不足'); redirect('/products.php');
        }
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('/products.php?action=categories'); }
        if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/products.php?action=categories'); }

        $catId = !empty($_POST['id']) ? (int)$_POST['id'] : 0;
        $catName = trim($_POST['name'] ?? '');
        $catParent = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;

        if (!$catName) {
            Session::flash('error', '請輸入分類名稱');
            redirect('/products.php?action=categories');
        }
        if ($catId) {
            $model->updateCategory($catId, $catName, $catParent);
            Session::flash('success', '分類已更新');
        } else {
            $model->createCategory($catName, $catParent);
            Session::flash('success', '分類已新增');
        }
        redirect('/products.php?action=categories');
        break;

    case 'category_delete':
        if (!Auth::hasPermission('products.manage') && !in_array(Auth::user()['role'], array('boss','manager'))) {
            Session::flash('error', '權限不足'); redirect('/products.php');
        }
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('/products.php?action=categories'); }
        if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/products.php?action=categories'); }

        $catId = (int)($_POST['id'] ?? 0);
        $result = $model->deleteCategory($catId);
        if ($result === true) {
            Session::flash('success', '分類已刪除');
        } else {
            Session::flash('error', $result);
        }
        redirect('/products.php?action=categories');
        break;

    // ---- AJAX: 取得子分類 ----
    case 'ajax_subcategories':
        header('Content-Type: application/json');
        $parentId = (int)($_GET['parent_id'] ?? 0);
        $db = Database::getInstance();
        if ($parentId === 0) {
            $stmt = $db->query("SELECT id, name FROM product_categories WHERE parent_id IS NULL OR parent_id = 0 ORDER BY name");
        } else {
            $stmt = $db->prepare("SELECT id, name FROM product_categories WHERE parent_id = ? ORDER BY name");
            $stmt->execute(array($parentId));
        }
        echo json_encode($stmt->fetchAll());
        exit;

    default:
        redirect('/products.php');
}
