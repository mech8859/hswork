<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/cases/CaseModel.php';

$model = new CaseModel();
$action = isset($_GET['action']) ? $_GET['action'] : 'list';

// 權限檢查
if (!Auth::hasPermission('business_tracking.manage') && !Auth::hasPermission('business_tracking.view') && !Auth::hasPermission('business_tracking.own')) {
    Session::flash('error', '權限不足');
    redirect('/');
}

$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    // ---- 看板/列表 ----
    case 'list':
        $user = Auth::user();
        $salesRoles = array('sales', 'sales_manager', 'sales_assistant');
        $isSalesRole = in_array($user['role'], $salesRoles);
        $isFirstVisit = !isset($_GET['sales_id']) && !isset($_GET['branch_id']) && !isset($_GET['case_type']) && !isset($_GET['case_source']) && !isset($_GET['keyword']) && !isset($_GET['stage']) && !isset($_GET['all']);

        // 預設值：業務→預設自己；非業務→預設所屬分公司
        $defaultSalesId = '';
        $defaultBranchId = '';
        if ($isFirstVisit) {
            if ($isSalesRole) {
                $defaultSalesId = Auth::id();
            } else {
                $defaultBranchId = $user['branch_id'];
            }
        }

        $filters = array(
            'sales_id'    => isset($_GET['sales_id']) ? $_GET['sales_id'] : $defaultSalesId,
            'branch_id'   => isset($_GET['branch_id']) ? $_GET['branch_id'] : $defaultBranchId,
            'case_type'   => isset($_GET['case_type']) ? $_GET['case_type'] : '',
            'case_source' => isset($_GET['case_source']) ? $_GET['case_source'] : '',
            'keyword'     => isset($_GET['keyword']) ? $_GET['keyword'] : '',
            'start_date'  => isset($_GET['start_date']) ? $_GET['start_date'] : '',
            'end_date'    => isset($_GET['end_date']) ? $_GET['end_date'] : '',
            'stage'       => isset($_GET['stage']) ? $_GET['stage'] : '',
        );

        // 僅自己的
        if (Auth::hasPermission('business_tracking.own') && !Auth::hasPermission('business_tracking.manage') && !Auth::hasPermission('business_tracking.view')) {
            $filters['sales_id'] = Auth::id();
        }

        $cases = $model->getSalesTrackingList($filters);
        $stats = $model->getStageStats($filters);
        $salespeople = $model->getSalespeople();
        $branches = $model->getBranches();

        $pageTitle = '業務追蹤表';
        $currentPage = 'business_tracking';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/business_tracking/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 新增進件 ----
    case 'create':
        if (!Auth::hasPermission('business_tracking.manage') && !Auth::hasPermission('business_tracking.own')) {
            Session::flash('error', '權限不足');
            redirect('/business_tracking.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/business_tracking.php?action=create');
            }
            $caseId = $model->createSalesCase($_POST);
            Session::flash('success', '進件已新增');
            redirect('/business_tracking.php?action=view&id=' . $caseId);
        }

        $salespeople = $model->getSalespeople();
        $branches = $model->getBranches();

        $pageTitle = '新增進件';
        $currentPage = 'business_tracking';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/business_tracking/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 編輯 ----
    case 'edit':
        if (!Auth::hasPermission('business_tracking.manage') && !Auth::hasPermission('business_tracking.own')) {
            Session::flash('error', '權限不足');
            redirect('/business_tracking.php');
        }

        $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
        $case = $model->getById($id);
        if (!$case) {
            Session::flash('error', '案件不存在');
            redirect('/business_tracking.php');
        }

        // own 權限只能編輯自己的
        if (Auth::hasPermission('business_tracking.own') && !Auth::hasPermission('business_tracking.manage')) {
            if ((int)$case['sales_id'] !== Auth::id()) {
                Session::flash('error', '權限不足');
                redirect('/business_tracking.php');
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/business_tracking.php?action=edit&id=' . $id);
            }

            $updates = array(
                'title'          => isset($_POST['title']) ? $_POST['title'] : '',
                'branch_id'      => isset($_POST['branch_id']) ? $_POST['branch_id'] : null,
                'case_type'      => isset($_POST['case_type']) ? $_POST['case_type'] : null,
                'case_source'    => isset($_POST['case_source']) ? $_POST['case_source'] : null,
                'company'        => isset($_POST['company']) ? $_POST['company'] : null,
                'customer_name'  => isset($_POST['customer_name']) ? $_POST['customer_name'] : null,
                'customer_phone' => isset($_POST['customer_phone']) ? $_POST['customer_phone'] : null,
                'customer_mobile'=> isset($_POST['customer_mobile']) ? $_POST['customer_mobile'] : null,
                'contact_person' => isset($_POST['contact_person']) ? $_POST['contact_person'] : null,
                'city'           => isset($_POST['city']) ? $_POST['city'] : null,
                'district'       => isset($_POST['district']) ? $_POST['district'] : null,
                'address'        => isset($_POST['address']) ? $_POST['address'] : null,
                'sales_id'       => isset($_POST['sales_id']) ? $_POST['sales_id'] : null,
                'deal_amount'    => isset($_POST['deal_amount']) ? $_POST['deal_amount'] : null,
                'sales_note'     => isset($_POST['sales_note']) ? $_POST['sales_note'] : null,
            );

            $sets = array();
            $params = array();
            foreach ($updates as $col => $val) {
                $sets[] = $col . ' = ?';
                $params[] = ($val !== '' && $val !== null) ? $val : null;
            }
            $params[] = $id;
            $db = Database::getInstance();
            $db->prepare("UPDATE cases SET " . implode(', ', $sets) . " WHERE id = ?")->execute($params);

            Session::flash('success', '案件已更新');
            redirect('/business_tracking.php?action=view&id=' . $id);
        }

        $salespeople = $model->getSalespeople();
        $branches = $model->getBranches();

        $pageTitle = '編輯案件';
        $currentPage = 'business_tracking';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/business_tracking/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 檢視詳情 ----
    case 'view':
        $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
        $case = $model->getById($id);
        if (!$case) {
            Session::flash('error', '案件不存在');
            redirect('/business_tracking.php');
        }

        // own 權限只能看自己的
        if (Auth::hasPermission('business_tracking.own') && !Auth::hasPermission('business_tracking.manage') && !Auth::hasPermission('business_tracking.view')) {
            if ((int)$case['sales_id'] !== Auth::id()) {
                Session::flash('error', '權限不足');
                redirect('/business_tracking.php');
            }
        }

        $pageTitle = $case['title'] . ' - 案件詳情';
        $currentPage = 'business_tracking';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/business_tracking/view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 更新階段 (AJAX) ----
    case 'update_stage':
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(array('ok' => false, 'msg' => 'Invalid method'));
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            $input = $_POST;
        }

        $id = (int)(isset($input['id']) ? $input['id'] : 0);
        $stage = (int)(isset($input['stage']) ? $input['stage'] : 0);

        if ($id <= 0 || $stage < 1 || $stage > 7) {
            echo json_encode(array('ok' => false, 'msg' => '參數錯誤'));
            exit;
        }

        $case = $model->getById($id);
        if (!$case) {
            echo json_encode(array('ok' => false, 'msg' => '案件不存在'));
            exit;
        }

        if (Auth::hasPermission('business_tracking.own') && !Auth::hasPermission('business_tracking.manage')) {
            if ((int)$case['sales_id'] !== Auth::id()) {
                echo json_encode(array('ok' => false, 'msg' => '權限不足'));
                exit;
            }
        }

        $data = array();
        if (isset($input['deal_amount'])) { $data['deal_amount'] = $input['deal_amount']; }
        if (isset($input['deal_date'])) { $data['deal_date'] = $input['deal_date']; }
        if (isset($input['lost_reason'])) { $data['lost_reason'] = $input['lost_reason']; }

        $model->updateStage($id, $stage, $data);
        $labels = CaseModel::stageLabels();
        echo json_encode(array('ok' => true, 'msg' => '已更新為：' . (isset($labels[$stage]) ? $labels[$stage] : $stage)));
        exit;

    default:
        redirect('/business_tracking.php');
}
