<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/staff/StaffModel.php';

$model = new StaffModel();
$action = $_GET['action'] ?? 'list';
$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    // ---- 人員清單 ----
    case 'list':
        $filters = [
            'branch_id'   => $_GET['branch_id'] ?? '',
            'role'        => $_GET['role'] ?? '',
            'is_engineer' => $_GET['is_engineer'] ?? '',
            'is_active'   => isset($_GET['is_active']) ? $_GET['is_active'] : '1',
            'keyword'     => $_GET['keyword'] ?? '',
        ];
        $users = $model->getList($branchIds, $filters);
        $branches = $model->getAllBranches();
        $appConfig = require __DIR__ . '/../config/app.php';

        $pageTitle = '人員管理';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 新增人員 ----
    case 'create':
        Auth::requirePermission('staff.manage');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/staff.php'); }

            // 帳號檢查
            $db = Database::getInstance();
            $chk = $db->prepare('SELECT id FROM users WHERE username = ?');
            $chk->execute([$_POST['username']]);
            if ($chk->fetch()) {
                Session::flash('error', '帳號已存在');
                redirect('/staff.php?action=create');
            }

            $userId = $model->create($_POST);
            Session::flash('success', '人員已新增');
            redirect('/staff.php?action=view&id=' . $userId);
        }
        $branches = $model->getAllBranches();
        $appConfig = require __DIR__ . '/../config/app.php';
        $user = null;

        $pageTitle = '新增人員';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 編輯人員 ----
    case 'edit':
        $id = (int)($_GET['id'] ?? 0);
        // 允許編輯自己的資料，或需要 staff.manage 權限
        if ($id !== Auth::id() && !Auth::hasPermission('staff.manage')) {
            Session::flash('error', '權限不足');
            redirect('/staff.php');
        }
        $user = $model->getById($id);
        if (!$user) { Session::flash('error', '人員不存在'); redirect('/staff.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/staff.php?action=edit&id='.$id); }

            // 處理個人權限設定（僅 boss 可設定）
            if (Auth::user()['role'] === 'boss') {
                $modules = array('cases','schedule','repairs','worklog','attendance','products','staff','vehicles','leaves','inter_branch','reports','quotations','customers','business_calendar','business_tracking');
                $customPerms = array();
                foreach ($modules as $mod) {
                    $val = isset($_POST['perm_' . $mod]) ? $_POST['perm_' . $mod] : 'off';
                    $customPerms[$mod] = ($val === 'off') ? false : $val;
                }
                // 案件編輯區域權限
                $sectionKeys = array('basic','finance','schedule','attach','site','contacts','skills','delete');
                $selectedSections = array();
                foreach ($sectionKeys as $sk) {
                    if (!empty($_POST['case_section_' . $sk])) {
                        $selectedSections[] = $sk;
                    }
                }
                $customPerms['case_sections'] = $selectedSections;

                // 報表存取權限
                $reportLabels = $appConfig['report_labels'];
                $selectedReports = array();
                foreach (array_keys($reportLabels) as $rk) {
                    if (!empty($_POST['report_access_' . $rk])) {
                        $selectedReports[] = $rk;
                    }
                }
                $customPerms['report_access'] = $selectedReports;

                $_POST['custom_permissions'] = json_encode($customPerms);
            }

            $oldUser = $model->getById($id);
            $model->update($id, $_POST);
            AuditLog::logChange('staff', $id, $oldUser['real_name'], $oldUser, $_POST, array('real_name','role','branch_id','phone','email','is_engineer','can_view_all_branches','holiday_availability','night_availability','caution_notes'));
            Session::flash('success', '人員已更新');
            redirect('/staff.php?action=view&id=' . $id);
        }
        $branches = $model->getAllBranches();
        $appConfig = require __DIR__ . '/../config/app.php';

        $pageTitle = '編輯人員';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 人員詳情 (技能/證照) ----
    case 'view':
        $id = (int)($_GET['id'] ?? 0);
        // 非管理者/檢視權限者只能看自己
        if (!Auth::hasPermission('staff.manage') && !Auth::hasPermission('staff.view') && $id !== Auth::id()) {
            redirect('/staff.php?action=view&id=' . Auth::id());
        }
        $user = $model->getById($id);
        if (!$user) { Session::flash('error', '人員不存在'); redirect('/staff.php'); }

        $userSkills = $model->getUserSkills($id);
        $userCerts = $model->getUserCertifications($id);
        $vendorTrainings = $model->getVendorTrainings($id);

        $pageTitle = $user['real_name'] . ' - 人員資料';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 技能管理 ----
    case 'skills':
        Auth::requirePermission('staff.manage');
        $id = (int)($_GET['id'] ?? 0);
        $user = $model->getById($id);
        if (!$user) { Session::flash('error', '人員不存在'); redirect('/staff.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/staff.php?action=skills&id='.$id); }
            $model->saveUserSkills($id, $_POST['skills'] ?? []);
            Session::flash('success', '技能已更新');
            redirect('/staff.php?action=view&id=' . $id);
        }

        $allSkills = $model->getAllSkills();
        $userSkills = $model->getUserSkills($id);
        $userSkillMap = array();
        foreach ($userSkills as $us) { $userSkillMap[$us['skill_id']] = $us['proficiency']; }

        // 配對資料（放在技能設定旁）
        $userPairs = $model->getUserPairs($id);
        $engineers = $model->getEngineers($branchIds);

        $pageTitle = $user['real_name'] . ' - 技能設定';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/skills.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 證照管理 ----
    case 'add_cert':
        Auth::requirePermission('staff.manage');
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $model->addCertification((int)$_POST['user_id'], $_POST);
            Session::flash('success', '證照已新增');
            redirect('/staff.php?action=view&id=' . (int)$_POST['user_id']);
        }
        redirect('/staff.php');
        break;

    case 'remove_cert':
        Auth::requirePermission('staff.manage');
        if (verify_csrf()) {
            $model->removeCertification((int)$_GET['cert_id']);
        }
        redirect('/staff.php?action=view&id=' . (int)$_GET['user_id']);
        break;

    // ---- 廠商上課證管理 ----
    case 'add_vendor_training':
        Auth::requirePermission('staff.manage');
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $model->addVendorTraining((int)$_POST['user_id'], $_POST);
            Session::flash('success', '廠商上課證已新增');
            redirect('/staff.php?action=view&id=' . (int)$_POST['user_id']);
        }
        redirect('/staff.php');
        break;

    case 'remove_vendor_training':
        Auth::requirePermission('staff.manage');
        if (verify_csrf()) {
            $model->removeVendorTraining((int)$_GET['vt_id']);
        }
        redirect('/staff.php?action=view&id=' . (int)$_GET['user_id']);
        break;

    // ---- 配對表（個人） ----
    case 'pairs':
        Auth::requirePermission('staff.manage');
        $userId = (int)($_GET['id'] ?? 0);
        if (!$userId) { Session::flash('error', '請指定人員'); redirect('/staff.php'); }

        $targetUser = $model->getById($userId);
        if (!$targetUser) { Session::flash('error', '人員不存在'); redirect('/staff.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            // 批次儲存配對
            $pairData = $_POST['pairs'] ?? array();
            foreach ($pairData as $partnerId => $info) {
                $partnerId = (int)$partnerId;
                $compat = (int)($info['compatibility'] ?? 3);
                $note = trim($info['note'] ?? '');
                if ($compat > 0) {
                    $model->savePair($userId, $partnerId, $compat, $note ?: null);
                }
            }
            Session::flash('success', '配對已更新');
            redirect('/staff.php?action=pairs&id=' . $userId);
        }

        $engineers = $model->getEngineers($branchIds);
        // 取得此人員的所有配對
        $existingPairs = array();
        $allPairs = $model->getPairs($branchIds);
        foreach ($allPairs as $p) {
            if ((int)$p['user_a_id'] === $userId) {
                $existingPairs[(int)$p['user_b_id']] = $p;
            } elseif ((int)$p['user_b_id'] === $userId) {
                $existingPairs[(int)$p['user_a_id']] = $p;
            }
        }

        $pageTitle = $targetUser['real_name'] . ' - 配對表';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/pairs_individual.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 刪除配對 ----
    case 'delete_pair':
        Auth::requirePermission('staff.manage');
        if (verify_csrf()) {
            $model->deletePair((int)$_GET['pair_id']);
            Session::flash('success', '配對已刪除');
        }
        $returnTo = $_GET['return'] ?? 'pairs';
        if ($returnTo === 'skills' && !empty($_GET['user_id'])) {
            redirect('/staff.php?action=skills&id=' . (int)$_GET['user_id']);
        }
        redirect('/staff.php?action=pairs');
        break;

    // ---- 技能項目管理（CRUD） ----
    case 'manage_skills':
        Auth::requirePermission('staff.manage');

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $subAction = $_POST['sub_action'] ?? '';
            if ($subAction === 'create') {
                $model->createSkill($_POST);
                Session::flash('success', '技能已新增');
            } elseif ($subAction === 'update' && !empty($_POST['skill_id'])) {
                $model->updateSkill((int)$_POST['skill_id'], $_POST);
                Session::flash('success', '技能已更新');
            } elseif ($subAction === 'delete' && !empty($_POST['skill_id'])) {
                $model->deleteSkill((int)$_POST['skill_id']);
                Session::flash('success', '技能已刪除');
            }
            redirect('/staff.php?action=manage_skills');
        }

        $skillGroups = $model->getSkillGroups();
        $distinctGroups = $model->getDistinctSkillGroups();
        $distinctCategories = $model->getDistinctCategories();

        $pageTitle = '技能項目管理';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/manage_skills.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 停用/啟用 ----
    case 'toggle':
        Auth::requirePermission('staff.manage');
        if (verify_csrf()) {
            $id = (int)$_GET['id'];
            // 不能停用自己
            if ($id === Auth::id()) {
                Session::flash('error', '不能停用自己的帳號');
            } else {
                $model->toggleActive($id);
                Session::flash('success', '已更新人員狀態');
            }
        }
        redirect('/staff.php');
        break;

    // ---- 重設密碼 ----
    case 'reset_password':
        Auth::requirePermission('staff.manage');
        $id = (int)($_GET['id'] ?? 0);
        $user = $model->getById($id);
        if (!$user) { Session::flash('error', '人員不存在'); redirect('/staff.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/staff.php?action=view&id='.$id); }

            $newPassword = trim($_POST['new_password'] ?? '');
            $confirmPassword = trim($_POST['confirm_password'] ?? '');

            if (strlen($newPassword) < 6) {
                Session::flash('error', '密碼長度至少 6 個字元');
                redirect('/staff.php?action=reset_password&id=' . $id);
            } elseif ($newPassword !== $confirmPassword) {
                Session::flash('error', '兩次密碼輸入不一致');
                redirect('/staff.php?action=reset_password&id=' . $id);
            } else {
                $model->resetPassword($id, $newPassword);
                Session::flash('success', '密碼已重設');
                redirect('/staff.php?action=view&id=' . $id);
            }
        }

        $pageTitle = '重設密碼 - ' . $user['real_name'];
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/reset_password.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 解除鎖定 ----
    case 'unlock':
        Auth::requirePermission('staff.manage');
        if (verify_csrf()) {
            $id = (int)$_GET['id'];
            $model->unlockAccount($id);
            Session::flash('success', '帳號已解除鎖定');
        }
        redirect('/staff.php?action=view&id=' . (int)$_GET['id']);
        break;

    // ---- 分公司管理 ----
    case 'branches':
        if (Auth::user()['role'] !== 'boss') { Session::flash('error', '權限不足'); redirect('/staff.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $subAction = isset($_POST['sub_action']) ? $_POST['sub_action'] : '';
            if ($subAction === 'create') {
                $model->createBranch($_POST);
                Session::flash('success', '分公司已新增');
            } elseif ($subAction === 'update' && !empty($_POST['branch_id'])) {
                $model->updateBranch((int)$_POST['branch_id'], $_POST);
                Session::flash('success', '分公司已更新');
            }
            redirect('/staff.php?action=branches');
        }

        $branches = $model->getAllBranchesIncludeInactive();
        $pageTitle = '分公司管理';
        $currentPage = 'staff';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/staff/branches.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    default:
        redirect('/staff.php');
}
