<div class="d-flex justify-between align-center mb-2">
    <h2>待簽核</h2>
    <?php if ($canManageRules): ?>
    <a href="/approvals.php?action=settings" class="btn btn-outline btn-sm">簽核設定</a>
    <?php endif; ?>
</div>

<?php if (empty($pendingList)): ?>
<div class="card">
    <p class="text-muted text-center" style="padding:40px">目前沒有待簽核的項目 ✅</p>
</div>
<?php else: ?>
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>模組</th>
                    <th>單據</th>
                    <th>金額</th>
                    <th>送簽人</th>
                    <th>送簽時間</th>
                    <th style="width:200px">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pendingList as $item):
                    $info = $item['target_info'];
                ?>
                <tr>
                    <td><span class="badge badge-primary"><?= e(ApprovalModel::moduleLabel($item['module'])) ?></span></td>
                    <td>
                        <?php if (!empty($info['url'])): ?>
                        <a href="<?= e($info['url']) ?>"><?= e($info['label'] ?? '-') ?></a>
                        <?php else: ?>
                        <?= e($info['label'] ?? $item['module'] . ' #' . $item['target_id']) ?>
                        <?php endif; ?>
                    </td>
                    <td class="text-right"><?= !empty($info['amount']) ? '$' . number_format($info['amount']) : '-' ?></td>
                    <td><?= e($item['submitter_name'] ?? '-') ?></td>
                    <td><?= e(substr($item['submitted_at'], 0, 16)) ?></td>
                    <td>
                        <div class="d-flex gap-1">
                            <form method="POST" action="/approvals.php?action=approve" style="display:inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="flow_id" value="<?= $item['id'] ?>">
                                <input type="hidden" name="module" value="<?= e($item['module']) ?>">
                                <input type="hidden" name="target_id" value="<?= $item['target_id'] ?>">
                                <input type="hidden" name="redirect" value="/approvals.php">
                                <input type="text" name="comment" class="form-control" placeholder="意見(選填)" style="display:inline-block;width:100px;font-size:.8rem">
                                <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('確定核准？')">核准</button>
                            </form>
                            <form method="POST" action="/approvals.php?action=reject" style="display:inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="flow_id" value="<?= $item['id'] ?>">
                                <input type="hidden" name="module" value="<?= e($item['module']) ?>">
                                <input type="hidden" name="target_id" value="<?= $item['target_id'] ?>">
                                <input type="hidden" name="redirect" value="/approvals.php">
                                <input type="hidden" name="comment" value="">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="var c=prompt('退回原因：');if(!c)return false;this.form.querySelector('input[name=comment]').value=c;return true;">退回</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
