<?php
// 安全取值函式（避免 null 傳入 e() 造成 TypeError）
function pv($product, $field, $default = '') {
    if (!$product) return $default;
    return isset($product[$field]) && $product[$field] !== null ? (string)$product[$field] : $default;
}
?>
<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2><?= $product ? '編輯產品' : '新增產品' ?></h2>
    <a href="<?= $product ? '/products.php?action=view&id=' . (int)$product['id'] : '/products.php' ?>" class="btn btn-outline btn-sm">返回</a>
</div>

<div class="card" style="max-width:900px">
    <form method="POST" action="/products.php?action=<?= $product ? 'edit&id=' . (int)$product['id'] : 'create' ?>">
        <?= csrf_field() ?>

        <div class="form-grid-2">
            <div class="form-group">
                <label>產品名稱 <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= e(pv($product, 'name')) ?>" required>
            </div>
            <div class="form-group">
                <label>型號</label>
                <input type="text" name="model" class="form-control" value="<?= e(pv($product, 'model')) ?>">
            </div>
        </div>

        <div class="form-grid-2">
            <div class="form-group">
                <label>品牌</label>
                <input type="text" name="brand" class="form-control" value="<?= e(pv($product, 'brand')) ?>">
            </div>
            <div class="form-group">
                <label>供應商</label>
                <input type="text" name="supplier" class="form-control" value="<?= e(pv($product, 'supplier')) ?>">
            </div>
        </div>

        <div class="form-grid-2">
            <div class="form-group">
                <label>分類</label>
                <select name="category_id" class="form-control">
                    <option value="">未分類</option>
                    <?php foreach ($allCategories as $cat): ?>
                    <option value="<?= (int)$cat['id'] ?>" <?= ($product && isset($product['category_id']) && $product['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                        <?= e($cat['full_path']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>單位</label>
                <input type="text" name="unit" class="form-control" value="<?= e(pv($product, 'unit', '台')) ?>" placeholder="台">
            </div>
        </div>

        <div class="form-grid-2">
            <div class="form-group">
                <label>售價</label>
                <input type="number" name="price" class="form-control" value="<?= (int)pv($product, 'price', '0') ?>" min="0">
            </div>
            <div class="form-group">
                <label>成本</label>
                <input type="number" name="cost" class="form-control" value="<?= (int)pv($product, 'cost', '0') ?>" min="0">
            </div>
        </div>

        <div class="form-grid-2">
            <div class="form-group">
                <label>零售價</label>
                <input type="number" name="retail_price" class="form-control" value="<?= (int)pv($product, 'retail_price', '0') ?>" min="0">
            </div>
            <div class="form-group">
                <label>工資</label>
                <input type="number" name="labor_cost" class="form-control" value="<?= (int)pv($product, 'labor_cost', '0') ?>" min="0">
            </div>
        </div>

        <div class="form-group">
            <label>規格</label>
            <textarea name="specifications" class="form-control" rows="2"><?= e(pv($product, 'specifications')) ?></textarea>
        </div>

        <div class="form-group">
            <label>說明</label>
            <textarea name="description" class="form-control" rows="3"><?= e(pv($product, 'description')) ?></textarea>
        </div>

        <div class="form-group">
            <label>保固說明</label>
            <input type="text" name="warranty_text" class="form-control" value="<?= e(pv($product, 'warranty_text')) ?>">
        </div>

        <?php if ($product): ?>
        <div class="form-group">
            <label class="checkbox-label">
                <input type="checkbox" name="is_active" value="1" <?= (!empty($product['is_active'])) ? 'checked' : '' ?>>
                啟用
            </label>
        </div>
        <?php endif; ?>

        <div class="d-flex gap-1 mt-2">
            <button type="submit" class="btn btn-primary"><?= $product ? '更新' : '新增' ?></button>
            <a href="<?= $product ? '/products.php?action=view&id=' . (int)$product['id'] : '/products.php' ?>" class="btn btn-outline">取消</a>
        </div>
    </form>
</div>

<style>
.form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
@media (max-width: 480px) { .form-grid-2 { grid-template-columns: 1fr; } }
.checkbox-label { display: flex; align-items: center; gap: 6px; cursor: pointer; }
</style>
