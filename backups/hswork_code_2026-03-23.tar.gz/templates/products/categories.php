<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>產品分類管理</h2>
    <div class="d-flex gap-1">
        <a href="/products.php" class="btn btn-outline btn-sm">返回產品目錄</a>
        <button type="button" class="btn btn-primary btn-sm" onclick="openCatModal()">+ 新增分類</button>
    </div>
</div>

<div class="card">
    <?php if (empty($categoriesTree)): ?>
        <p class="text-muted text-center mt-2">尚無分類</p>
    <?php else: ?>

    <?php
    // 整理成樹狀結構
    $catMap = array();
    foreach ($categoriesTree as $c) {
        $catMap[$c['id']] = $c;
    }
    $roots = array();
    $children = array();
    foreach ($categoriesTree as $c) {
        $pid = !empty($c['parent_id']) ? $c['parent_id'] : 0;
        if (!isset($children[$pid])) $children[$pid] = array();
        $children[$pid][] = $c;
    }
    ?>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>分類名稱</th>
                    <th class="text-right">子分類數</th>
                    <th class="text-right">產品數</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php
                function renderCatRow($cat, $children, $catMap, $depth, $allCategories) {
                    $indent = str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;', $depth);
                    $prefix = $depth > 0 ? '└ ' : '';
                    $bgColor = $depth === 0 ? 'background:#f8f9fa;font-weight:600' : ($depth === 1 ? '' : 'color:var(--gray-500)');
                ?>
                <tr style="<?= $bgColor ?>">
                    <td><?= $indent . $prefix . e($cat['name']) ?></td>
                    <td class="text-right"><?= (int)$cat['child_count'] ?></td>
                    <td class="text-right"><?= (int)$cat['product_count'] ?></td>
                    <td>
                        <div class="d-flex gap-1">
                            <button type="button" class="btn btn-outline btn-sm" onclick='openCatModal(<?= json_encode(array("id" => $cat["id"], "name" => $cat["name"], "parent_id" => $cat["parent_id"])) ?>)'>編輯</button>
                            <?php if ((int)$cat['child_count'] === 0 && (int)$cat['product_count'] === 0): ?>
                            <form method="POST" action="/products.php?action=category_delete" style="display:inline" onsubmit="return confirm('確認刪除分類「<?= e($cat['name']) ?>」？')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($cat['id']) ?>">
                                <button type="submit" class="btn btn-outline btn-sm" style="color:var(--danger)">刪除</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php
                    $cid = $cat['id'];
                    if (isset($children[$cid])) {
                        foreach ($children[$cid] as $child) {
                            renderCatRow($child, $children, $catMap, $depth + 1, $allCategories);
                        }
                    }
                }

                // 渲染根分類
                $rootCats = isset($children[0]) ? $children[0] : array();
                // 也要加入 parent_id IS NULL 的
                foreach ($categoriesTree as $c) {
                    if (empty($c['parent_id']) && !isset($children[0])) {
                        $rootCats[] = $c;
                    }
                }
                // 去重
                $rendered = array();
                foreach ($categoriesTree as $c) {
                    if (empty($c['parent_id'])) {
                        if (!isset($rendered[$c['id']])) {
                            renderCatRow($c, $children, $catMap, 0, $allCategories);
                            $rendered[$c['id']] = true;
                        }
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- Modal -->
<div class="modal-overlay" id="catModal" style="display:none">
    <div class="modal-content" style="max-width:450px">
        <div class="d-flex justify-between align-center mb-2">
            <h3 id="catModalTitle">新增分類</h3>
            <a href="javascript:void(0)" onclick="closeCatModal()" style="font-size:1.5rem;color:var(--gray-400)">&times;</a>
        </div>
        <form method="POST" action="/products.php?action=category_save">
            <?= csrf_field() ?>
            <input type="hidden" name="id" id="catId">

            <div class="form-group">
                <label>分類名稱 <span class="text-danger">*</span></label>
                <input type="text" name="name" id="catName" class="form-control" required>
            </div>

            <div class="form-group">
                <label>上層分類</label>
                <select name="parent_id" id="catParent" class="form-control">
                    <option value="">無（最上層）</option>
                    <?php foreach ($allCategories as $cat): ?>
                    <option value="<?= e($cat['id']) ?>"><?= e($cat['full_path']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="d-flex gap-1">
                <button type="submit" class="btn btn-primary">儲存</button>
                <button type="button" class="btn btn-outline" onclick="closeCatModal()">取消</button>
            </div>
        </form>
    </div>
</div>

<style>
.modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,.4); z-index: 999; display: flex; align-items: center; justify-content: center; }
.modal-content { background: #fff; border-radius: var(--radius); padding: 24px; width: 90%; }
</style>

<script>
function openCatModal(data) {
    var modal = document.getElementById('catModal');
    if (data) {
        document.getElementById('catModalTitle').textContent = '編輯分類';
        document.getElementById('catId').value = data.id;
        document.getElementById('catName').value = data.name;
        document.getElementById('catParent').value = data.parent_id || '';
    } else {
        document.getElementById('catModalTitle').textContent = '新增分類';
        document.getElementById('catId').value = '';
        document.getElementById('catName').value = '';
        document.getElementById('catParent').value = '';
    }
    modal.style.display = 'flex';
}
function closeCatModal() {
    document.getElementById('catModal').style.display = 'none';
}
document.getElementById('catModal').addEventListener('click', function(e) {
    if (e.target === this) closeCatModal();
});
</script>
