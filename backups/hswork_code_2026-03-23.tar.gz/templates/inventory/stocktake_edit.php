<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>盤點 - <?= e($stocktake['stocktake_number']) ?></h2>
    <div class="d-flex gap-1 align-center">
        <?php
            $statusClass = ($stocktake['status'] === '盤點中') ? 'badge-warning' : (($stocktake['status'] === '已完成') ? 'badge-success' : 'badge-muted');
        ?>
        <span class="badge <?= $statusClass ?>" style="font-size:.85rem"><?= e($stocktake['status']) ?></span>
        <a href="/inventory.php?action=stocktake_list" class="btn btn-outline btn-sm">返回列表</a>
    </div>
</div>

<div class="card mb-2">
    <div class="product-info-grid">
        <div class="product-info-item">
            <span class="product-info-label">倉庫</span>
            <span><?= e(!empty($stocktake['warehouse_name']) ? $stocktake['warehouse_name'] : '-') ?></span>
        </div>
        <div class="product-info-item">
            <span class="product-info-label">日期</span>
            <span><?= e($stocktake['stocktake_date']) ?></span>
        </div>
        <div class="product-info-item">
            <span class="product-info-label">品項數</span>
            <span><?= count($stocktakeItems) ?></span>
        </div>
        <?php if (!empty($stocktake['note'])): ?>
        <div class="product-info-item">
            <span class="product-info-label">備註</span>
            <span><?= e($stocktake['note']) ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $isEditable = ($stocktake['status'] === '盤點中' && $canManage); ?>

<div class="card">
    <?php if ($isEditable): ?>
    <form method="POST" action="/inventory.php?action=stocktake_edit&id=<?= e($stocktake['id']) ?>" id="stocktakeForm">
        <?= csrf_field() ?>
        <input type="hidden" name="post_action" id="postAction" value="save">
    <?php endif; ?>

    <?php if (empty($stocktakeItems)): ?>
        <p class="text-muted text-center mt-2">此倉庫目前無庫存品項</p>
    <?php else: ?>

    <!-- 手機卡片 -->
    <div class="staff-cards show-mobile">
        <?php foreach ($stocktakeItems as $item): ?>
        <?php
            $hasDiff = ($item['actual_qty'] !== null && (int)$item['diff_qty'] !== 0);
            $borderColor = $hasDiff ? 'var(--danger)' : 'var(--gray-200)';
        ?>
        <div class="staff-card" style="border-left:3px solid <?= $borderColor ?>">
            <div class="d-flex justify-between align-center">
                <strong><?= e(!empty($item['product_name']) ? $item['product_name'] : '-') ?></strong>
            </div>
            <?php if (!empty($item['product_model'])): ?>
            <div style="font-size:.85rem;color:var(--gray-500)"><?= e($item['product_model']) ?></div>
            <?php endif; ?>
            <div class="staff-card-meta" style="flex-wrap:wrap;margin-top:8px">
                <span>系統 <strong><?= (int)$item['system_qty'] ?></strong></span>
                <?php if ($isEditable): ?>
                <span style="display:flex;align-items:center;gap:4px">
                    實際
                    <input type="number" name="items[<?= e($item['id']) ?>][actual_qty]" value="<?= ($item['actual_qty'] !== null) ? (int)$item['actual_qty'] : '' ?>" class="form-control" style="width:70px;padding:4px 6px" min="0">
                    <input type="hidden" name="items[<?= e($item['id']) ?>][system_qty]" value="<?= (int)$item['system_qty'] ?>">
                </span>
                <?php else: ?>
                <span>實際 <strong><?= ($item['actual_qty'] !== null) ? (int)$item['actual_qty'] : '-' ?></strong></span>
                <?php endif; ?>
                <?php if ($item['actual_qty'] !== null): ?>
                <span style="color:<?= ((int)$item['diff_qty'] !== 0) ? 'var(--danger)' : 'var(--success)' ?>;font-weight:600">
                    差異 <?= ((int)$item['diff_qty'] > 0 ? '+' : '') . (int)$item['diff_qty'] ?>
                </span>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- 桌面表格 -->
    <div class="table-responsive hide-mobile">
        <table class="table">
            <thead>
                <tr>
                    <th>商品名稱</th>
                    <th>型號</th>
                    <th>單位</th>
                    <th class="text-right">系統數量</th>
                    <th class="text-right">實際數量</th>
                    <th class="text-right">差異</th>
                    <th>備註</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($stocktakeItems as $item): ?>
                <?php $hasDiff = ($item['actual_qty'] !== null && (int)$item['diff_qty'] !== 0); ?>
                <tr style="<?= $hasDiff ? 'background:#fff5f5' : '' ?>">
                    <td style="font-weight:600"><?= e(!empty($item['product_name']) ? $item['product_name'] : '-') ?></td>
                    <td style="font-size:.85rem"><?= e(!empty($item['product_model']) ? $item['product_model'] : '-') ?></td>
                    <td><?= e(!empty($item['unit']) ? $item['unit'] : '-') ?></td>
                    <td class="text-right"><?= (int)$item['system_qty'] ?></td>
                    <td class="text-right">
                        <?php if ($isEditable): ?>
                        <input type="number" name="items[<?= e($item['id']) ?>][actual_qty]" value="<?= ($item['actual_qty'] !== null) ? (int)$item['actual_qty'] : '' ?>" class="form-control" style="width:80px;text-align:right;padding:4px 6px;display:inline-block" min="0">
                        <input type="hidden" name="items[<?= e($item['id']) ?>][system_qty]" value="<?= (int)$item['system_qty'] ?>">
                        <?php else: ?>
                        <?= ($item['actual_qty'] !== null) ? (int)$item['actual_qty'] : '-' ?>
                        <?php endif; ?>
                    </td>
                    <td class="text-right">
                        <?php if ($item['actual_qty'] !== null): ?>
                        <span style="color:<?= ((int)$item['diff_qty'] !== 0) ? 'var(--danger)' : 'var(--success)' ?>;font-weight:600">
                            <?= ((int)$item['diff_qty'] > 0 ? '+' : '') . (int)$item['diff_qty'] ?>
                        </span>
                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($isEditable): ?>
                        <input type="text" name="items[<?= e($item['id']) ?>][note]" value="<?= e(!empty($item['note']) ? $item['note'] : '') ?>" class="form-control" style="width:120px;padding:4px 6px" placeholder="備註">
                        <?php else: ?>
                        <?= e(!empty($item['note']) ? $item['note'] : '-') ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <?php if ($isEditable): ?>
    <div class="d-flex gap-1 mt-2" style="flex-wrap:wrap">
        <button type="submit" class="btn btn-primary" onclick="document.getElementById('postAction').value='save'">儲存盤點</button>
        <button type="submit" class="btn btn-success" onclick="if(!confirm('確認完成盤點？差異將自動調整庫存數量')){event.preventDefault();return;}document.getElementById('postAction').value='complete'">完成盤點</button>
        <form method="POST" action="/inventory.php?action=stocktake_cancel" style="display:inline" onsubmit="return confirm('確認取消此盤點？')">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($stocktake['id']) ?>">
            <button type="submit" class="btn btn-outline" style="color:var(--danger)">取消盤點</button>
        </form>
    </div>
    </form>
    <?php endif; ?>
</div>

<style>
.product-info-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; }
.product-info-item { display: flex; flex-direction: column; }
.product-info-label { font-size: .75rem; color: var(--gray-500); margin-bottom: 2px; }
.badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: .75rem; font-weight: 600; }
.badge-success { background: #e6f9ee; color: var(--success); }
.badge-warning { background: #fff8e1; color: #f57f17; }
.badge-muted { background: var(--gray-100); color: var(--gray-500); }
.staff-cards { display: flex; flex-direction: column; gap: 8px; }
.staff-card { border: 1px solid var(--gray-200); border-radius: var(--radius); padding: 12px; }
.staff-card-meta { font-size: .8rem; color: var(--gray-500); display: flex; gap: 8px; margin-top: 4px; }
.show-mobile { display: flex; }
.hide-mobile { display: none; }
@media (min-width: 768px) { .show-mobile { display: none !important; } .hide-mobile { display: block !important; } }
</style>
