<?php
$isEdit = !empty($record);
$statusOptions = FinanceModel::receivableStatusOptions();
$categoryOptions = FinanceModel::invoiceCategoryOptions();
$paymentMethodOptions = FinanceModel::paymentMethodOptions();
$paymentTermsOptions = FinanceModel::paymentTermsOptions();
?>
<h2><?= $isEdit ? '編輯請款單 - ' . e($record['invoice_number']) : '新增請款單' ?></h2>

<form method="POST" class="mt-2">
    <?= csrf_field() ?>

    <!-- 訂單資訊 -->
    <div class="card">
        <div class="card-header">訂單資訊</div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 auto;min-width:200px">
                <label>請款單號</label>
                <input type="text" class="form-control" value="<?= e($isEdit ? $record['invoice_number'] : peek_next_doc_number('receivables')) ?>" readonly style="background:#f0f7ff;font-weight:600;color:var(--primary)">
            </div>
            <div class="form-group">
                <label>請款日期 *</label>
                <input type="date" max="2099-12-31" name="invoice_date" class="form-control" value="<?= e(!empty($record['invoice_date']) ? $record['invoice_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>案件編號</label>
                <input type="text" name="case_id" class="form-control" value="<?= e(!empty($record['case_id']) ? $record['case_id'] : '') ?>" placeholder="選填">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>客戶名稱</label>
                <input type="text" name="customer_name" class="form-control" value="<?= e(!empty($record['customer_name']) ? $record['customer_name'] : '') ?>">
            </div>
            <div class="form-group">
                <label>分公司</label>
                <select name="branch_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= (!empty($record['branch_id']) && $record['branch_id'] == $b['id']) ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>業務</label>
                <select name="sales_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($salesUsers as $u): ?>
                    <option value="<?= $u['id'] ?>" <?= (!empty($record['sales_id']) && $record['sales_id'] == $u['id']) ? 'selected' : '' ?>><?= e($u['real_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>請款類別</label>
                <select name="invoice_category" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($categoryOptions as $cv => $cl): ?>
                    <option value="<?= e($cv) ?>" <?= (!empty($record['invoice_category']) && $record['invoice_category'] === $cv) ? 'selected' : '' ?>><?= e($cl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <?php foreach ($statusOptions as $sv => $sl): ?>
                    <option value="<?= e($sv) ?>" <?= ((!empty($record['status']) ? $record['status'] : '待請款') === $sv) ? 'selected' : '' ?>><?= e($sl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <!-- 客戶資訊 -->
    <div class="card">
        <div class="card-header">客戶資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>發票抬頭</label>
                <input type="text" name="invoice_title" class="form-control" value="<?= e(!empty($record['invoice_title']) ? $record['invoice_title'] : '') ?>">
            </div>
            <div class="form-group">
                <label>統一編號</label>
                <input type="text" name="tax_id" class="form-control" value="<?= e(!empty($record['tax_id']) ? $record['tax_id'] : '') ?>" maxlength="8">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>電話</label>
                <input type="text" name="phone" class="form-control" value="<?= e(!empty($record['phone']) ? $record['phone'] : '') ?>">
            </div>
            <div class="form-group">
                <label>手機</label>
                <input type="text" name="mobile" class="form-control" value="<?= e(!empty($record['mobile']) ? $record['mobile'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>發票寄送 Email</label>
                <input type="email" name="invoice_email" class="form-control" value="<?= e(!empty($record['invoice_email']) ? $record['invoice_email'] : '') ?>">
            </div>
            <div class="form-group">
                <label>發票寄送地址</label>
                <input type="text" name="invoice_address" class="form-control" value="<?= e(!empty($record['invoice_address']) ? $record['invoice_address'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>付款方式</label>
                <select name="payment_method" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($paymentMethodOptions as $pv => $pl): ?>
                    <option value="<?= e($pv) ?>" <?= (!empty($record['payment_method']) && $record['payment_method'] === $pv) ? 'selected' : '' ?>><?= e($pl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>付款條件</label>
                <select name="payment_terms" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($paymentTermsOptions as $tv => $tl): ?>
                    <option value="<?= e($tv) ?>" <?= (!empty($record['payment_terms']) && $record['payment_terms'] === $tv) ? 'selected' : '' ?>><?= e($tl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <!-- 合併請款案件 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>合併請款案件</span>
            <button type="button" class="btn btn-outline btn-sm" onclick="addItemRow()">+ 新增一行</button>
        </div>
        <div class="table-responsive">
            <table class="table" id="itemsTable">
                <thead>
                    <tr>
                        <th>進件編號-主</th>
                        <th>進件編號-併</th>
                        <th style="text-align:right">金額</th>
                        <th>備註</th>
                        <th style="width:60px">操作</th>
                    </tr>
                </thead>
                <tbody id="itemsBody">
                    <?php
                    $itemList = !empty($items) ? $items : array();
                    if (empty($itemList)) {
                        $itemList = array(array('main_case_number' => '', 'merge_case_number' => '', 'amount' => '', 'note' => ''));
                    }
                    foreach ($itemList as $idx => $item):
                    ?>
                    <tr class="item-row">
                        <td><input type="text" name="items[<?= $idx ?>][main_case_number]" class="form-control" value="<?= e(!empty($item['main_case_number']) ? $item['main_case_number'] : '') ?>"></td>
                        <td><input type="text" name="items[<?= $idx ?>][merge_case_number]" class="form-control" value="<?= e(!empty($item['merge_case_number']) ? $item['merge_case_number'] : '') ?>"></td>
                        <td><input type="number" name="items[<?= $idx ?>][amount]" class="form-control item-amount" min="0" value="<?= e(!empty($item['amount']) ? $item['amount'] : '') ?>" oninput="calcSubtotal()" style="text-align:right"></td>
                        <td><input type="text" name="items[<?= $idx ?>][note]" class="form-control" value="<?= e(!empty($item['note']) ? $item['note'] : '') ?>"></td>
                        <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">刪除</button></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2" style="text-align:right;font-weight:600">小計</td>
                        <td style="text-align:right;font-weight:600" id="subtotalDisplay">0</td>
                        <td colspan="2"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <input type="hidden" name="subtotal" id="subtotalInput" value="<?= e(!empty($record['subtotal']) ? $record['subtotal'] : 0) ?>">
    </div>

    <!-- 備註 -->
    <div class="card">
        <div class="card-header">備註</div>
        <div class="form-group">
            <textarea name="note" class="form-control" rows="3"><?= e(!empty($record['note']) ? $record['note'] : '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '更新' : '儲存' ?></button>
        <a href="/receivables.php" class="btn btn-outline">取消</a>
    </div>
</form>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
.item-row td { padding: 4px 6px; vertical-align: middle; }
.item-row .form-control { margin-bottom: 0; }
</style>

<script>
var itemIndex = <?= count($itemList) ?>;

function addItemRow() {
    var tbody = document.getElementById('itemsBody');
    var html = '<tr class="item-row">' +
        '<td><input type="text" name="items[' + itemIndex + '][main_case_number]" class="form-control"></td>' +
        '<td><input type="text" name="items[' + itemIndex + '][merge_case_number]" class="form-control"></td>' +
        '<td><input type="number" name="items[' + itemIndex + '][amount]" class="form-control item-amount" min="0" oninput="calcSubtotal()" style="text-align:right"></td>' +
        '<td><input type="text" name="items[' + itemIndex + '][note]" class="form-control"></td>' +
        '<td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">刪除</button></td>' +
        '</tr>';
    tbody.insertAdjacentHTML('beforeend', html);
    itemIndex++;
}

function removeItemRow(btn) {
    var row = btn.closest('.item-row');
    if (row) {
        row.remove();
        calcSubtotal();
    }
}

function calcSubtotal() {
    var inputs = document.querySelectorAll('.item-amount');
    var total = 0;
    for (var i = 0; i < inputs.length; i++) {
        var val = parseFloat(inputs[i].value);
        if (!isNaN(val)) {
            total += val;
        }
    }
    document.getElementById('subtotalDisplay').textContent = total.toLocaleString();
    document.getElementById('subtotalInput').value = total;
}

// 初始化小計
calcSubtotal();
</script>
