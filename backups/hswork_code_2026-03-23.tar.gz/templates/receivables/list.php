<?php
$statusOptions = FinanceModel::receivableStatusOptions();
$statusBadgeMap = array(
    '待請款'   => 'badge-info',
    '已請款'   => 'badge-primary',
    '部分收款' => 'badge-warning',
    '已收款'   => 'badge-success',
    '逾期'     => 'badge-danger',
    '取消'     => 'badge-secondary',
);
?>
<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>應收帳款</h2>
    <a href="/receivables.php?action=create" class="btn btn-primary btn-sm">+ 新增請款單</a>
</div>

<!-- 篩選 -->
<div class="card">
    <form method="GET" action="/receivables.php" class="filter-form">
        <div class="filter-row">
            <div class="form-group">
                <select name="status" class="form-control">
                    <option value="">全部狀態</option>
                    <?php foreach ($statusOptions as $sv => $sl): ?>
                    <option value="<?= e($sv) ?>" <?= (!empty($filters['status']) && $filters['status'] === $sv) ? 'selected' : '' ?>><?= e($sl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="flex:2">
                <input type="text" name="keyword" class="form-control" value="<?= e(!empty($filters['keyword']) ? $filters['keyword'] : '') ?>" placeholder="搜尋請款單號/客戶名稱/發票抬頭..." autocomplete="off">
            </div>
            <div class="form-group" style="align-self:flex-end;flex:0;display:flex;gap:6px;">
                <button type="submit" class="btn btn-primary btn-sm">搜尋</button>
                <a href="/receivables.php" class="btn btn-outline btn-sm">清除</a>
            </div>
        </div>
    </form>
</div>

<!-- 列表 -->
<div class="card">
    <?php if (empty($data)): ?>
        <p class="text-muted text-center mt-2">目前無應收帳款資料</p>
    <?php else: ?>

    <!-- 手機版卡片 -->
    <div class="receivable-cards show-mobile">
        <?php foreach ($data as $row): ?>
        <div class="receivable-card" onclick="location.href='/receivables.php?action=edit&id=<?= $row['id'] ?>'">
            <div class="d-flex justify-between align-center">
                <strong><?= e(!empty($row['invoice_number']) ? $row['invoice_number'] : '') ?></strong>
                <?php $badgeCls = !empty($statusBadgeMap[$row['status']]) ? $statusBadgeMap[$row['status']] : 'badge-secondary'; ?>
                <span class="badge <?= $badgeCls ?>"><?= e(!empty($row['status']) ? $row['status'] : '-') ?></span>
            </div>
            <div class="receivable-card-title"><?= e(!empty($row['customer_name']) ? $row['customer_name'] : '-') ?></div>
            <div class="receivable-card-meta">
                <span><?= e(!empty($row['branch_name']) ? $row['branch_name'] : '') ?></span>
                <span><?= e(!empty($row['sales_name']) ? $row['sales_name'] : '') ?></span>
                <span>$<?= number_format(!empty($row['subtotal']) ? $row['subtotal'] : 0) ?></span>
                <?php if (!empty($row['invoice_date'])): ?><span><?= date('Y/m/d', strtotime($row['invoice_date'])) ?></span><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- 桌面版表格 -->
    <div class="table-responsive hide-mobile">
        <table class="table">
            <thead>
                <tr>
                    <th>請款單號</th>
                    <th>請款日期</th>
                    <th>客戶名稱</th>
                    <th>分公司</th>
                    <th>業務</th>
                    <th style="text-align:right">金額</th>
                    <th>狀態</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $row): ?>
                <tr>
                    <td><a href="/receivables.php?action=edit&id=<?= $row['id'] ?>"><?= e(!empty($row['invoice_number']) ? $row['invoice_number'] : '') ?></a></td>
                    <td><?= !empty($row['invoice_date']) ? date('Y/m/d', strtotime($row['invoice_date'])) : '-' ?></td>
                    <td><?= e(!empty($row['customer_name']) ? $row['customer_name'] : '-') ?></td>
                    <td><?= e(!empty($row['branch_name']) ? $row['branch_name'] : '-') ?></td>
                    <td><?= e(!empty($row['sales_name']) ? $row['sales_name'] : '-') ?></td>
                    <td style="text-align:right"><?= number_format(!empty($row['subtotal']) ? $row['subtotal'] : 0) ?></td>
                    <td>
                        <?php $badgeCls = !empty($statusBadgeMap[$row['status']]) ? $statusBadgeMap[$row['status']] : 'badge-secondary'; ?>
                        <span class="badge <?= $badgeCls ?>"><?= e(!empty($row['status']) ? $row['status'] : '-') ?></span>
                    </td>
                    <td>
                        <a href="/receivables.php?action=edit&id=<?= $row['id'] ?>" class="btn btn-outline btn-sm">編輯</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php endif; ?>
    <?php require __DIR__ . '/../layouts/pagination.php'; ?>
</div>

<style>
.filter-row { display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; }
.filter-row .form-group { flex: 1; min-width: 140px; margin-bottom: 0; }
.receivable-cards { display: flex; flex-direction: column; gap: 8px; }
.receivable-card {
    border: 1px solid var(--gray-200); border-radius: var(--radius);
    padding: 12px; cursor: pointer; transition: box-shadow .15s;
}
.receivable-card:hover { box-shadow: var(--shadow); }
.receivable-card-title { font-weight: 500; margin: 4px 0; }
.receivable-card-meta { font-size: .8rem; color: var(--gray-500); display: flex; gap: 8px; flex-wrap: wrap; }
.show-mobile { display: flex; }
.hide-mobile { display: none; }
@media (min-width: 768px) {
    .show-mobile { display: none !important; }
    .hide-mobile { display: block !important; }
}
</style>
