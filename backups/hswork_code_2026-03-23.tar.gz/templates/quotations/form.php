<?php
$isEdit = !empty($quote);
$fmt = $isEdit ? $quote['format'] : 'simple';
$sections = $isEdit ? $quote['sections'] : array(array('title' => '', 'items' => array(array())));
?>
<h2><?= $isEdit ? '編輯報價單 - ' . e($quote['quotation_number']) : '新增報價單' ?></h2>

<form method="POST" class="mt-2" id="quoteForm">
    <?= csrf_field() ?>

    <!-- 客戶資訊 -->
    <div class="card">
        <div class="card-header">客戶資訊</div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 auto;min-width:200px">
                <label>報價單編號</label>
                <input type="text" class="form-control" value="<?= e($isEdit ? $quote['quotation_number'] : peek_next_doc_number('quotations')) ?>" readonly style="background:#f0f7ff;font-weight:600;color:var(--primary)">
            </div>
            <?php
            $custNo = '';
            if (!empty($quote['customer_id'] ?? $_GET['customer_id'] ?? '')) {
                try {
                    $cStmt = Database::getInstance()->prepare('SELECT customer_no FROM customers WHERE id = ?');
                    $cStmt->execute(array($quote['customer_id'] ?? $_GET['customer_id']));
                    $cRow = $cStmt->fetch(PDO::FETCH_ASSOC);
                    if ($cRow) $custNo = $cRow['customer_no'];
                } catch (Exception $e) {}
            }
            ?>
            <div class="form-group" style="flex:0 0 auto;min-width:160px">
                <label>客戶編號</label>
                <input type="text" id="quoteCustomerNo" class="form-control" value="<?= e($custNo) ?>" readonly style="background:#f5f5f5;color:#888">
            </div>
            <div class="form-group" style="position:relative">
                <label>客戶名稱 *</label>
                <input type="text" name="customer_name" id="qCustName" class="form-control" value="<?= e($quote['customer_name'] ?? $_GET['customer_name'] ?? '') ?>" required autocomplete="off">
                <input type="hidden" name="customer_id" id="qCustId" value="<?= e($quote['customer_id'] ?? $_GET['customer_id'] ?? '') ?>">
                <div id="qCustDropdown" style="display:none;position:absolute;top:100%;left:0;right:0;z-index:100;background:#fff;border:1px solid var(--gray-200);border-radius:6px;max-height:200px;overflow-y:auto;box-shadow:0 4px 12px rgba(0,0,0,.15)"></div>
            </div>
            <div class="form-group">
                <label>連絡對象</label>
                <input type="text" name="contact_person" class="form-control" value="<?= e($quote['contact_person'] ?? $_GET['contact'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>連絡電話</label>
                <input type="text" name="contact_phone" class="form-control" value="<?= e($quote['contact_phone'] ?? $_GET['phone'] ?? '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>案場名稱</label>
                <input type="text" name="site_name" class="form-control" value="<?= e($quote['site_name'] ?? '') ?>">
            </div>
            <div class="form-group" style="flex:2">
                <label>施工地址</label>
                <input type="text" name="site_address" class="form-control" value="<?= e($quote['site_address'] ?? $_GET['address'] ?? '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>發票抬頭</label>
                <input type="text" name="invoice_title" class="form-control" value="<?= e($quote['invoice_title'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>統編</label>
                <input type="text" name="invoice_tax_id" class="form-control" value="<?= e($quote['invoice_tax_id'] ?? '') ?>">
            </div>
        </div>
    </div>

    <!-- 報價資訊 -->
    <div class="card">
        <div class="card-header">報價資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>報價日期 *</label>
                <input type="date" max="2099-12-31" name="quote_date" class="form-control" value="<?= e($quote['quote_date'] ?? date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>有效日期 *</label>
                <input type="date" max="2099-12-31" name="valid_date" class="form-control" value="<?= e($quote['valid_date'] ?? date('Y-m-d', strtotime('+30 days'))) ?>" required>
            </div>
            <div class="form-group">
                <label>承辦業務</label>
                <select name="sales_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($salespeople as $sp): ?>
                    <option value="<?= $sp['id'] ?>" <?= ($quote['sales_id'] ?? Auth::id()) == $sp['id'] ? 'selected' : '' ?>><?= e($sp['real_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <input type="hidden" name="case_id" value="<?= e($quote['case_id'] ?? $_GET['case_id'] ?? '') ?>">
            <div class="form-group">
                <label>據點</label>
                <select name="branch_id" class="form-control" required>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= ($quote['branch_id'] ?? (Session::getUser()['branch_id'] ?? '')) == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>報價格式 *</label>
                <div class="d-flex gap-2 mt-1">
                    <label class="checkbox-label"><input type="radio" name="format" value="simple" <?= $fmt === 'simple' ? 'checked' : '' ?> onchange="toggleFormat(this.value)"> 普銷</label>
                    <label class="checkbox-label"><input type="radio" name="format" value="project" <?= $fmt === 'project' ? 'checked' : '' ?> onchange="toggleFormat(this.value)"> 專案</label>
                </div>
            </div>
            <div class="form-group" style="flex:2;min-width:250px">
                <label>列印選項</label>
                <div class="mt-1" style="display:flex;flex-wrap:wrap;gap:12px">
                    <label class="checkbox-label"><input type="checkbox" name="hide_model_on_print" value="1" <?= !empty($quote['hide_model_on_print']) ? 'checked' : '' ?>> 不顯示型號</label>
                    <label class="checkbox-label"><input type="checkbox" name="tax_free" value="1" <?= !empty($quote['tax_free']) ? 'checked' : '' ?> onchange="recalcAll()"> 未稅(不開發票)</label>
                    <label class="checkbox-label"><input type="checkbox" name="has_discount" value="1" <?= !empty($quote['has_discount']) ? 'checked' : '' ?> onchange="toggleDiscount()"> 優惠價</label>
                </div>
            </div>
        </div>
    </div>

    <!-- 報價內容 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>報價內容</span>
            <button type="button" class="btn btn-outline btn-sm" id="btnAddSection" onclick="addSection()" style="<?= $fmt === 'simple' ? 'display:none' : '' ?>">+ 新增區段</button>
        </div>
        <div id="sectionsContainer">
            <?php foreach ($sections as $sIdx => $sec): ?>
            <div class="quote-section" data-sidx="<?= $sIdx ?>">
                <div class="quote-section-header" style="<?= $fmt === 'simple' ? 'display:none' : '' ?>">
                    <input type="text" name="sections[<?= $sIdx ?>][title]" class="form-control" placeholder="區段標題（如：電話線工程）" value="<?= e($sec['title'] ?? '') ?>">
                    <button type="button" class="btn btn-danger btn-sm" onclick="removeSection(this)" title="刪除區段">&times;</button>
                </div>
                <div class="table-responsive">
                    <table class="table quote-items-table">
                        <thead><tr>
                            <th style="width:30px">序</th>
                            <th style="min-width:160px">產品名稱</th>
                            <th style="width:120px">型號</th>
                            <th style="width:70px">數量</th>
                            <th style="width:50px">單位</th>
                            <th style="width:100px">單價</th>
                            <th style="width:90px">小計</th>
                            <th style="width:100px">備註</th>
                            <?php if ($canManage): ?><th style="width:100px">成本</th><?php endif; ?>
                            <th style="width:30px"></th>
                        </tr></thead>
                        <tbody>
                            <?php
                            $items = isset($sec['items']) ? $sec['items'] : array(array());
                            foreach ($items as $iIdx => $item):
                            ?>
                            <tr>
                                <td class="row-num"><?= $iIdx + 1 ?></td>
                                <td>
                                    <input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][item_name]" class="form-control item-name" value="<?= e($item['item_name'] ?? '') ?>" placeholder="品名（可手動輸入）" style="font-weight:600;font-size:.85rem">
                                    <input type="hidden" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][product_id]" value="<?= e($item['product_id'] ?? '') ?>">
                                </td>
                                <td><input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][model_number]" class="form-control item-model" value="<?= e($item['model_number'] ?? '') ?>" placeholder="型號" style="font-size:.8rem;color:#1565c0"></td>
                                <td><input type="number" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][quantity]" class="form-control item-qty" value="<?= e($item['quantity'] ?? 1) ?>" step="0.01" min="0" oninput="calcRow(this)"></td>
                                <td><input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][unit]" class="form-control item-unit" value="<?= e($item['unit'] ?? '式') ?>"></td>
                                <td><input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][unit_price]" class="form-control item-price" value="<?= e($item['unit_price'] ?? 0) ?>" oninput="calcRow(this)" inputmode="numeric"></td>
                                <td class="item-amount text-right"><?= number_format((float)($item['quantity'] ?? 1) * (float)($item['unit_price'] ?? 0)) ?></td>
                                <td><input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][remark]" class="form-control" value="<?= e($item['remark'] ?? '') ?>"></td>
                                <?php if ($canManage): ?>
                                <td><input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][unit_cost]" class="form-control item-cost" value="<?= e($item['unit_cost'] ?? 0) ?>" readonly style="background:#f5f5f5;color:#666"></td>
                                <?php endif; ?>
                                <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">&times;</button></td>
                            </tr>
                            <!-- 第二排：選擇工具列 -->
                            <tr class="psel-row" data-parent="<?= $iIdx ?>">
                                <td></td>
                                <td colspan="<?= $canManage ? 9 : 8 ?>" style="padding:4px 8px;background:#fafafa;border-top:none">
                                    <div class="psel-controls">
                                        <select class="form-control psel-cat1" onchange="onCat1(this)"><option value="">主分類</option></select>
                                        <select class="form-control psel-cat2" onchange="onCat2(this)"><option value="">子分類</option></select>
                                        <select class="form-control psel-product" onchange="onProductSelect(this)"><option value="">產品名稱</option></select>
                                        <span class="psel-model-display" style="font-size:.8rem;color:#1565c0;min-width:80px"></span>
                                        <span class="psel-stock-display" style="font-size:.8rem;min-width:60px"></span>
                                        <input type="text" class="form-control psel-keyword" placeholder="關鍵字搜尋" autocomplete="off" oninput="keywordSearch(this)">
                                    </div>
                                    <div class="product-dropdown" style="position:relative"></div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="6" class="text-right"><strong>小計</strong></td>
                                <td class="section-subtotal text-right"><strong>0</strong></td>
                                <td colspan="<?= $canManage ? 3 : 2 ?>">
                                    <button type="button" class="btn btn-outline btn-sm" onclick="addItem(this)">+ 新增項目</button>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- 總計 -->
        <div class="quote-totals">
            <div class="quote-total-row" id="rowSubtotal">
                <span>未稅合計：</span>
                <strong id="grandSubtotal">$0</strong>
            </div>
            <div class="quote-total-row" id="rowTax">
                <span>營業稅 (5%)：</span>
                <strong id="grandTax">$0</strong>
            </div>
            <div class="quote-total-row quote-total-grand">
                <span>合計新台幣：</span>
                <strong id="grandTotal">$0</strong>
            </div>
            <div class="quote-total-row" id="rowDiscount" style="display:<?= !empty($quote['has_discount']) ? 'flex' : 'none' ?>">
                <span style="color:var(--danger)">優惠價：</span>
                <input type="number" name="discount_amount" id="discountAmount" class="form-control" style="width:150px;text-align:right;font-weight:700;color:var(--danger)" value="<?= $isEdit ? (int)($quote['discount_amount'] ?? 0) : '' ?>" min="0" placeholder="輸入優惠價">
            </div>
        </div>
        <input type="hidden" name="tax_free" id="taxFreeHidden" value="<?= !empty($quote['tax_free']) ? '1' : '0' ?>">
        <input type="hidden" name="has_discount" id="hasDiscountHidden" value="<?= !empty($quote['has_discount']) ? '1' : '0' ?>">
    </div>

    <!-- 內部成本（僅管理者可見） -->
    <?php if ($canManage): ?>
    <div class="card">
        <div class="card-header">內部成本分析（不顯示在報價單）</div>
        <div class="form-row">
            <div class="form-group">
                <label>施工天數</label>
                <input type="number" name="labor_days" class="form-control" value="<?= e($quote['labor_days'] ?? '') ?>" step="0.5" min="0">
            </div>
            <div class="form-group">
                <label>施工人數</label>
                <input type="number" name="labor_people" class="form-control" value="<?= e($quote['labor_people'] ?? '') ?>" min="0">
            </div>
            <div class="form-group">
                <label>施工時數</label>
                <input type="number" name="labor_hours" class="form-control" value="<?= e($quote['labor_hours'] ?? '') ?>" step="0.5" min="0">
            </div>
            <div class="form-group">
                <label>人力成本</label>
                <input type="number" name="labor_cost_total" id="laborCostTotal" class="form-control" value="<?= e($quote['labor_cost_total'] ?? '') ?>" min="0">
            </div>
        </div>
        <div class="form-row" style="background:#f8f9fa;padding:8px;border-radius:6px">
            <div class="form-group">
                <label>器材總成本</label>
                <div id="materialCost" style="font-weight:600;font-size:1.1rem">$0</div>
            </div>
            <div class="form-group">
                <label>利潤金額</label>
                <div id="profitAmount" style="font-weight:600;font-size:1.1rem">$0</div>
            </div>
            <div class="form-group">
                <label>利潤率</label>
                <div id="profitRate" style="font-weight:600;font-size:1.1rem">0%</div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- 附加資訊 -->
    <div class="card">
        <div class="card-header">附加資訊</div>
        <div class="form-group">
            <label>收款條件</label>
            <textarea name="payment_terms" class="form-control" rows="2"><?= e($quote['payment_terms'] ?? '30%定金 70% 完工當日付現或當日匯款') ?></textarea>
        </div>
        <div class="form-group">
            <label>附註說明</label>
            <textarea name="notes" class="form-control" rows="2"><?= e($quote['notes'] ?? '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '建立報價單' ?></button>
        <a href="/quotations.php" class="btn btn-outline">取消</a>
    </div>
</form>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
.checkbox-label { display: flex; align-items: center; gap: 6px; cursor: pointer; }
/* 隱藏 number input 的上下箭頭 */
.quote-items-table input[type="number"]::-webkit-inner-spin-button,
.quote-items-table input[type="number"]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
.quote-items-table input[type="number"] { -moz-appearance: textfield; }

.quote-section { border: 1px solid var(--gray-200); border-radius: 8px; margin-bottom: 12px; overflow: hidden; }
.quote-section-header { display: flex; gap: 8px; padding: 8px; background: var(--gray-100); }
.quote-section-header input { flex: 1; }
.quote-items-table { margin: 0; font-size: .85rem; }
.quote-items-table input { font-size: .85rem; padding: 4px 6px; }
.quote-items-table th { font-size: .75rem; padding: 6px 4px; white-space: nowrap; }
.quote-items-table td { padding: 4px; vertical-align: middle; }
.row-num { text-align: center; color: var(--gray-500); font-size: .8rem; }

.quote-totals { text-align: right; padding: 12px; border-top: 2px solid var(--gray-200); }
.quote-total-row { margin-bottom: 4px; font-size: .95rem; }
.quote-total-grand { font-size: 1.2rem; color: var(--primary); margin-top: 8px; }

.product-dropdown {
    position: absolute; top: 100%; left: 0; right: 0; z-index: 100;
    background: #fff; border: 1px solid var(--gray-300); border-radius: 6px;
    max-height: 200px; overflow-y: auto; display: none; box-shadow: var(--shadow);
}
.product-dropdown-item {
    padding: 6px 8px; cursor: pointer; font-size: .8rem; border-bottom: 1px solid var(--gray-100);
}
.product-dropdown-item:hover { background: var(--gray-100); }
.product-dropdown-item .product-meta { color: var(--gray-500); font-size: .7rem; }
.psel-controls { display:flex; gap:4px; align-items:center; flex-wrap:nowrap; }
.psel-controls select, .psel-controls input { font-size:.8rem !important; padding:3px 6px !important; height:28px; min-width:0; }
.psel-controls .psel-cat1 { flex:0 0 110px; }
.psel-controls .psel-cat2 { flex:0 0 110px; }
.psel-controls .psel-product { flex:1; min-width:120px; }
.psel-controls .psel-keyword { flex:0 0 100px; }
.psel-model-display, .psel-stock-display { white-space:nowrap; }
.psel-row td { padding-top:0 !important; }

@media (max-width: 768px) {
    .quote-items-table { font-size: .75rem; }
    .quote-items-table input { font-size: .75rem; }
}
</style>

<script>
var sectionIdx = <?= count($sections) ?>;
var canManage = <?= $canManage ? 'true' : 'false' ?>;
var searchTimer = null;

function toggleDiscount() {
    var cb = document.querySelector('input[name="has_discount"][type="checkbox"]');
    var row = document.getElementById('rowDiscount');
    var hf = document.getElementById('hasDiscountHidden');
    if (cb && row) {
        row.style.display = cb.checked ? 'flex' : 'none';
        if (!cb.checked) document.getElementById('discountAmount').value = '';
    }
    if (hf) hf.value = cb.checked ? '1' : '0';
}

function toggleFormat(fmt) {
    var headers = document.querySelectorAll('.quote-section-header');
    var btn = document.getElementById('btnAddSection');
    for (var i = 0; i < headers.length; i++) {
        headers[i].style.display = fmt === 'project' ? 'flex' : 'none';
    }
    btn.style.display = fmt === 'project' ? '' : 'none';
}

function addSection() {
    var container = document.getElementById('sectionsContainer');
    var costTh = canManage ? '<th style="width:100px">成本</th>' : '';
    var costTd = canManage ? '<td><input type="text" name="sections[' + sectionIdx + '][items][0][unit_cost]" class="form-control item-cost" value="0" readonly style="background:#f5f5f5;color:#666"></td>' : '';
    var extraCols = canManage ? 3 : 2;

    var html = '<div class="quote-section" data-sidx="' + sectionIdx + '">' +
        '<div class="quote-section-header">' +
            '<input type="text" name="sections[' + sectionIdx + '][title]" class="form-control" placeholder="區段標題（如：電話線工程）">' +
            '<button type="button" class="btn btn-danger btn-sm" onclick="removeSection(this)">&times;</button>' +
        '</div>' +
        '<div class="table-responsive"><table class="table quote-items-table">' +
        '<thead><tr><th style="width:30px">序</th><th style="min-width:350px">品名/型號</th><th style="width:80px">數量</th><th style="width:60px">單位</th><th style="width:100px">單價</th><th style="width:100px">小計</th><th style="width:120px">備註</th>' + costTh + '<th style="width:40px"></th></tr></thead>' +
        '<tbody>' + buildItemRow(sectionIdx, 0) + '</tbody>' +
        '<tfoot><tr><td colspan="5" class="text-right"><strong>小計</strong></td><td class="section-subtotal text-right"><strong>0</strong></td><td colspan="' + extraCols + '"><button type="button" class="btn btn-outline btn-sm" onclick="addItem(this)">+ 新增項目</button></td></tr></tfoot>' +
        '</table></div></div>';

    container.insertAdjacentHTML('beforeend', html);
    sectionIdx++;
    reindexAll();
    calcGrandTotal();
}

function removeSection(btn) {
    var section = btn.closest('.quote-section');
    if (document.querySelectorAll('.quote-section').length <= 1) {
        alert('至少需要一個區段');
        return;
    }
    section.remove();
    reindexAll();
    calcGrandTotal();
}

function addItem(btn) {
    var section = btn.closest('.quote-section');
    var tbody = section.querySelector('tbody');
    var sidx = section.getAttribute('data-sidx');
    var rows = tbody.querySelectorAll('tr');
    var iidx = rows.length;
    tbody.insertAdjacentHTML('beforeend', buildItemRow(sidx, iidx));
    loadCat1Options();
    reindexSection(section);
    calcSectionSubtotal(section);
}

function removeItem(btn) {
    var row = btn.closest('tr');
    var section = row.closest('.quote-section');
    var tbody = section.querySelector('tbody');
    if (tbody.querySelectorAll('tr').length <= 1) {
        // 清空而不是刪除最後一行
        var inputs = row.querySelectorAll('input');
        for (var i = 0; i < inputs.length; i++) {
            if (inputs[i].type === 'number') inputs[i].value = inputs[i].name.indexOf('quantity') !== -1 ? '1' : '0';
            else if (inputs[i].type !== 'hidden') inputs[i].value = '';
            else inputs[i].value = '';
        }
        calcRow(row.querySelector('.item-qty'));
        return;
    }
    // 也刪除對應的 psel-row
    var nextRow = row.nextElementSibling;
    if (nextRow && nextRow.classList.contains('psel-row')) nextRow.remove();
    row.remove();
    reindexSection(section);
    calcSectionSubtotal(section);
    calcGrandTotal();
}

function buildItemRow(sidx, iidx) {
    var costTh = canManage ? '<td><input type="text" name="sections[' + sidx + '][items][' + iidx + '][unit_cost]" class="form-control item-cost" value="0" readonly style="background:#f5f5f5;color:#666"></td>' : '';
    var colSpan = canManage ? 9 : 8;
    return '<tr>' +
        '<td class="row-num">' + (iidx + 1) + '</td>' +
        '<td><input type="text" name="sections[' + sidx + '][items][' + iidx + '][item_name]" class="form-control item-name" value="" placeholder="\u54c1\u540d\uff08\u53ef\u624b\u52d5\u8f38\u5165\uff09" style="font-weight:600;font-size:.85rem"><input type="hidden" name="sections[' + sidx + '][items][' + iidx + '][product_id]" value=""></td>' +
        '<td><input type="text" name="sections[' + sidx + '][items][' + iidx + '][model_number]" class="form-control item-model" value="" placeholder="\u578b\u865f" style="font-size:.8rem;color:#1565c0"></td>' +
        '<td><input type="number" name="sections[' + sidx + '][items][' + iidx + '][quantity]" class="form-control item-qty" value="1" step="0.01" min="0" oninput="calcRow(this)"></td>' +
        '<td><input type="text" name="sections[' + sidx + '][items][' + iidx + '][unit]" class="form-control item-unit" value="式"></td>' +
        '<td><input type="text" name="sections[' + sidx + '][items][' + iidx + '][unit_price]" class="form-control item-price" value="0" oninput="calcRow(this)" inputmode="numeric"></td>' +
        '<td class="item-amount text-right">0</td>' +
        '<td><input type="text" name="sections[' + sidx + '][items][' + iidx + '][remark]" class="form-control"></td>' +
        costTh +
        '<td><button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">&times;</button></td>' +
    '</tr>' +
    '<tr class="psel-row">' +
        '<td></td>' +
        '<td colspan="' + colSpan + '" style="padding:4px 8px;background:#fafafa;border-top:none">' +
            '<div class="psel-controls">' +
                '<select class="form-control psel-cat1" onchange="onCat1(this)"><option value="">主分類</option></select>' +
                '<select class="form-control psel-cat2" onchange="onCat2(this)"><option value="">子分類</option></select>' +
                '<select class="form-control psel-product" onchange="onProductSelect(this)"><option value="">產品名稱</option></select>' +
                '<span class="psel-model-display" style="font-size:.8rem;color:#1565c0;min-width:80px"></span>' +
                '<span class="psel-stock-display" style="font-size:.8rem;min-width:60px"></span>' +
                '<input type="text" class="form-control psel-keyword" placeholder="關鍵字搜尋" autocomplete="off" oninput="keywordSearch(this)">' +
            '</div>' +
            '<div class="product-dropdown" style="position:relative"></div>' +
        '</td>' +
    '</tr>';
}

function reindexAll() {
    var sections = document.querySelectorAll('.quote-section');
    for (var s = 0; s < sections.length; s++) {
        sections[s].setAttribute('data-sidx', s);
        // 更新 section title name
        var titleInput = sections[s].querySelector('.quote-section-header input');
        if (titleInput) titleInput.name = 'sections[' + s + '][title]';
        reindexSection(sections[s]);
    }
}

function reindexSection(section) {
    var sidx = section.getAttribute('data-sidx');
    var rows = section.querySelectorAll('tbody tr:not(.psel-row)');
    for (var i = 0; i < rows.length; i++) {
        var numEl = rows[i].querySelector('.row-num');
        if (numEl) numEl.textContent = i + 1;
        var inputs = rows[i].querySelectorAll('input');
        for (var j = 0; j < inputs.length; j++) {
            var name = inputs[j].name;
            if (name) {
                inputs[j].name = name.replace(/sections\[\d+\]\[items\]\[\d+\]/, 'sections[' + sidx + '][items][' + i + ']');
            }
        }
    }
}

function calcRow(el) {
    var row = el.closest('tr');
    var qty = parseFloat(row.querySelector('.item-qty').value) || 0;
    var price = parseFloat(row.querySelector('.item-price').value) || 0;
    var amount = Math.round(qty * price);
    row.querySelector('.item-amount').textContent = amount.toLocaleString();
    calcSectionSubtotal(row.closest('.quote-section'));
    calcGrandTotal();
}

function calcSectionSubtotal(section) {
    var rows = section.querySelectorAll('tbody tr:not(.psel-row)');
    var subtotal = 0;
    for (var i = 0; i < rows.length; i++) {
        var qtyEl = rows[i].querySelector('.item-qty');
        var priceEl = rows[i].querySelector('.item-price');
        if (!qtyEl || !priceEl) continue;
        var qty = parseFloat(qtyEl.value) || 0;
        var price = parseFloat(priceEl.value) || 0;
        subtotal += Math.round(qty * price);
    }
    var el = section.querySelector('.section-subtotal strong');
    if (el) el.textContent = subtotal.toLocaleString();
}

function calcGrandTotal() {
    var sections = document.querySelectorAll('.quote-section');
    var grandSubtotal = 0;
    var grandCost = 0;
    for (var s = 0; s < sections.length; s++) {
        var rows = sections[s].querySelectorAll('tbody tr:not(.psel-row)');
        for (var i = 0; i < rows.length; i++) {
            var qtyEl = rows[i].querySelector('.item-qty');
            var priceEl = rows[i].querySelector('.item-price');
            if (!qtyEl || !priceEl) continue;
            var qty = parseFloat(qtyEl.value) || 0;
            var price = parseFloat(priceEl.value) || 0;
            grandSubtotal += Math.round(qty * price);
            var costEl = rows[i].querySelector('.item-cost');
            if (costEl) {
                grandCost += Math.round(qty * (parseFloat(costEl.value) || 0));
            }
        }
    }
    var isTaxFree = document.querySelector('input[name="tax_free"][type="checkbox"]');
    var taxFree = isTaxFree && isTaxFree.checked;
    var tax = taxFree ? 0 : Math.round(grandSubtotal * 0.05);
    var total = grandSubtotal + tax;
    document.getElementById('grandSubtotal').textContent = '$' + grandSubtotal.toLocaleString();
    document.getElementById('grandTax').textContent = '$' + tax.toLocaleString();
    document.getElementById('grandTotal').textContent = '$' + total.toLocaleString();
    // 未稅時隱藏稅額行
    document.getElementById('rowSubtotal').style.display = taxFree ? 'none' : 'flex';
    document.getElementById('rowTax').style.display = taxFree ? 'none' : 'flex';
    // 未稅時合計標籤改
    var totalLabel = document.querySelector('#grandTotal').parentElement.querySelector('span');
    if (totalLabel) totalLabel.textContent = taxFree ? '合計新台幣(未稅)：' : '合計新台幣：';
    // hidden field
    var hf = document.getElementById('taxFreeHidden');
    if (hf) hf.value = taxFree ? '1' : '0';

    // 內部成本計算
    if (canManage) {
        var laborCost = parseFloat(document.getElementById('laborCostTotal').value) || 0;
        var totalCost = grandCost + laborCost;
        var profit = grandSubtotal - totalCost;
        var profitPct = grandSubtotal > 0 ? (profit / grandSubtotal * 100).toFixed(1) : 0;
        document.getElementById('materialCost').textContent = '$' + grandCost.toLocaleString();
        document.getElementById('profitAmount').textContent = '$' + profit.toLocaleString();
        document.getElementById('profitRate').textContent = profitPct + '%';
        document.getElementById('profitAmount').style.color = profit >= 0 ? '#137333' : '#c5221f';
    }
}

// 主分類變更
function onCat1(select) {
    var td = select.closest('td');
    var cat2 = td.querySelector('.psel-cat2');
    var prodSel = td.querySelector('.psel-product');
    cat2.innerHTML = '<option value="">子分類</option>';
    prodSel.innerHTML = '<option value="">產品名稱</option>';

    if (!select.value) return;

    fetch('/quotations.php?action=ajax_categories&parent_id=' + select.value)
    .then(function(r) { return r.json(); })
    .then(function(subs) {
        if (subs && subs.length > 0) {
            var html = '<option value="">子分類 (' + subs.length + ')</option>';
            for (var i = 0; i < subs.length; i++) html += '<option value="' + subs[i].id + '">' + escHtml(subs[i].name) + '</option>';
            cat2.innerHTML = html;
            // 同時也載入全部產品到產品選單
            loadProducts(td, select.value);
        } else {
            cat2.innerHTML = '<option value="">無子分類</option>';
            loadProducts(td, select.value);
        }
    });
}

// 子分類變更
function onCat2(select) {
    var td = select.closest('td');
    if (!select.value) {
        var cat1 = td.querySelector('.psel-cat1');
        if (cat1.value) loadProducts(td, cat1.value);
        return;
    }
    loadProducts(td, select.value);
}

// 載入產品到下拉選單
function loadProducts(td, categoryId) {
    var prodSel = td.querySelector('.psel-product');
    fetch('/quotations.php?action=ajax_products&category_id=' + categoryId)
    .then(function(r) { return r.json(); })
    .then(function(data) {
        var html = '<option value="">選擇產品 (' + data.length + '項)</option>';
        for (var i = 0; i < data.length; i++) {
            var stockLabel = data[i].stock_qty > 0 ? ' [庫存:' + data[i].stock_qty + ']' : ' [無庫存]';
            html += '<option value="' + i + '" ' +
                'data-id="' + data[i].id + '" ' +
                'data-name="' + escHtml(data[i].name) + '" ' +
                'data-model="' + escHtml(data[i].model || '') + '" ' +
                'data-unit="' + escHtml(data[i].unit || '式') + '" ' +
                'data-price="' + (data[i].price || 0) + '" ' +
                'data-cost="' + (data[i].cost || 0) + '" ' +
                'data-stock="' + (data[i].stock_qty || 0) + '">' +
                escHtml(data[i].name) + (data[i].model ? ' ' + data[i].model : '') + stockLabel +
                '</option>';
        }
        prodSel.innerHTML = html;
    });
}

// 選擇產品
function onProductSelect(select) {
    var opt = select.options[select.selectedIndex];
    if (!opt || !opt.getAttribute('data-id')) return;
    var pselRow = select.closest('tr');
    // 找到上面的資料列（前一個 tr）
    var dataRow = pselRow.previousElementSibling;
    var name = opt.getAttribute('data-name');
    var model = opt.getAttribute('data-model') || '';
    var stock = opt.getAttribute('data-stock') || '0';

    // 填入第一排
    dataRow.querySelector('input[name*="product_id"]').value = opt.getAttribute('data-id');
    dataRow.querySelector('.item-name').value = name;
    var modelInput = dataRow.querySelector('.item-model');
    if (modelInput) modelInput.value = model;
    dataRow.querySelector('.item-unit').value = opt.getAttribute('data-unit');
    dataRow.querySelector('.item-price').value = opt.getAttribute('data-price');
    var costInput = dataRow.querySelector('.item-cost');
    if (costInput) costInput.value = opt.getAttribute('data-cost');
    calcRow(dataRow.querySelector('.item-qty'));

    // 第二排顯示型號和庫存
    var modelDisp = pselRow.querySelector('.psel-model-display');
    if (modelDisp) modelDisp.textContent = model ? '型號: ' + model : '';
    var stockDisp = pselRow.querySelector('.psel-stock-display');
    if (stockDisp) {
        var stockColor = parseInt(stock) > 0 ? '#2e7d32' : '#c62828';
        stockDisp.innerHTML = '<span style="color:' + stockColor + '">庫存: ' + stock + '</span>';
    }
}

function clearProductSelection(pselRow) {
    var dataRow = pselRow.closest('tr').previousElementSibling || pselRow.closest('tr');
    dataRow.querySelector('input[name*="product_id"]').value = '';
    dataRow.querySelector('.item-name').value = '';
    var modelInput = dataRow.querySelector('.item-model');
    if (modelInput) modelInput.value = '';
    dataRow.querySelector('.item-price').value = '0';
    var costInput = dataRow.querySelector('.item-cost');
    if (costInput) costInput.value = '0';
    calcRow(dataRow.querySelector('.item-qty'));
}

// 關鍵字搜尋
function keywordSearch(input) {
    clearTimeout(searchTimer);
    var keyword = input.value.trim();
    var td = input.closest('td');
    var dropdown = td.querySelector('.product-dropdown');
    if (keyword.length < 2) { dropdown.style.display = 'none'; return; }
    searchTimer = setTimeout(function() {
        var url = '/quotations.php?action=ajax_products&keyword=' + encodeURIComponent(keyword);
        fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data.length) {
                dropdown.innerHTML = '<div class="product-dropdown-item" style="color:#999;cursor:default">無符合產品</div>';
                dropdown.style.display = 'block';
                return;
            }
            var html = '';
            for (var i = 0; i < data.length; i++) {
                var stockColor = data[i].stock_qty > 0 ? '#2e7d32' : '#999';
                var stockText = '庫存: ' + data[i].stock_qty;
                html += '<div class="product-dropdown-item" onclick="selectProduct(this)" ' +
                    'data-id="' + data[i].id + '" ' +
                    'data-name="' + escHtml(data[i].name) + '" ' +
                    'data-model="' + escHtml(data[i].model || '') + '" ' +
                    'data-unit="' + escHtml(data[i].unit || '式') + '" ' +
                    'data-price="' + (data[i].price || 0) + '" ' +
                    'data-cost="' + (data[i].cost || 0) + '" ' +
                    'data-stock="' + (data[i].stock_qty || 0) + '">' +
                    '<div style="font-weight:600">' + escHtml(data[i].name) + '</div>' +
                    '<div class="product-meta">' +
                        (data[i].model ? '<span style="color:#1565c0">' + escHtml(data[i].model) + '</span> | ' : '') +
                        '<span style="color:' + stockColor + '">' + stockText + '</span> | ' +
                        '$' + Number(data[i].price || 0).toLocaleString() + '/' + escHtml(data[i].unit || '式') +
                        (data[i].category_name ? ' | <span style="color:#888">' + escHtml(data[i].category_name) + '</span>' : '') +
                    '</div>' +
                '</div>';
            }
            dropdown.innerHTML = html;
            dropdown.style.display = 'block';
        });
    }, 300);
}

function selectProduct(el) {
    var pselRow = el.closest('tr');
    var dataRow = pselRow.previousElementSibling;
    var name = el.getAttribute('data-name');
    var model = el.getAttribute('data-model') || '';
    var stock = el.getAttribute('data-stock') || '0';

    dataRow.querySelector('input[name*="product_id"]').value = el.getAttribute('data-id');
    dataRow.querySelector('.item-name').value = name;
    var modelInput = dataRow.querySelector('.item-model');
    if (modelInput) modelInput.value = model;
    dataRow.querySelector('.item-unit').value = el.getAttribute('data-unit');
    dataRow.querySelector('.item-price').value = el.getAttribute('data-price');
    var costInput = dataRow.querySelector('.item-cost');
    if (costInput) costInput.value = el.getAttribute('data-cost');
    el.closest('.product-dropdown').style.display = 'none';
    pselRow.querySelector('.psel-keyword').value = '';
    calcRow(dataRow.querySelector('.item-qty'));

    var modelDisp = pselRow.querySelector('.psel-model-display');
    if (modelDisp) modelDisp.textContent = model ? '型號: ' + model : '';
    var stockDisp = pselRow.querySelector('.psel-stock-display');
    if (stockDisp) {
        var stockColor = parseInt(stock) > 0 ? '#2e7d32' : '#c62828';
        stockDisp.innerHTML = '<span style="color:' + stockColor + '">庫存: ' + stock + '</span>';
    }
}

function escHtml(s) {
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(s));
    return div.innerHTML;
}

// 關閉下拉
document.addEventListener('click', function(e) {
    if (!e.target.classList.contains('psel-keyword')) {
        var dd = document.querySelectorAll('.product-dropdown');
        for (var i = 0; i < dd.length; i++) dd[i].style.display = 'none';
    }
});

// 人力成本輸入時重算
if (document.getElementById('laborCostTotal')) {
    document.getElementById('laborCostTotal').addEventListener('input', calcGrandTotal);
}

// 載入主分類
var productCategories = [];
fetch('/quotations.php?action=ajax_categories')
.then(function(r) { return r.json(); })
.then(function(cats) {
    productCategories = cats;
    loadCat1Options();
});

function loadCat1Options() {
    var selects = document.querySelectorAll('.psel-cat1');
    for (var i = 0; i < selects.length; i++) {
        if (selects[i].options.length <= 1) {
            for (var j = 0; j < productCategories.length; j++) {
                var opt = document.createElement('option');
                opt.value = productCategories[j].id;
                opt.textContent = productCategories[j].name;
                selects[i].appendChild(opt);
            }
        }
    }
}

// 客戶搜尋
(function() {
    var inp = document.getElementById('qCustName');
    var dd = document.getElementById('qCustDropdown');
    var hiddenId = document.getElementById('qCustId');
    var timer = null;

    if (!inp || !dd) return;

    inp.addEventListener('input', function() {
        clearTimeout(timer);
        hiddenId.value = '';
        var q = inp.value.trim();
        if (q.length < 1) { dd.style.display = 'none'; return; }
        timer = setTimeout(function() {
            fetch('/customers.php?action=ajax_search&q=' + encodeURIComponent(q))
            .then(function(r) { return r.json(); })
            .then(function(list) {
                dd.innerHTML = '';
                if (!list.length) {
                    dd.innerHTML = '<div style="padding:8px;color:#999;font-size:.85rem">無符合客戶</div>';
                    dd.style.display = 'block';
                    return;
                }
                for (var i = 0; i < list.length; i++) {
                    var c = list[i];
                    var div = document.createElement('div');
                    div.style.cssText = 'padding:8px 12px;cursor:pointer;font-size:.85rem;border-bottom:1px solid #eee';
                    div.textContent = c.name + (c.customer_no ? ' (' + c.customer_no + ')' : '');
                    div.dataset.id = c.id;
                    div.dataset.name = c.name;
                    div.dataset.contact = c.contact_person || '';
                    div.dataset.phone = c.phone || '';
                    div.dataset.custNo = c.customer_no || '';
                    div.dataset.invoiceTitle = c.invoice_title || '';
                    div.dataset.taxId = c.tax_id || '';
                    div.addEventListener('click', function() {
                        inp.value = this.dataset.name;
                        hiddenId.value = this.dataset.id;
                        dd.style.display = 'none';
                        // 帶入其他欄位
                        var cp = document.querySelector('input[name="contact_person"]');
                        var cph = document.querySelector('input[name="contact_phone"]');
                        var cno = document.getElementById('quoteCustomerNo');
                        var it = document.querySelector('input[name="invoice_title"]');
                        var tid = document.querySelector('input[name="invoice_tax_id"]');
                        if (cp && !cp.value && this.dataset.contact) cp.value = this.dataset.contact;
                        if (cph && !cph.value && this.dataset.phone) cph.value = this.dataset.phone;
                        if (cno) cno.value = this.dataset.custNo;
                        if (it && !it.value && this.dataset.invoiceTitle) it.value = this.dataset.invoiceTitle;
                        if (tid && !tid.value && this.dataset.taxId) tid.value = this.dataset.taxId;
                    });
                    div.addEventListener('mouseenter', function() { this.style.background = '#f0f7ff'; });
                    div.addEventListener('mouseleave', function() { this.style.background = ''; });
                    dd.appendChild(div);
                }
                dd.style.display = 'block';
            });
        }, 300);
    });

    document.addEventListener('click', function(e) {
        if (!dd.contains(e.target) && e.target !== inp) dd.style.display = 'none';
    });
})();

// 初始計算
document.addEventListener('DOMContentLoaded', function() {
    var sections = document.querySelectorAll('.quote-section');
    for (var i = 0; i < sections.length; i++) calcSectionSubtotal(sections[i]);
    calcGrandTotal();
});
</script>
