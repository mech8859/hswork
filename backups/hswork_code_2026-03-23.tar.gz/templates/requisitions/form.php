<?php
$isEdit = !empty($record);
$statusOptions = ProcurementModel::requisitionStatusOptions();
$urgencyOptions = ProcurementModel::urgencyOptions();
?>
<h2><?= $isEdit ? '編輯請購單 - ' . e($record['requisition_number']) : '新增請購單' ?></h2>

<form method="POST" action="/requisitions.php?action=<?= $isEdit ? 'edit&id=' . $record['id'] : 'create' ?>" class="mt-2">
    <?= csrf_field() ?>

    <!-- 請購資訊 -->
    <div class="card">
        <div class="card-header">請購資訊</div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 auto;min-width:200px">
                <label>請購單號</label>
                <input type="text" class="form-control" value="<?= e($isEdit ? $record['requisition_number'] : peek_next_doc_number('requisitions')) ?>" readonly style="background:#f0f7ff;font-weight:600;color:var(--primary)">
            </div>
            <div class="form-group">
                <label>請購日期 *</label>
                <input type="date" max="2099-12-31" name="requisition_date" class="form-control" value="<?= e(!empty($record['requisition_date']) ? $record['requisition_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>請購人 *</label>
                <input type="text" name="requester_name" class="form-control" value="<?= e(!empty($record['requester_name']) ? $record['requester_name'] : '') ?>" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>分公司</label>
                <select name="branch_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= (!empty($record['branch_id']) && $record['branch_id'] == $b['id']) ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>業務人員</label>
                <input type="text" name="sales_name" class="form-control" value="<?= e(!empty($record['sales_name']) ? $record['sales_name'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>緊急程度</label>
                <select name="urgency" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($urgencyOptions as $uv => $ul): ?>
                    <option value="<?= e($uv) ?>" <?= (!empty($record['urgency']) && $record['urgency'] === $uv) ? 'selected' : '' ?>><?= e($ul) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>案名</label>
                <input type="text" name="case_name" class="form-control" value="<?= e(!empty($record['case_name']) ? $record['case_name'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>報價單號</label>
                <input type="text" name="quotation_number" class="form-control" value="<?= e(!empty($record['quotation_number']) ? $record['quotation_number'] : '') ?>">
            </div>
            <div class="form-group">
                <label>廠商名稱</label>
                <input type="text" name="vendor_name" class="form-control" value="<?= e(!empty($record['vendor_name']) ? $record['vendor_name'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>期望交貨日</label>
                <input type="date" max="2099-12-31" name="expected_date" class="form-control" value="<?= e(!empty($record['expected_date']) ? $record['expected_date'] : '') ?>">
            </div>
            <div class="form-group"></div>
        </div>
    </div>

    <!-- 簽核資訊 -->
    <div class="card">
        <div class="card-header">簽核資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <?php foreach ($statusOptions as $sv => $sl): ?>
                    <option value="<?= e($sv) ?>" <?= ((!empty($record['status']) ? $record['status'] : '簽核中') === $sv) ? 'selected' : '' ?>><?= e($sl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>簽核人</label>
                <input type="text" name="approval_user" class="form-control" value="<?= e(!empty($record['approval_user']) ? $record['approval_user'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>簽核日期</label>
                <input type="date" max="2099-12-31" name="approval_date" class="form-control" value="<?= e(!empty($record['approval_date']) ? $record['approval_date'] : '') ?>">
            </div>
            <div class="form-group">
                <label>簽核備註</label>
                <input type="text" name="approval_note" class="form-control" value="<?= e(!empty($record['approval_note']) ? $record['approval_note'] : '') ?>">
            </div>
        </div>
    </div>

    <!-- 請購商品 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>請購商品</span>
            <button type="button" class="btn btn-outline btn-sm" onclick="addItemRow()">+ 新增品項</button>
        </div>
        <div class="table-responsive">
            <table class="table" id="itemsTable">
                <thead>
                    <tr>
                        <th style="width:50px">項次</th>
                        <th>商品型號</th>
                        <th>商品名稱</th>
                        <th style="width:90px">請購數量</th>
                        <th>用途說明</th>
                        <th style="width:90px">覆核數量</th>
                        <th style="width:60px">操作</th>
                    </tr>
                </thead>
                <tbody id="itemsBody">
                    <?php
                    $itemList = !empty($items) ? $items : array();
                    if (empty($itemList)) {
                        $itemList = array(array('model' => '', 'product_name' => '', 'quantity' => '', 'purpose' => '', 'approved_qty' => ''));
                    }
                    foreach ($itemList as $idx => $item):
                    ?>
                    <tr class="item-row">
                        <td class="item-seq" style="text-align:center"><?= $idx + 1 ?></td>
                        <td><input type="text" name="items[<?= $idx ?>][model]" class="form-control" value="<?= e(!empty($item['model']) ? $item['model'] : '') ?>"></td>
                        <td><input type="text" name="items[<?= $idx ?>][product_name]" class="form-control" value="<?= e(!empty($item['product_name']) ? $item['product_name'] : '') ?>"></td>
                        <td><input type="number" name="items[<?= $idx ?>][quantity]" class="form-control" min="0" value="<?= e(!empty($item['quantity']) ? $item['quantity'] : '') ?>"></td>
                        <td><input type="text" name="items[<?= $idx ?>][purpose]" class="form-control" value="<?= e(!empty($item['purpose']) ? $item['purpose'] : '') ?>"></td>
                        <td><input type="number" name="items[<?= $idx ?>][approved_qty]" class="form-control" min="0" value="<?= e(!empty($item['approved_qty']) ? $item['approved_qty'] : '') ?>"></td>
                        <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">刪除</button></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 備註 -->
    <div class="card">
        <div class="card-header">備註</div>
        <div class="form-group">
            <textarea name="note" class="form-control" rows="3"><?= e(!empty($record['note']) ? $record['note'] : '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '更新' : '儲存' ?></button>
        <a href="/requisitions.php" class="btn btn-outline">取消</a>
    </div>
</form>

<style>
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px; }
.item-row td { padding: 4px 6px; vertical-align: middle; }
.item-row .form-control { margin-bottom: 0; }
@media (max-width: 767px) {
    .form-row { grid-template-columns: 1fr; }
}
</style>

<script>
var itemIndex = <?= count($itemList) ?>;

function addItemRow() {
    var tbody = document.getElementById('itemsBody');
    var seq = tbody.querySelectorAll('.item-row').length + 1;
    var html = '<tr class="item-row">' +
        '<td class="item-seq" style="text-align:center">' + seq + '</td>' +
        '<td><input type="text" name="items[' + itemIndex + '][model]" class="form-control"></td>' +
        '<td><input type="text" name="items[' + itemIndex + '][product_name]" class="form-control"></td>' +
        '<td><input type="number" name="items[' + itemIndex + '][quantity]" class="form-control" min="0"></td>' +
        '<td><input type="text" name="items[' + itemIndex + '][purpose]" class="form-control"></td>' +
        '<td><input type="number" name="items[' + itemIndex + '][approved_qty]" class="form-control" min="0"></td>' +
        '<td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">刪除</button></td>' +
        '</tr>';
    tbody.insertAdjacentHTML('beforeend', html);
    itemIndex++;
}

function removeItemRow(btn) {
    var row = btn.closest('.item-row');
    if (row) {
        row.remove();
        reindexSeq();
    }
}

function reindexSeq() {
    var rows = document.querySelectorAll('#itemsBody .item-row');
    for (var i = 0; i < rows.length; i++) {
        rows[i].querySelector('.item-seq').textContent = i + 1;
    }
}
</script>
