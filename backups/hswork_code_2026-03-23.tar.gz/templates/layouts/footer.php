</main>

<script src="/js/app.js"></script>
<script>
// Enter 鍵跳下一格，不送出表單
document.addEventListener('keydown', function(e) {
    if (e.key !== 'Enter') return;
    var el = e.target;
    if (el.tagName === 'TEXTAREA') return; // textarea 允許換行
    if (el.tagName === 'BUTTON' || el.type === 'submit') return; // 按鈕允許送出
    if (el.tagName !== 'INPUT' && el.tagName !== 'SELECT') return;

    e.preventDefault();

    // 找同表單內的下一個可輸入元素
    var form = el.closest('form');
    if (!form) return;
    var inputs = Array.from(form.querySelectorAll('input:not([type="hidden"]):not([disabled]):not([readonly]), select:not([disabled]), textarea:not([disabled])'));
    var idx = inputs.indexOf(el);
    if (idx >= 0 && idx < inputs.length - 1) {
        inputs[idx + 1].focus();
    }
});
</script>
<?php if (!empty($extraJs)): ?>
    <?php foreach ($extraJs as $js): ?>
        <script src="<?= e($js) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>
