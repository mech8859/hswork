<?php $isEdit = !empty($record); ?>

<h2><?= $isEdit ? '編輯調撥單 - ' . e($record['transfer_number']) : '新增調撥單' ?></h2>

<form method="POST" class="mt-2" id="transferForm">
    <?= csrf_field() ?>

    <!-- 調撥資訊 -->
    <div class="card">
        <div class="card-header">調撥資訊</div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 auto;min-width:200px">
                <label>調撥單號</label>
                <input type="text" class="form-control" value="<?= e($isEdit ? $record['transfer_number'] : peek_next_doc_number('warehouse_transfers')) ?>" readonly style="background:#f0f7ff;font-weight:600;color:var(--primary)">
            </div>
            <div class="form-group">
                <label>調撥日期 *</label>
                <input type="date" max="2099-12-31" name="transfer_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['transfer_date']) ? $record['transfer_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <?php foreach (ProcurementModel::transferStatusOptions() as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && !empty($record['status']) ? $record['status'] : '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>出貨倉庫 *</label>
                <select name="from_warehouse_id" class="form-control" required>
                    <option value="">請選擇</option>
                    <?php foreach ($warehouses as $w): ?>
                    <option value="<?= $w['id'] ?>" <?= ($isEdit && !empty($record['from_warehouse_id']) ? $record['from_warehouse_id'] : '') == $w['id'] ? 'selected' : '' ?>><?= e($w['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>進貨倉庫 *</label>
                <select name="to_warehouse_id" class="form-control" required>
                    <option value="">請選擇</option>
                    <?php foreach ($warehouses as $w): ?>
                    <option value="<?= $w['id'] ?>" <?= ($isEdit && !empty($record['to_warehouse_id']) ? $record['to_warehouse_id'] : '') == $w['id'] ? 'selected' : '' ?>><?= e($w['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>出貨人</label>
                <input type="text" name="shipper_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['shipper_name']) ? $record['shipper_name'] : '') ?>">
            </div>
            <div class="form-group">
                <label>進貨人</label>
                <input type="text" name="receiver_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['receiver_name']) ? $record['receiver_name'] : '') ?>">
            </div>
        </div>
    </div>

    <!-- 調撥明細 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>調撥明細</span>
            <button type="button" class="btn btn-primary btn-sm" onclick="addItemRow()">+ 新增</button>
        </div>
        <div class="table-responsive">
            <table class="table" id="itemTable">
                <thead>
                    <tr>
                        <th style="width:50px">項次</th>
                        <th>商品型號</th>
                        <th>商品名稱</th>
                        <th style="width:80px">數量</th>
                        <th style="width:100px">單價</th>
                        <th style="width:100px">金額</th>
                        <th style="width:50px"></th>
                    </tr>
                </thead>
                <tbody id="itemBody">
                    <?php if (!empty($items)): ?>
                        <?php foreach ($items as $idx => $item): ?>
                        <tr>
                            <td class="item-seq"><?= $idx + 1 ?></td>
                            <td><input type="text" name="items[<?= $idx ?>][model]" class="form-control" value="<?= e(!empty($item['model']) ? $item['model'] : '') ?>"></td>
                            <td><input type="text" name="items[<?= $idx ?>][product_name]" class="form-control" value="<?= e(!empty($item['product_name']) ? $item['product_name'] : '') ?>"></td>
                            <td><input type="number" name="items[<?= $idx ?>][quantity]" class="form-control item-qty" step="1" min="0" value="<?= !empty($item['quantity']) ? (int)$item['quantity'] : 0 ?>" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[<?= $idx ?>][unit_price]" class="form-control item-price" step="1" min="0" value="<?= !empty($item['unit_price']) ? (int)$item['unit_price'] : 0 ?>" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[<?= $idx ?>][amount]" class="form-control item-amount" step="1" min="0" value="<?= !empty($item['amount']) ? (int)$item['amount'] : 0 ?>" readonly></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td class="item-seq">1</td>
                            <td><input type="text" name="items[0][model]" class="form-control" value=""></td>
                            <td><input type="text" name="items[0][product_name]" class="form-control" value=""></td>
                            <td><input type="number" name="items[0][quantity]" class="form-control item-qty" step="1" min="0" value="0" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[0][unit_price]" class="form-control item-price" step="1" min="0" value="0" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[0][amount]" class="form-control item-amount" step="1" min="0" value="0" readonly></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 其他 -->
    <div class="card">
        <div class="card-header">其他</div>
        <div class="form-row">
            <div class="form-group">
                <label>合計金額</label>
                <input type="number" name="total_amount" id="total_amount" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['total_amount']) ? (int)$record['total_amount'] : 0 ?>" readonly>
            </div>
        </div>
        <div class="form-group">
            <label>備註</label>
            <textarea name="note" class="form-control" rows="3"><?= e($isEdit && !empty($record['note']) ? $record['note'] : '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '建立調撥單' ?></button>
        <a href="/warehouse_transfers.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
// ---- 調撥明細 動態列 ----
var itemIdx = <?= !empty($items) ? count($items) : 1 ?>;

function addItemRow() {
    var tbody = document.getElementById('itemBody');
    var tr = document.createElement('tr');
    var seq = tbody.querySelectorAll('tr').length + 1;
    tr.innerHTML = '<td class="item-seq">' + seq + '</td>'
        + '<td><input type="text" name="items['+itemIdx+'][model]" class="form-control" value=""></td>'
        + '<td><input type="text" name="items['+itemIdx+'][product_name]" class="form-control" value=""></td>'
        + '<td><input type="number" name="items['+itemIdx+'][quantity]" class="form-control item-qty" step="1" min="0" value="0" oninput="calcRowAmount(this.closest(\'tr\'))"></td>'
        + '<td><input type="number" name="items['+itemIdx+'][unit_price]" class="form-control item-price" step="1" min="0" value="0" oninput="calcRowAmount(this.closest(\'tr\'))"></td>'
        + '<td><input type="number" name="items['+itemIdx+'][amount]" class="form-control item-amount" step="1" min="0" value="0" readonly></td>'
        + '<td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>';
    tbody.appendChild(tr);
    itemIdx++;
}

function removeItemRow(btn) {
    btn.closest('tr').remove();
    reindexItems();
    calcTotal();
}

function reindexItems() {
    var rows = document.querySelectorAll('#itemBody tr');
    for (var i = 0; i < rows.length; i++) {
        rows[i].querySelector('.item-seq').textContent = i + 1;
    }
}

// ---- 金額計算 ----
function calcRowAmount(row) {
    var price = parseFloat(row.querySelector('.item-price').value) || 0;
    var qty = parseFloat(row.querySelector('.item-qty').value) || 0;
    row.querySelector('.item-amount').value = Math.round(price * qty);
    calcTotal();
}

function calcTotal() {
    var total = 0;
    document.querySelectorAll('.item-amount').forEach(function(el) {
        total += parseFloat(el.value) || 0;
    });
    document.getElementById('total_amount').value = total;
}

// 頁面載入時初始計算
calcTotal();
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
</style>
