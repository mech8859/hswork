<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>現金明細</h2>
    <span class="text-muted"><?= isset($result['total']) ? $result['total'] : count($records) ?> 筆</span>
</div>

<div class="card">
    <form method="GET" action="/cash_details.php" class="filter-form">
        <div class="filter-row">
            <div class="form-group">
                <label>分公司</label>
                <select name="branch_id" class="form-control">
                    <option value="">全部</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= e($b['id']) ?>" <?= (!empty($filters['branch_id']) && $filters['branch_id'] == $b['id']) ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>起始日期</label>
                <input type="date" max="2099-12-31" name="date_from" class="form-control" value="<?= e(!empty($filters['date_from']) ? $filters['date_from'] : '') ?>">
            </div>
            <div class="form-group">
                <label>結束日期</label>
                <input type="date" max="2099-12-31" name="date_to" class="form-control" value="<?= e(!empty($filters['date_to']) ? $filters['date_to'] : '') ?>">
            </div>
            <div class="form-group">
                <label>關鍵字</label>
                <input type="text" name="keyword" class="form-control" value="<?= e(!empty($filters['keyword']) ? $filters['keyword'] : '') ?>" placeholder="明細/承辦業務" autocomplete="off">
            </div>
            <div class="form-group" style="align-self:flex-end">
                <button type="submit" class="btn btn-primary btn-sm">搜尋</button>
                <a href="/cash_details.php" class="btn btn-outline btn-sm">清除</a>
            </div>
        </div>
    </form>
</div>

<div class="card">
    <?php if (empty($records)): ?>
        <p class="text-muted text-center mt-2">目前無資料</p>
    <?php else: ?>
    <!-- 手機卡片 -->
    <div class="staff-cards show-mobile">
        <?php foreach ($records as $r): ?>
        <div class="staff-card">
            <div class="d-flex justify-between align-center">
                <strong><?= e(!empty($r['entry_number']) ? $r['entry_number'] : '-') ?></strong>
                <span class="text-muted" style="font-size:.8rem"><?= e(!empty($r['transaction_date']) ? $r['transaction_date'] : '-') ?></span>
            </div>
            <div class="staff-card-meta">
                <?php if (!empty($r['income_amount']) && $r['income_amount'] > 0): ?>
                <span style="color:var(--success)">收入 $<?= number_format($r['income_amount']) ?></span>
                <?php endif; ?>
                <?php if (!empty($r['expense_amount']) && $r['expense_amount'] > 0): ?>
                <span style="color:var(--danger)">支出 $<?= number_format($r['expense_amount']) ?></span>
                <?php endif; ?>
            </div>
            <div class="staff-card-meta">
                <span><?= e(!empty($r['description']) ? $r['description'] : '-') ?></span>
            </div>
            <div class="staff-card-meta">
                <?php if (!empty($r['branch_name'])): ?><span><?= e($r['branch_name']) ?></span><?php endif; ?>
                <?php if (!empty($r['sales_name'])): ?><span><?= e($r['sales_name']) ?></span><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- 桌面表格 -->
    <div class="table-responsive hide-mobile">
        <table class="table">
            <thead>
                <tr>
                    <th>編號</th>
                    <th>登記日期</th>
                    <th>交易日期</th>
                    <th>分公司</th>
                    <th>承辦業務</th>
                    <th>明細</th>
                    <th class="text-right">收入</th>
                    <th class="text-right">支出</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $r): ?>
                <tr>
                    <td style="font-size:.85rem"><?= e(!empty($r['entry_number']) ? $r['entry_number'] : '-') ?></td>
                    <td><?= e(!empty($r['register_date']) ? $r['register_date'] : '-') ?></td>
                    <td><?= e(!empty($r['transaction_date']) ? $r['transaction_date'] : '-') ?></td>
                    <td><?= e(!empty($r['branch_name']) ? $r['branch_name'] : '-') ?></td>
                    <td><?= e(!empty($r['sales_name']) ? $r['sales_name'] : '-') ?></td>
                    <td><?= e(!empty($r['description']) ? $r['description'] : '-') ?></td>
                    <td class="text-right"><?= (!empty($r['income_amount']) && $r['income_amount'] > 0) ? '<span style="color:var(--success)">$' . number_format($r['income_amount']) . '</span>' : '-' ?></td>
                    <td class="text-right"><?= (!empty($r['expense_amount']) && $r['expense_amount'] > 0) ? '<span style="color:var(--danger)">$' . number_format($r['expense_amount']) . '</span>' : '-' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    <?php require __DIR__ . '/../layouts/pagination.php'; ?>
</div>

<style>
.filter-row { display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; }
.filter-row .form-group { flex: 1; min-width: 130px; margin-bottom: 0; }
.staff-cards { display: flex; flex-direction: column; gap: 8px; }
.staff-card { border: 1px solid var(--gray-200); border-radius: var(--radius); padding: 12px; }
.staff-card-meta { font-size: .8rem; color: var(--gray-500); display: flex; gap: 8px; margin-top: 4px; }
.show-mobile { display: flex; }
.hide-mobile { display: none; }
@media (min-width: 768px) { .show-mobile { display: none !important; } .hide-mobile { display: block !important; } }
</style>
