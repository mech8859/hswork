<div class="d-flex justify-between align-center mb-2">
    <h2>施工回報</h2>
    <div class="d-flex gap-1">
        <a href="/worklog.php?action=history" class="btn btn-outline btn-sm">歷史記錄</a>
        <a href="/worklog.php" class="btn btn-outline btn-sm">返回</a>
    </div>
</div>

<!-- 案件資訊 -->
<div class="card">
    <div class="d-flex justify-between align-center">
        <strong><?= e($worklog['case_title']) ?></strong>
        <span class="badge badge-primary"><?= e($worklog['case_number']) ?></span>
    </div>
    <div class="text-muted" style="font-size:.85rem;margin-top:4px">
        <?= format_date($worklog['schedule_date']) ?>
        <?php if ($worklog['total_visits'] > 1): ?> | 第<?= $worklog['visit_number'] ?>/<?= $worklog['total_visits'] ?>次<?php endif; ?>
        <?php if ($worklog['address']): ?> | <?= e($worklog['address']) ?> <a href="https://maps.google.com/?q=<?= urlencode($worklog['address']) ?>" target="_blank" rel="noopener" title="導航">&#x1F5FA;</a><?php endif; ?>
    </div>
    <div class="worklog-time-display mt-1">
        <span>到場: <strong><?= $worklog['arrival_time'] ? format_datetime($worklog['arrival_time'], 'H:i') : '未打卡' ?></strong></span>
        <span>離場: <strong><?= $worklog['departure_time'] ? format_datetime($worklog['departure_time'], 'H:i') : '未打卡' ?></strong></span>
        <?php if ($worklog['arrival_time'] && $worklog['departure_time']): ?>
        <?php
            $dur = strtotime($worklog['departure_time']) - strtotime($worklog['arrival_time']);
            $hours = floor($dur / 3600);
            $mins = floor(($dur % 3600) / 60);
        ?>
        <span class="text-muted">工時: <?= $hours ?>時<?= $mins ?>分</span>
        <?php endif; ?>
    </div>
</div>

<!-- 已上傳照片 -->
<?php if (!empty($worklog['photos'])): ?>
<div class="card">
    <div class="card-header">施工照片</div>
    <div class="photo-gallery">
        <?php foreach ($worklog['photos'] as $photo): ?>
        <div class="photo-item" id="photo-<?= $photo['id'] ?>">
            <img src="<?= e($photo['file_path']) ?>" alt="<?= e($photo['caption'] ?? '施工照片') ?>" loading="lazy" onclick="openPhotoModal(this.src)">
            <?php if ($photo['caption']): ?><div class="photo-caption"><?= e($photo['caption']) ?></div><?php endif; ?>
            <button type="button" class="photo-delete" onclick="deletePhoto(<?= $photo['id'] ?>)" title="刪除">&times;</button>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <!-- 上工/下工時間提醒 -->
    <?php if (!$worklog['arrival_time'] || !$worklog['departure_time']): ?>
    <div class="alert alert-warning">
        <?php if (!$worklog['arrival_time']): ?>尚未打卡到場，請先打卡。<?php endif; ?>
        <?php if ($worklog['arrival_time'] && !$worklog['departure_time']): ?>施工完畢請記得打卡離場。<?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- 施作說明 -->
    <div class="card">
        <div class="card-header">施作說明</div>
        <div class="form-group">
            <label>今日施工項目 <span class="text-danger">*</span></label>
            <textarea name="work_description" class="form-control" rows="4" placeholder="請描述今日施工項目及完成情況" required><?= e($worklog['work_description'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
            <label>問題/異常</label>
            <textarea name="issues" class="form-control" rows="3" placeholder="如有遇到問題或異常請填寫"><?= e($worklog['issues'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
            <label class="checkbox-label">
                <input type="hidden" name="next_visit_needed" value="0">
                <input type="checkbox" name="next_visit_needed" value="1" <?= !empty($worklog['next_visit_needed']) ? 'checked' : '' ?>
                       onchange="document.getElementById('nextVisitNote').style.display = this.checked ? 'block' : 'none'">
                <span>需要再次施工</span>
            </label>
        </div>
        <div class="form-group" id="nextVisitNote" style="display:<?= !empty($worklog['next_visit_needed']) ? 'block' : 'none' ?>">
            <label>下次施工備註</label>
            <textarea name="next_visit_note" class="form-control" rows="2" placeholder="下次施工需注意的事項"><?= e($worklog['next_visit_note'] ?? '') ?></textarea>
        </div>
    </div>

    <!-- 照片上傳 -->
    <div class="card">
        <div class="card-header">上傳照片</div>
        <div class="form-group">
            <input type="file" name="photos[]" multiple accept="image/*" class="form-control" capture="environment">
            <p class="text-muted" style="font-size:.8rem;margin-top:4px">可選擇多張照片，每張最大 10MB（支援 JPG/PNG/GIF/WebP）</p>
        </div>
    </div>

    <!-- 收款資訊 -->
    <div class="card">
        <div class="card-header">收款資訊</div>
        <div class="form-group">
            <label class="checkbox-label">
                <input type="hidden" name="payment_collected" value="0">
                <input type="checkbox" name="payment_collected" value="1" <?= !empty($worklog['payment_collected']) ? 'checked' : '' ?>
                       onchange="document.getElementById('paymentSection').style.display = this.checked ? 'block' : 'none'">
                <span>本次有收款</span>
            </label>
        </div>
        <div id="paymentSection" style="display:<?= !empty($worklog['payment_collected']) ? 'block' : 'none' ?>">
            <div class="form-row">
                <div class="form-group">
                    <label>收款金額</label>
                    <input type="number" name="payment_amount" class="form-control" step="1" min="0" value="<?= e($worklog['payment_amount'] ?? '') ?>" placeholder="0">
                </div>
                <div class="form-group">
                    <label>收款方式</label>
                    <select name="payment_method" class="form-control">
                        <option value="">請選擇</option>
                        <option value="cash" <?= ($worklog['payment_method'] ?? '') === 'cash' ? 'selected' : '' ?>>現金</option>
                        <option value="transfer" <?= ($worklog['payment_method'] ?? '') === 'transfer' ? 'selected' : '' ?>>匯款</option>
                        <option value="check" <?= ($worklog['payment_method'] ?? '') === 'check' ? 'selected' : '' ?>>支票</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>收款備註</label>
                <input type="text" name="payment_note" class="form-control" value="<?= e($worklog['payment_note'] ?? '') ?>" placeholder="收款備註（如支票號碼等）">
            </div>
        </div>
    </div>

    <!-- 材料使用 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>器材/耗材使用</span>
            <button type="button" class="btn btn-outline btn-sm" onclick="addMaterial()">+ 新增材料</button>
        </div>
        <p class="text-muted mb-1" style="font-size:.85rem">記錄出貨、使用、退回數量</p>

        <div id="materialsContainer">
            <?php
            $materials = $worklog['materials'] ?? array();
            if (empty($materials)) {
                $materials = array(array('material_type'=>'equipment','product_id'=>'','material_name'=>'','unit'=>'','shipped_qty'=>'','used_qty'=>'','returned_qty'=>'','unit_cost'=>'','material_note'=>''));
            }
            foreach ($materials as $idx => $m):
            ?>
            <div class="material-row" data-index="<?= $idx ?>">
                <div class="form-row">
                    <div class="form-group">
                        <label>類型</label>
                        <select name="materials[<?= $idx ?>][material_type]" class="form-control" onchange="toggleProductSearch(this)">
                            <option value="equipment" <?= ($m['material_type'] ?? '') === 'equipment' ? 'selected' : '' ?>>器材</option>
                            <option value="consumable" <?= ($m['material_type'] ?? '') === 'consumable' ? 'selected' : '' ?>>耗材</option>
                            <option value="cable" <?= ($m['material_type'] ?? '') === 'cable' ? 'selected' : '' ?>>線材</option>
                        </select>
                    </div>
                    <div class="form-group" style="flex:2">
                        <label>名稱</label>
                        <input type="text" name="materials[<?= $idx ?>][material_name]" class="form-control material-name-input"
                               value="<?= e($m['material_name'] ?? $m['product_name'] ?? '') ?>" placeholder="輸入關鍵字搜尋產品..."
                               autocomplete="off" oninput="searchProduct(this, <?= $idx ?>)">
                        <input type="hidden" name="materials[<?= $idx ?>][product_id]" value="<?= e($m['product_id'] ?? '') ?>">
                        <div class="product-suggestions" id="suggestions-<?= $idx ?>" style="display:none"></div>
                    </div>
                    <div class="form-group" style="max-width:80px">
                        <label>單位</label>
                        <input type="text" name="materials[<?= $idx ?>][unit]" class="form-control" value="<?= e($m['unit'] ?? '') ?>" placeholder="個/米">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>出貨量</label>
                        <input type="number" name="materials[<?= $idx ?>][shipped_qty]" class="form-control" step="0.1" min="0" value="<?= e($m['shipped_qty'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>使用量</label>
                        <input type="number" name="materials[<?= $idx ?>][used_qty]" class="form-control" step="0.1" min="0" value="<?= e($m['used_qty'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>退回量</label>
                        <input type="number" name="materials[<?= $idx ?>][returned_qty]" class="form-control" step="0.1" min="0" value="<?= e($m['returned_qty'] ?? '') ?>">
                    </div>
                    <div class="form-group" style="max-width:100px">
                        <label>單價</label>
                        <input type="number" name="materials[<?= $idx ?>][unit_cost]" class="form-control" step="1" min="0" value="<?= e($m['unit_cost'] ?? '') ?>">
                    </div>
                    <div class="form-group" style="align-self:flex-end;flex:0">
                        <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.material-row').remove()">X</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <button type="submit" class="btn btn-primary btn-block mt-1">儲存回報</button>
</form>

<!-- 照片預覽彈窗 -->
<div id="photoModal" class="modal-overlay hidden" onclick="if(event.target===this)this.classList.add('hidden')">
    <div style="max-width:90vw;max-height:90vh;position:relative">
        <img id="photoModalImg" src="" style="max-width:90vw;max-height:85vh;border-radius:8px">
        <span class="modal-close" onclick="document.getElementById('photoModal').classList.add('hidden')" style="position:absolute;top:-10px;right:-10px;background:#fff;border-radius:50%;width:30px;height:30px;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.3)">&times;</span>
    </div>
</div>

<style>
.worklog-time-display { display: flex; gap: 20px; font-size: .9rem; flex-wrap: wrap; }
.material-row {
    border: 1px solid var(--gray-200); border-radius: var(--radius);
    padding: 10px; margin-bottom: 8px;
}
.form-row { display: flex; flex-wrap: wrap; gap: 8px; }
.form-row .form-group { flex: 1; min-width: 80px; }
.checkbox-label { display: flex; align-items: center; gap: 6px; cursor: pointer; }
.checkbox-label input[type="checkbox"] { width: 18px; height: 18px; }

/* 照片 */
.photo-gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 8px; margin-top: 8px; }
.photo-item { position: relative; border-radius: var(--radius); overflow: hidden; }
.photo-item img { width: 100%; height: 120px; object-fit: cover; cursor: pointer; }
.photo-caption { font-size: .75rem; padding: 2px 4px; color: var(--gray-700); }
.photo-delete {
    position: absolute; top: 4px; right: 4px;
    background: rgba(0,0,0,.5); color: #fff; border: none;
    width: 24px; height: 24px; border-radius: 50%; cursor: pointer;
    font-size: 1rem; line-height: 1; display: flex; align-items: center; justify-content: center;
}
.photo-delete:hover { background: var(--danger); }

/* 產品搜尋建議 */
.product-suggestions {
    position: absolute; z-index: 100; background: #fff;
    border: 1px solid var(--gray-300); border-radius: var(--radius);
    max-height: 200px; overflow-y: auto; width: 100%;
    box-shadow: var(--shadow);
}
.product-suggestion-item {
    padding: 6px 10px; cursor: pointer; font-size: .85rem;
    border-bottom: 1px solid var(--gray-100);
}
.product-suggestion-item:hover { background: var(--gray-50); }
.product-suggestion-item .text-muted { font-size: .75rem; }

.form-group { position: relative; }
</style>

<script>
var materialIndex = <?= count($materials) ?>;
var searchTimeout = null;

function addMaterial() {
    var i = materialIndex;
    var html = '<div class="material-row" data-index="' + i + '">' +
        '<div class="form-row">' +
        '<div class="form-group"><label>類型</label><select name="materials[' + i + '][material_type]" class="form-control"><option value="equipment">器材</option><option value="consumable">耗材</option><option value="cable">線材</option></select></div>' +
        '<div class="form-group" style="flex:2"><label>名稱</label><input type="text" name="materials[' + i + '][material_name]" class="form-control material-name-input" placeholder="輸入關鍵字搜尋產品..." autocomplete="off" oninput="searchProduct(this,' + i + ')"><input type="hidden" name="materials[' + i + '][product_id]" value=""><div class="product-suggestions" id="suggestions-' + i + '" style="display:none"></div></div>' +
        '<div class="form-group" style="max-width:80px"><label>單位</label><input type="text" name="materials[' + i + '][unit]" class="form-control" placeholder="個/米"></div>' +
        '</div>' +
        '<div class="form-row">' +
        '<div class="form-group"><label>出貨量</label><input type="number" name="materials[' + i + '][shipped_qty]" class="form-control" step="0.1" min="0"></div>' +
        '<div class="form-group"><label>使用量</label><input type="number" name="materials[' + i + '][used_qty]" class="form-control" step="0.1" min="0"></div>' +
        '<div class="form-group"><label>退回量</label><input type="number" name="materials[' + i + '][returned_qty]" class="form-control" step="0.1" min="0"></div>' +
        '<div class="form-group" style="max-width:100px"><label>單價</label><input type="number" name="materials[' + i + '][unit_cost]" class="form-control" step="1" min="0"></div>' +
        '<div class="form-group" style="align-self:flex-end;flex:0"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest(\'.material-row\').remove()">X</button></div>' +
        '</div></div>';
    document.getElementById('materialsContainer').insertAdjacentHTML('beforeend', html);
    materialIndex++;
}

function searchProduct(input, idx) {
    var keyword = input.value.trim();
    var sugBox = document.getElementById('suggestions-' + idx);
    if (keyword.length < 2) { sugBox.style.display = 'none'; return; }

    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(function() {
        fetch('/products.php?action=ajax_search&keyword=' + encodeURIComponent(keyword))
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data.data || data.data.length === 0) { sugBox.style.display = 'none'; return; }
            var html = '';
            data.data.forEach(function(p) {
                html += '<div class="product-suggestion-item" onclick="selectProduct(' + idx + ',' + p.id + ',\'' + p.name.replace(/'/g, "\\'") + '\',\'' + (p.unit || '').replace(/'/g, "\\'") + '\',' + (p.price || 0) + ')">' +
                    '<div>' + p.name + '</div>' +
                    '<div class="text-muted">' + (p.model_number || '') + ' | $' + (p.price || 0) + '</div></div>';
            });
            sugBox.innerHTML = html;
            sugBox.style.display = 'block';
        });
    }, 300);
}

function selectProduct(idx, productId, name, unit, price) {
    var row = document.querySelector('.material-row[data-index="' + idx + '"]');
    row.querySelector('[name="materials[' + idx + '][material_name]"]').value = name;
    row.querySelector('[name="materials[' + idx + '][product_id]"]').value = productId;
    if (unit) row.querySelector('[name="materials[' + idx + '][unit]"]').value = unit;
    if (price) row.querySelector('[name="materials[' + idx + '][unit_cost]"]').value = price;
    document.getElementById('suggestions-' + idx).style.display = 'none';
}

// 點擊外部關閉建議
document.addEventListener('click', function(e) {
    if (!e.target.classList.contains('material-name-input')) {
        document.querySelectorAll('.product-suggestions').forEach(function(el) { el.style.display = 'none'; });
    }
});

function openPhotoModal(src) {
    document.getElementById('photoModalImg').src = src;
    document.getElementById('photoModal').classList.remove('hidden');
}

function deletePhoto(photoId) {
    if (!confirm('確定刪除此照片?')) return;
    fetch('/worklog.php?action=delete_photo', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({photo_id: photoId})
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.success) {
            var el = document.getElementById('photo-' + photoId);
            if (el) el.remove();
        } else {
            alert(data.error || '刪除失敗');
        }
    });
}
</script>
