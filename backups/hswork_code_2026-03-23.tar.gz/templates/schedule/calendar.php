<?php
// 計算月曆資料
$firstDay = mktime(0, 0, 0, $month, 1, $year);
$daysInMonth = (int)date('t', $firstDay);
$startWeekday = (int)date('w', $firstDay); // 0=Sun
$prevMonth = $month - 1; $prevYear = $year;
if ($prevMonth < 1) { $prevMonth = 12; $prevYear--; }
$nextMonth = $month + 1; $nextYear = $year;
if ($nextMonth > 12) { $nextMonth = 1; $nextYear++; }
$today = date('Y-m-d');

// 容量閥值
$capYellow = max(1, (int)ceil($totalEngineers * 0.6));
$capRed    = $totalEngineers;
?>

<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2><?= $year ?> 年 <?= $month ?> 月 工程行事曆</h2>
    <div class="d-flex gap-1 align-center flex-wrap">
        <?php if (Auth::hasPermission('schedule.manage')): ?>
        <div class="cal-filter-wrap">
            <select id="personFilter" class="form-control form-control-sm" onchange="filterByPerson(this.value)" style="min-width:120px">
                <option value="0">全部人員</option>
                <?php foreach ($engineerList as $eng): ?>
                <option value="<?= $eng['id'] ?>" <?= $filterUserId == $eng['id'] ? 'selected' : '' ?>><?= e($eng['real_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <?php if (Auth::hasPermission('schedule.manage')): ?>
        <a href="/schedule.php?action=create" class="btn btn-primary btn-sm">+ 新增排工</a>
        <?php endif; ?>
    </div>
</div>

<!-- 圖例 -->
<div class="d-flex gap-2 flex-wrap mb-1" style="font-size:.8rem">
    <span><span class="status-dot status-open"></span> 可排工</span>
    <span><span class="status-dot status-partial"></span> 已排</span>
    <span><span class="status-dot status-full"></span> 已滿</span>
    <span><span class="status-dot status-closed"></span> 不可排工</span>
    <span style="color:#e65100">🏖 休假</span>
    <span class="text-muted">共 <?= $totalEngineers ?> 位工程人員</span>
    <?php if ($filterUserId): ?>
    <span class="badge badge-primary">篩選中：<?= e(array_reduce($engineerList, function($carry, $e) use ($filterUserId) { return $e['id'] == $filterUserId ? $e['real_name'] : $carry; }, '')) ?></span>
    <?php endif; ?>
</div>

<!-- 多次施工人員不同組通知 -->
<?php if (!empty($visitWarnings)): ?>
<div class="alert alert-warning">
    <strong>多次施工人員組別不同：</strong>
    <ul style="margin:4px 0 0 16px;padding:0">
        <?php foreach ($visitWarnings as $w): ?>
        <li><?= e($w['case_number']) ?> <?= e($w['case_title']) ?> - 第<?= $w['visit_number'] ?>次施工人員與第<?= $w['previous_visit_number'] ?>次不同</li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<!-- 月份切換 -->
<div class="d-flex justify-between align-center mb-1">
    <a href="/schedule.php?year=<?= $prevYear ?>&month=<?= $prevMonth ?><?= $filterUserId ? '&user_id='.$filterUserId : '' ?>" class="btn btn-outline btn-sm">&laquo; 上月</a>
    <a href="/schedule.php?year=<?= date('Y') ?>&month=<?= date('m') ?><?= $filterUserId ? '&user_id='.$filterUserId : '' ?>" class="btn btn-outline btn-sm">今天</a>
    <a href="/schedule.php?year=<?= $nextYear ?>&month=<?= $nextMonth ?><?= $filterUserId ? '&user_id='.$filterUserId : '' ?>" class="btn btn-outline btn-sm">下月 &raquo;</a>
</div>

<?php
// 預先計算每日狀態供重複使用
$dayStatusData = array();
for ($day = 1; $day <= $daysInMonth; $day++) {
    $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $day);
    $dow = ($startWeekday + $day - 1) % 7;
    $isSunday = ($dow === 0);

    // 是否開放
    $isOpen = $model->isDayOpen($dateStr, $daySettings);
    $setting = isset($daySettings[$dateStr]) ? $daySettings[$dateStr] : null;
    $maxTeams = $setting ? $setting['max_teams'] : null;
    $maxEng = $setting ? $setting['max_engineers'] : null;
    $settingNote = $setting ? $setting['note'] : '';

    // 已用容量
    $usedEng = isset($dailyCapacity[$dateStr]) ? $dailyCapacity[$dateStr] : 0;
    $usedTeams = isset($dailyTeams[$dateStr]) ? $dailyTeams[$dateStr] : 0;

    // 判斷狀態
    // closed / open / partial / full
    if (!$isOpen) {
        $status = 'closed';
        $statusLabel = '不可排工';
    } else {
        // 檢查是否已滿
        $isFull = false;
        if ($maxTeams !== null && $usedTeams >= $maxTeams) $isFull = true;
        if ($maxEng !== null && $usedEng >= $maxEng) $isFull = true;
        if ($maxTeams === null && $maxEng === null && $usedEng >= $totalEngineers) $isFull = true;

        if ($isFull) {
            $status = 'full';
            $statusLabel = '已滿';
        } elseif ($usedTeams > 0) {
            $status = 'partial';
            $statusLabel = '已排';
        } else {
            $status = 'open';
            $statusLabel = '可排工';
        }
    }

    // 容量文字 + 百分比
    $capText = '';
    if ($isOpen && ($usedEng > 0 || $usedTeams > 0)) {
        $capMax = ($maxEng !== null) ? $maxEng : $totalEngineers;
        $pct = ($capMax > 0) ? (int)round($usedEng / $capMax * 100) : 0;
        if ($maxTeams !== null) {
            $capText = $usedTeams . '/' . $maxTeams . '組 ';
        }
        $capText .= $usedEng . '/' . $capMax . '人 ' . $pct . '%';
    }

    $dayStatusData[$dateStr] = array(
        'isOpen' => $isOpen,
        'status' => $status,
        'statusLabel' => $statusLabel,
        'capText' => $capText,
        'maxTeams' => $maxTeams,
        'maxEng' => $maxEng,
        'usedTeams' => $usedTeams,
        'usedEng' => $usedEng,
        'note' => $settingNote,
        'isSunday' => $isSunday,
    );
}
?>

<!-- 行事曆 - 桌面版 -->
<div class="calendar-desktop hide-mobile">
    <div class="calendar-grid">
        <div class="cal-header">日</div>
        <div class="cal-header">一</div>
        <div class="cal-header">二</div>
        <div class="cal-header">三</div>
        <div class="cal-header">四</div>
        <div class="cal-header">五</div>
        <div class="cal-header">六</div>

        <?php for ($i = 0; $i < $startWeekday; $i++): ?>
        <div class="cal-cell cal-empty"></div>
        <?php endfor; ?>

        <?php for ($day = 1; $day <= $daysInMonth; $day++):
            $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $day);
            $daySchedules = isset($schedulesByDate[$dateStr]) ? $schedulesByDate[$dateStr] : array();
            $isToday = ($dateStr === $today);
            $isWeekend = in_array(($startWeekday + $day - 1) % 7, array(0, 6));
            $ds_info = $dayStatusData[$dateStr];

            // 當日休假人員（去重）
            $dayLeaves = isset($leavesByDate[$dateStr]) ? $leavesByDate[$dateStr] : array();
            $leaveNames = array();
            foreach ($dayLeaves as $lv) {
                if (!isset($leaveNames[$lv['user_id']])) {
                    $leaveNames[$lv['user_id']] = $lv['real_name'];
                }
            }

            // 登入者的排工放前面
            $mySchedules = array();
            $otherSchedules = array();
            foreach ($daySchedules as $ds) {
                $engIds = array_column($ds['engineers'], 'user_id');
                if (in_array($currentUserId, $engIds)) {
                    $mySchedules[] = $ds;
                } else {
                    $otherSchedules[] = $ds;
                }
            }
            $sortedSchedules = array_merge($mySchedules, $otherSchedules);

            // +N 收合
            $maxShow = 3;
            $hasMore = count($sortedSchedules) > $maxShow;
        ?>
        <div class="cal-cell <?= $isToday ? 'cal-today' : '' ?> <?= !$ds_info['isOpen'] ? 'cal-closed' : '' ?> <?= $ds_info['status'] === 'full' ? 'cal-status-full' : '' ?>"
             data-date="<?= $dateStr ?>">
            <div class="cal-date">
                <span><?= $day ?></span>
                <span class="cal-date-actions">
                    <?php if ($isBoss): ?>
                    <span class="cal-setting-btn" onclick="openDaySetting('<?= $dateStr ?>')" title="排工日設定">&#9881;</span>
                    <?php endif; ?>
                    <?php if (Auth::hasPermission('schedule.manage')): ?>
                    <span class="cal-leave-btn" onclick="openLeaveModal('<?= $dateStr ?>')" title="標記休假">🏖</span>
                    <?php if ($ds_info['isOpen']): ?>
                    <a href="/schedule.php?action=create&date=<?= $dateStr ?>" class="cal-add" title="新增排工">+</a>
                    <?php endif; ?>
                    <?php endif; ?>
                </span>
            </div>
            <div class="cal-status-row">
                <span class="status-tag status-tag-<?= $ds_info['status'] ?>"><?= $ds_info['statusLabel'] ?></span>
                <?php if ($ds_info['capText']): ?>
                <span class="cap-badge cap-badge-<?= $ds_info['status'] ?>"><?= $ds_info['capText'] ?></span>
                <?php endif; ?>
            </div>
            <?php if (!empty($leaveNames)): ?>
            <div class="cal-leave-bar" title="休假：<?= e(implode('、', $leaveNames)) ?>"<?php if (Auth::hasPermission('schedule.manage')): ?> onclick="openLeaveModal('<?= $dateStr ?>')" style="cursor:pointer"<?php endif; ?>>
                🏖 <?= e(implode('、', $leaveNames)) ?>
            </div>
            <?php endif; ?>
            <?php if ($ds_info['note']): ?>
            <div class="cal-note-bar"><?= e($ds_info['note']) ?></div>
            <?php endif; ?>
            <?php
            $shown = 0;
            foreach ($sortedSchedules as $ds):
                if ($shown >= $maxShow && $hasMore) break;
                $shown++;
                $isMine = in_array($currentUserId, array_column($ds['engineers'], 'user_id'));
            ?>
            <a href="/schedule.php?action=view&id=<?= $ds['id'] ?>" class="cal-event cal-event-<?= $ds['status'] ?> <?= $isMine ? 'cal-event-mine' : '' ?>">
                <div class="cal-event-title"><?= e(mb_substr($ds['case_title'], 0, 10)) ?></div>
                <div class="cal-event-info">
                    <?php if ($ds['plate_number']): ?><span><?= e($ds['plate_number']) ?></span><?php endif; ?>
                    <span><?= count($ds['engineers']) ?>人</span>
                    <?php if ($ds['total_visits'] > 1): ?><span><?= $ds['visit_number'] ?>/<?= $ds['total_visits'] ?></span><?php endif; ?>
                </div>
            </a>
            <?php endforeach; ?>
            <?php if ($hasMore): ?>
            <div class="cal-more" onclick="toggleMore(this)" data-date="<?= $dateStr ?>">+<?= count($sortedSchedules) - $maxShow ?> 更多</div>
            <div class="cal-hidden" style="display:none">
                <?php for ($si = $maxShow; $si < count($sortedSchedules); $si++):
                    $ds = $sortedSchedules[$si];
                    $isMine = in_array($currentUserId, array_column($ds['engineers'], 'user_id'));
                ?>
                <a href="/schedule.php?action=view&id=<?= $ds['id'] ?>" class="cal-event cal-event-<?= $ds['status'] ?> <?= $isMine ? 'cal-event-mine' : '' ?>">
                    <div class="cal-event-title"><?= e(mb_substr($ds['case_title'], 0, 10)) ?></div>
                    <div class="cal-event-info">
                        <?php if ($ds['plate_number']): ?><span><?= e($ds['plate_number']) ?></span><?php endif; ?>
                        <span><?= count($ds['engineers']) ?>人</span>
                    </div>
                </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endfor; ?>
    </div>
</div>

<!-- 行事曆 - 手機版列表 -->
<div class="calendar-mobile show-mobile">
    <?php for ($day = 1; $day <= $daysInMonth; $day++):
        $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $day);
        $daySchedules = isset($schedulesByDate[$dateStr]) ? $schedulesByDate[$dateStr] : array();
        $dayLeaves = isset($leavesByDate[$dateStr]) ? $leavesByDate[$dateStr] : array();
        $ds_info = $dayStatusData[$dateStr];
        if (empty($daySchedules) && empty($dayLeaves) && $dateStr < $today && $ds_info['isOpen']) continue;
        $isToday = ($dateStr === $today);
        $weekdays = array('日','一','二','三','四','五','六');
        $wd = $weekdays[($startWeekday + $day - 1) % 7];

        // 登入者排工優先
        $mySchedules = array();
        $otherSchedules = array();
        foreach ($daySchedules as $ds) {
            $engIds = array_column($ds['engineers'], 'user_id');
            if (in_array($currentUserId, $engIds)) {
                $mySchedules[] = $ds;
            } else {
                $otherSchedules[] = $ds;
            }
        }
        $sortedSchedules = array_merge($mySchedules, $otherSchedules);

        $leaveNames = array();
        foreach ($dayLeaves as $lv) {
            if (!isset($leaveNames[$lv['user_id']])) {
                $leaveNames[$lv['user_id']] = $lv['real_name'];
            }
        }
    ?>
    <div class="mobile-day <?= $isToday ? 'mobile-day-today' : '' ?> <?= !$ds_info['isOpen'] ? 'mobile-day-closed' : '' ?> <?= $ds_info['status'] === 'full' ? 'mobile-day-full' : '' ?>">
        <div class="mobile-day-header">
            <span class="mobile-day-num"><?= $month ?>/<?= $day ?> (<?= $wd ?>)</span>
            <?php if ($isToday): ?><span class="badge badge-primary">今天</span><?php endif; ?>
            <span class="status-tag status-tag-<?= $ds_info['status'] ?>"><?= $ds_info['statusLabel'] ?></span>
            <?php if ($ds_info['capText']): ?>
            <span class="cap-badge cap-badge-<?= $ds_info['status'] ?>"><?= $ds_info['capText'] ?></span>
            <?php endif; ?>
            <div style="margin-left:auto;display:flex;gap:4px">
                <?php if ($isBoss): ?>
                <button type="button" class="btn btn-outline btn-sm" onclick="openDaySetting('<?= $dateStr ?>')" style="padding:2px 6px">&#9881;</button>
                <?php endif; ?>
                <?php if (Auth::hasPermission('schedule.manage')): ?>
                <button type="button" class="btn btn-outline btn-sm" onclick="openLeaveModal('<?= $dateStr ?>')" style="padding:2px 6px">🏖</button>
                <?php if ($ds_info['isOpen']): ?>
                <a href="/schedule.php?action=create&date=<?= $dateStr ?>" class="btn btn-outline btn-sm" style="padding:2px 6px">+ 排工</a>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php if (!empty($leaveNames)): ?>
        <div class="cal-leave-bar" <?php if (Auth::hasPermission('schedule.manage')): ?>onclick="openLeaveModal('<?= $dateStr ?>')" style="cursor:pointer"<?php endif; ?>>
            🏖 休假：<?= e(implode('、', $leaveNames)) ?>
        </div>
        <?php endif; ?>
        <?php if ($ds_info['note']): ?>
        <div class="cal-note-bar"><?= e($ds_info['note']) ?></div>
        <?php endif; ?>
        <?php if (empty($sortedSchedules) && empty($leaveNames) && $ds_info['isOpen']): ?>
            <p class="text-muted" style="font-size:.85rem;padding:4px 0">無排工</p>
        <?php endif; ?>
        <?php foreach ($sortedSchedules as $ds):
            $isMine = in_array($currentUserId, array_column($ds['engineers'], 'user_id'));
        ?>
        <a href="/schedule.php?action=view&id=<?= $ds['id'] ?>" class="mobile-schedule-card <?= $isMine ? 'mobile-card-mine' : '' ?>">
            <div class="d-flex justify-between align-center">
                <strong><?= e($ds['case_title']) ?></strong>
                <span class="badge badge-<?= $ds['status'] === 'completed' ? 'success' : 'primary' ?>"><?= e($ds['status']) ?></span>
            </div>
            <div class="mobile-schedule-meta">
                <?php if ($ds['plate_number']): ?><span><?= e($ds['plate_number']) ?></span><?php endif; ?>
                <span><?= implode(', ', array_column($ds['engineers'], 'real_name')) ?: '未指派' ?></span>
                <?php if ($ds['total_visits'] > 1): ?><span>第<?= $ds['visit_number'] ?>/<?= $ds['total_visits'] ?>次</span><?php endif; ?>
            </div>
            <?php if ($ds['address']): ?>
            <div class="text-muted" style="font-size:.8rem"><?= e($ds['address']) ?> <a href="https://maps.google.com/?q=<?= urlencode($ds['address']) ?>" target="_blank" rel="noopener" onclick="event.stopPropagation()" title="導航" class="map-btn">&#x1F5FA;</a></div>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endfor; ?>
</div>

<!-- 休假 Modal -->
<?php if (Auth::hasPermission('schedule.manage')): ?>
<div id="leaveModal" class="modal-overlay" style="display:none" onclick="if(event.target===this)closeLeaveModal()">
    <div class="modal-content" style="max-width:400px">
        <div class="modal-header">
            <h3 id="leaveModalTitle">標記休假</h3>
            <button type="button" onclick="closeLeaveModal()" style="background:none;border:none;font-size:1.2rem;cursor:pointer">&times;</button>
        </div>
        <div class="modal-body">
            <p style="font-size:.85rem;color:var(--gray-500);margin-bottom:8px">勾選當日休假的人員：</p>
            <div id="leaveEngList" style="max-height:300px;overflow-y:auto">
                <?php foreach ($engineerList as $eng): ?>
                <label class="leave-eng-item" data-uid="<?= $eng['id'] ?>">
                    <input type="checkbox" value="<?= $eng['id'] ?>" class="leave-cb">
                    <span><?= e($eng['real_name']) ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary btn-sm" onclick="saveLeave()">儲存</button>
            <button type="button" class="btn btn-outline btn-sm" onclick="closeLeaveModal()">取消</button>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- 排工日設定 Modal（僅管理者） -->
<?php if ($isBoss): ?>
<div id="daySettingModal" class="modal-overlay" style="display:none" onclick="if(event.target===this)closeDaySetting()">
    <div class="modal-content" style="max-width:420px">
        <div class="modal-header">
            <h3 id="daySettingTitle">排工日設定</h3>
            <button type="button" onclick="closeDaySetting()" style="background:none;border:none;font-size:1.2rem;cursor:pointer">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group mb-1">
                <label style="font-weight:600">是否開放排工</label>
                <div class="d-flex gap-2" style="margin-top:4px">
                    <label><input type="radio" name="ds_is_open" value="1"> 開放</label>
                    <label><input type="radio" name="ds_is_open" value="0"> 不可排工</label>
                </div>
            </div>
            <div id="dsCapFields">
                <div class="form-group mb-1">
                    <label>最大組數 <span class="text-muted" style="font-size:.8rem">(留空=不限)</span></label>
                    <input type="number" id="ds_max_teams" class="form-control" min="0" placeholder="不限">
                </div>
                <div class="form-group mb-1">
                    <label>最大可排人數 <span class="text-muted" style="font-size:.8rem">(留空=不限)</span></label>
                    <input type="number" id="ds_max_engineers" class="form-control" min="0" placeholder="不限">
                </div>
            </div>
            <div class="form-group mb-1">
                <label>備註</label>
                <input type="text" id="ds_note" class="form-control" placeholder="例：國定假日、教育訓練日">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary btn-sm" onclick="saveDaySetting()">儲存</button>
            <button type="button" class="btn btn-outline btn-sm" onclick="closeDaySetting()">取消</button>
        </div>
    </div>
</div>
<?php endif; ?>

<style>
/* 狀態圖例 */
.status-dot { display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 4px; vertical-align: middle; }
.status-open { background: #34a853; }
.status-partial { background: #fbbc04; }
.status-full { background: #ea4335; }
.status-closed { background: #9e9e9e; }

/* 狀態標籤（每日顯示） */
.status-tag { font-size: .6rem; padding: 1px 4px; border-radius: 3px; font-weight: 600; vertical-align: middle; margin-left: 2px; }
.status-tag-open { background: #e6f4ea; color: #137333; }
.status-tag-partial { background: #fef7e0; color: #b06000; }
.status-tag-full { background: #fce8e6; color: #c5221f; }
.status-tag-closed { background: #f0f0f0; color: #666; }

/* 容量 badge */
.cap-badge { font-size: .6rem; padding: 1px 4px; border-radius: 8px; font-weight: 600; vertical-align: middle; margin-left: 2px; }
.cap-badge-open { background: #e6f4ea; color: #137333; }
.cap-badge-partial { background: #fef7e0; color: #b06000; }
.cap-badge-full { background: #fce8e6; color: #c5221f; }
.cap-badge-closed { display: none; }

/* 桌面版行事曆 */
.calendar-grid {
    display: grid; grid-template-columns: repeat(7, 1fr);
    border: 1px solid var(--gray-200); border-radius: var(--radius);
    background: #fff;
}
.cal-header {
    padding: 8px; text-align: center; font-weight: 600;
    background: var(--gray-100); border-bottom: 1px solid var(--gray-200);
    font-size: .85rem;
}
.cal-cell {
    min-height: 100px; padding: 4px; border-right: 1px solid var(--gray-200);
    border-bottom: 1px solid var(--gray-200); position: relative;
}
.cal-cell:nth-child(7n) { border-right: none; }
.cal-empty { background: var(--gray-50); }
.cal-today { background: #e8f0fe; }
.cal-closed { background: #f5f5f5; opacity: .75; }
.cal-status-full { border-left: 3px solid var(--danger); background: #fff5f5; }

.cal-date {
    display: flex; justify-content: space-between; align-items: center;
    font-size: .85rem; font-weight: 500; margin-bottom: 0;
}
.cal-status-row {
    display: flex; gap: 3px; align-items: center; margin-bottom: 3px;
    flex-wrap: nowrap;
}
.cal-date-actions { display: flex; gap: 2px; align-items: center; }
.cal-add {
    width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;
    background: var(--primary); color: #fff; border-radius: 50%;
    font-size: .8rem; text-decoration: none; opacity: 0;
    transition: opacity .15s;
}
.cal-leave-btn, .cal-setting-btn {
    width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;
    cursor: pointer; font-size: .75rem; opacity: 0;
    transition: opacity .15s; border-radius: 50%;
}
.cal-leave-btn:hover { background: #fff3e0; }
.cal-setting-btn:hover { background: #e3f2fd; }
.cal-cell:hover .cal-add, .cal-cell:hover .cal-leave-btn, .cal-cell:hover .cal-setting-btn { opacity: 1; }

.cal-event {
    display: block; padding: 3px 6px; margin-bottom: 2px;
    border-radius: 4px; font-size: .75rem; text-decoration: none;
    color: #fff; transition: opacity .15s;
}
.cal-event:hover { opacity: .85; text-decoration: none; }
.cal-event-planned { background: var(--primary); }
.cal-event-confirmed { background: var(--info); }
.cal-event-in_progress { background: var(--warning); color: #333; }
.cal-event-completed { background: var(--success); }
.cal-event-cancelled { background: var(--gray-500); }
.cal-event-title { font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cal-event-info { display: flex; gap: 4px; opacity: .9; font-size: .7rem; }

/* 登入者的排工（醒目邊框） */
.cal-event-mine { box-shadow: 0 0 0 2px #ff6b35; }
.mobile-card-mine { border-left: 3px solid #ff6b35; }

/* 休假人員 */
.cal-leave-bar {
    font-size: .7rem; padding: 2px 5px; margin-bottom: 3px;
    background: #fff3e0; color: #e65100; border-radius: 3px;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    border-left: 2px solid #ff9800;
}

/* 備註 */
.cal-note-bar {
    font-size: .65rem; padding: 1px 5px; margin-bottom: 3px;
    background: #e3f2fd; color: #1565c0; border-radius: 3px;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}

/* +N 展開 */
.cal-more {
    font-size: .7rem; color: var(--primary); cursor: pointer;
    padding: 2px 6px; text-align: center; font-weight: 500;
}
.cal-more:hover { text-decoration: underline; }

/* 手機版列表 */
.calendar-mobile { display: flex; flex-direction: column; gap: 4px; }
.mobile-day { background: #fff; border-radius: var(--radius); padding: 10px; box-shadow: var(--shadow); }
.mobile-day-today { border-left: 3px solid var(--primary); }
.mobile-day-closed { background: #f5f5f5; opacity: .75; }
.mobile-day-full { border-top: 2px solid var(--danger); background: #fff8f8; }
.mobile-day-header { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; flex-wrap: wrap; }
.mobile-day-num { font-weight: 600; }
.mobile-schedule-card {
    display: block; border: 1px solid var(--gray-200); border-radius: var(--radius);
    padding: 8px; margin-bottom: 4px; text-decoration: none; color: inherit;
}
.mobile-schedule-card:hover { box-shadow: var(--shadow); text-decoration: none; }
.mobile-schedule-meta { font-size: .8rem; color: var(--gray-500); display: flex; gap: 8px; flex-wrap: wrap; margin-top: 2px; }

/* 篩選 */
.cal-filter-wrap select { font-size: .85rem; padding: 4px 8px; border-radius: var(--radius); border: 1px solid var(--gray-300); }

/* Modal 共用 */
.modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,.5); z-index: 1000; display: flex; align-items: center; justify-content: center; }
.modal-content { background: #fff; border-radius: var(--radius); padding: 20px; width: 90%; max-height: 80vh; overflow-y: auto; }
.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.modal-header h3 { margin: 0; font-size: 1.1rem; }
.modal-body { margin-bottom: 16px; }
.modal-footer { display: flex; gap: 8px; }

.leave-eng-item {
    display: flex; align-items: center; gap: 8px; padding: 6px 8px;
    border-bottom: 1px solid var(--gray-100); cursor: pointer; font-size: .9rem;
}
.leave-eng-item:hover { background: var(--gray-50); }
.leave-eng-item input[type="checkbox"] { width: 16px; height: 16px; }

.show-mobile { display: flex; }
.hide-mobile { display: none; }
@media (min-width: 768px) {
    .show-mobile { display: none !important; }
    .hide-mobile { display: block !important; }
}
</style>

<script>
function filterByPerson(userId) {
    var url = '/schedule.php?year=<?= $year ?>&month=<?= $month ?>';
    if (userId && userId !== '0') url += '&user_id=' + userId;
    window.location.href = url;
}

function toggleMore(el) {
    var hidden = el.nextElementSibling;
    if (hidden.style.display === 'none') {
        hidden.style.display = 'block';
        el.textContent = '收合';
    } else {
        hidden.style.display = 'none';
        var count = hidden.querySelectorAll('.cal-event').length;
        el.textContent = '+' + count + ' 更多';
    }
}

// ===== 休假功能 =====
var leaveModalDate = '';
var leaveData = <?= json_encode(
    array_map(function($dayLeaves) {
        $uids = array();
        foreach ($dayLeaves as $lv) {
            $uids[$lv['user_id']] = true;
        }
        return array_keys($uids);
    }, $leavesByDate),
    JSON_FORCE_OBJECT
) ?>;

function openLeaveModal(dateStr) {
    leaveModalDate = dateStr;
    document.getElementById('leaveModalTitle').textContent = dateStr + ' 休假設定';
    var onLeave = leaveData[dateStr] || [];
    var cbs = document.querySelectorAll('#leaveEngList .leave-cb');
    for (var i = 0; i < cbs.length; i++) {
        cbs[i].checked = onLeave.indexOf(parseInt(cbs[i].value)) !== -1;
    }
    document.getElementById('leaveModal').style.display = 'flex';
}
function closeLeaveModal() { document.getElementById('leaveModal').style.display = 'none'; }

function saveLeave() {
    var cbs = document.querySelectorAll('#leaveEngList .leave-cb');
    var selected = [];
    for (var i = 0; i < cbs.length; i++) {
        if (cbs[i].checked) selected.push(cbs[i].value);
    }
    var form = new FormData();
    form.append('date', leaveModalDate);
    for (var j = 0; j < selected.length; j++) form.append('user_ids[]', selected[j]);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/schedule.php?action=set_day_leave');
    xhr.onload = function() { if (xhr.status === 200) window.location.reload(); else alert('儲存失敗'); };
    xhr.send(form);
}

// ===== 排工日設定（管理者） =====
var dsDate = '';
var dsData = <?= json_encode(array_map(function($s) {
    return array(
        'is_open' => (int)$s['is_open'],
        'max_teams' => $s['max_teams'],
        'max_engineers' => $s['max_engineers'],
        'note' => $s['note'],
    );
}, $daySettings), JSON_FORCE_OBJECT) ?>;
// 記錄星期日（預設不可排）
var sundayDates = <?= json_encode(array_keys(array_filter($dayStatusData, function($d) { return $d['isSunday']; }))) ?>;

function openDaySetting(dateStr) {
    dsDate = dateStr;
    document.getElementById('daySettingTitle').textContent = dateStr + ' 排工日設定';
    var setting = dsData[dateStr];
    var isSunday = sundayDates.indexOf(dateStr) !== -1;

    // 預設值
    var isOpen = 1;
    var maxTeams = '';
    var maxEng = '';
    var note = '';

    if (setting) {
        isOpen = setting.is_open;
        maxTeams = setting.max_teams !== null ? setting.max_teams : '';
        maxEng = setting.max_engineers !== null ? setting.max_engineers : '';
        note = setting.note || '';
    } else if (isSunday) {
        isOpen = 0; // 星期日預設不可排
    }

    var radios = document.querySelectorAll('input[name="ds_is_open"]');
    for (var i = 0; i < radios.length; i++) {
        radios[i].checked = (parseInt(radios[i].value) === isOpen);
    }
    document.getElementById('ds_max_teams').value = maxTeams;
    document.getElementById('ds_max_engineers').value = maxEng;
    document.getElementById('ds_note').value = note;
    toggleCapFields();
    document.getElementById('daySettingModal').style.display = 'flex';
}
function closeDaySetting() { document.getElementById('daySettingModal').style.display = 'none'; }

// 切換開放/不可排時顯示/隱藏容量欄位
document.addEventListener('change', function(e) {
    if (e.target.name === 'ds_is_open') toggleCapFields();
});
function toggleCapFields() {
    var isOpen = document.querySelector('input[name="ds_is_open"]:checked');
    var show = isOpen && isOpen.value === '1';
    document.getElementById('dsCapFields').style.display = show ? 'block' : 'none';
}

function saveDaySetting() {
    var isOpen = document.querySelector('input[name="ds_is_open"]:checked');
    if (!isOpen) { alert('請選擇是否開放'); return; }

    var form = new FormData();
    form.append('date', dsDate);
    form.append('is_open', isOpen.value);
    form.append('max_teams', document.getElementById('ds_max_teams').value);
    form.append('max_engineers', document.getElementById('ds_max_engineers').value);
    form.append('note', document.getElementById('ds_note').value);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/schedule.php?action=save_day_setting');
    xhr.onload = function() { if (xhr.status === 200) window.location.reload(); else alert('儲存失敗'); };
    xhr.send(form);
}
</script>
