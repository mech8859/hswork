<?php
$statusLabels = ['planned'=>'已規劃','confirmed'=>'已確認','in_progress'=>'施工中','completed'=>'已完工','cancelled'=>'已取消'];
$statusBadge = ['planned'=>'primary','confirmed'=>'info','in_progress'=>'warning','completed'=>'success','cancelled'=>'danger'];
?>

<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <div>
        <h2>排工詳情</h2>
        <span class="badge badge-<?= $statusBadge[$schedule['status']] ?? 'primary' ?>"><?= e($statusLabels[$schedule['status']] ?? $schedule['status']) ?></span>
    </div>
    <div class="d-flex gap-1">
        <a href="/cases.php?action=edit&id=<?= $schedule['case_id'] ?>#sec-worklog" class="btn btn-sm" style="background:#FF9800;color:#fff">施工回報</a>
        <?php if (Auth::hasPermission('schedule.manage')): ?>
        <a href="/schedule.php?action=edit&id=<?= $schedule['id'] ?>" class="btn btn-primary btn-sm">編輯</a>
        <a href="/schedule.php?action=delete&id=<?= $schedule['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>"
           class="btn btn-danger btn-sm" onclick="return confirm('確定刪除此排工?')">刪除</a>
        <?php endif; ?>
        <a href="/schedule.php" class="btn btn-outline btn-sm">返回行事曆</a>
    </div>
</div>

<div class="card">
    <div class="card-header">排工資料</div>
    <div class="detail-grid">
        <div class="detail-item">
            <span class="detail-label">案件</span>
            <span class="detail-value"><a href="/cases.php?action=view&id=<?= $schedule['case_id'] ?>"><?= e($schedule['case_number']) ?> - <?= e($schedule['case_title']) ?></a></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">施工日期</span>
            <span class="detail-value"><?= format_date($schedule['schedule_date']) ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">施工地址</span>
            <span class="detail-value"><?= e($schedule['address'] ?: '-') ?></span>
        </div>
        <?php if (!empty($schedule['address'])): ?>
        <div class="detail-item" style="grid-column: span 2">
            <span class="detail-label">地圖</span>
            <iframe src="https://maps.google.com/maps?q=<?= urlencode($schedule['address']) ?>&output=embed&hl=zh-TW" style="width:100%;max-width:480px;height:200px;border:1px solid var(--gray-200);border-radius:6px" allowfullscreen loading="lazy"></iframe>
        </div>
        <?php endif; ?>
        <div class="detail-item">
            <span class="detail-label">第幾次施工</span>
            <span class="detail-value"><?= $schedule['visit_number'] ?> / <?= $schedule['total_visits'] ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">車輛</span>
            <span class="detail-value"><?= $schedule['plate_number'] ? e($schedule['plate_number']) . ' (' . e($schedule['vehicle_type']) . ')' : '未指派' ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">據點</span>
            <span class="detail-value"><?= e($schedule['branch_name']) ?></span>
        </div>
    </div>
    <?php if ($schedule['note']): ?>
    <div class="mt-1"><span class="detail-label">備註</span><p><?= nl2br(e($schedule['note'])) ?></p></div>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header">施工人員</div>
    <?php if (empty($schedule['engineers'])): ?>
        <p class="text-muted">未指派工程師</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>姓名</th><th>電話</th><th>主工程師</th><th>強制加入</th></tr></thead>
            <tbody>
                <?php foreach ($schedule['engineers'] as $eng): ?>
                <tr>
                    <td><a href="/staff.php?action=view&id=<?= $eng['user_id'] ?>"><?= e($eng['real_name']) ?></a></td>
                    <td><a href="tel:<?= e($eng['phone'] ?? '') ?>"><?= e($eng['phone'] ?? '-') ?></a></td>
                    <td><?= $eng['is_lead'] ? '<span class="badge badge-primary">主工程師</span>' : '-' ?></td>
                    <td>
                        <?php if ($eng['is_override']): ?>
                        <span class="badge badge-warning">強制加入</span>
                        <?php if ($eng['override_reason']): ?><br><small><?= e($eng['override_reason']) ?></small><?php endif; ?>
                        <?php else: ?>-<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php if (!empty($schedule['dispatch_workers'])): ?>
<div class="card">
    <div class="card-header">點工人員</div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>姓名</th><th>電話</th><th>所屬廠商</th></tr></thead>
            <tbody>
                <?php foreach ($schedule['dispatch_workers'] as $dw): ?>
                <tr>
                    <td><?= e($dw['name']) ?></td>
                    <td><a href="tel:<?= e($dw['phone'] ?? '') ?>"><?= e($dw['phone'] ?? '-') ?></a></td>
                    <td><?= e($dw['vendor'] ?? '-') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 施工回報紀錄 -->
<div class="card">
    <div class="card-header d-flex justify-between align-center">
        <span>施工回報紀錄</span>
        <a href="/cases.php?action=edit&id=<?= $schedule['case_id'] ?>#sec-worklog" class="btn btn-sm" style="background:#FF9800;color:#fff">前往回報</a>
    </div>
    <?php if (empty($worklogs)): ?>
        <p class="text-muted" style="padding:16px">尚無施工回報</p>
    <?php else: ?>
        <?php foreach ($worklogs as $wl): ?>
        <div style="padding:12px;border-bottom:1px solid var(--gray-100)">
            <div class="d-flex justify-between align-center mb-1">
                <strong><?= e($wl['real_name']) ?></strong>
                <div style="font-size:.8rem;color:#666">
                    <?php if ($wl['arrival_time']): ?>
                    到場 <?= date('H:i', strtotime($wl['arrival_time'])) ?>
                    <?php endif; ?>
                    <?php if ($wl['departure_time']): ?>
                    ~ 離場 <?= date('H:i', strtotime($wl['departure_time'])) ?>
                    <?php
                    $dur = strtotime($wl['departure_time']) - strtotime($wl['arrival_time']);
                    if ($dur > 0) echo ' (' . round($dur/3600, 1) . 'h)';
                    ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php if ($wl['work_description']): ?>
            <div style="margin-bottom:8px">
                <span style="font-size:.8rem;color:var(--gray-500)">工作內容</span>
                <p style="margin:2px 0;white-space:pre-line"><?= e($wl['work_description']) ?></p>
            </div>
            <?php endif; ?>
            <?php if ($wl['issues']): ?>
            <div style="margin-bottom:8px">
                <span style="font-size:.8rem;color:var(--danger)">問題回報</span>
                <p style="margin:2px 0;white-space:pre-line"><?= e($wl['issues']) ?></p>
            </div>
            <?php endif; ?>
            <?php if ($wl['next_visit_needed']): ?>
            <div style="margin-bottom:8px">
                <span class="badge badge-warning">需再次施工</span>
                <?php if ($wl['next_visit_note']): ?><span style="font-size:.85rem;margin-left:4px"><?= e($wl['next_visit_note']) ?></span><?php endif; ?>
            </div>
            <?php endif; ?>
            <?php if ($wl['payment_collected']): ?>
            <div style="margin-bottom:8px">
                <span class="badge badge-success">已收款</span>
                <span style="font-size:.85rem">$<?= number_format($wl['payment_amount']) ?> (<?= e($wl['payment_method'] ?: '-') ?>)</span>
            </div>
            <?php endif; ?>
            <?php if (!empty($wl['photos'])): ?>
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px">
                <?php foreach ($wl['photos'] as $p): ?>
                <a href="<?= e($p['file_path']) ?>" target="_blank">
                    <img src="<?= e($p['file_path']) ?>" style="width:80px;height:80px;object-fit:cover;border-radius:4px;border:1px solid var(--gray-200)">
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php if (!empty($wl['materials'])): ?>
            <div style="font-size:.8rem">
                <span style="color:var(--gray-500)">使用材料：</span>
                <?php foreach ($wl['materials'] as $m): ?>
                <span style="background:var(--gray-50);padding:2px 6px;border-radius:3px;margin-right:4px"><?= e($m['material_name']) ?> x<?= $m['used_qty'] ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<style>
.detail-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
.detail-item { display: flex; flex-direction: column; }
.detail-label { font-size: .8rem; color: var(--gray-500); }
@media (max-width: 767px) { .detail-grid { grid-template-columns: 1fr; } }
</style>
