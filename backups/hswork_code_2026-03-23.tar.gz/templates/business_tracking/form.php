<?php
$caseTypeOptions = CaseModel::caseTypeOptions();
$sourceOptions = CaseModel::caseSourceOptions();
$isEdit = !empty($case);
?>
<div class="d-flex justify-between align-center mb-2">
    <h2><?= $isEdit ? '編輯案件' : '新增進件' ?></h2>
    <a href="/business_tracking.php" class="btn btn-outline btn-sm">返回</a>
</div>

<form method="POST" action="/business_tracking.php?action=<?= $isEdit ? 'edit&id='.$case['id'] : 'create' ?>">
    <input type="hidden" name="csrf_token" value="<?= e(Session::getCsrfToken()) ?>">

    <div class="card mb-2">
        <div class="card-header">案件資訊</div>
        <div class="form-grid">
            <div class="form-group" style="grid-column: span 2">
                <label>案件名稱 <span class="text-danger">*</span></label>
                <input type="text" name="title" class="form-control" value="<?= e(isset($case['title']) ? $case['title'] : '') ?>" required>
            </div>
            <div class="form-group">
                <label>案別</label>
                <select name="case_type" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($caseTypeOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= (isset($case['case_type']) ? $case['case_type'] : '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>案件來源</label>
                <select name="case_source" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($sourceOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= (isset($case['case_source']) ? $case['case_source'] : '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>進件公司</label>
                <select name="company" class="form-control">
                    <option value="">請選擇</option>
                    <option value="禾順監視數位" <?= (isset($case['company']) ? $case['company'] : '') === '禾順監視數位' ? 'selected' : '' ?>>禾順監視數位</option>
                    <option value="理創(政遠企業)" <?= (isset($case['company']) ? $case['company'] : '') === '理創(政遠企業)' ? 'selected' : '' ?>>理創(政遠企業)</option>
                </select>
            </div>
            <div class="form-group">
                <label>分公司</label>
                <select name="branch_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= (isset($case['branch_id']) ? $case['branch_id'] : '') == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="card mb-2">
        <div class="card-header">客戶資訊</div>
        <div class="form-grid">
            <div class="form-group">
                <label>客戶名稱</label>
                <input type="text" name="customer_name" class="form-control" value="<?= e(isset($case['customer_name']) ? $case['customer_name'] : '') ?>" id="customer_name_input">
                <input type="hidden" name="customer_id" value="<?= e(isset($case['customer_id']) ? $case['customer_id'] : '') ?>" id="customer_id_input">
            </div>
            <div class="form-group">
                <label>聯絡人</label>
                <input type="text" name="contact_person" class="form-control" value="<?= e(isset($case['contact_person']) ? $case['contact_person'] : '') ?>">
            </div>
            <div class="form-group">
                <label>電話</label>
                <input type="text" name="customer_phone" class="form-control" value="<?= e(isset($case['customer_phone']) ? $case['customer_phone'] : '') ?>">
            </div>
            <div class="form-group">
                <label>手機</label>
                <input type="text" name="customer_mobile" class="form-control" value="<?= e(isset($case['customer_mobile']) ? $case['customer_mobile'] : '') ?>">
            </div>
        </div>
    </div>

    <div class="card mb-2">
        <div class="card-header">施工地址</div>
        <div class="form-grid">
            <div class="form-group">
                <label>縣市</label>
                <input type="text" name="city" class="form-control" value="<?= e(isset($case['city']) ? $case['city'] : '') ?>" placeholder="如：台中市">
            </div>
            <div class="form-group">
                <label>鄉鎮區</label>
                <input type="text" name="district" class="form-control" value="<?= e(isset($case['district']) ? $case['district'] : '') ?>">
            </div>
            <div class="form-group" style="grid-column: span 2">
                <label>地址</label>
                <input type="text" name="address" class="form-control" value="<?= e(isset($case['address']) ? $case['address'] : '') ?>">
            </div>
        </div>
    </div>

    <div class="card mb-2">
        <div class="card-header">業務資訊</div>
        <div class="form-grid">
            <div class="form-group">
                <label>承辦業務</label>
                <select name="sales_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($salespeople as $sp): ?>
                    <option value="<?= $sp['id'] ?>" <?= (isset($case['sales_id']) ? $case['sales_id'] : Auth::id()) == $sp['id'] ? 'selected' : '' ?>><?= e($sp['real_name']) ?><?= $sp['is_active'] ? '' : '(離職)' ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>預估金額</label>
                <input type="number" name="deal_amount" class="form-control" value="<?= e(isset($case['deal_amount']) ? $case['deal_amount'] : '') ?>" placeholder="未稅">
            </div>
            <div class="form-group" style="grid-column: span 2">
                <label>備註</label>
                <textarea name="sales_note" class="form-control" rows="3"><?= e(isset($case['sales_note']) ? $case['sales_note'] : '') ?></textarea>
            </div>
        </div>
    </div>

    <div class="d-flex gap-1">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '建立進件' ?></button>
        <a href="/business_tracking.php" class="btn btn-outline">取消</a>
    </div>
</form>

<style>
.form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
@media (max-width: 767px) { .form-grid { grid-template-columns: 1fr; } .form-grid .form-group[style*="span 2"] { grid-column: span 1; } }
</style>
