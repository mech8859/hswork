<?php
$statusOptions = FinanceModel::paymentOutStatusOptions();
$statusBadgeMap = array(
    '待付款' => 'badge-warning',
    '已付款' => 'badge-success',
    '取消'   => 'badge-secondary',
);
?>
<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>付款單</h2>
    <a href="/payments_out.php?action=create" class="btn btn-primary btn-sm">+ 新增付款單</a>
</div>

<div class="card">
    <form method="GET" action="/payments_out.php" class="filter-form">
        <div class="filter-row">
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <option value="">全部</option>
                    <?php foreach ($statusOptions as $val => $label): ?>
                    <option value="<?= e($val) ?>" <?= (!empty($filters['status']) && $filters['status'] === $val) ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>主分類</label>
                <select name="main_category" class="form-control">
                    <option value="">全部</option>
                    <?php foreach (FinanceModel::mainCategoryOptions() as $label): ?>
                    <option value="<?= e($label) ?>" <?= (!empty($filters['main_category']) && $filters['main_category'] === $label) ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>關鍵字</label>
                <input type="text" name="keyword" class="form-control" value="<?= e(!empty($filters['keyword']) ? $filters['keyword'] : '') ?>" placeholder="廠商名/單號" autocomplete="off">
            </div>
            <div class="form-group" style="align-self:flex-end">
                <button type="submit" class="btn btn-primary btn-sm">搜尋</button>
                <a href="/payments_out.php" class="btn btn-outline btn-sm">清除</a>
            </div>
        </div>
    </form>
</div>

<div class="card">
    <?php if (empty($records)): ?>
        <p class="text-muted text-center mt-2">目前無付款單</p>
    <?php else: ?>
    <!-- 手機卡片 -->
    <div class="staff-cards show-mobile">
        <?php foreach ($records as $r): ?>
        <?php $badgeCls = !empty($statusBadgeMap[$r['status']]) ? $statusBadgeMap[$r['status']] : 'badge-secondary'; ?>
        <div class="staff-card" onclick="location.href='/payments_out.php?action=edit&id=<?= $r['id'] ?>'">
            <div class="d-flex justify-between align-center">
                <strong><?= e(!empty($r['vendor_name']) ? $r['vendor_name'] : '-') ?></strong>
                <span class="badge <?= $badgeCls ?>"><?= e(!empty($r['status']) ? $r['status'] : '-') ?></span>
            </div>
            <div class="staff-card-meta">
                <span><?= e(!empty($r['payment_number']) ? $r['payment_number'] : '-') ?></span>
                <span><?= e(!empty($r['payment_date']) ? $r['payment_date'] : '-') ?></span>
                <span>$<?= number_format(!empty($r['total_amount']) ? $r['total_amount'] : 0) ?></span>
            </div>
            <?php if (!empty($r['main_category'])): ?>
            <div class="staff-card-meta">
                <span><?= e($r['main_category']) ?></span>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- 桌面表格 -->
    <div class="table-responsive hide-mobile">
        <table class="table">
            <thead>
                <tr>
                    <th>付款單編號</th>
                    <th>建立日期</th>
                    <th>付款日期</th>
                    <th>廠商名稱</th>
                    <th>主分類</th>
                    <th class="text-right">付款金額</th>
                    <th>狀態</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $r): ?>
                <?php $badgeCls = !empty($statusBadgeMap[$r['status']]) ? $statusBadgeMap[$r['status']] : 'badge-secondary'; ?>
                <tr>
                    <td><a href="/payments_out.php?action=edit&id=<?= $r['id'] ?>"><?= e(!empty($r['payment_number']) ? $r['payment_number'] : '-') ?></a></td>
                    <td><?= e(!empty($r['create_date']) ? $r['create_date'] : '-') ?></td>
                    <td><?= e(!empty($r['payment_date']) ? $r['payment_date'] : '-') ?></td>
                    <td><?= e(!empty($r['vendor_name']) ? $r['vendor_name'] : '-') ?></td>
                    <td><?= e(!empty($r['main_category']) ? $r['main_category'] : '-') ?></td>
                    <td class="text-right">$<?= number_format(!empty($r['total_amount']) ? $r['total_amount'] : 0) ?></td>
                    <td><span class="badge <?= $badgeCls ?>"><?= e(!empty($r['status']) ? $r['status'] : '-') ?></span></td>
                    <td>
                        <a href="/payments_out.php?action=edit&id=<?= $r['id'] ?>" class="btn btn-outline btn-sm">編輯</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    <?php require __DIR__ . '/../layouts/pagination.php'; ?>
</div>

<style>
.filter-row { display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; }
.filter-row .form-group { flex: 1; min-width: 130px; margin-bottom: 0; }
.staff-cards { display: flex; flex-direction: column; gap: 8px; }
.staff-card { border: 1px solid var(--gray-200); border-radius: var(--radius); padding: 12px; cursor: pointer; transition: box-shadow .15s; }
.staff-card:hover { box-shadow: var(--shadow); }
.staff-card-meta { font-size: .8rem; color: var(--gray-500); display: flex; gap: 8px; margin-top: 4px; }
.show-mobile { display: flex; }
.hide-mobile { display: none; }
@media (min-width: 768px) { .show-mobile { display: none !important; } .hide-mobile { display: block !important; } }
</style>
