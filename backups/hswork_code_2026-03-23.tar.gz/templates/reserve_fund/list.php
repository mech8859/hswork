<?php $typeOptions = FinanceModel::incomeExpenseOptions(); ?>
<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>備用金管理</h2>
    <span class="text-muted"><?= isset($result['total']) ? $result['total'] : count($records) ?> 筆</span>
</div>

<div class="card">
    <form method="GET" action="/reserve_fund.php" class="filter-form">
        <div class="filter-row">
            <div class="form-group">
                <label>分公司</label>
                <select name="branch_id" class="form-control">
                    <option value="">全部</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= e($b['id']) ?>" <?= (!empty($filters['branch_id']) && $filters['branch_id'] == $b['id']) ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>收支別</label>
                <select name="type" class="form-control">
                    <option value="">全部</option>
                    <?php foreach ($typeOptions as $val => $label): ?>
                    <option value="<?= e($val) ?>" <?= (!empty($filters['type']) && $filters['type'] === $val) ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="align-self:flex-end">
                <button type="submit" class="btn btn-primary btn-sm">搜尋</button>
                <a href="/reserve_fund.php" class="btn btn-outline btn-sm">清除</a>
            </div>
        </div>
    </form>
</div>

<div class="card">
    <?php if (empty($records)): ?>
        <p class="text-muted text-center mt-2">目前無資料</p>
    <?php else: ?>
    <!-- 手機卡片 -->
    <div class="staff-cards show-mobile">
        <?php foreach ($records as $r): ?>
        <div class="staff-card">
            <div class="d-flex justify-between align-center">
                <strong><?= e(!empty($r['entry_number']) ? $r['entry_number'] : '-') ?></strong>
                <span class="text-muted" style="font-size:.8rem"><?= e(!empty($r['entry_date']) ? $r['entry_date'] : '-') ?></span>
            </div>
            <div class="staff-card-meta">
                <?php if (!empty($r['type'])): ?>
                <span class="badge <?= $r['type'] === '支出' ? 'badge-danger' : 'badge-success' ?>"><?= e($r['type']) ?></span>
                <?php endif; ?>
                <?php if (!empty($r['expense_amount']) && $r['expense_amount'] > 0): ?>
                <span style="color:var(--danger)">支出 $<?= number_format($r['expense_amount']) ?></span>
                <?php endif; ?>
                <?php if (!empty($r['income_amount']) && $r['income_amount'] > 0): ?>
                <span style="color:var(--success)">收入 $<?= number_format($r['income_amount']) ?></span>
                <?php endif; ?>
            </div>
            <div class="staff-card-meta">
                <span><?= e(!empty($r['description']) ? $r['description'] : '-') ?></span>
            </div>
            <div class="staff-card-meta">
                <?php if (!empty($r['branch_name'])): ?><span><?= e($r['branch_name']) ?></span><?php endif; ?>
                <?php if (!empty($r['registrar'])): ?><span><?= e($r['registrar']) ?></span><?php endif; ?>
                <?php if (!empty($r['approval_status'])): ?><span><?= e($r['approval_status']) ?></span><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- 桌面表格 -->
    <div class="table-responsive hide-mobile">
        <table class="table">
            <thead>
                <tr>
                    <th>編號</th>
                    <th>日期</th>
                    <th>支出日期</th>
                    <th>收支別</th>
                    <th class="text-right">支出金額</th>
                    <th class="text-right">收入金額</th>
                    <th>用途說明</th>
                    <th>發票資訊</th>
                    <th>分公司</th>
                    <th>登記人</th>
                    <th>簽核狀態</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $r): ?>
                <tr>
                    <td style="font-size:.85rem"><?= e(!empty($r['entry_number']) ? $r['entry_number'] : '-') ?></td>
                    <td><?= e(!empty($r['entry_date']) ? $r['entry_date'] : '-') ?></td>
                    <td><?= e(!empty($r['expense_date']) ? $r['expense_date'] : '-') ?></td>
                    <td>
                        <?php if (!empty($r['type'])): ?>
                        <span class="badge <?= $r['type'] === '支出' ? 'badge-danger' : 'badge-success' ?>"><?= e($r['type']) ?></span>
                        <?php else: ?>-<?php endif; ?>
                    </td>
                    <td class="text-right"><?= (!empty($r['expense_amount']) && $r['expense_amount'] > 0) ? '<span style="color:var(--danger)">$' . number_format($r['expense_amount']) . '</span>' : '-' ?></td>
                    <td class="text-right"><?= (!empty($r['income_amount']) && $r['income_amount'] > 0) ? '<span style="color:var(--success)">$' . number_format($r['income_amount']) . '</span>' : '-' ?></td>
                    <td><?= e(!empty($r['description']) ? $r['description'] : '-') ?></td>
                    <td style="font-size:.85rem"><?= e(!empty($r['invoice_info']) ? $r['invoice_info'] : '-') ?></td>
                    <td><?= e(!empty($r['branch_name']) ? $r['branch_name'] : '-') ?></td>
                    <td><?= e(!empty($r['registrar']) ? $r['registrar'] : '-') ?></td>
                    <td><?= e(!empty($r['approval_status']) ? $r['approval_status'] : '-') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    <?php require __DIR__ . '/../layouts/pagination.php'; ?>
</div>

<style>
.filter-row { display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; }
.filter-row .form-group { flex: 1; min-width: 130px; margin-bottom: 0; }
.staff-cards { display: flex; flex-direction: column; gap: 8px; }
.staff-card { border: 1px solid var(--gray-200); border-radius: var(--radius); padding: 12px; }
.staff-card-meta { font-size: .8rem; color: var(--gray-500); display: flex; gap: 8px; margin-top: 4px; }
.show-mobile { display: flex; }
.hide-mobile { display: none; }
@media (min-width: 768px) { .show-mobile { display: none !important; } .hide-mobile { display: block !important; } }
</style>
