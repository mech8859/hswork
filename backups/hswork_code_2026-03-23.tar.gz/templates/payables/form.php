<?php $isEdit = !empty($record); ?>

<h2><?= $isEdit ? '編輯應付帳款單 - ' . e($record['payable_number']) : '新增應付帳款單' ?></h2>

<form method="POST" class="mt-2" id="payableForm">
    <?= csrf_field() ?>

    <!-- 基本資訊 -->
    <div class="card">
        <div class="card-header">基本資訊</div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 auto;min-width:200px">
                <label>應付單號</label>
                <input type="text" class="form-control" value="<?= e($isEdit ? $record['payable_number'] : peek_next_doc_number('payables')) ?>" readonly style="background:#f0f7ff;font-weight:600;color:var(--primary)">
            </div>
            <div class="form-group">
                <label>建立日期 *</label>
                <input type="date" max="2099-12-31" name="create_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['create_date']) ? $record['create_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>廠商名稱 *</label>
                <input type="text" name="vendor_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_name']) ? $record['vendor_name'] : '') ?>" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>付款期間</label>
                <input type="text" name="payment_period" class="form-control" placeholder="例：2026/03"
                       value="<?= e($isEdit && !empty($record['payment_period']) ? $record['payment_period'] : '') ?>">
            </div>
            <div class="form-group">
                <label>付款條件</label>
                <select name="payment_terms" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach (FinanceModel::paymentTermsOptions() as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && !empty($record['payment_terms']) ? $record['payment_terms'] : '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <!-- 金額 -->
    <div class="card">
        <div class="card-header">金額</div>
        <div class="form-row">
            <div class="form-group">
                <label>未稅總額 *</label>
                <input type="number" name="subtotal" id="fldSubtotal" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['subtotal']) ? (int)$record['subtotal'] : 0 ?>"
                       oninput="calcAmounts()">
            </div>
            <div class="form-group">
                <label>稅金 (5%)</label>
                <input type="number" name="tax" id="fldTax" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['tax']) ? (int)$record['tax'] : 0 ?>" readonly>
            </div>
            <div class="form-group">
                <label>總計</label>
                <input type="number" name="total_amount" id="fldTotal" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['total_amount']) ? (int)$record['total_amount'] : 0 ?>" readonly>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>預付款</label>
                <input type="number" name="prepaid" id="fldPrepaid" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['prepaid']) ? (int)$record['prepaid'] : 0 ?>"
                       oninput="calcAmounts()">
            </div>
            <div class="form-group">
                <label>應付總額</label>
                <input type="number" name="payable_amount" id="fldPayable" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['payable_amount']) ? (int)$record['payable_amount'] : 0 ?>" readonly>
            </div>
        </div>
    </div>

    <!-- 分公司拆帳 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>分公司拆帳</span>
            <button type="button" class="btn btn-primary btn-sm" onclick="addBranchRow()">+ 新增</button>
        </div>
        <div class="table-responsive">
            <table class="table" id="branchTable">
                <thead>
                    <tr>
                        <th>分公司</th>
                        <th style="width:140px">金額</th>
                        <th>備註</th>
                        <th style="width:50px"></th>
                    </tr>
                </thead>
                <tbody id="branchBody">
                    <?php if (!empty($branchItems)): ?>
                        <?php foreach ($branchItems as $idx => $bi): ?>
                        <tr>
                            <td>
                                <select name="branches[<?= $idx ?>][branch_id]" class="form-control">
                                    <option value="">請選擇</option>
                                    <?php foreach ($branches as $b): ?>
                                    <option value="<?= $b['id'] ?>" <?= (!empty($bi['branch_id']) ? $bi['branch_id'] : '') == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><input type="number" name="branches[<?= $idx ?>][amount]" class="form-control" step="1" min="0" value="<?= !empty($bi['amount']) ? (int)$bi['amount'] : 0 ?>"></td>
                            <td><input type="text" name="branches[<?= $idx ?>][note]" class="form-control" value="<?= e(!empty($bi['note']) ? $bi['note'] : '') ?>"></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove()">X</button></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td>
                                <select name="branches[0][branch_id]" class="form-control">
                                    <option value="">請選擇</option>
                                    <?php foreach ($branches as $b): ?>
                                    <option value="<?= $b['id'] ?>"><?= e($b['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><input type="number" name="branches[0][amount]" class="form-control" step="1" min="0" value="0"></td>
                            <td><input type="text" name="branches[0][note]" class="form-control" value=""></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove()">X</button></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 發票明細 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>發票明細</span>
            <button type="button" class="btn btn-primary btn-sm" onclick="addInvoiceRow()">+ 新增</button>
        </div>
        <div class="table-responsive">
            <table class="table" id="invoiceTable">
                <thead>
                    <tr>
                        <th>發票日期</th>
                        <th>發票號碼</th>
                        <th>統一編號</th>
                        <th style="width:120px">未稅金額</th>
                        <th style="width:100px">稅金</th>
                        <th style="width:120px">小計</th>
                        <th style="width:50px"></th>
                    </tr>
                </thead>
                <tbody id="invoiceBody">
                    <?php if (!empty($invoiceItems)): ?>
                        <?php foreach ($invoiceItems as $idx => $inv): ?>
                        <tr>
                            <td><input type="date" max="2099-12-31" name="invoices[<?= $idx ?>][invoice_date]" class="form-control" value="<?= e(!empty($inv['invoice_date']) ? $inv['invoice_date'] : '') ?>"></td>
                            <td><input type="text" name="invoices[<?= $idx ?>][invoice_number]" class="form-control" value="<?= e(!empty($inv['invoice_number']) ? $inv['invoice_number'] : '') ?>"></td>
                            <td><input type="text" name="invoices[<?= $idx ?>][tax_id]" class="form-control" value="<?= e(!empty($inv['tax_id']) ? $inv['tax_id'] : '') ?>"></td>
                            <td><input type="number" name="invoices[<?= $idx ?>][amount_untaxed]" class="form-control inv-untaxed" step="1" min="0" value="<?= !empty($inv['amount_untaxed']) ? (int)$inv['amount_untaxed'] : 0 ?>" oninput="calcInvRow(this)"></td>
                            <td><input type="number" name="invoices[<?= $idx ?>][tax]" class="form-control inv-tax" step="1" min="0" value="<?= !empty($inv['tax']) ? (int)$inv['tax'] : 0 ?>" readonly></td>
                            <td><input type="number" name="invoices[<?= $idx ?>][subtotal]" class="form-control inv-subtotal" step="1" min="0" value="<?= !empty($inv['subtotal']) ? (int)$inv['subtotal'] : 0 ?>" readonly></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove()">X</button></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td><input type="date" max="2099-12-31" name="invoices[0][invoice_date]" class="form-control" value=""></td>
                            <td><input type="text" name="invoices[0][invoice_number]" class="form-control" value="" placeholder="發票號碼"></td>
                            <td><input type="text" name="invoices[0][tax_id]" class="form-control" value="" placeholder="統一編號"></td>
                            <td><input type="number" name="invoices[0][amount_untaxed]" class="form-control inv-untaxed" step="1" min="0" value="0" oninput="calcInvRow(this)"></td>
                            <td><input type="number" name="invoices[0][tax]" class="form-control inv-tax" step="1" min="0" value="0" readonly></td>
                            <td><input type="number" name="invoices[0][subtotal]" class="form-control inv-subtotal" step="1" min="0" value="0" readonly></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove()">X</button></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 備註 -->
    <div class="card">
        <div class="card-header">備註</div>
        <div class="form-group">
            <textarea name="note" class="form-control" rows="3"><?= e($isEdit && !empty($record['note']) ? $record['note'] : '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '建立應付帳款單' ?></button>
        <a href="/payables.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
// ---- 金額自動計算 ----
function calcAmounts() {
    var subtotal = parseInt(document.getElementById('fldSubtotal').value) || 0;
    var tax = Math.round(subtotal * 0.05);
    var total = subtotal + tax;
    var prepaid = parseInt(document.getElementById('fldPrepaid').value) || 0;
    var payable = total - prepaid;

    document.getElementById('fldTax').value = tax;
    document.getElementById('fldTotal').value = total;
    document.getElementById('fldPayable').value = payable;
}

// ---- 分公司拆帳 動態列 ----
var branchIdx = <?= !empty($branchItems) ? count($branchItems) : 1 ?>;
function addBranchRow() {
    var tbody = document.getElementById('branchBody');
    var tr = document.createElement('tr');
    var opts = '';
    <?php foreach ($branches as $b): ?>
    opts += '<option value="<?= $b['id'] ?>"><?= e($b['name']) ?></option>';
    <?php endforeach; ?>
    tr.innerHTML = '<td><select name="branches['+branchIdx+'][branch_id]" class="form-control"><option value="">請選擇</option>'+opts+'</select></td>'
        + '<td><input type="number" name="branches['+branchIdx+'][amount]" class="form-control" step="1" min="0" value="0"></td>'
        + '<td><input type="text" name="branches['+branchIdx+'][note]" class="form-control" value=""></td>'
        + '<td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest(\'tr\').remove()">X</button></td>';
    tbody.appendChild(tr);
    branchIdx++;
}

// ---- 發票明細 動態列 ----
var invIdx = <?= !empty($invoiceItems) ? count($invoiceItems) : 1 ?>;
function addInvoiceRow() {
    var tbody = document.getElementById('invoiceBody');
    var tr = document.createElement('tr');
    tr.innerHTML = '<td><input type="date" max="2099-12-31" name="invoices['+invIdx+'][invoice_date]" class="form-control" value=""></td>'
        + '<td><input type="text" name="invoices['+invIdx+'][invoice_number]" class="form-control" value="" placeholder="發票號碼"></td>'
        + '<td><input type="text" name="invoices['+invIdx+'][tax_id]" class="form-control" value="" placeholder="統一編號"></td>'
        + '<td><input type="number" name="invoices['+invIdx+'][amount_untaxed]" class="form-control inv-untaxed" step="1" min="0" value="0" oninput="calcInvRow(this)"></td>'
        + '<td><input type="number" name="invoices['+invIdx+'][tax]" class="form-control inv-tax" step="1" min="0" value="0" readonly></td>'
        + '<td><input type="number" name="invoices['+invIdx+'][subtotal]" class="form-control inv-subtotal" step="1" min="0" value="0" readonly></td>'
        + '<td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest(\'tr\').remove()">X</button></td>';
    tbody.appendChild(tr);
    invIdx++;
}

// ---- 發票小計自動計算 ----
function calcInvRow(el) {
    var tr = el.closest('tr');
    var untaxed = parseInt(tr.querySelector('.inv-untaxed').value) || 0;
    var tax = Math.round(untaxed * 0.05);
    var subtotal = untaxed + tax;
    tr.querySelector('.inv-tax').value = tax;
    tr.querySelector('.inv-subtotal').value = subtotal;
}

// 頁面載入時初始計算
calcAmounts();
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
</style>
