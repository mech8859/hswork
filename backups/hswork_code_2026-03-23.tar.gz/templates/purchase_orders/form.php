<?php $isEdit = !empty($record); ?>

<h2><?= $isEdit ? '編輯採購單 - ' . e($record['po_number']) : '新增採購單' ?></h2>

<form method="POST" class="mt-2" id="poForm">
    <?= csrf_field() ?>

    <!-- 採購單資訊 -->
    <div class="card">
        <div class="card-header">採購單資訊</div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 auto;min-width:200px">
                <label>採購單號</label>
                <input type="text" class="form-control" value="<?= e($isEdit ? $record['po_number'] : peek_next_doc_number('purchase_orders')) ?>" readonly style="background:#f0f7ff;font-weight:600;color:var(--primary)">
            </div>
            <div class="form-group">
                <label>採購日期 *</label>
                <input type="date" max="2099-12-31" name="po_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['po_date']) ? $record['po_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <?php foreach (ProcurementModel::poStatusOptions() as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && !empty($record['status']) ? $record['status'] : '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>採購人</label>
                <input type="text" name="purchaser_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['purchaser_name']) ? $record['purchaser_name'] : '') ?>">
            </div>
            <div class="form-group">
                <label>請購單號</label>
                <input type="text" name="requisition_number" class="form-control"
                       value="<?= e($isEdit && !empty($record['requisition_number']) ? $record['requisition_number'] : '') ?>" readonly>
            </div>
            <div class="form-group">
                <label>案件名稱</label>
                <input type="text" name="case_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['case_name']) ? $record['case_name'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>分公司</label>
                <select name="branch_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= ($isEdit && !empty($record['branch_id']) ? $record['branch_id'] : '') == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>業務人員</label>
                <input type="text" name="sales_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['sales_name']) ? $record['sales_name'] : '') ?>">
            </div>
            <div class="form-group">
                <label>急迫性</label>
                <select name="urgency" class="form-control">
                    <option value="">請選擇</option>
                    <option value="一般" <?= ($isEdit && !empty($record['urgency']) ? $record['urgency'] : '') === '一般' ? 'selected' : '' ?>>一般</option>
                    <option value="急件" <?= ($isEdit && !empty($record['urgency']) ? $record['urgency'] : '') === '急件' ? 'selected' : '' ?>>急件</option>
                    <option value="特急" <?= ($isEdit && !empty($record['urgency']) ? $record['urgency'] : '') === '特急' ? 'selected' : '' ?>>特急</option>
                </select>
            </div>
        </div>
    </div>

    <!-- 廠商資訊 -->
    <div class="card">
        <div class="card-header">廠商資訊</div>
        <input type="hidden" name="vendor_id" id="vendor_id"
               value="<?= e($isEdit && !empty($record['vendor_id']) ? $record['vendor_id'] : '') ?>">
        <div class="form-row">
            <div class="form-group">
                <label>快速選擇廠商</label>
                <select id="vendorSelect" class="form-control">
                    <option value="">-- 選擇廠商 --</option>
                    <?php foreach ($vendors as $v): ?>
                    <option value="<?= $v['id'] ?>"><?= e(!empty($v['name']) ? $v['name'] : '') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>廠商名稱 *</label>
                <input type="text" name="vendor_name" id="vendor_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_name']) ? $record['vendor_name'] : '') ?>" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>廠商代號</label>
                <input type="text" name="vendor_code" id="vendor_code" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_code']) ? $record['vendor_code'] : '') ?>">
            </div>
            <div class="form-group">
                <label>統一編號</label>
                <input type="text" name="vendor_tax_id" id="vendor_tax_id" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_tax_id']) ? $record['vendor_tax_id'] : '') ?>">
            </div>
            <div class="form-group">
                <label>聯絡人</label>
                <input type="text" name="vendor_contact" id="vendor_contact" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_contact']) ? $record['vendor_contact'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>電話</label>
                <input type="text" name="vendor_phone" id="vendor_phone" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_phone']) ? $record['vendor_phone'] : '') ?>">
            </div>
            <div class="form-group">
                <label>傳真</label>
                <input type="text" name="vendor_fax" id="vendor_fax" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_fax']) ? $record['vendor_fax'] : '') ?>">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="vendor_email" id="vendor_email" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_email']) ? $record['vendor_email'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group" style="flex:2">
                <label>地址</label>
                <input type="text" name="vendor_address" id="vendor_address" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_address']) ? $record['vendor_address'] : '') ?>">
            </div>
        </div>
    </div>

    <!-- 付款資訊 -->
    <div class="card">
        <div class="card-header">付款資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>付款方式</label>
                <input type="text" name="payment_method" class="form-control"
                       value="<?= e($isEdit && !empty($record['payment_method']) ? $record['payment_method'] : '') ?>">
            </div>
            <div class="form-group">
                <label>付款條件</label>
                <input type="text" name="payment_terms" class="form-control"
                       value="<?= e($isEdit && !empty($record['payment_terms']) ? $record['payment_terms'] : '') ?>">
            </div>
            <div class="form-group">
                <label>發票方式</label>
                <input type="text" name="invoice_method" class="form-control"
                       value="<?= e($isEdit && !empty($record['invoice_method']) ? $record['invoice_method'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>發票類別</label>
                <input type="text" name="invoice_type" class="form-control"
                       value="<?= e($isEdit && !empty($record['invoice_type']) ? $record['invoice_type'] : '') ?>">
            </div>
            <div class="form-group">
                <label>付款日期</label>
                <input type="date" max="2099-12-31" name="payment_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['payment_date']) ? $record['payment_date'] : '') ?>">
            </div>
            <div class="form-group">
                <label>已付金額</label>
                <input type="number" name="paid_amount" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['paid_amount']) ? (int)$record['paid_amount'] : 0 ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>
                    <input type="checkbox" name="is_paid" value="1"
                           <?= ($isEdit && !empty($record['is_paid'])) ? 'checked' : '' ?>>
                    已付款
                </label>
            </div>
        </div>
    </div>

    <!-- 交貨 -->
    <div class="card">
        <div class="card-header">交貨資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>交貨地點</label>
                <input type="text" name="delivery_location" class="form-control"
                       value="<?= e($isEdit && !empty($record['delivery_location']) ? $record['delivery_location'] : '') ?>">
            </div>
            <div class="form-group">
                <label>需求日期</label>
                <input type="date" max="2099-12-31" name="required_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['required_date']) ? $record['required_date'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>預計交貨日</label>
                <input type="date" max="2099-12-31" name="promised_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['promised_date']) ? $record['promised_date'] : '') ?>">
            </div>
            <div class="form-group">
                <label>實際到貨日</label>
                <input type="date" max="2099-12-31" name="receiving_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['receiving_date']) ? $record['receiving_date'] : '') ?>">
            </div>
        </div>
    </div>

    <!-- 採購細項 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>採購細項</span>
            <button type="button" class="btn btn-primary btn-sm" onclick="addItemRow()">+ 新增</button>
        </div>
        <div class="table-responsive">
            <table class="table" id="itemTable">
                <thead>
                    <tr>
                        <th style="width:50px">項次</th>
                        <th>商品型號</th>
                        <th>商品名稱</th>
                        <th>規格</th>
                        <th style="width:100px">單價</th>
                        <th style="width:80px">數量</th>
                        <th style="width:100px">金額</th>
                        <th>交貨日期</th>
                        <th style="width:50px"></th>
                    </tr>
                </thead>
                <tbody id="itemBody">
                    <?php if (!empty($items)): ?>
                        <?php foreach ($items as $idx => $item): ?>
                        <tr>
                            <td class="item-seq"><?= $idx + 1 ?></td>
                            <td><input type="text" name="items[<?= $idx ?>][model]" class="form-control" value="<?= e(!empty($item['model']) ? $item['model'] : '') ?>"></td>
                            <td><input type="text" name="items[<?= $idx ?>][product_name]" class="form-control" value="<?= e(!empty($item['product_name']) ? $item['product_name'] : '') ?>"></td>
                            <td><input type="text" name="items[<?= $idx ?>][spec]" class="form-control" value="<?= e(!empty($item['spec']) ? $item['spec'] : '') ?>"></td>
                            <td><input type="number" name="items[<?= $idx ?>][unit_price]" class="form-control item-price" step="1" min="0" value="<?= !empty($item['unit_price']) ? (int)$item['unit_price'] : 0 ?>" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[<?= $idx ?>][quantity]" class="form-control item-qty" step="1" min="0" value="<?= !empty($item['quantity']) ? (int)$item['quantity'] : 0 ?>" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[<?= $idx ?>][amount]" class="form-control item-amount" step="1" min="0" value="<?= !empty($item['amount']) ? (int)$item['amount'] : 0 ?>" readonly></td>
                            <td><input type="date" max="2099-12-31" name="items[<?= $idx ?>][delivery_date]" class="form-control" value="<?= e(!empty($item['delivery_date']) ? $item['delivery_date'] : '') ?>"></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td class="item-seq">1</td>
                            <td><input type="text" name="items[0][model]" class="form-control" value=""></td>
                            <td><input type="text" name="items[0][product_name]" class="form-control" value=""></td>
                            <td><input type="text" name="items[0][spec]" class="form-control" value=""></td>
                            <td><input type="number" name="items[0][unit_price]" class="form-control item-price" step="1" min="0" value="0" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[0][quantity]" class="form-control item-qty" step="1" min="0" value="0" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[0][amount]" class="form-control item-amount" step="1" min="0" value="0" readonly></td>
                            <td><input type="date" max="2099-12-31" name="items[0][delivery_date]" class="form-control" value=""></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 金額 -->
    <div class="card">
        <div class="card-header">金額</div>
        <div class="form-row">
            <div class="form-group">
                <label>小計</label>
                <input type="number" name="subtotal" id="subtotal" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['subtotal']) ? (int)$record['subtotal'] : 0 ?>" readonly>
            </div>
            <div class="form-group">
                <label>稅別</label>
                <select name="tax_type" id="tax_type" class="form-control" onchange="calcSubtotal()">
                    <option value="含稅" <?= ($isEdit && !empty($record['tax_type']) ? $record['tax_type'] : '') === '含稅' ? 'selected' : '' ?>>含稅</option>
                    <option value="未稅" <?= ($isEdit && !empty($record['tax_type']) ? $record['tax_type'] : '') === '未稅' ? 'selected' : '' ?>>未稅</option>
                    <option value="免稅" <?= ($isEdit && !empty($record['tax_type']) ? $record['tax_type'] : '') === '免稅' ? 'selected' : '' ?>>免稅</option>
                </select>
            </div>
            <div class="form-group">
                <label>稅率 (%)</label>
                <input type="number" name="tax_rate" id="tax_rate" class="form-control" step="0.01" min="0"
                       value="<?= $isEdit && !empty($record['tax_rate']) ? $record['tax_rate'] : 5 ?>"
                       oninput="calcSubtotal()">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>稅額</label>
                <input type="number" name="tax_amount" id="tax_amount" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['tax_amount']) ? (int)$record['tax_amount'] : 0 ?>" readonly>
            </div>
            <div class="form-group">
                <label>運費</label>
                <input type="number" name="shipping_fee" id="shipping_fee" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['shipping_fee']) ? (int)$record['shipping_fee'] : 0 ?>"
                       oninput="calcSubtotal()">
            </div>
            <div class="form-group">
                <label>合計金額</label>
                <input type="number" name="total_amount" id="total_amount" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['total_amount']) ? (int)$record['total_amount'] : 0 ?>" readonly>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>本次金額</label>
                <input type="number" name="this_amount" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['this_amount']) ? (int)$record['this_amount'] : 0 ?>">
            </div>
            <div class="form-group">
                <label>未稅折扣</label>
                <input type="number" name="discount_untaxed" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['discount_untaxed']) ? (int)$record['discount_untaxed'] : 0 ?>">
            </div>
            <div class="form-group">
                <label>含稅折扣</label>
                <input type="number" name="discount_taxed" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['discount_taxed']) ? (int)$record['discount_taxed'] : 0 ?>">
            </div>
        </div>
    </div>

    <!-- 其他 -->
    <div class="card">
        <div class="card-header">其他</div>
        <div class="form-row">
            <div class="form-group">
                <label>
                    <input type="checkbox" name="use_payment_flow" value="1"
                           <?= ($isEdit && !empty($record['use_payment_flow'])) ? 'checked' : '' ?>>
                    啟用付款流程
                </label>
            </div>
            <div class="form-group">
                <label>
                    <input type="checkbox" name="convert_to_receiving" value="1"
                           <?= ($isEdit && !empty($record['convert_to_receiving'])) ? 'checked' : '' ?>>
                    轉入進貨單
                </label>
            </div>
            <div class="form-group">
                <label>
                    <input type="checkbox" name="is_cancelled" value="1"
                           <?= ($isEdit && !empty($record['is_cancelled'])) ? 'checked' : '' ?>>
                    已取消
                </label>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>退款日期</label>
                <input type="date" max="2099-12-31" name="refund_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['refund_date']) ? $record['refund_date'] : '') ?>">
            </div>
        </div>
        <div class="form-group">
            <label>備註</label>
            <textarea name="note" class="form-control" rows="3"><?= e($isEdit && !empty($record['note']) ? $record['note'] : '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '建立採購單' ?></button>
        <a href="/purchase_orders.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
// ---- 廠商選擇自動填入 ----
var vendors = <?= json_encode($vendors) ?>;
document.getElementById('vendorSelect').addEventListener('change', function() {
    var id = this.value;
    for (var i = 0; i < vendors.length; i++) {
        if (vendors[i].id == id) {
            document.getElementById('vendor_id').value = vendors[i].id;
            document.getElementById('vendor_name').value = vendors[i].name || '';
            document.getElementById('vendor_code').value = vendors[i].code || '';
            document.getElementById('vendor_tax_id').value = vendors[i].tax_id || '';
            document.getElementById('vendor_contact').value = vendors[i].contact || '';
            document.getElementById('vendor_phone').value = vendors[i].phone || '';
            document.getElementById('vendor_fax').value = vendors[i].fax || '';
            document.getElementById('vendor_email').value = vendors[i].email || '';
            document.getElementById('vendor_address').value = vendors[i].address || '';
            break;
        }
    }
});

// ---- 採購細項 動態列 ----
var itemIdx = <?= !empty($items) ? count($items) : 1 ?>;

function addItemRow() {
    var tbody = document.getElementById('itemBody');
    var tr = document.createElement('tr');
    var seq = tbody.querySelectorAll('tr').length + 1;
    tr.innerHTML = '<td class="item-seq">' + seq + '</td>'
        + '<td><input type="text" name="items['+itemIdx+'][model]" class="form-control" value=""></td>'
        + '<td><input type="text" name="items['+itemIdx+'][product_name]" class="form-control" value=""></td>'
        + '<td><input type="text" name="items['+itemIdx+'][spec]" class="form-control" value=""></td>'
        + '<td><input type="number" name="items['+itemIdx+'][unit_price]" class="form-control item-price" step="1" min="0" value="0" oninput="calcRowAmount(this.closest(\'tr\'))"></td>'
        + '<td><input type="number" name="items['+itemIdx+'][quantity]" class="form-control item-qty" step="1" min="0" value="0" oninput="calcRowAmount(this.closest(\'tr\'))"></td>'
        + '<td><input type="number" name="items['+itemIdx+'][amount]" class="form-control item-amount" step="1" min="0" value="0" readonly></td>'
        + '<td><input type="date" max="2099-12-31" name="items['+itemIdx+'][delivery_date]" class="form-control" value=""></td>'
        + '<td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>';
    tbody.appendChild(tr);
    itemIdx++;
}

function removeItemRow(btn) {
    btn.closest('tr').remove();
    reindexItems();
    calcSubtotal();
}

function reindexItems() {
    var rows = document.querySelectorAll('#itemBody tr');
    for (var i = 0; i < rows.length; i++) {
        rows[i].querySelector('.item-seq').textContent = i + 1;
    }
}

// ---- 金額計算 ----
function calcRowAmount(row) {
    var price = parseFloat(row.querySelector('.item-price').value) || 0;
    var qty = parseFloat(row.querySelector('.item-qty').value) || 0;
    row.querySelector('.item-amount').value = Math.round(price * qty);
    calcSubtotal();
}

function calcSubtotal() {
    var total = 0;
    document.querySelectorAll('.item-amount').forEach(function(el) {
        total += parseFloat(el.value) || 0;
    });
    document.getElementById('subtotal').value = total;

    var taxRate = parseFloat(document.getElementById('tax_rate').value) || 0;
    var taxAmount = Math.round(total * taxRate / 100);
    document.getElementById('tax_amount').value = taxAmount;

    var shipping = parseFloat(document.getElementById('shipping_fee').value) || 0;
    document.getElementById('total_amount').value = total + taxAmount + shipping;
}

// 頁面載入時初始計算
calcSubtotal();
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
</style>
