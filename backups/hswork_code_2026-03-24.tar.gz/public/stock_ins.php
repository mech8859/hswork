<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/inventory/StockModel.php';
require_once __DIR__ . '/../modules/inventory/InventoryModel.php';

$model = new StockModel();
$invModel = new InventoryModel();
$action = !empty($_GET['action']) ? $_GET['action'] : 'list';

switch ($action) {
    case 'list':
        $filters = array(
            'status'       => !empty($_GET['status']) ? $_GET['status'] : '',
            'warehouse_id' => !empty($_GET['warehouse_id']) ? $_GET['warehouse_id'] : '',
            'keyword'      => !empty($_GET['keyword']) ? $_GET['keyword'] : '',
            'date_from'    => !empty($_GET['date_from']) ? $_GET['date_from'] : '',
            'date_to'      => !empty($_GET['date_to']) ? $_GET['date_to'] : '',
            'source_type'  => !empty($_GET['source_type']) ? $_GET['source_type'] : '',
        );
        $records = $model->getStockIns($filters);
        $warehouses = $invModel->getWarehouses();

        $pageTitle = '入庫單';
        $currentPage = 'stock_ins';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/stock_ins/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'view':
        $id = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
        $record = $model->getStockInById($id);
        if (!$record) {
            Session::flash('error', '入庫單不存在');
            redirect('/stock_ins.php');
        }
        $items = $model->getStockInItems($id);

        $pageTitle = '入庫單 - ' . $record['si_number'];
        $currentPage = 'stock_ins';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/stock_ins/view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'confirm':
        $id = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
        if ($id > 0) {
            try {
                $userId = Session::getUser()['id'];
                $result = $model->confirmStockIn($id, $userId);
                if ($result) {
                    Session::flash('success', '入庫單已確認，庫存已更新');
                } else {
                    Session::flash('error', '確認失敗：入庫單狀態不正確或無明細');
                }
            } catch (Exception $e) {
                Session::flash('error', '確認失敗: ' . $e->getMessage());
            }
        }
        redirect('/stock_ins.php?action=view&id=' . $id);
        break;

    default:
        redirect('/stock_ins.php');
        break;
}
