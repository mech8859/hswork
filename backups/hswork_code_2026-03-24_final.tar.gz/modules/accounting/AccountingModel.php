<?php
/**
 * ERP Accounting Model
 * Chart of Accounts, Cost Centers, Journal Entries, General Ledger
 */
class AccountingModel
{
    /** @var PDO */
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ============================================================
    // Chart of Accounts
    // ============================================================

    /**
     * Get accounts as tree structure
     * @param int|null $parentId
     * @return array
     */
    public function getAccounts($parentId = null)
    {
        if ($parentId === null) {
            // Get top-level accounts grouped by account_type
            $stmt = $this->db->query(
                "SELECT * FROM chart_of_accounts WHERE is_active = 1 ORDER BY sort_order, code"
            );
        } else {
            $stmt = $this->db->prepare(
                "SELECT * FROM chart_of_accounts WHERE parent_id = ? AND is_active = 1 ORDER BY sort_order, code"
            );
            $stmt->execute(array($parentId));
        }
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get flat list for dropdowns (only detail accounts by default)
     * @param bool $detailOnly
     * @return array
     */
    public function getAccountsFlat($detailOnly = true)
    {
        $where = 'is_active = 1';
        if ($detailOnly) {
            $where .= ' AND is_detail = 1';
        }
        $stmt = $this->db->query(
            "SELECT id, code, name, account_type, normal_balance, level1 FROM chart_of_accounts WHERE {$where} ORDER BY code"
        );
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get account by ID
     * @param int $id
     * @return array|false
     */
    public function getAccountById($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM chart_of_accounts WHERE id = ?");
        $stmt->execute(array($id));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Get account by code
     * @param string $code
     * @return array|false
     */
    public function getAccountByCode($code)
    {
        $stmt = $this->db->prepare("SELECT * FROM chart_of_accounts WHERE code = ?");
        $stmt->execute(array($code));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Create a new account
     * @param array $data
     * @return int
     */
    public function createAccount($data)
    {
        $sql = "INSERT INTO chart_of_accounts (code, name, account_type, parent_id, level, is_detail, normal_balance, description, sort_order, account_code, account_name, level1, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(array(
            $data['code'],
            $data['name'],
            $data['account_type'],
            !empty($data['parent_id']) ? $data['parent_id'] : null,
            isset($data['level']) ? $data['level'] : 1,
            isset($data['is_detail']) ? $data['is_detail'] : 1,
            isset($data['normal_balance']) ? $data['normal_balance'] : 'debit',
            isset($data['description']) ? $data['description'] : '',
            isset($data['sort_order']) ? $data['sort_order'] : 0,
            $data['code'],
            $data['name'],
            isset($data['level1']) ? $data['level1'] : '',
        ));
        return (int)$this->db->lastInsertId();
    }

    /**
     * Update account
     * @param int $id
     * @param array $data
     */
    public function updateAccount($id, $data)
    {
        $sql = "UPDATE chart_of_accounts SET code = ?, name = ?, account_type = ?, parent_id = ?, level = ?, is_detail = ?, normal_balance = ?, description = ?, sort_order = ?, account_code = ?, account_name = ?, level1 = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(array(
            $data['code'],
            $data['name'],
            $data['account_type'],
            !empty($data['parent_id']) ? $data['parent_id'] : null,
            isset($data['level']) ? $data['level'] : 1,
            isset($data['is_detail']) ? $data['is_detail'] : 1,
            isset($data['normal_balance']) ? $data['normal_balance'] : 'debit',
            isset($data['description']) ? $data['description'] : '',
            isset($data['sort_order']) ? $data['sort_order'] : 0,
            $data['code'],
            $data['name'],
            isset($data['level1']) ? $data['level1'] : '',
            $id,
        ));
    }

    /**
     * Toggle account active/inactive
     * @param int $id
     */
    public function toggleAccount($id)
    {
        $this->db->prepare("UPDATE chart_of_accounts SET is_active = IF(is_active=1,0,1) WHERE id = ?")->execute(array($id));
    }

    /**
     * Get account type options
     * @return array
     */
    public static function accountTypeOptions()
    {
        return array(
            'asset'     => '資產',
            'liability' => '負債',
            'equity'    => '權益',
            'revenue'   => '收入',
            'expense'   => '費用',
        );
    }

    /**
     * Get accounts grouped by type for tree display
     * @param bool $showInactive
     * @return array
     */
    public function getAccountsTree($showInactive = false)
    {
        $where = $showInactive ? '1=1' : 'is_active = 1';
        $stmt = $this->db->query("SELECT * FROM chart_of_accounts WHERE {$where} ORDER BY code");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ============================================================
    // Cost Centers
    // ============================================================

    /**
     * Get active cost centers
     * @return array
     */
    public function getCostCenters()
    {
        return $this->db->query(
            "SELECT cc.*, b.name as branch_name FROM cost_centers cc LEFT JOIN branches b ON cc.branch_id = b.id WHERE cc.is_active = 1 ORDER BY cc.code"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get all cost centers (including inactive)
     * @return array
     */
    public function getAllCostCenters()
    {
        return $this->db->query(
            "SELECT cc.*, b.name as branch_name FROM cost_centers cc LEFT JOIN branches b ON cc.branch_id = b.id ORDER BY cc.code"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get cost center by ID
     * @param int $id
     * @return array|false
     */
    public function getCostCenterById($id)
    {
        $stmt = $this->db->prepare("SELECT cc.*, b.name as branch_name FROM cost_centers cc LEFT JOIN branches b ON cc.branch_id = b.id WHERE cc.id = ?");
        $stmt->execute(array($id));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Create cost center
     * @param array $data
     * @return int
     */
    public function createCostCenter($data)
    {
        $stmt = $this->db->prepare("INSERT INTO cost_centers (code, name, type, branch_id, is_active) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(array(
            $data['code'],
            $data['name'],
            isset($data['type']) ? $data['type'] : 'branch',
            !empty($data['branch_id']) ? $data['branch_id'] : null,
            isset($data['is_active']) ? $data['is_active'] : 1,
        ));
        return (int)$this->db->lastInsertId();
    }

    /**
     * Update cost center
     * @param int $id
     * @param array $data
     */
    public function updateCostCenter($id, $data)
    {
        $stmt = $this->db->prepare("UPDATE cost_centers SET code = ?, name = ?, type = ?, branch_id = ?, is_active = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute(array(
            $data['code'],
            $data['name'],
            isset($data['type']) ? $data['type'] : 'branch',
            !empty($data['branch_id']) ? $data['branch_id'] : null,
            isset($data['is_active']) ? $data['is_active'] : 1,
            $id,
        ));
    }

    /**
     * Cost center type options
     * @return array
     */
    public static function costCenterTypeOptions()
    {
        return array(
            'branch'     => '分處',
            'project'    => '專案',
            'department' => '部門',
        );
    }

    // ============================================================
    // Journal Entries
    // ============================================================

    /**
     * Get journal entries list with filters
     * @param array $filters
     * @param int $limit
     * @return array
     */
    public function getJournalEntries($filters = array(), $limit = 200)
    {
        $where = '1=1';
        $params = array();

        if (!empty($filters['status'])) {
            $where .= ' AND je.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['voucher_type'])) {
            $where .= ' AND je.voucher_type = ?';
            $params[] = $filters['voucher_type'];
        }
        if (!empty($filters['date_from'])) {
            $where .= ' AND je.voucher_date >= ?';
            $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where .= ' AND je.voucher_date <= ?';
            $params[] = $filters['date_to'];
        }
        if (!empty($filters['keyword'])) {
            $where .= ' AND (je.voucher_number LIKE ? OR je.description LIKE ?)';
            $kw = '%' . $filters['keyword'] . '%';
            $params[] = $kw;
            $params[] = $kw;
        }
        if (!empty($filters['source_module'])) {
            $where .= ' AND je.source_module = ?';
            $params[] = $filters['source_module'];
        }

        $params[] = (int)$limit;
        $sql = "SELECT je.*, u.real_name as created_by_name, up.real_name as posted_by_name
                FROM journal_entries je
                LEFT JOIN staff u ON je.created_by = u.id
                LEFT JOIN staff up ON je.posted_by = up.id
                WHERE {$where}
                ORDER BY je.voucher_date DESC, je.id DESC
                LIMIT ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get journal entry with lines
     * @param int $id
     * @return array|false
     */
    public function getJournalEntryById($id)
    {
        $stmt = $this->db->prepare(
            "SELECT je.*, u.real_name as created_by_name, up.real_name as posted_by_name, uv.real_name as voided_by_name
             FROM journal_entries je
             LEFT JOIN staff u ON je.created_by = u.id
             LEFT JOIN staff up ON je.posted_by = up.id
             LEFT JOIN staff uv ON je.voided_by = uv.id
             WHERE je.id = ?"
        );
        $stmt->execute(array($id));
        $entry = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$entry) return false;

        // Load lines
        $lineStmt = $this->db->prepare(
            "SELECT jl.*, coa.code as account_code, coa.name as account_name, cc.name as cost_center_name
             FROM journal_entry_lines jl
             LEFT JOIN chart_of_accounts coa ON jl.account_id = coa.id
             LEFT JOIN cost_centers cc ON jl.cost_center_id = cc.id
             WHERE jl.journal_entry_id = ?
             ORDER BY jl.sort_order, jl.id"
        );
        $lineStmt->execute(array($id));
        $entry['lines'] = $lineStmt->fetchAll(PDO::FETCH_ASSOC);

        return $entry;
    }

    /**
     * Create journal entry with lines
     * Validates debit = credit balance
     * @param array $data
     * @return int
     * @throws Exception
     */
    public function createJournalEntry($data)
    {
        // Validate lines
        if (empty($data['lines']) || !is_array($data['lines'])) {
            throw new Exception('Please add at least one journal line');
        }

        $totalDebit = 0;
        $totalCredit = 0;
        foreach ($data['lines'] as $line) {
            $totalDebit += (float)$line['debit_amount'];
            $totalCredit += (float)$line['credit_amount'];
        }

        // Balance check (allow small rounding difference)
        if (abs($totalDebit - $totalCredit) > 0.01) {
            throw new Exception('Debit and Credit totals must be equal. Debit: ' . number_format($totalDebit, 2) . ', Credit: ' . number_format($totalCredit, 2));
        }

        if ($totalDebit <= 0) {
            throw new Exception('Total amount must be greater than zero');
        }

        $this->db->beginTransaction();
        try {
            $voucherNumber = generate_doc_number('journal_entries');

            $stmt = $this->db->prepare(
                "INSERT INTO journal_entries (voucher_number, voucher_date, voucher_type, description, source_module, source_id, status, total_debit, total_credit, created_by, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, 'draft', ?, ?, ?, NOW())"
            );
            $stmt->execute(array(
                $voucherNumber,
                $data['voucher_date'],
                isset($data['voucher_type']) ? $data['voucher_type'] : 'general',
                isset($data['description']) ? $data['description'] : '',
                isset($data['source_module']) ? $data['source_module'] : 'manual',
                isset($data['source_id']) ? $data['source_id'] : null,
                $totalDebit,
                $totalCredit,
                $data['created_by'],
            ));
            $journalId = (int)$this->db->lastInsertId();

            // Insert lines
            $lineStmt = $this->db->prepare(
                "INSERT INTO journal_entry_lines (journal_entry_id, account_id, cost_center_id, debit_amount, credit_amount, description, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $sortOrder = 0;
            foreach ($data['lines'] as $line) {
                $debit = (float)$line['debit_amount'];
                $credit = (float)$line['credit_amount'];
                if ($debit == 0 && $credit == 0) continue;

                $lineStmt->execute(array(
                    $journalId,
                    (int)$line['account_id'],
                    !empty($line['cost_center_id']) ? (int)$line['cost_center_id'] : null,
                    $debit,
                    $credit,
                    isset($line['description']) ? $line['description'] : '',
                    $sortOrder++,
                ));
            }

            $this->db->commit();
            return $journalId;

        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Update journal entry (only draft)
     * @param int $id
     * @param array $data
     * @throws Exception
     */
    public function updateJournalEntry($id, $data)
    {
        $entry = $this->getJournalEntryById($id);
        if (!$entry) throw new Exception('Journal entry not found');
        if ($entry['status'] !== 'draft') throw new Exception('Only draft entries can be edited');

        if (empty($data['lines']) || !is_array($data['lines'])) {
            throw new Exception('Please add at least one journal line');
        }

        $totalDebit = 0;
        $totalCredit = 0;
        foreach ($data['lines'] as $line) {
            $totalDebit += (float)$line['debit_amount'];
            $totalCredit += (float)$line['credit_amount'];
        }

        if (abs($totalDebit - $totalCredit) > 0.01) {
            throw new Exception('Debit and Credit totals must be equal');
        }

        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare(
                "UPDATE journal_entries SET voucher_date = ?, voucher_type = ?, description = ?, total_debit = ?, total_credit = ?, updated_by = ?, updated_at = NOW() WHERE id = ?"
            );
            $stmt->execute(array(
                $data['voucher_date'],
                isset($data['voucher_type']) ? $data['voucher_type'] : 'general',
                isset($data['description']) ? $data['description'] : '',
                $totalDebit,
                $totalCredit,
                $data['updated_by'],
                $id,
            ));

            // Delete old lines and re-insert
            $this->db->prepare("DELETE FROM journal_entry_lines WHERE journal_entry_id = ?")->execute(array($id));

            $lineStmt = $this->db->prepare(
                "INSERT INTO journal_entry_lines (journal_entry_id, account_id, cost_center_id, debit_amount, credit_amount, description, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $sortOrder = 0;
            foreach ($data['lines'] as $line) {
                $debit = (float)$line['debit_amount'];
                $credit = (float)$line['credit_amount'];
                if ($debit == 0 && $credit == 0) continue;

                $lineStmt->execute(array(
                    $id,
                    (int)$line['account_id'],
                    !empty($line['cost_center_id']) ? (int)$line['cost_center_id'] : null,
                    $debit,
                    $credit,
                    isset($line['description']) ? $line['description'] : '',
                    $sortOrder++,
                ));
            }

            $this->db->commit();
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Post journal entry
     * @param int $id
     * @param int $userId
     * @throws Exception
     */
    public function postJournalEntry($id, $userId)
    {
        $entry = $this->getJournalEntryById($id);
        if (!$entry) throw new Exception('Journal entry not found');
        if ($entry['status'] !== 'draft') throw new Exception('Only draft entries can be posted');
        if (empty($entry['lines'])) throw new Exception('Cannot post entry with no lines');

        $this->db->prepare(
            "UPDATE journal_entries SET status = 'posted', posted_by = ?, posted_at = NOW() WHERE id = ?"
        )->execute(array($userId, $id));
    }

    /**
     * Void journal entry (create reverse entry)
     * @param int $id
     * @param int $userId
     * @param string $reason
     * @return int new reverse entry id
     * @throws Exception
     */
    public function voidJournalEntry($id, $userId, $reason = '')
    {
        $entry = $this->getJournalEntryById($id);
        if (!$entry) throw new Exception('Journal entry not found');
        if ($entry['status'] !== 'posted') throw new Exception('Only posted entries can be voided');

        $this->db->beginTransaction();
        try {
            // Mark original as voided
            $this->db->prepare(
                "UPDATE journal_entries SET status = 'voided', voided_by = ?, voided_at = NOW(), void_reason = ? WHERE id = ?"
            )->execute(array($userId, $reason, $id));

            // Create reverse entry
            $reverseNumber = generate_doc_number('journal_entries');
            $reverseStmt = $this->db->prepare(
                "INSERT INTO journal_entries (voucher_number, voucher_date, voucher_type, description, source_module, source_id, status, total_debit, total_credit, posted_by, posted_at, created_by, created_at)
                 VALUES (?, ?, 'adjustment', ?, 'void', ?, 'posted', ?, ?, ?, NOW(), ?, NOW())"
            );
            $reverseStmt->execute(array(
                $reverseNumber,
                date('Y-m-d'),
                'Void: ' . $entry['voucher_number'] . ($reason ? ' - ' . $reason : ''),
                $id,
                $entry['total_debit'],
                $entry['total_credit'],
                $userId,
                $userId,
            ));
            $reverseId = (int)$this->db->lastInsertId();

            // Insert reversed lines (swap debit/credit)
            $lineStmt = $this->db->prepare(
                "INSERT INTO journal_entry_lines (journal_entry_id, account_id, cost_center_id, debit_amount, credit_amount, description, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            foreach ($entry['lines'] as $line) {
                $lineStmt->execute(array(
                    $reverseId,
                    $line['account_id'],
                    $line['cost_center_id'],
                    $line['credit_amount'],  // swap
                    $line['debit_amount'],   // swap
                    'Void: ' . $line['description'],
                    $line['sort_order'],
                ));
            }

            $this->db->commit();
            return $reverseId;

        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Delete journal entry (only draft)
     * @param int $id
     * @throws Exception
     */
    public function deleteJournalEntry($id)
    {
        $entry = $this->getJournalEntryById($id);
        if (!$entry) throw new Exception('Journal entry not found');
        if ($entry['status'] !== 'draft') throw new Exception('Only draft entries can be deleted');

        $this->db->beginTransaction();
        try {
            $this->db->prepare("DELETE FROM journal_entry_lines WHERE journal_entry_id = ?")->execute(array($id));
            $this->db->prepare("DELETE FROM journal_entries WHERE id = ?")->execute(array($id));
            $this->db->commit();
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Generate next voucher number (preview only)
     * @return string
     */
    public function generateVoucherNumber()
    {
        return peek_next_doc_number('journal_entries');
    }

    /**
     * Voucher type options
     * @return array
     */
    public static function voucherTypeOptions()
    {
        return array(
            'general'    => '一般傳票',
            'receipt'    => '收款傳票',
            'payment'    => '付款傳票',
            'transfer'   => '轉帳傳票',
            'adjustment' => '調整傳票',
        );
    }

    /**
     * Status options
     * @return array
     */
    public static function statusOptions()
    {
        return array(
            'draft'  => '草稿',
            'posted' => '已過帳',
            'voided' => '已作廢',
        );
    }

    // ============================================================
    // General Ledger
    // ============================================================

    /**
     * Get ledger entries for an account
     * @param int $accountId
     * @param string $startDate
     * @param string $endDate
     * @param int|null $costCenterId
     * @return array
     */
    public function getLedger($accountId, $startDate, $endDate, $costCenterId = null)
    {
        $where = 'je.status = ? AND jl.account_id = ? AND je.voucher_date >= ? AND je.voucher_date <= ?';
        $params = array('posted', $accountId, $startDate, $endDate);

        if ($costCenterId) {
            $where .= ' AND jl.cost_center_id = ?';
            $params[] = $costCenterId;
        }

        $sql = "SELECT jl.*, je.voucher_number, je.voucher_date, je.description as je_description, je.voucher_type,
                       coa.code as account_code, coa.name as account_name,
                       cc.name as cost_center_name
                FROM journal_entry_lines jl
                JOIN journal_entries je ON jl.journal_entry_id = je.id
                JOIN chart_of_accounts coa ON jl.account_id = coa.id
                LEFT JOIN cost_centers cc ON jl.cost_center_id = cc.id
                WHERE {$where}
                ORDER BY je.voucher_date, je.id, jl.sort_order";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get account balance as of a date
     * @param int $accountId
     * @param string $asOfDate
     * @param int|null $costCenterId
     * @return array [debit_total, credit_total, balance]
     */
    public function getAccountBalance($accountId, $asOfDate, $costCenterId = null)
    {
        $where = 'je.status = ? AND jl.account_id = ? AND je.voucher_date <= ?';
        $params = array('posted', $accountId, $asOfDate);

        if ($costCenterId) {
            $where .= ' AND jl.cost_center_id = ?';
            $params[] = $costCenterId;
        }

        $sql = "SELECT COALESCE(SUM(jl.debit_amount),0) as debit_total, COALESCE(SUM(jl.credit_amount),0) as credit_total
                FROM journal_entry_lines jl
                JOIN journal_entries je ON jl.journal_entry_id = je.id
                WHERE {$where}";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // Get account info for normal_balance
        $account = $this->getAccountById($accountId);
        $debit = (float)$row['debit_total'];
        $credit = (float)$row['credit_total'];

        // Balance depends on normal balance side
        if ($account && $account['normal_balance'] === 'debit') {
            $balance = $debit - $credit;
        } else {
            $balance = $credit - $debit;
        }

        return array(
            'debit_total'  => $debit,
            'credit_total' => $credit,
            'balance'      => $balance,
            'normal_balance' => $account ? $account['normal_balance'] : 'debit',
        );
    }

    /**
     * Get opening balance for a period
     * @param int $accountId
     * @param string $startDate
     * @param int|null $costCenterId
     * @return float
     */
    public function getOpeningBalance($accountId, $startDate, $costCenterId = null)
    {
        $endDate = date('Y-m-d', strtotime($startDate . ' -1 day'));
        $bal = $this->getAccountBalance($accountId, $endDate, $costCenterId);

        $account = $this->getAccountById($accountId);
        if ($account && $account['normal_balance'] === 'debit') {
            return $bal['debit_total'] - $bal['credit_total'];
        }
        return $bal['credit_total'] - $bal['debit_total'];
    }

    /**
     * Get trial balance as of a date
     * @param string $asOfDate
     * @param int|null $costCenterId
     * @return array
     */
    public function getTrialBalance($asOfDate, $costCenterId = null)
    {
        $ccWhere = '';
        $params = array('posted', $asOfDate);
        if ($costCenterId) {
            $ccWhere = ' AND jl.cost_center_id = ?';
            $params[] = $costCenterId;
        }

        $sql = "SELECT coa.id, coa.code, coa.name, coa.account_type, coa.normal_balance, coa.level1,
                       COALESCE(SUM(jl.debit_amount),0) as total_debit,
                       COALESCE(SUM(jl.credit_amount),0) as total_credit
                FROM chart_of_accounts coa
                LEFT JOIN journal_entry_lines jl ON jl.account_id = coa.id
                LEFT JOIN journal_entries je ON jl.journal_entry_id = je.id AND je.status = ? AND je.voucher_date <= ?
                WHERE coa.is_active = 1{$ccWhere}
                GROUP BY coa.id, coa.code, coa.name, coa.account_type, coa.normal_balance, coa.level1
                HAVING total_debit > 0 OR total_credit > 0
                ORDER BY coa.code";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get journal entry count by status
     * @return array
     */
    public function getJournalStats()
    {
        $stmt = $this->db->query(
            "SELECT status, COUNT(*) as cnt FROM journal_entries GROUP BY status"
        );
        $stats = array('draft' => 0, 'posted' => 0, 'voided' => 0);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $stats[$row['status']] = (int)$row['cnt'];
        }
        return $stats;
    }

    /**
     * Get branches for forms
     * @return array
     */
    public function getBranches()
    {
        return $this->db->query("SELECT id, code, name FROM branches WHERE is_active = 1 ORDER BY code")->fetchAll(PDO::FETCH_ASSOC);
    }
}
