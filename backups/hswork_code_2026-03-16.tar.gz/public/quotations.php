<?php
/**
 * 報價管理
 */
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/quotations/QuotationModel.php';

// 權限檢查
$canManage = Auth::hasPermission('quotations.manage');
$canView = Auth::hasPermission('quotations.view');
$canOwn = Auth::hasPermission('quotations.own');
if (!$canManage && !$canView && !$canOwn) {
    Session::flash('error', '無權限');
    redirect('/index.php');
}

$model = new QuotationModel();
$action = $_GET['action'] ?? 'list';
$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    case 'list':
    default:
        $filters = array(
            'month'   => $_GET['month'] ?? date('Y-m'),
            'status'  => $_GET['status'] ?? '',
            'keyword' => $_GET['keyword'] ?? '',
        );
        // 僅 own 權限的只能看自己
        if (!$canManage && !$canView && $canOwn) {
            $filters['own_only'] = Auth::id();
        }
        $quotations = $model->getList($branchIds, $filters);
        $pageTitle = '報價管理';
        $currentPage = 'quotations';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/quotations/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'create':
        if (!$canManage) { Session::flash('error', '無權限'); redirect('/quotations.php'); }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/quotations.php'); }
            $quoteId = $model->create($_POST);
            if (!empty($_POST['sections'])) {
                $model->saveSections($quoteId, $_POST['sections']);
            }
            if ($canManage) {
                $model->saveLaborCost($quoteId, $_POST);
            }
            Session::flash('success', '報價單已建立');
            redirect('/quotations.php?action=view&id=' . $quoteId);
        }
        $quote = null;
        $salespeople = $model->getSalespeople($branchIds);
        $branches = $model->getBranches();
        $cases = $model->getCaseOptions($branchIds);
        $pageTitle = '新增報價單';
        $currentPage = 'quotations';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/quotations/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'edit':
        if (!$canManage) { Session::flash('error', '無權限'); redirect('/quotations.php'); }
        $id = (int)($_GET['id'] ?? 0);
        $quote = $model->getById($id);
        if (!$quote) { Session::flash('error', '報價單不存在'); redirect('/quotations.php'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/quotations.php?action=edit&id='.$id); }
            $model->update($id, $_POST);
            if (isset($_POST['sections'])) {
                $model->saveSections($id, $_POST['sections']);
            }
            if ($canManage) {
                $model->saveLaborCost($id, $_POST);
            }
            Session::flash('success', '報價單已更新');
            redirect('/quotations.php?action=view&id=' . $id);
        }
        $salespeople = $model->getSalespeople($branchIds);
        $branches = $model->getBranches();
        $cases = $model->getCaseOptions($branchIds);
        $pageTitle = '編輯報價單';
        $currentPage = 'quotations';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/quotations/form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'view':
        $id = (int)($_GET['id'] ?? 0);
        $quote = $model->getById($id);
        if (!$quote) { Session::flash('error', '報價單不存在'); redirect('/quotations.php'); }
        // own 權限檢查
        if (!$canManage && !$canView && $canOwn && $quote['sales_id'] != Auth::id()) {
            Session::flash('error', '無權限'); redirect('/quotations.php');
        }
        $pageTitle = '報價單 ' . $quote['quotation_number'];
        $currentPage = 'quotations';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/quotations/view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'print':
        $id = (int)($_GET['id'] ?? 0);
        $quote = $model->getById($id);
        if (!$quote) { Session::flash('error', '報價單不存在'); redirect('/quotations.php'); }
        require __DIR__ . '/../templates/quotations/print.php';
        break;

    case 'status':
        if (!$canManage) { Session::flash('error', '無權限'); redirect('/quotations.php'); }
        if (verify_csrf()) {
            $newStatus = $_GET['status'] ?? '';
            if (in_array($newStatus, array('draft', 'sent', 'accepted', 'rejected'))) {
                $model->updateStatus((int)$_GET['id'], $newStatus);
                Session::flash('success', '狀態已更新');
            }
        }
        redirect('/quotations.php?action=view&id=' . (int)$_GET['id']);
        break;

    case 'delete':
        if (!$canManage) { Session::flash('error', '無權限'); redirect('/quotations.php'); }
        if (verify_csrf()) {
            $model->delete((int)$_GET['id']);
            Session::flash('success', '報價單已刪除');
        }
        redirect('/quotations.php');
        break;

    case 'duplicate':
        if (!$canManage) { Session::flash('error', '無權限'); redirect('/quotations.php'); }
        if (verify_csrf()) {
            $newId = $model->duplicate((int)$_GET['id']);
            if ($newId) {
                Session::flash('success', '報價單已複製');
                redirect('/quotations.php?action=edit&id=' . $newId);
            }
        }
        redirect('/quotations.php');
        break;

    case 'ajax_products':
        header('Content-Type: application/json');
        $keyword = $_GET['keyword'] ?? '';
        if (strlen($keyword) < 1) {
            echo json_encode(array());
            exit;
        }
        $db = Database::getInstance();
        $stmt = $db->prepare("
            SELECT id, name, model_number, unit, price, cost
            FROM products
            WHERE is_active = 1 AND (name LIKE ? OR model_number LIKE ?)
            ORDER BY name
            LIMIT 20
        ");
        $kw = '%' . $keyword . '%';
        $stmt->execute(array($kw, $kw));
        echo json_encode($stmt->fetchAll());
        exit;
}
