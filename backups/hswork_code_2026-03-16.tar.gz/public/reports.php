<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requirePermission('reports.view');
require_once __DIR__ . '/../modules/reports/ReportModel.php';

$model = new ReportModel();
$action = $_GET['action'] ?? 'index';
$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    // ---- 報表首頁 ----
    case 'index':
        $caseSummary = $model->getCaseStatusSummary($branchIds);
        $currentMonth = date('Y-m');
        $monthlyStats = $model->getMonthlyScheduleStats($branchIds, $currentMonth);

        $pageTitle = '報表與分析';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/index.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 案件利潤 ----
    case 'case_profit':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        $data = $model->getCaseProfitReport($branchIds, $startDate, $endDate);

        $pageTitle = '案件利潤分析';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/case_profit.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 員工產值 ----
    case 'staff_productivity':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        $data = $model->getStaffProductivityReport($branchIds, $startDate, $endDate);

        $pageTitle = '員工產值統計';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/staff_productivity.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 點工費月結 ----
    case 'inter_branch':
        $month = $_GET['month'] ?? date('Y-m');
        $data = $model->getInterBranchMonthlyReport($branchIds, $month);

        $pageTitle = '跨點點工費月結報表';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/inter_branch_monthly.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    default:
        redirect('/reports.php');
}
