<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/products/ProductModel.php';

$model = new ProductModel();
$action = $_GET['action'] ?? 'list';

switch ($action) {
    // ---- 產品列表 ----
    case 'list':
        $filters = array(
            'keyword'     => trim($_GET['keyword'] ?? ''),
            'category_id' => (int)($_GET['category_id'] ?? 0),
            'supplier'    => trim($_GET['supplier'] ?? ''),
        );
        $page = max(1, (int)($_GET['page'] ?? 1));

        $result = $model->getList($filters, $page, 24);
        $categories = $model->getTopCategories();
        $suppliers = $model->getSuppliers();

        $pageTitle = '產品目錄';
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 產品詳情 ----
    case 'view':
        $id = (int)($_GET['id'] ?? 0);
        $product = $model->getById($id);
        if (!$product) {
            Session::flash('error', '產品不存在');
            redirect('/products.php');
        }

        $pageTitle = $product['name'];
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 修改價格 ----
    case 'edit_price':
        if (!Auth::hasPermission('admin')) {
            Session::flash('error', '權限不足');
            redirect('/products.php');
        }

        $id = (int)($_GET['id'] ?? 0);
        $product = $model->getById($id);
        if (!$product) {
            Session::flash('error', '產品不存在');
            redirect('/products.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                Session::flash('error', '安全驗證失敗');
                redirect('/products.php?action=edit_price&id=' . $id);
            }
            $model->updatePrice($id, $_POST);
            Session::flash('success', '價格已更新');
            redirect('/products.php?action=view&id=' . $id);
        }

        $pageTitle = '修改價格 - ' . $product['name'];
        $currentPage = 'products';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/products/edit_price.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- AJAX: 產品搜尋（施工回報材料用）----
    case 'ajax_search':
        $keyword = trim($_GET['keyword'] ?? '');
        if (mb_strlen($keyword) < 2) {
            json_response(array('data' => array()));
        }
        $result = $model->getList(array('keyword' => $keyword), 1, 10);
        $items = array();
        foreach ($result['data'] as $p) {
            $items[] = array(
                'id' => $p['id'],
                'name' => $p['name'],
                'model_number' => $p['model_number'] ?? '',
                'price' => $p['price'] ?? 0,
                'unit' => $p['unit'] ?? '',
            );
        }
        json_response(array('data' => $items));
        break;

    default:
        redirect('/products.php');
}
