<?php
/**
 * 應用程式設定
 */
return [
    'name'     => '弱電工程排程系統',
    'version'  => '1.0.0',
    'timezone' => 'Asia/Taipei',
    'locale'   => 'zh_TW',

    // 網站根路徑 (智邦虛擬主機設定)
    'base_url' => getenv('APP_URL') ?: 'https://hswork.com.tw',
    'base_path' => __DIR__ . '/..',

    // Session 設定
    'session' => [
        'name'     => 'HSWORK_SID',
        'lifetime' => 28800, // 8小時
    ],

    // 上傳設定
    'upload' => [
        'max_size'       => 10 * 1024 * 1024, // 10MB
        'allowed_types'  => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx'],
        'cases_path'     => '/uploads/cases/',
    ],

    // 角色定義
    'roles' => [
        'boss'            => '系統管理者',
        'manager'         => '管理者',
        'sales_manager'   => '業務主管',
        'eng_manager'     => '工程主管',
        'eng_deputy'      => '工程副主管',
        'engineer'        => '工程人員',
        'sales'           => '業務',
        'sales_assistant' => '業務助理',
        'admin_staff'     => '行政人員',
    ],

    // 角色權限
    'permissions' => [
        'boss'            => ['all'],
        'manager'         => ['all'],
        'sales_manager'   => ['cases.manage', 'staff.view', 'schedule.view', 'reports.view', 'leaves.manage', 'inter_branch.view', 'repairs.view', 'quotations.manage'],
        'eng_manager'     => ['cases.view', 'staff.manage', 'schedule.manage', 'reports.view', 'leaves.manage', 'inter_branch.manage', 'repairs.manage', 'quotations.view'],
        'eng_deputy'      => ['cases.view', 'staff.view', 'schedule.manage', 'leaves.manage', 'inter_branch.view', 'repairs.view'],
        'engineer'        => ['cases.view', 'schedule.view', 'leaves.own', 'repairs.view'],
        'sales'           => ['cases.own', 'schedule.view', 'leaves.own', 'repairs.own', 'quotations.own'],
        'sales_assistant' => ['cases.assist', 'schedule.view', 'leaves.own', 'quotations.view'],
        'admin_staff'     => ['cases.view', 'staff.view', 'schedule.view', 'payments.manage', 'leaves.view', 'inter_branch.manage', 'repairs.manage', 'quotations.view'],
    ],

    // 假別
    'leave_types' => [
        'annual'   => '特休',
        'personal' => '事假',
        'sick'     => '病假',
        'official' => '公假',
    ],

    // 證照到期預警天數
    'cert_warning_days' => 30,

    // API 設定
    'api' => [
        'rate_limit'     => 1000,  // 每小時
        'token_lifetime' => 86400, // 24小時
    ],
];
