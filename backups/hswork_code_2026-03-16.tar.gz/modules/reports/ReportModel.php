<?php
/**
 * 報表資料模型
 */
class ReportModel
{
    /** @var PDO */
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * 案件利潤分析
     */
    public function getCaseProfitReport(array $branchIds, string $startDate, string $endDate): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $params = array_merge($branchIds, [$startDate, $endDate]);

        $stmt = $this->db->prepare("
            SELECT c.id, c.case_number, c.title, c.case_type, c.status,
                   b.name AS branch_name,
                   COALESCE(p.total_paid, 0) AS total_paid,
                   COALESCE(s.work_days, 0) AS work_days,
                   COALESCE(s.engineer_count, 0) AS total_engineer_days
            FROM cases c
            JOIN branches b ON c.branch_id = b.id
            LEFT JOIN (
                SELECT case_id, SUM(amount) AS total_paid
                FROM payments
                GROUP BY case_id
            ) p ON p.case_id = c.id
            LEFT JOIN (
                SELECT s2.case_id,
                       COUNT(DISTINCT s2.id) AS work_days,
                       COUNT(se.id) AS engineer_count
                FROM schedules s2
                LEFT JOIN schedule_engineers se ON se.schedule_id = s2.id
                WHERE s2.status != 'cancelled'
                GROUP BY s2.case_id
            ) s ON s.case_id = c.id
            WHERE c.branch_id IN ($ph)
              AND c.created_at BETWEEN ? AND ?
            ORDER BY c.created_at DESC
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 員工產值統計
     */
    public function getStaffProductivityReport(array $branchIds, string $startDate, string $endDate): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $params = array_merge($branchIds, [$startDate, $endDate]);

        $stmt = $this->db->prepare("
            SELECT u.id, u.real_name, b.name AS branch_name,
                   COUNT(DISTINCT se.schedule_id) AS schedule_count,
                   COUNT(DISTINCT s.case_id) AS case_count,
                   COUNT(DISTINCT wl.id) AS worklog_count,
                   SUM(CASE WHEN wl.arrival_time IS NOT NULL AND wl.departure_time IS NOT NULL
                       THEN TIMESTAMPDIFF(MINUTE, wl.arrival_time, wl.departure_time) ELSE 0 END) AS total_minutes
            FROM users u
            JOIN branches b ON u.branch_id = b.id
            LEFT JOIN schedule_engineers se ON se.user_id = u.id
            LEFT JOIN schedules s ON se.schedule_id = s.id AND s.status != 'cancelled'
                AND s.schedule_date BETWEEN ? AND ?
            LEFT JOIN work_logs wl ON wl.user_id = u.id AND wl.work_date BETWEEN ? AND ?
            WHERE u.branch_id IN ($ph) AND u.is_engineer = 1 AND u.is_active = 1
            GROUP BY u.id, u.real_name, b.name
            ORDER BY schedule_count DESC
        ");
        $allParams = array_merge([$startDate, $endDate, $startDate, $endDate], $branchIds);
        $stmt->execute($allParams);
        return $stmt->fetchAll();
    }

    /**
     * 跨點點工費月結報表
     */
    public function getInterBranchMonthlyReport(array $branchIds, string $month): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $startDate = $month . '-01';
        $endDate = date('Y-m-t', strtotime($startDate));
        $params = array_merge($branchIds, [$startDate, $endDate]);

        $stmt = $this->db->prepare("
            SELECT bf.name AS from_branch, bt.name AS to_branch,
                   COUNT(*) AS support_count,
                   SUM(CASE WHEN ibs.charge_type = 'full_day' THEN 1 ELSE 0 END) AS full_days,
                   SUM(CASE WHEN ibs.charge_type = 'half_day' THEN 1 ELSE 0 END) AS half_days,
                   SUM(CASE WHEN ibs.charge_type = 'hourly' THEN COALESCE(ibs.hours, 0) ELSE 0 END) AS total_hours,
                   SUM(ibs.settled) AS settled_count
            FROM inter_branch_support ibs
            JOIN branches bf ON ibs.from_branch_id = bf.id
            JOIN branches bt ON ibs.to_branch_id = bt.id
            WHERE ibs.from_branch_id IN ($ph)
              AND ibs.support_date BETWEEN ? AND ?
            GROUP BY bf.name, bt.name
            ORDER BY bf.name, bt.name
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 案件狀態彙總
     */
    public function getCaseStatusSummary(array $branchIds): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $stmt = $this->db->prepare("
            SELECT status, COUNT(*) AS cnt
            FROM cases
            WHERE branch_id IN ($ph)
            GROUP BY status
            ORDER BY FIELD(status, 'pending','ready','scheduled','in_progress','completed','cancelled')
        ");
        $stmt->execute($branchIds);
        return $stmt->fetchAll();
    }

    /**
     * 月度排工統計
     */
    public function getMonthlyScheduleStats(array $branchIds, string $month): array
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $startDate = $month . '-01';
        $endDate = date('Y-m-t', strtotime($startDate));
        $params = array_merge($branchIds, [$startDate, $endDate]);

        $stmt = $this->db->prepare("
            SELECT s.schedule_date, COUNT(DISTINCT s.id) AS schedule_count,
                   COUNT(DISTINCT se.user_id) AS engineer_count
            FROM schedules s
            JOIN cases c ON s.case_id = c.id
            LEFT JOIN schedule_engineers se ON se.schedule_id = s.id
            WHERE c.branch_id IN ($ph)
              AND s.schedule_date BETWEEN ? AND ?
              AND s.status != 'cancelled'
            GROUP BY s.schedule_date
            ORDER BY s.schedule_date
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
