<?php
/**
 * 產品資料模型
 */
class ProductModel
{
    /** @var PDO */
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * 取得產品清單 (含分頁/篩選)
     */
    public function getList(array $filters = [], $page = 1, $perPage = 24)
    {
        $where = 'p.is_active = 1';
        $params = array();

        if (!empty($filters['keyword'])) {
            $where .= ' AND (p.name LIKE ? OR p.model LIKE ? OR p.brand LIKE ?)';
            $kw = '%' . $filters['keyword'] . '%';
            $params[] = $kw;
            $params[] = $kw;
            $params[] = $kw;
        }
        if (!empty($filters['category_id'])) {
            // 包含子分類
            $catIds = $this->getCategoryDescendants((int)$filters['category_id']);
            $catIds[] = (int)$filters['category_id'];
            $placeholders = implode(',', array_fill(0, count($catIds), '?'));
            $where .= " AND p.category_id IN ($placeholders)";
            $params = array_merge($params, $catIds);
        }
        if (!empty($filters['supplier'])) {
            $where .= ' AND p.supplier = ?';
            $params[] = $filters['supplier'];
        }

        // 計算總數
        $countStmt = $this->db->prepare("SELECT COUNT(*) FROM products p WHERE $where");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $page = max(1, (int)$page);
        $offset = ($page - 1) * $perPage;

        $stmt = $this->db->prepare("
            SELECT p.*, pc.name AS category_name
            FROM products p
            LEFT JOIN product_categories pc ON p.category_id = pc.id
            WHERE $where
            ORDER BY p.name ASC
            LIMIT $perPage OFFSET $offset
        ");
        $stmt->execute($params);

        return array(
            'data'     => $stmt->fetchAll(),
            'total'    => $total,
            'page'     => $page,
            'perPage'  => $perPage,
            'lastPage' => (int)ceil($total / max($perPage, 1)),
        );
    }

    /**
     * 取得單一產品
     */
    public function getById($id)
    {
        $stmt = $this->db->prepare('
            SELECT p.*, pc.name AS category_name
            FROM products p
            LEFT JOIN product_categories pc ON p.category_id = pc.id
            WHERE p.id = ?
        ');
        $stmt->execute(array($id));
        $product = $stmt->fetch();
        if (!$product) return null;

        // 取得分類路徑
        if ($product['category_id']) {
            $product['category_path'] = $this->getCategoryPath($product['category_id']);
        }

        return $product;
    }

    /**
     * 更新價格
     */
    public function updatePrice($id, array $data)
    {
        $stmt = $this->db->prepare('
            UPDATE products SET price = ?, cost = ?, retail_price = ?, labor_cost = ?
            WHERE id = ?
        ');
        $stmt->execute(array(
            (float)$data['price'],
            (float)$data['cost'],
            (float)$data['retail_price'],
            !empty($data['labor_cost']) ? (float)$data['labor_cost'] : null,
            (int)$id
        ));
    }

    /**
     * 取得頂層分類（供篩選用）
     */
    public function getTopCategories()
    {
        $stmt = $this->db->query('
            SELECT pc.*, COUNT(p.id) AS product_count
            FROM product_categories pc
            LEFT JOIN product_categories sub ON sub.parent_id = pc.id
            LEFT JOIN products p ON (p.category_id = pc.id OR p.category_id = sub.id) AND p.is_active = 1
            WHERE pc.parent_id IS NULL
            GROUP BY pc.id
            HAVING product_count > 0
            ORDER BY pc.name
        ');
        return $stmt->fetchAll();
    }

    /**
     * 取得分類的所有子分類 ID
     */
    public function getCategoryDescendants($parentId)
    {
        $ids = array();
        $stmt = $this->db->prepare('SELECT id FROM product_categories WHERE parent_id = ?');
        $stmt->execute(array($parentId));
        $children = $stmt->fetchAll(PDO::FETCH_COLUMN);

        foreach ($children as $childId) {
            $ids[] = (int)$childId;
            $ids = array_merge($ids, $this->getCategoryDescendants((int)$childId));
        }
        return $ids;
    }

    /**
     * 取得分類路徑 (如: 監控系統 > 攝影機 > 球型)
     */
    public function getCategoryPath($categoryId)
    {
        $path = array();
        $maxDepth = 5;
        $currentId = $categoryId;

        while ($currentId && $maxDepth-- > 0) {
            $stmt = $this->db->prepare('SELECT id, name, parent_id FROM product_categories WHERE id = ?');
            $stmt->execute(array($currentId));
            $cat = $stmt->fetch();
            if (!$cat) break;
            array_unshift($path, $cat['name']);
            $currentId = $cat['parent_id'];
        }

        return implode(' > ', $path);
    }

    /**
     * 取得不重複供應商列表
     */
    public function getSuppliers()
    {
        $stmt = $this->db->query("
            SELECT DISTINCT supplier FROM products
            WHERE supplier IS NOT NULL AND supplier != '' AND is_active = 1
            ORDER BY supplier
        ");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}
