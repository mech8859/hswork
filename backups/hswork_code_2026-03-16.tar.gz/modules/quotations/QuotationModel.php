<?php
/**
 * 報價單模型
 */
class QuotationModel
{
    /** @var PDO */
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public static function statusLabel($status)
    {
        $map = array('draft' => '草稿', 'sent' => '已送出', 'accepted' => '已接受', 'rejected' => '已拒絕');
        return isset($map[$status]) ? $map[$status] : $status;
    }

    public static function statusBadge($status)
    {
        $map = array('draft' => 'warning', 'sent' => 'primary', 'accepted' => 'success', 'rejected' => 'danger');
        return isset($map[$status]) ? $map[$status] : '';
    }

    public static function formatLabel($format)
    {
        $map = array('simple' => '普銷', 'project' => '專案');
        return isset($map[$format]) ? $map[$format] : $format;
    }

    /**
     * 列表
     */
    public function getList(array $branchIds, array $filters = array())
    {
        $where = 'q.branch_id IN (' . implode(',', array_fill(0, count($branchIds), '?')) . ')';
        $params = $branchIds;

        if (!empty($filters['month'])) {
            $where .= ' AND q.quote_date LIKE ?';
            $params[] = $filters['month'] . '%';
        }
        if (!empty($filters['status'])) {
            $where .= ' AND q.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['keyword'])) {
            $where .= ' AND (q.customer_name LIKE ? OR q.quotation_number LIKE ? OR q.site_name LIKE ?)';
            $kw = '%' . $filters['keyword'] . '%';
            $params[] = $kw;
            $params[] = $kw;
            $params[] = $kw;
        }
        // 僅自己的報價單
        if (!empty($filters['own_only'])) {
            $where .= ' AND q.sales_id = ?';
            $params[] = $filters['own_only'];
        }

        $stmt = $this->db->prepare("
            SELECT q.*, b.name AS branch_name, s.real_name AS sales_name
            FROM quotations q
            JOIN branches b ON q.branch_id = b.id
            LEFT JOIN users s ON q.sales_id = s.id
            WHERE $where
            ORDER BY q.quote_date DESC, q.id DESC
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 取得單筆（含區段和項目）
     */
    public function getById($id)
    {
        $stmt = $this->db->prepare('
            SELECT q.*, b.name AS branch_name, s.real_name AS sales_name,
                   cr.real_name AS creator_name
            FROM quotations q
            JOIN branches b ON q.branch_id = b.id
            LEFT JOIN users s ON q.sales_id = s.id
            LEFT JOIN users cr ON q.created_by = cr.id
            WHERE q.id = ?
        ');
        $stmt->execute(array($id));
        $quote = $stmt->fetch();
        if (!$quote) return null;

        // 載入區段
        $secStmt = $this->db->prepare('SELECT * FROM quotation_sections WHERE quotation_id = ? ORDER BY sort_order, id');
        $secStmt->execute(array($id));
        $sections = $secStmt->fetchAll();

        // 載入每個區段的項目
        $itemStmt = $this->db->prepare('SELECT * FROM quotation_items WHERE section_id = ? ORDER BY sort_order, id');
        foreach ($sections as &$sec) {
            $itemStmt->execute(array($sec['id']));
            $sec['items'] = $itemStmt->fetchAll();
        }

        $quote['sections'] = $sections;
        return $quote;
    }

    /**
     * 新增
     */
    public function create(array $data)
    {
        $number = $this->generateNumber();
        $stmt = $this->db->prepare('
            INSERT INTO quotations (quotation_number, branch_id, case_id, format, customer_name,
                contact_person, contact_phone, site_name, site_address,
                invoice_title, invoice_tax_id, quote_date, valid_date,
                payment_terms, notes, sales_id, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ');
        $stmt->execute(array(
            $number,
            $data['branch_id'],
            $data['case_id'] ?: null,
            $data['format'],
            $data['customer_name'],
            $data['contact_person'] ?: null,
            $data['contact_phone'] ?: null,
            $data['site_name'] ?: null,
            $data['site_address'] ?: null,
            $data['invoice_title'] ?: null,
            $data['invoice_tax_id'] ?: null,
            $data['quote_date'],
            $data['valid_date'],
            $data['payment_terms'] ?: null,
            $data['notes'] ?: null,
            $data['sales_id'] ?: null,
            Auth::id(),
        ));
        return (int)$this->db->lastInsertId();
    }

    /**
     * 更新
     */
    public function update($id, array $data)
    {
        $stmt = $this->db->prepare('
            UPDATE quotations SET
                case_id = ?, format = ?, customer_name = ?,
                contact_person = ?, contact_phone = ?, site_name = ?, site_address = ?,
                invoice_title = ?, invoice_tax_id = ?, quote_date = ?, valid_date = ?,
                payment_terms = ?, notes = ?, sales_id = ?
            WHERE id = ?
        ');
        $stmt->execute(array(
            $data['case_id'] ?: null,
            $data['format'],
            $data['customer_name'],
            $data['contact_person'] ?: null,
            $data['contact_phone'] ?: null,
            $data['site_name'] ?: null,
            $data['site_address'] ?: null,
            $data['invoice_title'] ?: null,
            $data['invoice_tax_id'] ?: null,
            $data['quote_date'],
            $data['valid_date'],
            $data['payment_terms'] ?: null,
            $data['notes'] ?: null,
            $data['sales_id'] ?: null,
            $id,
        ));
    }

    /**
     * 儲存內部成本欄位
     */
    public function saveLaborCost($id, array $data)
    {
        $stmt = $this->db->prepare('
            UPDATE quotations SET labor_days = ?, labor_people = ?, labor_hours = ?, labor_cost_total = ?
            WHERE id = ?
        ');
        $stmt->execute(array(
            $data['labor_days'] ?: null,
            $data['labor_people'] ?: null,
            $data['labor_hours'] ?: null,
            $data['labor_cost_total'] ?: null,
            $id,
        ));
    }

    /**
     * 刪除（僅草稿）
     */
    public function delete($id)
    {
        // CASCADE 會自動刪除 sections 和 items
        $this->db->prepare("DELETE FROM quotations WHERE id = ? AND status = 'draft'")->execute(array($id));
    }

    /**
     * 更新狀態
     */
    public function updateStatus($id, $status)
    {
        $this->db->prepare('UPDATE quotations SET status = ? WHERE id = ?')->execute(array($status, $id));

        // 連動案件 has_quotation
        $quote = $this->getById($id);
        if ($quote && $quote['case_id']) {
            $this->syncCaseQuotationFlag($quote['case_id']);
        }
    }

    /**
     * 儲存區段和項目（delete-all-then-insert）
     */
    public function saveSections($quotationId, array $sectionsData)
    {
        // 刪除舊資料（CASCADE 會連帶刪除 items）
        $this->db->prepare('DELETE FROM quotation_sections WHERE quotation_id = ?')->execute(array($quotationId));

        $secStmt = $this->db->prepare('
            INSERT INTO quotation_sections (quotation_id, title, sort_order, subtotal)
            VALUES (?, ?, ?, ?)
        ');
        $itemStmt = $this->db->prepare('
            INSERT INTO quotation_items (section_id, product_id, item_name, quantity, unit, unit_price, amount, remark, sort_order, unit_cost, cost_amount)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ');

        $grandSubtotal = 0;
        $grandCost = 0;

        foreach ($sectionsData as $sIdx => $sec) {
            $secSubtotal = 0;
            $secStmt->execute(array($quotationId, $sec['title'] ?: '', (int)$sIdx, 0));
            $sectionId = (int)$this->db->lastInsertId();

            $items = isset($sec['items']) ? $sec['items'] : array();
            foreach ($items as $iIdx => $item) {
                if (empty($item['item_name'])) continue;
                $qty = (float)$item['quantity'];
                if ($qty <= 0) $qty = 1;
                $price = (int)$item['unit_price'];
                $amount = (int)round($qty * $price);
                $unitCost = (int)($item['unit_cost'] ?: 0);
                $costAmount = (int)round($qty * $unitCost);

                $itemStmt->execute(array(
                    $sectionId,
                    $item['product_id'] ?: null,
                    $item['item_name'],
                    $qty,
                    $item['unit'] ?: '式',
                    $price,
                    $amount,
                    $item['remark'] ?: null,
                    (int)$iIdx,
                    $unitCost,
                    $costAmount,
                ));
                $secSubtotal += $amount;
                $grandCost += $costAmount;
            }

            // 更新區段小計
            $this->db->prepare('UPDATE quotation_sections SET subtotal = ? WHERE id = ?')
                ->execute(array($secSubtotal, $sectionId));
            $grandSubtotal += $secSubtotal;
        }

        // 更新報價單金額
        $this->recalcTotals($quotationId, $grandSubtotal, $grandCost);
    }

    /**
     * 重算報價單金額
     */
    private function recalcTotals($quotationId, $subtotal, $materialCost)
    {
        $stmt = $this->db->prepare('SELECT tax_rate, labor_cost_total FROM quotations WHERE id = ?');
        $stmt->execute(array($quotationId));
        $q = $stmt->fetch();
        $taxRate = $q ? (float)$q['tax_rate'] : 5.0;
        $laborCost = $q ? (int)$q['labor_cost_total'] : 0;

        $taxAmount = (int)round($subtotal * $taxRate / 100);
        $totalAmount = $subtotal + $taxAmount;
        $totalCost = $materialCost + $laborCost;
        $profitAmount = $subtotal - $totalCost;
        $profitRate = ($subtotal > 0) ? round($profitAmount / $subtotal * 100, 2) : 0;

        $this->db->prepare('
            UPDATE quotations SET subtotal = ?, tax_amount = ?, total_amount = ?,
                total_cost = ?, profit_amount = ?, profit_rate = ?
            WHERE id = ?
        ')->execute(array($subtotal, $taxAmount, $totalAmount, $totalCost, $profitAmount, $profitRate, $quotationId));
    }

    /**
     * 複製報價單
     */
    public function duplicate($id)
    {
        $orig = $this->getById($id);
        if (!$orig) return null;

        $data = $orig;
        $data['format'] = $orig['format'];
        $data['quote_date'] = date('Y-m-d');
        $data['valid_date'] = date('Y-m-d', strtotime('+30 days'));
        $newId = $this->create($data);

        // 複製區段和項目
        $sectionsData = array();
        foreach ($orig['sections'] as $sec) {
            $secData = array('title' => $sec['title'], 'items' => array());
            foreach ($sec['items'] as $item) {
                $secData['items'][] = array(
                    'product_id' => $item['product_id'],
                    'item_name' => $item['item_name'],
                    'quantity' => $item['quantity'],
                    'unit' => $item['unit'],
                    'unit_price' => $item['unit_price'],
                    'remark' => $item['remark'],
                    'unit_cost' => $item['unit_cost'],
                );
            }
            $sectionsData[] = $secData;
        }
        $this->saveSections($newId, $sectionsData);

        // 複製人力成本
        $this->saveLaborCost($newId, array(
            'labor_days' => $orig['labor_days'],
            'labor_people' => $orig['labor_people'],
            'labor_hours' => $orig['labor_hours'],
            'labor_cost_total' => $orig['labor_cost_total'],
        ));

        return $newId;
    }

    /**
     * 同步案件的 has_quotation 旗標
     */
    public function syncCaseQuotationFlag($caseId)
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM quotations
            WHERE case_id = ? AND status IN ('sent','accepted')
        ");
        $stmt->execute(array($caseId));
        $hasQuote = (int)$stmt->fetchColumn() > 0 ? 1 : 0;

        $this->db->prepare('UPDATE case_readiness SET has_quotation = ? WHERE case_id = ?')
            ->execute(array($hasQuote, $caseId));
    }

    /**
     * 取得業務人員列表
     */
    public function getSalespeople(array $branchIds)
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $stmt = $this->db->prepare("
            SELECT id, real_name, role FROM users
            WHERE branch_id IN ($ph) AND is_active = 1
              AND role IN ('boss','manager','sales_manager','sales','sales_assistant')
            ORDER BY real_name
        ");
        $stmt->execute($branchIds);
        return $stmt->fetchAll();
    }

    /**
     * 取得案件列表（供選擇關聯）
     */
    public function getCaseOptions(array $branchIds)
    {
        $ph = implode(',', array_fill(0, count($branchIds), '?'));
        $stmt = $this->db->prepare("
            SELECT id, case_number, title FROM cases
            WHERE branch_id IN ($ph) AND status NOT IN ('completed','cancelled')
            ORDER BY id DESC
            LIMIT 200
        ");
        $stmt->execute($branchIds);
        return $stmt->fetchAll();
    }

    public function getBranches()
    {
        return $this->db->query('SELECT * FROM branches WHERE is_active = 1 ORDER BY id')->fetchAll();
    }

    /**
     * 取得案件的報價單列表
     */
    public function getByCase($caseId)
    {
        $stmt = $this->db->prepare('
            SELECT q.*, s.real_name AS sales_name
            FROM quotations q
            LEFT JOIN users s ON q.sales_id = s.id
            WHERE q.case_id = ?
            ORDER BY q.quote_date DESC
        ');
        $stmt->execute(array($caseId));
        return $stmt->fetchAll();
    }

    private function generateNumber()
    {
        $prefix = 'Q-' . date('Ymd') . '-';
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM quotations WHERE quotation_number LIKE ?");
        $stmt->execute(array($prefix . '%'));
        $count = (int)$stmt->fetchColumn() + 1;
        return $prefix . str_pad($count, 3, '0', STR_PAD_LEFT);
    }
}
