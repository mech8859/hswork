<?php
$chineseNums = array('一','二','三','四','五','六','七','八','九','十');
$salesName = $quote['sales_name'] ?: '';
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<title>報價單 <?= e($quote['quotation_number']) ?></title>
<style>
@page { size: A4; margin: 10mm 12mm; }
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: "Microsoft JhengHei", "微軟正黑體", Arial, sans-serif; font-size: 11px; color: #333; line-height: 1.4; }

.header { text-align: center; margin-bottom: 8px; }
.header .logo-row { display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 2px; }
.header h1 { font-size: 22px; font-weight: bold; margin: 0; }
.header .subtitle { font-size: 11px; color: #666; margin-bottom: 6px; }

.info-table { width: 100%; border-collapse: collapse; margin-bottom: 6px; font-size: 10.5px; }
.info-table td { padding: 2px 4px; vertical-align: top; }
.info-table .label { color: #666; white-space: nowrap; }
.info-right { text-align: right; }

.items-table { width: 100%; border-collapse: collapse; margin-bottom: 4px; font-size: 10.5px; }
.items-table th { background: #e8f0e8; border: 1px solid #ccc; padding: 4px 6px; text-align: center; font-weight: bold; }
.items-table td { border: 1px solid #ccc; padding: 3px 6px; }
.items-table .text-right { text-align: right; }
.items-table .text-center { text-align: center; }
.items-table .section-header { background: #f5f5f5; font-weight: bold; }
.items-table .subtotal-row { background: #fafafa; }
.items-table .subtotal-row td { border-top: 2px solid #999; }

.totals-table { width: 100%; border-collapse: collapse; margin-bottom: 8px; font-size: 11px; }
.totals-table td { padding: 2px 6px; border: 1px solid #ccc; }
.totals-table .label { text-align: right; width: 75%; }
.totals-table .amount { text-align: right; width: 25%; font-weight: bold; }

.payment-row { font-size: 10.5px; margin-bottom: 6px; }
.payment-row strong { color: #333; }

.footer-section { margin-top: 8px; font-size: 9.5px; }
.bank-info { display: flex; gap: 30px; margin-bottom: 6px; }
.bank-info div { flex: 1; }
.bank-info .bank-label { color: #666; display: inline-block; width: 45px; }
.bank-notice { color: #c00; font-size: 9px; margin-bottom: 4px; }

.warranty { font-size: 9px; margin-bottom: 8px; line-height: 1.5; }
.warranty p { margin-bottom: 3px; }

.sign-area { display: flex; justify-content: flex-end; gap: 40px; margin-top: 10px; }
.sign-block { text-align: center; }
.sign-block .sign-title { font-weight: bold; font-size: 10.5px; margin-bottom: 20px; }
.sign-line { border-bottom: 1px solid #333; width: 120px; margin: 0 auto 4px; }

.line-id { text-align: center; font-size: 10px; margin-top: 8px; color: #666; }

@media print {
    body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .no-print { display: none !important; }
}
@media screen {
    body { max-width: 210mm; margin: 10mm auto; padding: 10mm; background: #f5f5f5; }
    body > * { background: #fff; }
}
</style>
</head>
<body>

<button class="no-print" onclick="window.print()" style="position:fixed;top:10px;right:10px;padding:8px 16px;background:#2563eb;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:14px;z-index:100">列印 / 存PDF</button>

<!-- 公司抬頭 -->
<div class="header">
    <h1>禾順監視數位科技-台中分公司 報價單</h1>
    <div class="subtitle">監控系統/電話總機/影視對講/門禁管制/商用音響/網路工程</div>
</div>

<!-- 客戶及報價資訊 -->
<table class="info-table">
    <tr>
        <td class="label">客戶名稱：</td>
        <td><?= e($quote['customer_name']) ?></td>
        <td class="label">發票資訊</td>
        <td></td>
        <td class="info-right label">報價日期：</td>
        <td class="info-right"><?= e($quote['quote_date']) ?></td>
    </tr>
    <tr>
        <td class="label">連絡對象：</td>
        <td><?= e($quote['contact_person'] ?: '') ?></td>
        <td class="label">抬　頭：</td>
        <td><?= e($quote['invoice_title'] ?: '') ?></td>
        <td class="info-right label">有效日期：</td>
        <td class="info-right"><?= e($quote['valid_date']) ?></td>
    </tr>
    <tr>
        <td class="label">連絡電話：</td>
        <td><?= e($quote['contact_phone'] ?: '') ?></td>
        <td class="label">統　編：</td>
        <td><?= e($quote['invoice_tax_id'] ?: '') ?></td>
        <td class="info-right label">承辦業務：</td>
        <td class="info-right"><?= e($salesName) ?></td>
    </tr>
    <tr>
        <td class="label">案場名稱：</td>
        <td colspan="3"><?= e($quote['site_name'] ?: '') ?></td>
        <td class="info-right label">服務專線：</td>
        <td class="info-right">0800-008-859</td>
    </tr>
    <tr>
        <td class="label">施工地址：</td>
        <td colspan="5"><?= e($quote['site_address'] ?: '') ?></td>
    </tr>
</table>

<!-- 報價明細 -->
<table class="items-table">
    <thead>
        <tr>
            <th style="width:25px">序</th>
            <th>品名/型號</th>
            <th style="width:55px">數量</th>
            <th style="width:35px">單位</th>
            <th style="width:70px">單價</th>
            <th style="width:80px">小計</th>
            <th style="width:80px">備註</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($quote['sections'] as $sIdx => $sec): ?>
        <?php if ($quote['format'] === 'project'): ?>
        <tr class="section-header">
            <td><?= isset($chineseNums[$sIdx]) ? $chineseNums[$sIdx] : ($sIdx + 1) ?></td>
            <td colspan="6"><?= e($sec['title'] ?: '') ?></td>
        </tr>
        <?php endif; ?>
        <?php foreach ($sec['items'] as $iIdx => $item): ?>
        <tr>
            <td class="text-center"><?= $iIdx + 1 ?></td>
            <td><?= e($item['item_name']) ?></td>
            <td class="text-right"><?= rtrim(rtrim(number_format((float)$item['quantity'], 2), '0'), '.') ?></td>
            <td class="text-center"><?= e($item['unit']) ?></td>
            <td class="text-right"><?= number_format((int)$item['unit_price']) ?></td>
            <td class="text-right"><?= number_format((int)$item['amount']) ?></td>
            <td><?= e($item['remark'] ?: '') ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if ($quote['format'] === 'project'): ?>
        <tr class="subtotal-row">
            <td colspan="5" class="text-right"><strong>小計</strong></td>
            <td class="text-right"><strong><?= number_format((int)$sec['subtotal']) ?></strong></td>
            <td></td>
        </tr>
        <?php endif; ?>
    <?php endforeach; ?>
    </tbody>
</table>

<!-- 合計 -->
<table class="totals-table">
    <tr><td class="label">未稅合計：</td><td class="amount">$<?= number_format((int)$quote['subtotal']) ?></td></tr>
    <tr><td class="label">營業稅：</td><td class="amount">$<?= number_format((int)$quote['tax_amount']) ?></td></tr>
    <tr><td class="label"><strong>合計新台幣：</strong></td><td class="amount"><strong>$<?= number_format((int)$quote['total_amount']) ?></strong></td></tr>
</table>

<!-- 收款條件 -->
<?php if ($quote['payment_terms']): ?>
<div class="payment-row"><strong>收款條件：</strong><?= e($quote['payment_terms']) ?></div>
<?php endif; ?>
<?php if ($quote['notes']): ?>
<div class="payment-row"><strong>附註說明：</strong><?= e($quote['notes']) ?></div>
<?php endif; ?>

<!-- 匯款資料 & 連絡資訊 -->
<div class="footer-section">
    <div class="bank-info">
        <div>
            <strong>匯款資料</strong><br>
            <span class="bank-label">戶名：</span>禾順監視數位科技有限公司<br>
            <span class="bank-label">銀行：</span>中國信託銀行(822) 豐原分行<br>
            <span class="bank-label">帳號：</span>3925-4087-3162
        </div>
        <div>
            <strong>連絡資訊</strong><br>
            <span class="bank-label">地址：</span>台中市潭子區環中路一段138巷1之5號<br>
            <span class="bank-label">電話：</span>04-2534-7007<br>
            <span class="bank-label">傳真：</span>04-2534-7661
        </div>
    </div>
    <div class="bank-notice">溫馨提醒:匯款後記得告知匯款帳號4-6碼及金額</div>
    <div class="bank-notice">附註說明:( 定金視同價金之一部分,除不可抗力之因素外,凡取消安裝.定金即視為違約金沒入。)</div>
</div>

<!-- 保固條款 -->
<div class="warranty">
    <p>一、 產品安裝日【設備(含變壓器)保固12個月，消耗品除外】，保固期內任何因材質、製造、裝配等瑕疵外屬人為因素導致設備與配線故障或損壞相關損壞之零件,本公司負責檢修及報價更換，如出勤維修判定非本公司因素,酌收出勤費用。</p>
    <p>二、 應收工程款未點交完成前，標的物線路、設備之所有權仍歸屬本公司，買受人無異議且同意本公司無須經法律程序，隨時取回貨品或代物清償。(天災、雷擊、鼠害、人為破壞 非保固範圍)。第二年起出勤需加收費用。</p>
    <p>三、付款方式:30%定金 70% 完工當日付現或當日匯款，如配合工程則以雙方協調後之訂定付款方式。</p>
</div>

<!-- 簽名區 -->
<div class="sign-area">
    <div class="sign-block">
        <div class="sign-title">業務確認</div>
        <div>簽名：<span style="text-decoration:underline">&nbsp;&nbsp;<?= e($salesName) ?>&nbsp;&nbsp;</span></div>
    </div>
    <div class="sign-block">
        <div class="sign-title">客戶確認</div>
        <div>簽名：<div class="sign-line"></div></div>
    </div>
</div>
<div class="sign-area" style="margin-top:10px">
    <div class="sign-block">
        <div class="sign-title">施工人員</div>
        <div>簽名：<div class="sign-line"></div></div>
    </div>
    <div class="sign-block">
        <div class="sign-title">完工日期</div>
        <div>簽名：<div class="sign-line"></div></div>
    </div>
</div>

<div class="line-id">官方LINE ID : @hs0425347007</div>

</body>
</html>
