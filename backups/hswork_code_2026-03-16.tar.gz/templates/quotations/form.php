<?php
$isEdit = !empty($quote);
$fmt = $isEdit ? $quote['format'] : 'simple';
$sections = $isEdit ? $quote['sections'] : array(array('title' => '', 'items' => array(array())));
?>
<h2><?= $isEdit ? '編輯報價單 - ' . e($quote['quotation_number']) : '新增報價單' ?></h2>

<form method="POST" class="mt-2" id="quoteForm">
    <?= csrf_field() ?>

    <!-- 客戶資訊 -->
    <div class="card">
        <div class="card-header">客戶資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>客戶名稱 *</label>
                <input type="text" name="customer_name" class="form-control" value="<?= e($quote['customer_name'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label>連絡對象</label>
                <input type="text" name="contact_person" class="form-control" value="<?= e($quote['contact_person'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>連絡電話</label>
                <input type="text" name="contact_phone" class="form-control" value="<?= e($quote['contact_phone'] ?? '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>案場名稱</label>
                <input type="text" name="site_name" class="form-control" value="<?= e($quote['site_name'] ?? '') ?>">
            </div>
            <div class="form-group" style="flex:2">
                <label>施工地址</label>
                <input type="text" name="site_address" class="form-control" value="<?= e($quote['site_address'] ?? '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>發票抬頭</label>
                <input type="text" name="invoice_title" class="form-control" value="<?= e($quote['invoice_title'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>統編</label>
                <input type="text" name="invoice_tax_id" class="form-control" value="<?= e($quote['invoice_tax_id'] ?? '') ?>">
            </div>
        </div>
    </div>

    <!-- 報價資訊 -->
    <div class="card">
        <div class="card-header">報價資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>報價日期 *</label>
                <input type="date" name="quote_date" class="form-control" value="<?= e($quote['quote_date'] ?? date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>有效日期 *</label>
                <input type="date" name="valid_date" class="form-control" value="<?= e($quote['valid_date'] ?? date('Y-m-d', strtotime('+30 days'))) ?>" required>
            </div>
            <div class="form-group">
                <label>承辦業務</label>
                <select name="sales_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($salespeople as $sp): ?>
                    <option value="<?= $sp['id'] ?>" <?= ($quote['sales_id'] ?? Auth::id()) == $sp['id'] ? 'selected' : '' ?>><?= e($sp['real_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>關聯案件</label>
                <select name="case_id" class="form-control">
                    <option value="">不關聯</option>
                    <?php foreach ($cases as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= ($quote['case_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= e($c['case_number'] . ' ' . $c['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>據點</label>
                <select name="branch_id" class="form-control" required>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= ($quote['branch_id'] ?? (Session::getUser()['branch_id'] ?? '')) == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>報價格式 *</label>
                <div class="d-flex gap-2 mt-1">
                    <label class="checkbox-label"><input type="radio" name="format" value="simple" <?= $fmt === 'simple' ? 'checked' : '' ?> onchange="toggleFormat(this.value)"> 普銷</label>
                    <label class="checkbox-label"><input type="radio" name="format" value="project" <?= $fmt === 'project' ? 'checked' : '' ?> onchange="toggleFormat(this.value)"> 專案</label>
                </div>
            </div>
        </div>
    </div>

    <!-- 報價內容 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>報價內容</span>
            <button type="button" class="btn btn-outline btn-sm" id="btnAddSection" onclick="addSection()" style="<?= $fmt === 'simple' ? 'display:none' : '' ?>">+ 新增區段</button>
        </div>
        <div id="sectionsContainer">
            <?php foreach ($sections as $sIdx => $sec): ?>
            <div class="quote-section" data-sidx="<?= $sIdx ?>">
                <div class="quote-section-header" style="<?= $fmt === 'simple' ? 'display:none' : '' ?>">
                    <input type="text" name="sections[<?= $sIdx ?>][title]" class="form-control" placeholder="區段標題（如：電話線工程）" value="<?= e($sec['title'] ?? '') ?>">
                    <button type="button" class="btn btn-danger btn-sm" onclick="removeSection(this)" title="刪除區段">&times;</button>
                </div>
                <div class="table-responsive">
                    <table class="table quote-items-table">
                        <thead><tr>
                            <th style="width:30px">序</th>
                            <th style="min-width:200px">品名/型號</th>
                            <th style="width:80px">數量</th>
                            <th style="width:60px">單位</th>
                            <th style="width:100px">單價</th>
                            <th style="width:100px">小計</th>
                            <th style="width:120px">備註</th>
                            <?php if ($canManage): ?><th style="width:90px">成本</th><?php endif; ?>
                            <th style="width:40px"></th>
                        </tr></thead>
                        <tbody>
                            <?php
                            $items = isset($sec['items']) ? $sec['items'] : array(array());
                            foreach ($items as $iIdx => $item):
                            ?>
                            <tr>
                                <td class="row-num"><?= $iIdx + 1 ?></td>
                                <td style="position:relative">
                                    <input type="hidden" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][product_id]" value="<?= e($item['product_id'] ?? '') ?>">
                                    <input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][item_name]" class="form-control item-name" value="<?= e($item['item_name'] ?? '') ?>" placeholder="輸入搜尋產品..." autocomplete="off" oninput="searchProduct(this)" onfocus="searchProduct(this)">
                                    <div class="product-dropdown"></div>
                                </td>
                                <td><input type="number" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][quantity]" class="form-control item-qty" value="<?= e($item['quantity'] ?? 1) ?>" step="0.01" min="0" oninput="calcRow(this)"></td>
                                <td><input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][unit]" class="form-control item-unit" value="<?= e($item['unit'] ?? '式') ?>"></td>
                                <td><input type="number" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][unit_price]" class="form-control item-price" value="<?= e($item['unit_price'] ?? 0) ?>" oninput="calcRow(this)"></td>
                                <td class="item-amount text-right"><?= number_format((float)($item['quantity'] ?? 1) * (float)($item['unit_price'] ?? 0)) ?></td>
                                <td><input type="text" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][remark]" class="form-control" value="<?= e($item['remark'] ?? '') ?>"></td>
                                <?php if ($canManage): ?>
                                <td><input type="number" name="sections[<?= $sIdx ?>][items][<?= $iIdx ?>][unit_cost]" class="form-control item-cost" value="<?= e($item['unit_cost'] ?? 0) ?>"></td>
                                <?php endif; ?>
                                <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">&times;</button></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5" class="text-right"><strong>小計</strong></td>
                                <td class="section-subtotal text-right"><strong>0</strong></td>
                                <td colspan="<?= $canManage ? 3 : 2 ?>">
                                    <button type="button" class="btn btn-outline btn-sm" onclick="addItem(this)">+ 新增項目</button>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- 總計 -->
        <div class="quote-totals">
            <div class="quote-total-row">
                <span>未稅合計：</span>
                <strong id="grandSubtotal">$0</strong>
            </div>
            <div class="quote-total-row">
                <span>營業稅 (5%)：</span>
                <strong id="grandTax">$0</strong>
            </div>
            <div class="quote-total-row quote-total-grand">
                <span>合計新台幣：</span>
                <strong id="grandTotal">$0</strong>
            </div>
        </div>
    </div>

    <!-- 內部成本（僅管理者可見） -->
    <?php if ($canManage): ?>
    <div class="card">
        <div class="card-header">內部成本分析（不顯示在報價單）</div>
        <div class="form-row">
            <div class="form-group">
                <label>施工天數</label>
                <input type="number" name="labor_days" class="form-control" value="<?= e($quote['labor_days'] ?? '') ?>" step="0.5" min="0">
            </div>
            <div class="form-group">
                <label>施工人數</label>
                <input type="number" name="labor_people" class="form-control" value="<?= e($quote['labor_people'] ?? '') ?>" min="0">
            </div>
            <div class="form-group">
                <label>施工時數</label>
                <input type="number" name="labor_hours" class="form-control" value="<?= e($quote['labor_hours'] ?? '') ?>" step="0.5" min="0">
            </div>
            <div class="form-group">
                <label>人力成本</label>
                <input type="number" name="labor_cost_total" id="laborCostTotal" class="form-control" value="<?= e($quote['labor_cost_total'] ?? '') ?>" min="0">
            </div>
        </div>
        <div class="form-row" style="background:#f8f9fa;padding:8px;border-radius:6px">
            <div class="form-group">
                <label>器材總成本</label>
                <div id="materialCost" style="font-weight:600;font-size:1.1rem">$0</div>
            </div>
            <div class="form-group">
                <label>利潤金額</label>
                <div id="profitAmount" style="font-weight:600;font-size:1.1rem">$0</div>
            </div>
            <div class="form-group">
                <label>利潤率</label>
                <div id="profitRate" style="font-weight:600;font-size:1.1rem">0%</div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- 附加資訊 -->
    <div class="card">
        <div class="card-header">附加資訊</div>
        <div class="form-group">
            <label>收款條件</label>
            <textarea name="payment_terms" class="form-control" rows="2"><?= e($quote['payment_terms'] ?? '30%定金 70% 完工當日付現或當日匯款') ?></textarea>
        </div>
        <div class="form-group">
            <label>附註說明</label>
            <textarea name="notes" class="form-control" rows="2"><?= e($quote['notes'] ?? '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '建立報價單' ?></button>
        <a href="/quotations.php" class="btn btn-outline">取消</a>
    </div>
</form>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
.checkbox-label { display: flex; align-items: center; gap: 6px; cursor: pointer; }

.quote-section { border: 1px solid var(--gray-200); border-radius: 8px; margin-bottom: 12px; overflow: hidden; }
.quote-section-header { display: flex; gap: 8px; padding: 8px; background: var(--gray-100); }
.quote-section-header input { flex: 1; }
.quote-items-table { margin: 0; font-size: .85rem; }
.quote-items-table input { font-size: .85rem; padding: 4px 6px; }
.quote-items-table th { font-size: .75rem; padding: 6px 4px; white-space: nowrap; }
.quote-items-table td { padding: 4px; vertical-align: middle; }
.row-num { text-align: center; color: var(--gray-500); font-size: .8rem; }

.quote-totals { text-align: right; padding: 12px; border-top: 2px solid var(--gray-200); }
.quote-total-row { margin-bottom: 4px; font-size: .95rem; }
.quote-total-grand { font-size: 1.2rem; color: var(--primary); margin-top: 8px; }

.product-dropdown {
    position: absolute; top: 100%; left: 0; right: 0; z-index: 100;
    background: #fff; border: 1px solid var(--gray-300); border-radius: 6px;
    max-height: 200px; overflow-y: auto; display: none; box-shadow: var(--shadow);
}
.product-dropdown-item {
    padding: 6px 8px; cursor: pointer; font-size: .8rem; border-bottom: 1px solid var(--gray-100);
}
.product-dropdown-item:hover { background: var(--gray-100); }
.product-dropdown-item .product-meta { color: var(--gray-500); font-size: .7rem; }

@media (max-width: 768px) {
    .quote-items-table { font-size: .75rem; }
    .quote-items-table input { font-size: .75rem; }
}
</style>

<script>
var sectionIdx = <?= count($sections) ?>;
var canManage = <?= $canManage ? 'true' : 'false' ?>;
var searchTimer = null;

function toggleFormat(fmt) {
    var headers = document.querySelectorAll('.quote-section-header');
    var btn = document.getElementById('btnAddSection');
    for (var i = 0; i < headers.length; i++) {
        headers[i].style.display = fmt === 'project' ? 'flex' : 'none';
    }
    btn.style.display = fmt === 'project' ? '' : 'none';
}

function addSection() {
    var container = document.getElementById('sectionsContainer');
    var costTh = canManage ? '<th style="width:90px">成本</th>' : '';
    var costTd = canManage ? '<td><input type="number" name="sections[' + sectionIdx + '][items][0][unit_cost]" class="form-control item-cost" value="0"></td>' : '';
    var extraCols = canManage ? 3 : 2;

    var html = '<div class="quote-section" data-sidx="' + sectionIdx + '">' +
        '<div class="quote-section-header">' +
            '<input type="text" name="sections[' + sectionIdx + '][title]" class="form-control" placeholder="區段標題（如：電話線工程）">' +
            '<button type="button" class="btn btn-danger btn-sm" onclick="removeSection(this)">&times;</button>' +
        '</div>' +
        '<div class="table-responsive"><table class="table quote-items-table">' +
        '<thead><tr><th style="width:30px">序</th><th style="min-width:200px">品名/型號</th><th style="width:80px">數量</th><th style="width:60px">單位</th><th style="width:100px">單價</th><th style="width:100px">小計</th><th style="width:120px">備註</th>' + costTh + '<th style="width:40px"></th></tr></thead>' +
        '<tbody>' + buildItemRow(sectionIdx, 0) + '</tbody>' +
        '<tfoot><tr><td colspan="5" class="text-right"><strong>小計</strong></td><td class="section-subtotal text-right"><strong>0</strong></td><td colspan="' + extraCols + '"><button type="button" class="btn btn-outline btn-sm" onclick="addItem(this)">+ 新增項目</button></td></tr></tfoot>' +
        '</table></div></div>';

    container.insertAdjacentHTML('beforeend', html);
    sectionIdx++;
    reindexAll();
    calcGrandTotal();
}

function removeSection(btn) {
    var section = btn.closest('.quote-section');
    if (document.querySelectorAll('.quote-section').length <= 1) {
        alert('至少需要一個區段');
        return;
    }
    section.remove();
    reindexAll();
    calcGrandTotal();
}

function addItem(btn) {
    var section = btn.closest('.quote-section');
    var tbody = section.querySelector('tbody');
    var sidx = section.getAttribute('data-sidx');
    var rows = tbody.querySelectorAll('tr');
    var iidx = rows.length;
    tbody.insertAdjacentHTML('beforeend', buildItemRow(sidx, iidx));
    reindexSection(section);
    calcSectionSubtotal(section);
}

function removeItem(btn) {
    var row = btn.closest('tr');
    var section = row.closest('.quote-section');
    var tbody = section.querySelector('tbody');
    if (tbody.querySelectorAll('tr').length <= 1) {
        // 清空而不是刪除最後一行
        var inputs = row.querySelectorAll('input');
        for (var i = 0; i < inputs.length; i++) {
            if (inputs[i].type === 'number') inputs[i].value = inputs[i].name.indexOf('quantity') !== -1 ? '1' : '0';
            else if (inputs[i].type !== 'hidden') inputs[i].value = '';
            else inputs[i].value = '';
        }
        calcRow(row.querySelector('.item-qty'));
        return;
    }
    row.remove();
    reindexSection(section);
    calcSectionSubtotal(section);
    calcGrandTotal();
}

function buildItemRow(sidx, iidx) {
    var costTd = canManage ? '<td><input type="number" name="sections[' + sidx + '][items][' + iidx + '][unit_cost]" class="form-control item-cost" value="0"></td>' : '';
    return '<tr>' +
        '<td class="row-num">' + (iidx + 1) + '</td>' +
        '<td style="position:relative">' +
            '<input type="hidden" name="sections[' + sidx + '][items][' + iidx + '][product_id]" value="">' +
            '<input type="text" name="sections[' + sidx + '][items][' + iidx + '][item_name]" class="form-control item-name" placeholder="輸入搜尋產品..." autocomplete="off" oninput="searchProduct(this)" onfocus="searchProduct(this)">' +
            '<div class="product-dropdown"></div>' +
        '</td>' +
        '<td><input type="number" name="sections[' + sidx + '][items][' + iidx + '][quantity]" class="form-control item-qty" value="1" step="0.01" min="0" oninput="calcRow(this)"></td>' +
        '<td><input type="text" name="sections[' + sidx + '][items][' + iidx + '][unit]" class="form-control item-unit" value="式"></td>' +
        '<td><input type="number" name="sections[' + sidx + '][items][' + iidx + '][unit_price]" class="form-control item-price" value="0" oninput="calcRow(this)"></td>' +
        '<td class="item-amount text-right">0</td>' +
        '<td><input type="text" name="sections[' + sidx + '][items][' + iidx + '][remark]" class="form-control"></td>' +
        costTd +
        '<td><button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">&times;</button></td>' +
    '</tr>';
}

function reindexAll() {
    var sections = document.querySelectorAll('.quote-section');
    for (var s = 0; s < sections.length; s++) {
        sections[s].setAttribute('data-sidx', s);
        // 更新 section title name
        var titleInput = sections[s].querySelector('.quote-section-header input');
        if (titleInput) titleInput.name = 'sections[' + s + '][title]';
        reindexSection(sections[s]);
    }
}

function reindexSection(section) {
    var sidx = section.getAttribute('data-sidx');
    var rows = section.querySelectorAll('tbody tr');
    for (var i = 0; i < rows.length; i++) {
        rows[i].querySelector('.row-num').textContent = i + 1;
        var inputs = rows[i].querySelectorAll('input');
        for (var j = 0; j < inputs.length; j++) {
            var name = inputs[j].name;
            if (name) {
                inputs[j].name = name.replace(/sections\[\d+\]\[items\]\[\d+\]/, 'sections[' + sidx + '][items][' + i + ']');
            }
        }
    }
}

function calcRow(el) {
    var row = el.closest('tr');
    var qty = parseFloat(row.querySelector('.item-qty').value) || 0;
    var price = parseFloat(row.querySelector('.item-price').value) || 0;
    var amount = Math.round(qty * price);
    row.querySelector('.item-amount').textContent = amount.toLocaleString();
    calcSectionSubtotal(row.closest('.quote-section'));
    calcGrandTotal();
}

function calcSectionSubtotal(section) {
    var rows = section.querySelectorAll('tbody tr');
    var subtotal = 0;
    for (var i = 0; i < rows.length; i++) {
        var qty = parseFloat(rows[i].querySelector('.item-qty').value) || 0;
        var price = parseFloat(rows[i].querySelector('.item-price').value) || 0;
        subtotal += Math.round(qty * price);
    }
    var el = section.querySelector('.section-subtotal strong');
    if (el) el.textContent = subtotal.toLocaleString();
}

function calcGrandTotal() {
    var sections = document.querySelectorAll('.quote-section');
    var grandSubtotal = 0;
    var grandCost = 0;
    for (var s = 0; s < sections.length; s++) {
        var rows = sections[s].querySelectorAll('tbody tr');
        for (var i = 0; i < rows.length; i++) {
            var qty = parseFloat(rows[i].querySelector('.item-qty').value) || 0;
            var price = parseFloat(rows[i].querySelector('.item-price').value) || 0;
            grandSubtotal += Math.round(qty * price);
            var costEl = rows[i].querySelector('.item-cost');
            if (costEl) {
                grandCost += Math.round(qty * (parseFloat(costEl.value) || 0));
            }
        }
    }
    var tax = Math.round(grandSubtotal * 0.05);
    var total = grandSubtotal + tax;
    document.getElementById('grandSubtotal').textContent = '$' + grandSubtotal.toLocaleString();
    document.getElementById('grandTax').textContent = '$' + tax.toLocaleString();
    document.getElementById('grandTotal').textContent = '$' + total.toLocaleString();

    // 內部成本計算
    if (canManage) {
        var laborCost = parseFloat(document.getElementById('laborCostTotal').value) || 0;
        var totalCost = grandCost + laborCost;
        var profit = grandSubtotal - totalCost;
        var profitPct = grandSubtotal > 0 ? (profit / grandSubtotal * 100).toFixed(1) : 0;
        document.getElementById('materialCost').textContent = '$' + grandCost.toLocaleString();
        document.getElementById('profitAmount').textContent = '$' + profit.toLocaleString();
        document.getElementById('profitRate').textContent = profitPct + '%';
        document.getElementById('profitAmount').style.color = profit >= 0 ? '#137333' : '#c5221f';
    }
}

// 產品搜尋
function searchProduct(input) {
    clearTimeout(searchTimer);
    var keyword = input.value.trim();
    var dropdown = input.parentElement.querySelector('.product-dropdown');
    if (keyword.length < 1) { dropdown.style.display = 'none'; return; }
    searchTimer = setTimeout(function() {
        fetch('/quotations.php?action=ajax_products&keyword=' + encodeURIComponent(keyword))
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data.length) { dropdown.style.display = 'none'; return; }
            var html = '';
            for (var i = 0; i < data.length; i++) {
                html += '<div class="product-dropdown-item" onclick="selectProduct(this)" ' +
                    'data-id="' + data[i].id + '" ' +
                    'data-name="' + escHtml(data[i].name + (data[i].model_number ? ' ' + data[i].model_number : '')) + '" ' +
                    'data-unit="' + escHtml(data[i].unit || '式') + '" ' +
                    'data-price="' + (data[i].price || 0) + '" ' +
                    'data-cost="' + (data[i].cost || 0) + '">' +
                    '<div>' + escHtml(data[i].name) + '</div>' +
                    '<div class="product-meta">' + escHtml(data[i].model_number || '') + ' | $' + Number(data[i].price || 0).toLocaleString() + '/' + escHtml(data[i].unit || '式') + '</div>' +
                '</div>';
            }
            dropdown.innerHTML = html;
            dropdown.style.display = 'block';
        });
    }, 300);
}

function selectProduct(el) {
    var row = el.closest('tr');
    row.querySelector('input[name*="product_id"]').value = el.getAttribute('data-id');
    row.querySelector('.item-name').value = el.getAttribute('data-name');
    row.querySelector('.item-unit').value = el.getAttribute('data-unit');
    row.querySelector('.item-price').value = el.getAttribute('data-price');
    var costInput = row.querySelector('.item-cost');
    if (costInput) costInput.value = el.getAttribute('data-cost');
    el.closest('.product-dropdown').style.display = 'none';
    calcRow(row.querySelector('.item-qty'));
}

function escHtml(s) {
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(s));
    return div.innerHTML;
}

// 關閉下拉
document.addEventListener('click', function(e) {
    if (!e.target.classList.contains('item-name')) {
        var dd = document.querySelectorAll('.product-dropdown');
        for (var i = 0; i < dd.length; i++) dd[i].style.display = 'none';
    }
});

// 人力成本輸入時重算
if (document.getElementById('laborCostTotal')) {
    document.getElementById('laborCostTotal').addEventListener('input', calcGrandTotal);
}

// 初始計算
document.addEventListener('DOMContentLoaded', function() {
    var sections = document.querySelectorAll('.quote-section');
    for (var i = 0; i < sections.length; i++) calcSectionSubtotal(sections[i]);
    calcGrandTotal();
});
</script>
