<h2><?= $case ? '編輯案件 - ' . e($case['case_number']) : '新增案件' ?></h2>

<form method="POST" class="mt-2">
    <?= csrf_field() ?>

    <!-- 基本資料 -->
    <div class="card">
        <div class="card-header">基本資料</div>
        <div class="form-row">
            <div class="form-group">
                <label>據點 *</label>
                <select name="branch_id" class="form-control" required>
                    <option value="">請選擇</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= ($case['branch_id'] ?? '') == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>案件名稱 *</label>
                <input type="text" name="title" class="form-control" value="<?= e($case['title'] ?? '') ?>" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>案件類型</label>
                <select name="case_type" class="form-control">
                    <?php foreach (['new_install'=>'新裝','maintenance'=>'保養','repair'=>'維修','inspection'=>'勘查','other'=>'其他'] as $v => $l): ?>
                    <option value="<?= $v ?>" <?= ($case['case_type'] ?? '') === $v ? 'selected' : '' ?>><?= $l ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <?php foreach (['pending'=>'待處理','ready'=>'可排工','scheduled'=>'已排工','in_progress'=>'施工中','completed'=>'已完工','cancelled'=>'已取消'] as $v => $l): ?>
                    <option value="<?= $v ?>" <?= ($case['status'] ?? 'pending') === $v ? 'selected' : '' ?>><?= $l ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>難易度</label>
                <select name="difficulty" class="form-control">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                    <option value="<?= $i ?>" <?= ($case['difficulty'] ?? 3) == $i ? 'selected' : '' ?>><?= $i ?> 星</option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>預估工時 (小時)</label>
                <input type="number" name="estimated_hours" class="form-control" step="0.5" min="0" value="<?= e($case['estimated_hours'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>預估施工次數</label>
                <input type="number" name="total_visits" class="form-control" min="1" value="<?= e($case['total_visits'] ?? 1) ?>">
            </div>
            <div class="form-group">
                <label>最多施工人數</label>
                <input type="number" name="max_engineers" class="form-control" min="1" max="10" value="<?= e($case['max_engineers'] ?? 4) ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>施工地址</label>
                <input type="text" name="address" class="form-control" value="<?= e($case['address'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>業務負責人</label>
                <select name="sales_id" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach ($salesUsers as $u): ?>
                    <option value="<?= $u['id'] ?>" <?= ($case['sales_id'] ?? '') == $u['id'] ? 'selected' : '' ?>><?= e($u['real_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>案件說明</label>
            <textarea name="description" class="form-control" rows="3"><?= e($case['description'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
            <label>Ragic ID</label>
            <input type="text" name="ragic_id" class="form-control" value="<?= e($case['ragic_id'] ?? '') ?>" placeholder="選填，用於同步">
        </div>
    </div>

    <!-- 施工時程與條件 -->
    <div class="card">
        <div class="card-header">施工時程與條件</div>
        <div class="form-row">
            <div class="form-group">
                <label>預計施工日</label>
                <input type="date" name="planned_start_date" class="form-control" value="<?= e($case['planned_start_date'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>預計完工日</label>
                <input type="date" name="planned_end_date" class="form-control" value="<?= e($case['planned_end_date'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>急迫性</label>
                <select name="urgency" class="form-control">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                    <option value="<?= $i ?>" <?= ($case['urgency'] ?? 3) == $i ? 'selected' : '' ?>><?= $i ?> <?= $i <= 2 ? '(低)' : ($i >= 4 ? '(高)' : '(中)') ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>施工時間起</label>
                <input type="time" name="work_time_start" class="form-control" value="<?= e($case['work_time_start'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>施工時間迄</label>
                <input type="time" name="work_time_end" class="form-control" value="<?= e($case['work_time_end'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>客戶休息時間</label>
                <input type="text" name="customer_break_time" class="form-control" value="<?= e($case['customer_break_time'] ?? '') ?>" placeholder="如: 12:00-13:00">
            </div>
        </div>
        <div class="checkbox-row mt-1">
            <label class="checkbox-label">
                <input type="hidden" name="has_time_restriction" value="0">
                <input type="checkbox" name="has_time_restriction" value="1" <?= !empty($case['has_time_restriction']) ? 'checked' : '' ?>>
                <span>有施工時間限制</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="allow_night_work" value="0">
                <input type="checkbox" name="allow_night_work" value="1" <?= !empty($case['allow_night_work']) ? 'checked' : '' ?>>
                <span>可夜間加班</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="is_flexible" value="0">
                <input type="checkbox" name="is_flexible" value="1" <?= !empty($case['is_flexible']) ? 'checked' : '' ?>>
                <span>可隨時安排</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="is_large_project" value="0">
                <input type="checkbox" name="is_large_project" value="1" <?= !empty($case['is_large_project']) ? 'checked' : '' ?>>
                <span>大型案件</span>
            </label>
        </div>
    </div>

    <!-- 附件上傳 -->
    <?php if ($case): ?>
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>附件管理</span>
        </div>
        <div class="form-row mb-1">
            <div class="form-group">
                <label>檔案類型</label>
                <select id="attachType" class="form-control">
                    <option value="drawing">施工圖</option>
                    <option value="quotation">報價單</option>
                    <option value="warranty">保固書</option>
                    <option value="wire_plan">預計使用線材</option>
                    <option value="site_photo">現場照片</option>
                    <option value="other">其他</option>
                </select>
            </div>
            <div class="form-group" style="flex:2">
                <label>選擇檔案</label>
                <input type="file" id="attachFile" class="form-control" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx">
            </div>
            <div class="form-group" style="align-self:flex-end;flex:0">
                <button type="button" class="btn btn-primary btn-sm" onclick="uploadAttachment()">上傳</button>
            </div>
        </div>
        <div id="attachmentList">
            <?php if (!empty($case['attachments'])): ?>
            <?php foreach ($case['attachments'] as $att): ?>
            <div class="attachment-item" id="att-<?= $att['id'] ?>">
                <span class="badge badge-info" style="font-size:.7rem"><?= e($att['file_type']) ?></span>
                <a href="<?= e($att['file_path']) ?>" target="_blank"><?= e($att['file_name']) ?></a>
                <span class="text-muted" style="font-size:.75rem"><?= e($att['uploader_name'] ?? '') ?></span>
                <button type="button" class="btn btn-danger btn-sm" style="padding:2px 6px;font-size:.7rem" onclick="deleteAttachment(<?= $att['id'] ?>)">X</button>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 排工條件驗證 -->
    <div class="card">
        <div class="card-header">排工條件驗證</div>
        <p class="text-muted mb-1" style="font-size:.85rem">缺少的項目將在案件列表中顯示警示</p>
        <?php $rd = $case['readiness'] ?? []; ?>
        <div class="checkbox-row">
            <label class="checkbox-label">
                <input type="hidden" name="has_quotation" value="0">
                <input type="checkbox" name="has_quotation" value="1" <?= !empty($rd['has_quotation']) ? 'checked' : '' ?>>
                <span>已有報價單</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="has_site_photos" value="0">
                <input type="checkbox" name="has_site_photos" value="1" <?= !empty($rd['has_site_photos']) ? 'checked' : '' ?>>
                <span>已有現場照片</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="has_amount_confirmed" value="0">
                <input type="checkbox" name="has_amount_confirmed" value="1" <?= !empty($rd['has_amount_confirmed']) ? 'checked' : '' ?>>
                <span>金額已確認</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="has_site_info" value="0">
                <input type="checkbox" name="has_site_info" value="1" <?= !empty($rd['has_site_info']) ? 'checked' : '' ?>>
                <span>現場資料已備齊</span>
            </label>
        </div>
        <div class="form-group mt-1">
            <label>備註</label>
            <textarea name="readiness_notes" class="form-control" rows="2"><?= e($rd['notes'] ?? '') ?></textarea>
        </div>
    </div>

    <!-- 現場環境 -->
    <div class="card">
        <div class="card-header">現場環境</div>
        <?php $sc = $case['site_conditions'] ?? []; ?>
        <div class="form-group">
            <label>建築結構 (可複選)</label>
            <div class="checkbox-row">
                <?php
                $structures = ['RC'=>'RC結構', 'steel_sheet'=>'鐵皮', 'open_area'=>'空曠地', 'construction_site'=>'建築工地'];
                $currentStructures = isset($sc['structure_type']) ? explode(',', $sc['structure_type']) : [];
                foreach ($structures as $v => $l):
                ?>
                <label class="checkbox-label">
                    <input type="checkbox" name="structure_type[]" value="<?= $v ?>" <?= in_array($v, $currentStructures) ? 'checked' : '' ?>>
                    <span><?= $l ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="form-group">
            <label>管線需求 (可複選)</label>
            <div class="checkbox-row">
                <?php
                $conduits = ['PVC'=>'PVC', 'EMT'=>'EMT', 'RSG'=>'RSG', 'molding'=>'壓條', 'wall_penetration'=>'穿牆', 'aerial'=>'架空', 'underground'=>'切地埋管'];
                $currentConduits = isset($sc['conduit_type']) ? explode(',', $sc['conduit_type']) : [];
                foreach ($conduits as $v => $l):
                ?>
                <label class="checkbox-label">
                    <input type="checkbox" name="conduit_type[]" value="<?= $v ?>" <?= in_array($v, $currentConduits) ? 'checked' : '' ?>>
                    <span><?= $l ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>樓層數</label>
                <input type="number" name="floor_count" class="form-control" min="0" value="<?= e($sc['floor_count'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <div class="checkbox-row">
                    <label class="checkbox-label">
                        <input type="checkbox" name="has_elevator" value="1" <?= !empty($sc['has_elevator']) ? 'checked' : '' ?>>
                        <span>有電梯</span>
                    </label>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label>特殊設備需求</label>
            <div class="equip-group">
                <!-- 拉梯 -->
                <div class="equip-item">
                    <label class="checkbox-label">
                        <input type="hidden" name="has_ladder_needed" value="0">
                        <input type="checkbox" name="has_ladder_needed" value="1" id="chkLadder" <?= !empty($sc['has_ladder_needed']) ? 'checked' : '' ?> onchange="toggleLadderSize()">
                        <span>拉梯</span>
                    </label>
                    <div id="ladderSizeWrap" style="display:<?= !empty($sc['has_ladder_needed']) ? 'flex' : 'none' ?>;align-items:center;gap:6px;margin-left:8px">
                        <?php
                        $ladderSizes = ['4'=>'4米','5'=>'5米','6'=>'6米','7'=>'7米','9'=>'9米'];
                        $currentLadder = $sc['ladder_size'] ?? '';
                        foreach ($ladderSizes as $lv => $ll):
                        ?>
                        <label class="checkbox-label">
                            <input type="radio" name="ladder_size" value="<?= $lv ?>" <?= $currentLadder == $lv ? 'checked' : '' ?>>
                            <span><?= $ll ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <!-- 挑高場所 -->
                <div class="equip-item">
                    <label class="checkbox-label">
                        <input type="checkbox" id="chkHighCeiling" <?= !empty($sc['high_ceiling_height']) ? 'checked' : '' ?> onchange="toggleHighCeiling()">
                        <span>挑高場所</span>
                    </label>
                    <div id="highCeilingWrap" style="display:<?= !empty($sc['high_ceiling_height']) ? 'inline-flex' : 'none' ?>;align-items:center;gap:4px;margin-left:8px">
                        <input type="text" name="high_ceiling_height" class="form-control" style="width:80px" value="<?= e($sc['high_ceiling_height'] ?? '') ?>" placeholder="高度">
                        <span>米</span>
                    </div>
                </div>
                <!-- 自走車 -->
                <div class="equip-item">
                    <label class="checkbox-label">
                        <input type="hidden" name="needs_scissor_lift" value="0">
                        <input type="checkbox" name="needs_scissor_lift" value="1" <?= !empty($sc['needs_scissor_lift']) ? 'checked' : '' ?>>
                        <span>自走車</span>
                    </label>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label>特殊需求</label>
            <textarea name="special_requirements" class="form-control" rows="2"><?= e($sc['special_requirements'] ?? '') ?></textarea>
        </div>
    </div>

    <!-- 聯絡人 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>聯絡人</span>
            <button type="button" class="btn btn-outline btn-sm" onclick="addContact()">+ 新增聯絡人</button>
        </div>
        <div id="contactsContainer">
            <?php
            $contacts = $case['contacts'] ?? [['contact_name'=>'','contact_phone'=>'','contact_role'=>'','contact_note'=>'']];
            foreach ($contacts as $idx => $c):
            ?>
            <div class="contact-row" data-index="<?= $idx ?>">
                <div class="form-row">
                    <div class="form-group">
                        <label>姓名</label>
                        <input type="text" name="contacts[<?= $idx ?>][contact_name]" class="form-control" value="<?= e($c['contact_name']) ?>">
                    </div>
                    <div class="form-group">
                        <label>電話</label>
                        <input type="text" name="contacts[<?= $idx ?>][contact_phone]" class="form-control" value="<?= e($c['contact_phone'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>角色</label>
                        <input type="text" name="contacts[<?= $idx ?>][contact_role]" class="form-control" value="<?= e($c['contact_role'] ?? '') ?>" placeholder="屋主/管委會/工地主任">
                    </div>
                    <div class="form-group" style="align-self:flex-end">
                        <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.contact-row').remove()">刪除</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- 所需技能 -->
    <div class="card">
        <div class="card-header">所需技能</div>
        <p class="text-muted mb-1" style="font-size:.85rem">勾選此案件需要的技能，並設定最低熟練度</p>
        <div class="skills-grid">
            <?php
            $reqSkills = [];
            if (!empty($case['required_skills'])) {
                foreach ($case['required_skills'] as $rs) {
                    $reqSkills[$rs['skill_id']] = $rs['min_proficiency'];
                }
            }
            $lastCat = '';
            foreach ($skills as $sk):
                if ($sk['category'] !== $lastCat):
                    $lastCat = $sk['category'];
            ?>
            <div class="skill-category"><?= e($sk['category']) ?></div>
            <?php endif; ?>
            <div class="skill-item">
                <label class="checkbox-label">
                    <input type="checkbox" class="skill-check" data-skill="<?= $sk['id'] ?>"
                           <?= isset($reqSkills[$sk['id']]) ? 'checked' : '' ?>
                           onchange="toggleSkillLevel(this)">
                    <span><?= e($sk['name']) ?></span>
                </label>
                <select name="required_skills[<?= $sk['id'] ?>]" class="form-control skill-level"
                        style="width:100px;display:<?= isset($reqSkills[$sk['id']]) ? 'inline-block' : 'none' ?>">
                    <option value="0">不需要</option>
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                    <option value="<?= $i ?>" <?= ($reqSkills[$sk['id']] ?? 0) == $i ? 'selected' : '' ?>><?= $i ?> 星以上</option>
                    <?php endfor; ?>
                </select>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $case ? '儲存變更' : '建立案件' ?></button>
        <a href="/cases.php" class="btn btn-outline">取消</a>
    </div>
</form>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
.checkbox-row { display: flex; flex-wrap: wrap; gap: 12px; }
.checkbox-label { display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: .9rem; }
.checkbox-label input[type="checkbox"] { width: 18px; height: 18px; }
.contact-row { border-bottom: 1px solid var(--gray-200); padding-bottom: 12px; margin-bottom: 12px; }
.skills-grid { display: flex; flex-direction: column; gap: 4px; }
.skill-category { font-weight: 600; color: var(--primary); margin-top: 12px; margin-bottom: 4px; padding-bottom: 4px; border-bottom: 1px solid var(--gray-200); }
.skill-item { display: flex; align-items: center; justify-content: space-between; padding: 4px 0; }
.skill-level { font-size: .85rem; }
.equip-group { display: flex; flex-direction: column; gap: 10px; }
.equip-item { display: flex; align-items: center; flex-wrap: wrap; }
.equip-item input[type="radio"] { width: 16px; height: 16px; }
.attachment-item {
    display: flex; align-items: center; gap: 8px; padding: 6px 10px;
    background: var(--gray-50); border-radius: var(--radius); margin-bottom: 6px;
    font-size: .9rem;
}
.attachment-item a { color: var(--primary); flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>

<script>
var contactIndex = <?= count($contacts) ?>;
function addContact() {
    var html = '<div class="contact-row" data-index="' + contactIndex + '">' +
        '<div class="form-row">' +
        '<div class="form-group"><label>姓名</label><input type="text" name="contacts[' + contactIndex + '][contact_name]" class="form-control"></div>' +
        '<div class="form-group"><label>電話</label><input type="text" name="contacts[' + contactIndex + '][contact_phone]" class="form-control"></div>' +
        '<div class="form-group"><label>角色</label><input type="text" name="contacts[' + contactIndex + '][contact_role]" class="form-control" placeholder="屋主/管委會/工地主任"></div>' +
        '<div class="form-group" style="align-self:flex-end"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest(\'.contact-row\').remove()">刪除</button></div>' +
        '</div></div>';
    document.getElementById('contactsContainer').insertAdjacentHTML('beforeend', html);
    contactIndex++;
}
function toggleLadderSize() {
    var wrap = document.getElementById('ladderSizeWrap');
    wrap.style.display = document.getElementById('chkLadder').checked ? 'flex' : 'none';
}
function toggleHighCeiling() {
    var wrap = document.getElementById('highCeilingWrap');
    wrap.style.display = document.getElementById('chkHighCeiling').checked ? 'inline-flex' : 'none';
    if (!document.getElementById('chkHighCeiling').checked) {
        wrap.querySelector('input[name="high_ceiling_height"]').value = '';
    }
}
function toggleSkillLevel(cb) {
    var sel = cb.closest('.skill-item').querySelector('.skill-level');
    if (cb.checked) {
        sel.style.display = 'inline-block';
        if (sel.value === '0') sel.value = '1';
    } else {
        sel.style.display = 'none';
        sel.value = '0';
    }
}
function uploadAttachment() {
    var fileInput = document.getElementById('attachFile');
    var typeSelect = document.getElementById('attachType');
    if (!fileInput.files.length) { alert('請選擇檔案'); return; }
    var file = fileInput.files[0];
    if (file.size > 20 * 1024 * 1024) { alert('檔案不可超過 20MB'); return; }
    var fd = new FormData();
    fd.append('file', file);
    fd.append('file_type', typeSelect.value);
    fd.append('csrf_token', document.querySelector('input[name="csrf_token"]').value);
    var btn = event.target;
    btn.disabled = true;
    btn.textContent = '上傳中...';
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/cases.php?action=upload_attachment&id=<?= $case ? $case['id'] : 0 ?>');
    xhr.onload = function() {
        btn.disabled = false;
        btn.textContent = '上傳';
        if (xhr.status === 200) {
            try {
                var res = JSON.parse(xhr.responseText);
                if (res.success) {
                    var typeLabels = {drawing:'施工圖',quotation:'報價單',warranty:'保固書',wire_plan:'線材',site_photo:'現場照片',other:'其他'};
                    var label = typeLabels[res.file_type] || res.file_type;
                    var html = '<div class="attachment-item" id="att-' + res.id + '">' +
                        '<span class="badge badge-info" style="font-size:.7rem">' + label + '</span>' +
                        '<a href="' + res.file_path + '" target="_blank">' + res.file_name + '</a>' +
                        '<button type="button" class="btn btn-danger btn-sm" style="padding:2px 6px;font-size:.7rem" onclick="deleteAttachment(' + res.id + ')">X</button>' +
                        '</div>';
                    document.getElementById('attachmentList').insertAdjacentHTML('beforeend', html);
                    fileInput.value = '';
                } else {
                    alert(res.error || '上傳失敗');
                }
            } catch(e) { alert('上傳失敗'); }
        } else { alert('上傳失敗 (' + xhr.status + ')'); }
    };
    xhr.onerror = function() { btn.disabled = false; btn.textContent = '上傳'; alert('網路錯誤'); };
    xhr.send(fd);
}
function deleteAttachment(id) {
    if (!confirm('確定刪除此附件?')) return;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/cases.php?action=delete_attachment');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var res = JSON.parse(xhr.responseText);
                if (res.success) {
                    var el = document.getElementById('att-' + id);
                    if (el) el.remove();
                } else { alert(res.error || '刪除失敗'); }
            } catch(e) { alert('刪除失敗'); }
        }
    };
    xhr.send('attachment_id=' + id + '&csrf_token=' + document.querySelector('input[name="csrf_token"]').value);
}
</script>
