<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>案件管理</h2>
    <?php if (Auth::hasPermission('cases.manage') || Auth::hasPermission('cases.own')): ?>
    <a href="/cases.php?action=create" class="btn btn-primary btn-sm">+ 新增案件</a>
    <?php endif; ?>
</div>

<!-- 快捷篩選按鈕 -->
<div class="filter-pills mb-1">
    <div class="pill-group">
        <span class="pill-label">狀態</span>
        <a href="/cases.php<?= $filters['case_type'] ? '?case_type=' . urlencode($filters['case_type']) : '' ?>" class="pill <?= empty($filters['status']) ? 'pill-active' : '' ?>">全部</a>
        <?php
        $statusList = array('pending'=>'待處理','ready'=>'可排工','scheduled'=>'已排工','in_progress'=>'施工中','completed'=>'已完工');
        foreach ($statusList as $sv => $sl):
            $qs = array('status' => $sv);
            if ($filters['case_type']) $qs['case_type'] = $filters['case_type'];
            if ($filters['keyword']) $qs['keyword'] = $filters['keyword'];
            if ($filters['branch_id']) $qs['branch_id'] = $filters['branch_id'];
        ?>
        <a href="/cases.php?<?= http_build_query($qs) ?>" class="pill <?= $filters['status'] === $sv ? 'pill-active' : '' ?>"><?= $sl ?></a>
        <?php endforeach; ?>
    </div>
    <div class="pill-group">
        <span class="pill-label">類型</span>
        <a href="/cases.php<?= $filters['status'] ? '?status=' . urlencode($filters['status']) : '' ?>" class="pill <?= empty($filters['case_type']) ? 'pill-active' : '' ?>">全部</a>
        <?php
        $typeList = array('new_install'=>'新裝','maintenance'=>'保養','repair'=>'維修','inspection'=>'勘查');
        foreach ($typeList as $tv => $tl):
            $qs2 = array('case_type' => $tv);
            if ($filters['status']) $qs2['status'] = $filters['status'];
            if ($filters['keyword']) $qs2['keyword'] = $filters['keyword'];
            if ($filters['branch_id']) $qs2['branch_id'] = $filters['branch_id'];
        ?>
        <a href="/cases.php?<?= http_build_query($qs2) ?>" class="pill <?= $filters['case_type'] === $tv ? 'pill-active' : '' ?>"><?= $tl ?></a>
        <?php endforeach; ?>
    </div>
</div>

<!-- 進階篩選 -->
<div class="card">
    <form method="GET" action="/cases.php" class="filter-form">
        <div class="filter-row">
            <div class="form-group" style="flex:2">
                <input type="text" name="keyword" class="form-control" value="<?= e($filters['keyword']) ?>" placeholder="搜尋案件名稱/編號/地址...">
            </div>
            <?php if (count($branches) > 1): ?>
            <div class="form-group">
                <select name="branch_id" class="form-control">
                    <option value="">全部據點</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= $filters['branch_id'] == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <?php if ($filters['status']): ?><input type="hidden" name="status" value="<?= e($filters['status']) ?>"><?php endif; ?>
            <?php if ($filters['case_type']): ?><input type="hidden" name="case_type" value="<?= e($filters['case_type']) ?>"><?php endif; ?>
            <div class="form-group" style="align-self:flex-end;flex:0">
                <button type="submit" class="btn btn-primary btn-sm">搜尋</button>
            </div>
        </div>
    </form>
</div>

<!-- 案件列表 -->
<div class="card">
    <?php if (empty($result['data'])): ?>
        <p class="text-muted text-center mt-2">目前無案件資料</p>
    <?php else: ?>

    <!-- 手機版卡片 -->
    <div class="case-cards show-mobile">
        <?php foreach ($result['data'] as $row): ?>
        <div class="case-card" onclick="location.href='/cases.php?action=view&id=<?= $row['id'] ?>'">
            <div class="d-flex justify-between align-center">
                <strong><?= e($row['case_number']) ?></strong>
                <span class="badge <?= CaseModel::statusBadge($row['status']) ?>"><?= e(CaseModel::statusLabel($row['status'])) ?></span>
            </div>
            <div class="case-card-title"><?= e($row['title']) ?></div>
            <div class="case-card-meta">
                <span><?= e($row['branch_name']) ?></span>
                <span><?= e(CaseModel::typeLabel($row['case_type'])) ?></span>
                <?php if ($row['sales_name']): ?><span>業務: <?= e($row['sales_name']) ?></span><?php endif; ?>
            </div>
            <?php
            $warnings = get_readiness_warnings($row);
            if (!empty($warnings)):
            ?>
            <div class="readiness-warnings">
                <?php foreach ($warnings as $w): ?>
                <span class="badge badge-warning"><?= e($w) ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- 桌面版表格 -->
    <div class="table-responsive hide-mobile">
        <table class="table">
            <thead>
                <tr>
                    <th>案件編號</th>
                    <th>名稱</th>
                    <th>據點</th>
                    <th>類型</th>
                    <th>狀態</th>
                    <th>難度</th>
                    <th>排工條件</th>
                    <th>業務</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($result['data'] as $row): ?>
                <tr>
                    <td><a href="/cases.php?action=view&id=<?= $row['id'] ?>"><?= e($row['case_number']) ?></a></td>
                    <td><?= e($row['title']) ?></td>
                    <td><?= e($row['branch_name']) ?></td>
                    <td><?= e(CaseModel::typeLabel($row['case_type'])) ?></td>
                    <td><span class="badge <?= CaseModel::statusBadge($row['status']) ?>"><?= e(CaseModel::statusLabel($row['status'])) ?></span></td>
                    <td><span class="stars"><?= str_repeat('&#9733;', $row['difficulty']) ?><?= str_repeat('&#9734;', 5 - $row['difficulty']) ?></span></td>
                    <td>
                        <?php
                        $warnings = get_readiness_warnings($row);
                        if (empty($warnings)): ?>
                            <span class="badge badge-success">已備齊</span>
                        <?php else: ?>
                            <?php foreach ($warnings as $w): ?>
                            <span class="badge badge-warning"><?= e($w) ?></span>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </td>
                    <td><?= e($row['sales_name'] ?? '-') ?></td>
                    <td>
                        <a href="/cases.php?action=edit&id=<?= $row['id'] ?>" class="btn btn-outline btn-sm">編輯</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- 分頁 -->
    <?php if ($result['lastPage'] > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $result['lastPage']; $i++): ?>
            <?php
            $qs = $_GET;
            $qs['page'] = $i;
            $url = '/cases.php?' . http_build_query($qs);
            ?>
            <a href="<?= $url ?>" class="btn btn-sm <?= $i === $result['page'] ? 'btn-primary' : 'btn-outline' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>

    <?php endif; ?>
</div>

<style>
.filter-pills { display: flex; flex-direction: column; gap: 8px; }
.pill-group { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.pill-label { font-size: .8rem; color: var(--gray-500); font-weight: 600; min-width: 32px; }
.pill {
    display: inline-block; padding: 4px 12px; border-radius: 16px; font-size: .8rem;
    background: var(--gray-100); color: var(--gray-700); text-decoration: none;
    transition: all .15s;
}
.pill:hover { background: var(--gray-200); }
.pill-active { background: var(--primary); color: #fff; }
.pill-active:hover { background: var(--primary); }
.filter-row { display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; }
.filter-row .form-group { flex: 1; min-width: 140px; margin-bottom: 0; }
.case-cards { display: flex; flex-direction: column; gap: 8px; }
.case-card {
    border: 1px solid var(--gray-200); border-radius: var(--radius);
    padding: 12px; cursor: pointer; transition: box-shadow .15s;
}
.case-card:hover { box-shadow: var(--shadow); }
.case-card-title { font-weight: 500; margin: 4px 0; }
.case-card-meta { font-size: .8rem; color: var(--gray-500); display: flex; gap: 8px; flex-wrap: wrap; }
.readiness-warnings { margin-top: 6px; display: flex; gap: 4px; flex-wrap: wrap; }
.pagination { display: flex; gap: 4px; justify-content: center; margin-top: 16px; flex-wrap: wrap; }
.show-mobile { display: flex; }
.hide-mobile { display: none; }
@media (min-width: 768px) {
    .show-mobile { display: none !important; }
    .hide-mobile { display: block !important; }
}
</style>
