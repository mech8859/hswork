<h2><?= $user ? '編輯人員 - ' . e($user['real_name']) : '新增人員' ?></h2>

<form method="POST" class="mt-2">
    <?= csrf_field() ?>

    <div class="card">
        <div class="card-header">帳號資料</div>
        <div class="form-row">
            <div class="form-group">
                <label>帳號 *</label>
                <?php if ($user): ?>
                    <input type="text" class="form-control" value="<?= e($user['username']) ?>" disabled>
                <?php else: ?>
                    <input type="text" name="username" class="form-control" value="<?= e($_POST['username'] ?? '') ?>" required>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label><?= $user ? '新密碼 (留空不修改)' : '密碼 *' ?></label>
                <div style="position:relative">
                    <input type="password" name="password" id="pwField" class="form-control" style="padding-right:40px" <?= $user ? '' : 'required' ?>>
                    <span onclick="togglePw()" id="pwEye" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);cursor:pointer;font-size:1.1rem;color:var(--gray-500);user-select:none">&#128065;</span>
                </div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>真實姓名 *</label>
                <input type="text" name="real_name" class="form-control" value="<?= e($user['real_name'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label>據點 *</label>
                <select name="branch_id" class="form-control" required>
                    <option value="">請選擇</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= ($user['branch_id'] ?? '') == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>角色 *</label>
                <select name="role" class="form-control" required>
                    <?php foreach ($appConfig['roles'] as $v => $l): ?>
                    <option value="<?= $v ?>" <?= ($user['role'] ?? '') === $v ? 'selected' : '' ?>><?= e($l) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>電話</label>
                <input type="text" name="phone" class="form-control" value="<?= e($user['phone'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?= e($user['email'] ?? '') ?>">
            </div>
        </div>
        <div class="checkbox-row mt-1">
            <label class="checkbox-label">
                <input type="hidden" name="is_engineer" value="0">
                <input type="checkbox" name="is_engineer" value="1" <?= !empty($user['is_engineer']) ? 'checked' : '' ?>>
                <span>工程師 (可排工)</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="is_mobile" value="0">
                <input type="checkbox" name="is_mobile" value="1" <?= ($user['is_mobile'] ?? 1) ? 'checked' : '' ?>>
                <span>手機介面</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="can_view_all_branches" value="0">
                <input type="checkbox" name="can_view_all_branches" value="1" <?= !empty($user['can_view_all_branches']) ? 'checked' : '' ?>>
                <span>可查看全區</span>
            </label>
        </div>
    </div>

    <div class="card">
        <div class="card-header">施工配合度</div>
        <div class="form-row">
            <div class="form-group">
                <label>假日施工配合度</label>
                <select name="holiday_availability" class="form-control">
                    <option value="high" <?= ($user['holiday_availability'] ?? 'medium') === 'high' ? 'selected' : '' ?>>高</option>
                    <option value="medium" <?= ($user['holiday_availability'] ?? 'medium') === 'medium' ? 'selected' : '' ?>>中</option>
                    <option value="low" <?= ($user['holiday_availability'] ?? 'medium') === 'low' ? 'selected' : '' ?>>低</option>
                </select>
            </div>
            <div class="form-group">
                <label>夜間施工配合度</label>
                <select name="night_availability" class="form-control">
                    <option value="high" <?= ($user['night_availability'] ?? 'medium') === 'high' ? 'selected' : '' ?>>高</option>
                    <option value="medium" <?= ($user['night_availability'] ?? 'medium') === 'medium' ? 'selected' : '' ?>>中</option>
                    <option value="low" <?= ($user['night_availability'] ?? 'medium') === 'low' ? 'selected' : '' ?>>低</option>
                </select>
            </div>
        </div>
    </div>

    <?php if (Auth::user()['role'] === 'boss' && $user): ?>
    <?php
    // 模組定義
    $allModules = array(
        'cases' => '案件管理',
        'schedule' => '工程行事曆',
        'repairs' => '維修單',
        'worklog' => '施工回報',
        'attendance' => '出勤狀況表',
        'products' => '產品目錄',
        'staff' => '人員管理',
        'vehicles' => '車輛管理',
        'leaves' => '請假管理',
        'inter_branch' => '點工費管理',
        'reports' => '報表',
        'quotations' => '報價管理',
    );

    // 該角色預設有哪些模組權限
    $rolePerms = isset($appConfig['permissions'][$user['role']]) ? $appConfig['permissions'][$user['role']] : array();
    $hasAll = in_array('all', $rolePerms);

    // 模組→權限選項（key => 中文標籤）
    $modulePermOptions = array(
        'cases' => array(
            'cases.manage' => '編輯管理',
            'cases.view' => '檢視',
            'cases.own' => '僅自己的',
            'cases.assist' => '協助',
        ),
        'schedule' => array(
            'schedule.manage' => '編輯管理',
            'schedule.view' => '檢視',
        ),
        'repairs' => array(
            'repairs.manage' => '編輯管理',
            'repairs.view' => '檢視',
            'repairs.own' => '僅自己的',
        ),
        'worklog' => array(
            'worklog.manage' => '編輯管理',
            'worklog.view' => '檢視',
        ),
        'attendance' => array(
            'attendance.view' => '檢視',
        ),
        'products' => array(
            'products.manage' => '編輯管理',
            'products.view' => '檢視',
        ),
        'staff' => array(
            'staff.manage' => '編輯管理',
            'staff.view' => '檢視',
        ),
        'vehicles' => array(
            'vehicles.manage' => '編輯管理',
            'vehicles.view' => '檢視',
        ),
        'leaves' => array(
            'leaves.manage' => '編輯管理',
            'leaves.view' => '檢視',
            'leaves.own' => '僅自己的',
        ),
        'inter_branch' => array(
            'inter_branch.manage' => '編輯管理',
            'inter_branch.view' => '檢視',
        ),
        'reports' => array(
            'reports.view' => '檢視',
        ),
        'quotations' => array(
            'quotations.manage' => '編輯管理',
            'quotations.view' => '檢視',
            'quotations.own' => '僅自己的',
        ),
    );

    // 找出角色預設擁有的權限等級
    $roleDefaultPerm = array();
    foreach ($allModules as $mod => $label) {
        $roleDefaultPerm[$mod] = 'off';
        if ($hasAll) {
            // boss/manager 預設最高權限
            $opts = array_keys($modulePermOptions[$mod]);
            $roleDefaultPerm[$mod] = $opts[0]; // manage 或最高的
        } else {
            // 找角色擁有的該模組權限（取第一個匹配的）
            foreach ($modulePermOptions[$mod] as $permKey => $permLabel) {
                if (in_array($permKey, $rolePerms)) {
                    $roleDefaultPerm[$mod] = $permKey;
                    break;
                }
            }
            // 特殊預設
            if ($roleDefaultPerm[$mod] === 'off') {
                if ($mod === 'products' || $mod === 'vehicles') {
                    $roleDefaultPerm[$mod] = $mod . '.view';
                } elseif ($mod === 'worklog' && !empty($user['is_engineer'])) {
                    $roleDefaultPerm[$mod] = 'worklog.view';
                } elseif ($mod === 'attendance' && count(array_intersect($rolePerms, array('schedule.manage', 'schedule.view'))) > 0) {
                    $roleDefaultPerm[$mod] = 'attendance.view';
                }
            }
        }
    }

    // 讀取已儲存的個人權限
    $customPerms = null;
    if (!empty($user['custom_permissions'])) {
        $customPerms = json_decode($user['custom_permissions'], true);
    }
    ?>
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>功能權限</span>
            <button type="button" class="btn btn-outline btn-sm" onclick="resetPermDefaults()">恢復角色預設</button>
        </div>
        <p class="text-muted" style="font-size:.8rem;padding:0 12px">設定每個模組的權限等級。選「關閉」則該人員看不到此模組。</p>
        <div class="perm-table">
            <?php foreach ($allModules as $mod => $label):
                $options = $modulePermOptions[$mod];
                $defaultVal = $roleDefaultPerm[$mod];
                // 有自訂就用自訂值
                if ($customPerms !== null && isset($customPerms[$mod])) {
                    $currentVal = $customPerms[$mod];
                    // 相容舊格式：true → 角色預設, false → off
                    if ($currentVal === true) { $currentVal = $defaultVal; }
                    elseif ($currentVal === false) { $currentVal = 'off'; }
                } else {
                    $currentVal = $defaultVal;
                }
            ?>
            <div class="perm-row">
                <span class="perm-label"><?= e($label) ?></span>
                <div class="perm-options">
                    <label class="perm-radio">
                        <input type="radio" name="perm_<?= $mod ?>" value="off"
                               data-default="<?= e($defaultVal) ?>"
                               <?= $currentVal === 'off' ? 'checked' : '' ?>>
                        <span class="perm-tag perm-off">關閉</span>
                    </label>
                    <?php foreach ($options as $permKey => $permLabel): ?>
                    <label class="perm-radio">
                        <input type="radio" name="perm_<?= $mod ?>" value="<?= e($permKey) ?>"
                               data-default="<?= e($defaultVal) ?>"
                               <?= $currentVal === $permKey ? 'checked' : '' ?>>
                        <span class="perm-tag perm-<?= strpos($permKey, '.manage') !== false ? 'manage' : (strpos($permKey, '.view') !== false ? 'view' : 'own') ?>"><?= e($permLabel) ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $user ? '儲存變更' : '建立人員' ?></button>
        <a href="/staff.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
function togglePw() {
    var f = document.getElementById('pwField');
    var e = document.getElementById('pwEye');
    if (f.type === 'password') { f.type = 'text'; e.style.opacity = '1'; }
    else { f.type = 'password'; e.style.opacity = '0.5'; }
}
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
.checkbox-row { display: flex; flex-wrap: wrap; gap: 16px; }
.checkbox-label { display: flex; align-items: center; gap: 6px; cursor: pointer; }
.checkbox-label input[type="checkbox"] { width: 18px; height: 18px; }
.perm-table { padding: 4px 12px; }
.perm-row { display: flex; align-items: center; padding: 8px 0; border-bottom: 1px solid var(--gray-200, #e5e7eb); }
.perm-row:last-child { border-bottom: none; }
.perm-label { font-weight: 600; min-width: 120px; font-size: .9rem; }
.perm-options { display: flex; flex-wrap: wrap; gap: 6px; }
.perm-radio { cursor: pointer; }
.perm-radio input[type="radio"] { display: none; }
.perm-tag { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: .8rem; border: 2px solid transparent; transition: all .15s; }
.perm-off { background: #f3f4f6; color: #6b7280; }
.perm-manage { background: #dbeafe; color: #1d4ed8; }
.perm-view { background: #d1fae5; color: #065f46; }
.perm-own { background: #fef3c7; color: #92400e; }
.perm-radio input[type="radio"]:checked + .perm-off { border-color: #6b7280; background: #e5e7eb; font-weight: 600; }
.perm-radio input[type="radio"]:checked + .perm-manage { border-color: #1d4ed8; font-weight: 600; }
.perm-radio input[type="radio"]:checked + .perm-view { border-color: #065f46; font-weight: 600; }
.perm-radio input[type="radio"]:checked + .perm-own { border-color: #92400e; font-weight: 600; }
@media (max-width: 600px) {
    .perm-row { flex-direction: column; align-items: flex-start; gap: 6px; }
    .perm-label { min-width: auto; }
}
</style>

<script>
function resetPermDefaults() {
    var radios = document.querySelectorAll('.perm-table input[type="radio"]');
    for (var i = 0; i < radios.length; i++) {
        var def = radios[i].getAttribute('data-default');
        radios[i].checked = (radios[i].value === def);
    }
}
</script>
