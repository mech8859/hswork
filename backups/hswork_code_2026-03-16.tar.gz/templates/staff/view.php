<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <div>
        <h2><?= e($user['real_name']) ?></h2>
        <span class="badge badge-primary"><?= e(role_name($user['role'])) ?></span>
        <span class="text-muted"><?= e($user['branch_name']) ?></span>
        <?php if ($user['is_engineer']): ?><span class="badge badge-success">工程師</span><?php endif; ?>
        <?php if (!$user['is_active']): ?><span class="badge badge-danger">已停用</span><?php endif; ?>
        <?php if (!empty($user['locked_until']) && strtotime($user['locked_until']) > time()): ?>
            <span class="badge badge-danger">已鎖定</span>
        <?php endif; ?>
    </div>
    <div class="d-flex gap-1 flex-wrap">
        <?php if (Auth::hasPermission('staff.manage')): ?>
        <a href="/staff.php?action=edit&id=<?= $user['id'] ?>" class="btn btn-primary btn-sm">編輯</a>
        <a href="/staff.php?action=reset_password&id=<?= $user['id'] ?>" class="btn btn-outline btn-sm">重設密碼</a>
        <a href="/staff.php?action=skills&id=<?= $user['id'] ?>" class="btn btn-outline btn-sm">技能設定</a>
        <?php if (!empty($user['locked_until']) && strtotime($user['locked_until']) > time()): ?>
        <a href="/staff.php?action=unlock&id=<?= $user['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>"
           class="btn btn-danger btn-sm" onclick="return confirm('確定解除此帳號的鎖定?')">解除鎖定</a>
        <?php endif; ?>
        <?php if ($user['id'] !== Auth::id()): ?>
        <a href="/staff.php?action=toggle&id=<?= $user['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>"
           class="btn <?= $user['is_active'] ? 'btn-danger' : 'btn-success' ?> btn-sm"
           onclick="return confirm('確定<?= $user['is_active'] ? '停用' : '啟用' ?>此帳號?')"><?= $user['is_active'] ? '停用帳號' : '啟用帳號' ?></a>
        <?php endif; ?>
        <?php endif; ?>
        <a href="/staff.php" class="btn btn-outline btn-sm">返回列表</a>
    </div>
</div>

<!-- 基本資料 -->
<div class="card">
    <div class="card-header">基本資料</div>
    <div class="detail-grid">
        <div class="detail-item"><span class="detail-label">帳號</span><span class="detail-value"><?= e($user['username']) ?></span></div>
        <?php if (Auth::user()['role'] === 'boss' && !empty($user['plain_password'])): ?>
        <div class="detail-item">
            <span class="detail-label">密碼</span>
            <span class="detail-value">
                <span id="pwdMask">••••••</span>
                <span id="pwdPlain" style="display:none"><?= e($user['plain_password']) ?></span>
                <button type="button" onclick="var m=document.getElementById('pwdMask'),p=document.getElementById('pwdPlain');if(m.style.display!=='none'){m.style.display='none';p.style.display='inline';this.textContent='🙈'}else{m.style.display='inline';p.style.display='none';this.textContent='👁'}" style="background:none;border:none;cursor:pointer;font-size:1rem;padding:0 4px">👁</button>
            </span>
        </div>
        <?php endif; ?>
        <div class="detail-item"><span class="detail-label">電話</span><span class="detail-value"><?= e($user['phone'] ?: '-') ?></span></div>
        <div class="detail-item"><span class="detail-label">Email</span><span class="detail-value"><?= e($user['email'] ?: '-') ?></span></div>
        <div class="detail-item"><span class="detail-label">最後登入</span><span class="detail-value"><?= format_datetime($user['last_login_at']) ?: '從未登入' ?></span></div>
        <div class="detail-item">
            <span class="detail-label">帳號狀態</span>
            <span class="detail-value">
                <?php if (!empty($user['locked_until']) && strtotime($user['locked_until']) > time()): ?>
                    <span class="text-danger">鎖定中 (至 <?= format_datetime($user['locked_until']) ?>，失敗 <?= (int)$user['failed_login_count'] ?> 次)</span>
                <?php elseif (($user['failed_login_count'] ?? 0) > 0): ?>
                    <span class="text-danger">已失敗 <?= (int)$user['failed_login_count'] ?> 次</span>
                <?php else: ?>
                    <span class="text-success">正常</span>
                <?php endif; ?>
            </span>
        </div>
    </div>
</div>

<?php if ($user['is_engineer']): ?>
<!-- 施工配合度 -->
<div class="card">
    <div class="card-header">施工配合度</div>
    <div class="detail-grid">
        <?php
        $avMap = ['high' => '高', 'medium' => '中', 'low' => '低'];
        $avColor = ['high' => 'text-success', 'medium' => '', 'low' => 'text-danger'];
        ?>
        <div class="detail-item">
            <span class="detail-label">假日施工配合度</span>
            <span class="detail-value <?= $avColor[$user['holiday_availability'] ?? 'medium'] ?>"><?= $avMap[$user['holiday_availability'] ?? 'medium'] ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">夜間施工配合度</span>
            <span class="detail-value <?= $avColor[$user['night_availability'] ?? 'medium'] ?>"><?= $avMap[$user['night_availability'] ?? 'medium'] ?></span>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- 技能 -->
<div class="card">
    <div class="card-header d-flex justify-between align-center">
        <span>技能</span>
        <?php if (Auth::hasPermission('staff.manage')): ?>
        <a href="/staff.php?action=skills&id=<?= $user['id'] ?>" class="btn btn-outline btn-sm">技能與配對設定</a>
        <?php endif; ?>
    </div>
    <?php if (empty($userSkills)): ?>
        <p class="text-muted">尚未設定技能</p>
    <?php else: ?>
    <div class="skills-display">
        <?php
        $lastGroup = '';
        $lastCat = '';
        foreach ($userSkills as $sk):
            $group = isset($sk['skill_group']) ? $sk['skill_group'] : '';
            if ($group && $group !== $lastGroup):
                $lastGroup = $group;
                $lastCat = '';
        ?>
        <div class="skill-group-label"><?= e($group) ?></div>
        <?php endif; ?>
        <?php
            if ($sk['category'] !== $lastCat):
                $lastCat = $sk['category'];
        ?>
        <div class="skill-category-label"><?= e($sk['category']) ?></div>
        <?php endif; ?>
        <div class="skill-display-item">
            <span><?= e($sk['skill_name']) ?></span>
            <span class="stars"><?= str_repeat('&#9733;', $sk['proficiency']) ?><?= str_repeat('&#9734;', 5 - $sk['proficiency']) ?></span>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- 證照 -->
<div class="card">
    <div class="card-header">證照 / 工作證</div>
    <?php if (!empty($userCerts)): ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>證照名稱</th><th>證號</th><th>發證日</th><th>到期日</th><th>操作</th></tr></thead>
            <tbody>
                <?php foreach ($userCerts as $uc): ?>
                <tr>
                    <td><?= e($uc['cert_name']) ?></td>
                    <td><?= e($uc['cert_number'] ?: '-') ?></td>
                    <td><?= format_date($uc['issue_date']) ?: '-' ?></td>
                    <td>
                        <?php if ($uc['expiry_date']): ?>
                            <span class="<?= $uc['is_expiring'] ? 'text-danger' : '' ?>">
                                <?= format_date($uc['expiry_date']) ?>
                                <?= $uc['is_expiring'] ? ' (即將到期!)' : '' ?>
                            </span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (Auth::hasPermission('staff.manage')): ?>
                        <a href="/staff.php?action=remove_cert&cert_id=<?= $uc['id'] ?>&user_id=<?= $user['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>"
                           class="btn btn-danger btn-sm" onclick="return confirm('確定刪除此證照記錄?')">刪除</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <p class="text-muted">尚無證照記錄</p>
    <?php endif; ?>

    <?php if (Auth::hasPermission('staff.manage')): ?>
    <div class="mt-2">
        <div class="card-header">新增證照</div>
        <form method="POST" action="/staff.php?action=add_cert" class="mt-1">
            <?= csrf_field() ?>
            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
            <div class="form-row">
                <div class="form-group">
                    <label>證照類型</label>
                    <select name="certification_id" class="form-control" required>
                        <option value="">請選擇</option>
                        <?php
                        $db = Database::getInstance();
                        $certTypes = $db->query('SELECT * FROM certifications WHERE is_active = 1 ORDER BY name')->fetchAll();
                        foreach ($certTypes as $ct):
                        ?>
                        <option value="<?= $ct['id'] ?>"><?= e($ct['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>證照號碼</label>
                    <input type="text" name="cert_number" class="form-control">
                </div>
                <div class="form-group">
                    <label>發證日期</label>
                    <input type="date" name="issue_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>到期日期</label>
                    <input type="date" name="expiry_date" class="form-control">
                </div>
                <div class="form-group" style="align-self:flex-end">
                    <button type="submit" class="btn btn-primary btn-sm">新增</button>
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<!-- 廠商上課證 -->
<div class="card">
    <div class="card-header">廠商上課證</div>
    <?php if (!empty($vendorTrainings)): ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>客戶/廠商</th><th>上課日期</th><th>有效期限</th><th>備註</th><th>操作</th></tr></thead>
            <tbody>
                <?php foreach ($vendorTrainings as $vt): ?>
                <tr>
                    <td><?= e($vt['vendor_name']) ?></td>
                    <td><?= format_date($vt['training_date']) ?: '-' ?></td>
                    <td>
                        <?php if ($vt['expiry_date']): ?>
                            <?php if ($vt['is_expired']): ?>
                                <span class="text-danger"><?= format_date($vt['expiry_date']) ?> (已過期)</span>
                            <?php elseif ($vt['is_expiring']): ?>
                                <span class="text-danger"><?= format_date($vt['expiry_date']) ?> (即將到期!)</span>
                            <?php else: ?>
                                <?= format_date($vt['expiry_date']) ?>
                            <?php endif; ?>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><?= e($vt['note'] ?: '-') ?></td>
                    <td>
                        <?php if (Auth::hasPermission('staff.manage')): ?>
                        <a href="/staff.php?action=remove_vendor_training&vt_id=<?= $vt['id'] ?>&user_id=<?= $user['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>"
                           class="btn btn-danger btn-sm" onclick="return confirm('確定刪除此上課證記錄?')">刪除</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <p class="text-muted">尚無廠商上課證記錄</p>
    <?php endif; ?>

    <?php if (Auth::hasPermission('staff.manage')): ?>
    <div class="mt-2">
        <div class="card-header">新增廠商上課證</div>
        <form method="POST" action="/staff.php?action=add_vendor_training" class="mt-1">
            <?= csrf_field() ?>
            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
            <div class="form-row">
                <div class="form-group">
                    <label>客戶/廠商名稱 *</label>
                    <input type="text" name="vendor_name" class="form-control" required placeholder="例：台積電">
                </div>
                <div class="form-group">
                    <label>上課日期</label>
                    <input type="date" name="training_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>有效期限</label>
                    <input type="date" name="expiry_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>備註</label>
                    <input type="text" name="note" class="form-control" placeholder="選填">
                </div>
                <div class="form-group" style="align-self:flex-end">
                    <button type="submit" class="btn btn-primary btn-sm">新增</button>
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<style>
.detail-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
.detail-item { display: flex; flex-direction: column; }
.detail-label { font-size: .8rem; color: var(--gray-500); }
.skills-display { display: flex; flex-direction: column; gap: 2px; }
.skill-group-label { font-weight: 700; color: var(--gray-900); margin-top: 12px; padding: 6px 0 2px; border-bottom: 2px solid var(--primary); font-size: .9rem; }
.skill-group-label:first-child { margin-top: 0; }
.skill-category-label { font-weight: 600; color: var(--primary); margin-top: 8px; font-size: .85rem; }
.skill-display-item { display: flex; justify-content: space-between; padding: 4px 0; font-size: .9rem; }
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 140px; }
@media (max-width: 767px) { .detail-grid { grid-template-columns: 1fr; } }
</style>
