<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2><?= e($user['real_name']) ?> - 技能設定</h2>
    <div class="d-flex gap-1">
        <?php if (Auth::hasPermission('staff.manage')): ?>
        <a href="/staff.php?action=manage_skills" class="btn btn-outline btn-sm">管理技能項目</a>
        <?php endif; ?>
        <a href="/staff.php?action=view&id=<?= $user['id'] ?>" class="btn btn-outline btn-sm">返回人員資料</a>
    </div>
</div>

<div class="skills-pairs-layout">
    <!-- 左側：技能設定 -->
    <div class="skills-section">
        <form method="POST">
            <?= csrf_field() ?>
            <div class="card">
                <div class="card-header">技能熟練度 (1-5星，0=不具備)</div>
                <div class="skills-form">
                    <?php
                    $lastGroup = '';
                    $lastCat = '';
                    foreach ($allSkills as $sk):
                        $group = $sk['skill_group'] ?: '其他';
                        if ($group !== $lastGroup):
                            $lastGroup = $group;
                            $lastCat = '';
                    ?>
                    <div class="skill-group-header"><?= e($group) ?></div>
                    <?php endif; ?>
                    <?php
                        if ($sk['category'] !== $lastCat):
                            $lastCat = $sk['category'];
                    ?>
                    <div class="skill-category-header"><?= e($sk['category']) ?></div>
                    <?php endif; ?>
                    <div class="skill-form-item">
                        <label><?= e($sk['name']) ?></label>
                        <div class="star-selector" data-skill="<?= $sk['id'] ?>">
                            <?php
                            $current = isset($userSkillMap[$sk['id']]) ? (int)$userSkillMap[$sk['id']] : 0;
                            for ($i = 1; $i <= 5; $i++):
                            ?>
                            <span class="star-btn <?= $i <= $current ? 'active' : '' ?>"
                                  data-value="<?= $i ?>"
                                  onclick="setStars(this)">&#9733;</span>
                            <?php endfor; ?>
                            <span class="star-clear" onclick="clearStars(this)">&times;</span>
                            <input type="hidden" name="skills[<?= $sk['id'] ?>]" value="<?= $current ?>">
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="d-flex gap-1 mt-2">
                <button type="submit" class="btn btn-primary">儲存技能</button>
                <a href="/staff.php?action=view&id=<?= $user['id'] ?>" class="btn btn-outline">取消</a>
            </div>
        </form>
    </div>

    <!-- 右側：配對設定 -->
    <?php if ($user['is_engineer']): ?>
    <div class="pairs-section">
        <div class="card">
            <div class="card-header">人員配對</div>

            <!-- 新增配對 -->
            <form method="POST" action="/staff.php?action=pairs" class="pair-form">
                <?= csrf_field() ?>
                <input type="hidden" name="user_a_id" value="<?= $user['id'] ?>">
                <div class="form-group">
                    <label>配對人員</label>
                    <select name="user_b_id" class="form-control" required>
                        <option value="">請選擇</option>
                        <?php foreach ($engineers as $eng): ?>
                            <?php if ($eng['id'] != $user['id']): ?>
                            <option value="<?= $eng['id'] ?>"><?= e($eng['real_name']) ?> (<?= e($eng['branch_name']) ?>)</option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>配對度</label>
                    <select name="compatibility" class="form-control">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                        <option value="<?= $i ?>" <?= $i === 3 ? 'selected' : '' ?>><?= $i ?> 星</option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>備註</label>
                    <input type="text" name="note" class="form-control" placeholder="選填">
                </div>
                <button type="submit" class="btn btn-primary btn-sm btn-block">新增配對</button>
            </form>

            <!-- 現有配對 -->
            <?php if (!empty($userPairs)): ?>
            <div class="pair-list mt-2">
                <?php foreach ($userPairs as $p): ?>
                <div class="pair-item">
                    <div class="pair-info">
                        <span class="pair-name"><?= e($p['partner_name']) ?></span>
                        <span class="stars"><?= str_repeat('&#9733;', $p['compatibility']) ?><?= str_repeat('&#9734;', 5 - $p['compatibility']) ?></span>
                    </div>
                    <?php if ($p['note']): ?>
                    <div class="text-muted" style="font-size:.8rem"><?= e($p['note']) ?></div>
                    <?php endif; ?>
                    <a href="/staff.php?action=delete_pair&pair_id=<?= $p['id'] ?>&user_id=<?= $user['id'] ?>&return=skills&csrf_token=<?= e(Session::getCsrfToken()) ?>"
                       class="pair-delete" onclick="return confirm('確定刪除此配對?')" title="刪除">&times;</a>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p class="text-muted mt-1" style="font-size:.85rem">尚未設定配對</p>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.skills-pairs-layout { display: flex; gap: 20px; align-items: flex-start; }
.skills-section { flex: 1; min-width: 0; }
.pairs-section { width: 300px; flex-shrink: 0; position: sticky; top: 72px; }
.skills-form { max-width: 100%; }
.skill-group-header {
    font-weight: 700; font-size: 1rem; color: var(--gray-900);
    margin-top: 20px; padding: 8px 0 4px;
    border-bottom: 2px solid var(--primary);
}
.skill-group-header:first-child { margin-top: 0; }
.skill-category-header {
    font-weight: 600; color: var(--primary);
    margin-top: 12px; padding-bottom: 4px;
    border-bottom: 1px solid var(--gray-200);
    font-size: .9rem;
}
.skill-form-item {
    display: flex; justify-content: space-between; align-items: center;
    padding: 6px 0; border-bottom: 1px solid var(--gray-100);
}
.skill-form-item label { font-size: .85rem; flex: 1; }
.star-selector { display: flex; align-items: center; gap: 2px; flex-shrink: 0; }
.star-btn {
    font-size: 1.3rem; cursor: pointer; color: var(--gray-300);
    transition: color .1s; user-select: none;
}
.star-btn.active { color: var(--warning); }
.star-btn:hover { color: var(--warning); }
.star-clear {
    font-size: 1.1rem; cursor: pointer; color: var(--gray-500);
    margin-left: 6px; padding: 0 4px;
}
.star-clear:hover { color: var(--danger); }

/* 配對區 */
.pair-form { display: flex; flex-direction: column; gap: 8px; padding-top: 8px; }
.pair-form .form-group { margin-bottom: 0; }
.pair-form .form-group label { font-size: .8rem; }
.pair-list { display: flex; flex-direction: column; gap: 6px; }
.pair-item {
    border: 1px solid var(--gray-200); border-radius: var(--radius);
    padding: 8px 10px; position: relative;
}
.pair-info { display: flex; justify-content: space-between; align-items: center; }
.pair-name { font-weight: 500; font-size: .9rem; }
.pair-delete {
    position: absolute; top: 4px; right: 8px;
    color: var(--gray-500); font-size: 1.1rem; text-decoration: none;
}
.pair-delete:hover { color: var(--danger); text-decoration: none; }

@media (max-width: 767px) {
    .skills-pairs-layout { flex-direction: column; }
    .pairs-section { width: 100%; position: static; }
}
</style>

<script>
function setStars(el) {
    var value = parseInt(el.dataset.value);
    var container = el.closest('.star-selector');
    var input = container.querySelector('input[type="hidden"]');
    input.value = value;
    container.querySelectorAll('.star-btn').forEach(function(s) {
        s.classList.toggle('active', parseInt(s.dataset.value) <= value);
    });
}
function clearStars(el) {
    var container = el.closest('.star-selector');
    var input = container.querySelector('input[type="hidden"]');
    input.value = '0';
    container.querySelectorAll('.star-btn').forEach(function(s) {
        s.classList.remove('active');
    });
}
</script>
