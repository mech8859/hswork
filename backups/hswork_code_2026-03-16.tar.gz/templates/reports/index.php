<h2>報表與分析</h2>

<!-- 案件狀態彙總 -->
<div class="card">
    <div class="card-header">案件狀態總覽</div>
    <div class="stat-grid">
        <?php
        $statusMap = ['pending'=>'待排工','ready'=>'已備齊','scheduled'=>'已排工','in_progress'=>'施工中','completed'=>'已完工','cancelled'=>'已取消'];
        $statusColor = ['pending'=>'warning','ready'=>'info','scheduled'=>'primary','in_progress'=>'warning','completed'=>'success','cancelled'=>''];
        foreach ($caseSummary as $cs):
            $label = isset($statusMap[$cs['status']]) ? $statusMap[$cs['status']] : $cs['status'];
            $color = isset($statusColor[$cs['status']]) ? $statusColor[$cs['status']] : '';
        ?>
        <div class="stat-card">
            <div class="stat-number"><?= (int)$cs['cnt'] ?></div>
            <div class="stat-label"><?= e($label) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- 報表入口 -->
<div class="card">
    <div class="card-header">報表選擇</div>
    <div class="report-links">
        <a href="/reports.php?action=case_profit" class="report-link-card">
            <div class="report-icon">&#128200;</div>
            <div class="report-title">案件利潤分析</div>
            <div class="report-desc">收款金額 vs 人力成本統計</div>
        </a>
        <a href="/reports.php?action=staff_productivity" class="report-link-card">
            <div class="report-icon">&#128101;</div>
            <div class="report-title">員工產值統計</div>
            <div class="report-desc">每月施工案件數、工時統計</div>
        </a>
        <a href="/reports.php?action=inter_branch" class="report-link-card">
            <div class="report-icon">&#128176;</div>
            <div class="report-title">跨點點工費月結</div>
            <div class="report-desc">各據點互相支援費用明細</div>
        </a>
    </div>
</div>

<!-- 本月排工統計 -->
<div class="card">
    <div class="card-header">本月排工統計 (<?= date('Y年m月') ?>)</div>
    <?php if (empty($monthlyStats)): ?>
        <p class="text-muted text-center">本月尚無排工記錄</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>日期</th><th>排工數</th><th>出勤人次</th></tr></thead>
            <tbody>
                <?php foreach ($monthlyStats as $ms): ?>
                <tr>
                    <td><?= e($ms['schedule_date']) ?></td>
                    <td><?= (int)$ms['schedule_count'] ?></td>
                    <td><?= (int)$ms['engineer_count'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; }
.stat-card { text-align: center; padding: 16px 8px; border: 1px solid var(--gray-200); border-radius: var(--radius); }
.stat-number { font-size: 2rem; font-weight: 700; color: var(--primary); }
.stat-label { font-size: .85rem; color: var(--gray-500); margin-top: 4px; }
.report-links { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; }
.report-link-card {
    display: block; padding: 20px; border: 1px solid var(--gray-200);
    border-radius: var(--radius); text-decoration: none; color: inherit;
    transition: box-shadow .15s, border-color .15s;
}
.report-link-card:hover { box-shadow: var(--shadow); border-color: var(--primary); text-decoration: none; }
.report-icon { font-size: 2rem; margin-bottom: 8px; }
.report-title { font-weight: 600; font-size: 1rem; }
.report-desc { font-size: .8rem; color: var(--gray-500); margin-top: 4px; }
</style>
