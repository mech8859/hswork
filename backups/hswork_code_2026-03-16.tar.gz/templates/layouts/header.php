<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= e($pageTitle ?? '弱電工程排程系統') ?></title>
    <link rel="stylesheet" href="/css/style.css">
    <?php if (!empty($extraCss)): ?>
        <?php foreach ($extraCss as $css): ?>
            <link rel="stylesheet" href="<?= e($css) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
<?php if (Session::isLoggedIn()): ?>
<nav class="navbar">
    <div class="navbar-brand">
        <button class="menu-toggle" id="menuToggle" aria-label="選單">&#9776;</button>
        <span class="navbar-title">弱電排程</span>
    </div>
    <div class="navbar-user">
        <span class="user-branch"><?= e(Session::getUser()['branch_name'] ?? '') ?></span>
        <span class="user-name"><?= e(Session::getUser()['real_name'] ?? '') ?></span>
        <span class="user-role"><?= e(role_name(Session::getUser()['role'] ?? '')) ?></span>
    </div>
</nav>
<aside class="sidebar" id="sidebar">
    <ul class="nav-menu">
        <?php $cp = Session::get('custom_permissions'); ?>
        <li><a href="/index.php" class="<?= ($currentPage ?? '') === 'dashboard' ? 'active' : '' ?>">🏠 儀表板</a></li>

        <!-- 工程管理 -->
        <li class="nav-section">工程管理</li>
        <?php if (Auth::hasPermission('cases.manage') || Auth::hasPermission('cases.view') || Auth::hasPermission('cases.own')): ?>
        <li><a href="/cases.php" class="<?= ($currentPage ?? '') === 'cases' ? 'active' : '' ?>">📋 案件管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('quotations.manage') || Auth::hasPermission('quotations.view') || Auth::hasPermission('quotations.own')): ?>
        <li><a href="/quotations.php" class="<?= ($currentPage ?? '') === 'quotations' ? 'active' : '' ?>">💲 報價管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('schedule.manage') || Auth::hasPermission('schedule.view')): ?>
        <li><a href="/schedule.php" class="<?= ($currentPage ?? '') === 'schedule' ? 'active' : '' ?>">📅 工程行事曆</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('repairs.manage') || Auth::hasPermission('repairs.view') || Auth::hasPermission('repairs.own')): ?>
        <li><a href="/repairs.php" class="<?= ($currentPage ?? '') === 'repairs' ? 'active' : '' ?>">🔧 維修單</a></li>
        <?php endif; ?>
        <?php $u = Session::getUser(); if ($u && $u['is_engineer'] && (!is_array($cp) || !isset($cp['worklog']) || $cp['worklog'])): ?>
        <li><a href="/worklog.php" class="<?= ($currentPage ?? '') === 'worklog' ? 'active' : '' ?>">📝 施工回報</a></li>
        <?php endif; ?>
        <?php if ((Auth::hasPermission('schedule.manage') || Auth::hasPermission('schedule.view')) && (!is_array($cp) || !isset($cp['attendance']) || $cp['attendance'])): ?>
        <li><a href="/attendance.php" class="<?= ($currentPage ?? '') === 'attendance' ? 'active' : '' ?>">📊 出勤狀況表</a></li>
        <?php endif; ?>

        <!-- 產品庫存 -->
        <?php if (!is_array($cp) || !isset($cp['products']) || $cp['products']): ?>
        <li class="nav-section">產品庫存</li>
        <li><a href="/products.php" class="<?= ($currentPage ?? '') === 'products' ? 'active' : '' ?>">📦 產品目錄</a></li>
        <?php endif; ?>

        <!-- 人事行政 -->
        <li class="nav-section">人事行政</li>
        <?php if (Auth::hasPermission('staff.manage') || Auth::hasPermission('staff.view')): ?>
        <li><a href="/staff.php" class="<?= ($currentPage ?? '') === 'staff' ? 'active' : '' ?>">👥 人員管理</a></li>
        <?php endif; ?>
        <?php if (!is_array($cp) || !isset($cp['vehicles']) || $cp['vehicles']): ?>
        <li><a href="/vehicles.php" class="<?= ($currentPage ?? '') === 'vehicles' ? 'active' : '' ?>">🚗 車輛管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('leaves.manage') || Auth::hasPermission('leaves.own') || Auth::hasPermission('leaves.view')): ?>
        <li><a href="/leaves.php" class="<?= ($currentPage ?? '') === 'leaves' ? 'active' : '' ?>">🏖 請假管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('inter_branch.manage') || Auth::hasPermission('inter_branch.view')): ?>
        <li><a href="/inter_branch.php" class="<?= ($currentPage ?? '') === 'inter_branch' ? 'active' : '' ?>">💰 點工費管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('reports.view')): ?>
        <li><a href="/reports.php" class="<?= ($currentPage ?? '') === 'reports' ? 'active' : '' ?>">📈 報表</a></li>
        <?php endif; ?>

        <li class="nav-divider"></li>
        <li><a href="/logout.php">🚪 登出</a></li>
    </ul>
</aside>
<main class="content" id="mainContent">
<?php else: ?>
<main class="content content-full">
<?php endif; ?>

<?php
// Flash 訊息
$flashSuccess = Session::getFlash('success');
$flashError = Session::getFlash('error');
if ($flashSuccess): ?>
    <div class="alert alert-success"><?= e($flashSuccess) ?></div>
<?php endif; ?>
<?php if ($flashError): ?>
    <div class="alert alert-error"><?= e($flashError) ?></div>
<?php endif; ?>
