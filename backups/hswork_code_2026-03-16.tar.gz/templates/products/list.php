<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>產品目錄 <span class="text-muted" style="font-size:.85rem;font-weight:400">(共 <?= number_format($result['total']) ?> 筆)</span></h2>
</div>

<!-- 篩選 -->
<div class="card mb-2">
    <form method="GET" action="/products.php" class="filter-form">
        <div class="filter-row">
            <div class="form-group" style="flex:2;min-width:180px">
                <input type="text" name="keyword" class="form-control" placeholder="搜尋名稱 / 型號 / 品牌..." value="<?= e($filters['keyword']) ?>">
            </div>
            <div class="form-group" style="flex:1;min-width:140px">
                <select name="category_id" class="form-control">
                    <option value="">全部分類</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= $filters['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                        <?= e($cat['name']) ?> (<?= $cat['product_count'] ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="flex:1;min-width:120px">
                <select name="supplier" class="form-control">
                    <option value="">全部供應商</option>
                    <?php foreach ($suppliers as $sup): ?>
                    <option value="<?= e($sup) ?>" <?= $filters['supplier'] === $sup ? 'selected' : '' ?>><?= e($sup) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="flex:0">
                <button type="submit" class="btn btn-primary">搜尋</button>
            </div>
            <?php if ($filters['keyword'] || $filters['category_id'] || $filters['supplier']): ?>
            <div class="form-group" style="flex:0">
                <a href="/products.php" class="btn btn-outline">清除</a>
            </div>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- 產品卡片 -->
<?php if (empty($result['data'])): ?>
<div class="card" style="text-align:center;padding:48px 16px">
    <div style="font-size:2rem;margin-bottom:8px">📦</div>
    <p class="text-muted">找不到符合條件的產品</p>
</div>
<?php else: ?>
<div class="product-grid">
    <?php foreach ($result['data'] as $p): ?>
    <a href="/products.php?action=view&id=<?= $p['id'] ?>" class="product-card">
        <div class="product-img">
            <?php if ($p['image']): ?>
            <img src="<?= e($p['image']) ?>" alt="<?= e($p['name']) ?>" loading="lazy" onerror="this.parentElement.innerHTML='<div class=\'product-img-placeholder\'>📦</div>'">
            <?php else: ?>
            <div class="product-img-placeholder">📦</div>
            <?php endif; ?>
        </div>
        <div class="product-info">
            <div class="product-name"><?= e($p['name']) ?></div>
            <?php if ($p['model']): ?>
            <div class="product-model"><?= e($p['model']) ?></div>
            <?php endif; ?>
            <div class="product-price">$<?= number_format((float)$p['price']) ?></div>
            <?php if ($p['category_name']): ?>
            <div class="product-cat"><?= e($p['category_name']) ?></div>
            <?php endif; ?>
        </div>
    </a>
    <?php endforeach; ?>
</div>

<!-- 分頁 -->
<?php if ($result['lastPage'] > 1): ?>
<div class="pagination mt-2">
    <?php
    $lastPage = $result['lastPage'];
    $currentP = $result['page'];

    // 顯示前後各 2 頁
    $start = max(1, $currentP - 2);
    $end = min($lastPage, $currentP + 2);
    ?>

    <?php if ($currentP > 1): ?>
    <?php $qs = $_GET; $qs['page'] = $currentP - 1; ?>
    <a href="/products.php?<?= http_build_query($qs) ?>" class="btn btn-sm btn-outline">&laquo;</a>
    <?php endif; ?>

    <?php if ($start > 1): ?>
    <?php $qs = $_GET; $qs['page'] = 1; ?>
    <a href="/products.php?<?= http_build_query($qs) ?>" class="btn btn-sm btn-outline">1</a>
    <?php if ($start > 2): ?><span class="pagination-dots">…</span><?php endif; ?>
    <?php endif; ?>

    <?php for ($i = $start; $i <= $end; $i++): ?>
    <?php $qs = $_GET; $qs['page'] = $i; ?>
    <a href="/products.php?<?= http_build_query($qs) ?>" class="btn btn-sm <?= $i === $currentP ? 'btn-primary' : 'btn-outline' ?>"><?= $i ?></a>
    <?php endfor; ?>

    <?php if ($end < $lastPage): ?>
    <?php if ($end < $lastPage - 1): ?><span class="pagination-dots">…</span><?php endif; ?>
    <?php $qs = $_GET; $qs['page'] = $lastPage; ?>
    <a href="/products.php?<?= http_build_query($qs) ?>" class="btn btn-sm btn-outline"><?= $lastPage ?></a>
    <?php endif; ?>

    <?php if ($currentP < $lastPage): ?>
    <?php $qs = $_GET; $qs['page'] = $currentP + 1; ?>
    <a href="/products.php?<?= http_build_query($qs) ?>" class="btn btn-sm btn-outline">&raquo;</a>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<style>
.product-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
}
.product-card {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,.1);
    overflow: hidden;
    text-decoration: none;
    color: inherit;
    transition: box-shadow .2s, transform .15s;
    display: flex;
    flex-direction: column;
}
.product-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,.15);
    transform: translateY(-2px);
}
.product-img {
    width: 100%;
    aspect-ratio: 1;
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}
.product-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    padding: 8px;
}
.product-img-placeholder {
    font-size: 3rem;
    opacity: .3;
}
.product-info {
    padding: 10px 12px 12px;
    flex: 1;
    display: flex;
    flex-direction: column;
}
.product-name {
    font-size: .85rem;
    font-weight: 600;
    line-height: 1.3;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    margin-bottom: 4px;
}
.product-model {
    font-size: .75rem;
    color: var(--gray-500);
    margin-bottom: 6px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.product-price {
    font-size: 1rem;
    font-weight: 700;
    color: var(--primary);
    margin-top: auto;
}
.product-cat {
    font-size: .7rem;
    color: var(--gray-400);
    margin-top: 4px;
}
.filter-form { padding: 0; }
.filter-row {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    align-items: flex-end;
}
.filter-row .form-group { margin-bottom: 0; }
.pagination { display: flex; justify-content: center; gap: 4px; flex-wrap: wrap; align-items: center; }
.pagination-dots { color: var(--gray-400); padding: 0 4px; }

@media (max-width: 1023px) {
    .product-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 767px) {
    .product-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
    .product-info { padding: 8px; }
    .product-name { font-size: .8rem; }
    .filter-row { flex-direction: column; }
    .filter-row .form-group { width: 100%; }
}
</style>
