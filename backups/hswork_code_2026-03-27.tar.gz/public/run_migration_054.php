<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
if (!Auth::hasPermission('admin') && !in_array(Auth::user()['role'], array('boss','manager'))) {
    die('需要管理員權限');
}

$db = Database::getInstance();
$results = array();

// 1. 交易主表
try {
    $tables = $db->query("SHOW TABLES LIKE 'transactions'")->fetchAll();
    if (empty($tables)) {
        $db->exec("CREATE TABLE transactions (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            register_no VARCHAR(30) NOT NULL COMMENT '登記編號',
            register_date DATE NOT NULL COMMENT '登記日期',
            target_type ENUM('employee','partner') NOT NULL COMMENT '交易對象',
            category ENUM('purchase','loan') NOT NULL DEFAULT 'purchase' COMMENT '交易分類',
            contact_name VARCHAR(100) NOT NULL COMMENT '姓名/廠商名稱',
            total_unpaid DECIMAL(12,2) NOT NULL DEFAULT 0 COMMENT '合計未收總金額',
            created_by INT UNSIGNED DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_register_date (register_date),
            INDEX idx_target_type (target_type),
            INDEX idx_contact_name (contact_name),
            UNIQUE KEY uk_register_no (register_no)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='員工/廠商交易'");
        $results[] = '<li style="color:green">OK: transactions 資料表已建立</li>';
    } else {
        $results[] = '<li style="color:gray">SKIP: transactions 資料表已存在</li>';
    }
} catch (Exception $e) {
    $results[] = '<li style="color:red">ERROR: ' . htmlspecialchars($e->getMessage()) . '</li>';
}

// 2. 交易明細表
try {
    $tables = $db->query("SHOW TABLES LIKE 'transaction_items'")->fetchAll();
    if (empty($tables)) {
        $db->exec("CREATE TABLE transaction_items (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            transaction_id INT UNSIGNED NOT NULL COMMENT '交易主表ID',
            trade_date DATE DEFAULT NULL COMMENT '交易日期',
            description VARCHAR(255) DEFAULT '' COMMENT '交易內容',
            product VARCHAR(255) DEFAULT '' COMMENT '商品',
            amount DECIMAL(12,2) NOT NULL DEFAULT 0 COMMENT '總金額',
            due_date VARCHAR(100) DEFAULT '' COMMENT '預計付款日',
            is_settled TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否已結清 0=未結清 1=已結清',
            note TEXT COMMENT '備註',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_transaction_id (transaction_id),
            INDEX idx_trade_date (trade_date),
            INDEX idx_is_settled (is_settled)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='交易明細'");
        $results[] = '<li style="color:green">OK: transaction_items 資料表已建立</li>';
    } else {
        $results[] = '<li style="color:gray">SKIP: transaction_items 資料表已存在</li>';
    }
} catch (Exception $e) {
    $results[] = '<li style="color:red">ERROR: ' . htmlspecialchars($e->getMessage()) . '</li>';
}

echo '<h1>Migration 054 結果</h1><ul>' . implode('', $results) . '</ul>';
echo '<p><a href="/transactions.php">前往交易管理</a></p>';
