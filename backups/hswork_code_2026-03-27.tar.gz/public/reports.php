<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requirePermission('reports.view');
require_once __DIR__ . '/../modules/reports/ReportModel.php';
require_once __DIR__ . '/../modules/cases/CaseModel.php';

$model = new ReportModel();
$action = $_GET['action'] ?? 'index';
$branchIds = Auth::getAccessibleBranchIds();

switch ($action) {
    // ---- 報表首頁 ----
    case 'index':
        $summaryYear = isset($_GET['year']) ? $_GET['year'] : date('Y');
        $summaryMonth = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
        $caseSummary = $model->getCaseStatusSummary($branchIds, $summaryYear);
        $caseSummaryMonth = $model->getCaseStatusSummaryByMonth($branchIds, $summaryMonth);
        $currentMonth = date('Y-m');
        $monthlyStats = $model->getMonthlyScheduleStats($branchIds, $currentMonth);

        $pageTitle = '報表與分析';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/index.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 案件利潤 ----
    case 'case_profit':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        $data = $model->getCaseProfitReport($branchIds, $startDate, $endDate);

        $pageTitle = '案件利潤分析';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/case_profit.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 員工產值 ----
    case 'staff_productivity':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        $data = $model->getStaffProductivityReport($branchIds, $startDate, $endDate);

        $pageTitle = '員工產值統計';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/staff_productivity.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 案件綜合分析 ----
    case 'case_analysis':
        $year = isset($_GET['year']) ? $_GET['year'] : date('Y');
        $analysis = $model->getCaseAnalysis($branchIds, $year);

        $pageTitle = '案件綜合分析';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/case_analysis.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 帳務綜合分析 ----
    case 'finance_analysis':
        $year = isset($_GET['year']) ? $_GET['year'] : date('Y');
        $analysis = $model->getFinanceAnalysis($year);

        $pageTitle = '帳務綜合分析';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/finance_analysis.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 業務個人分析 ----
    case 'sales_personal':
        $salesId = isset($_GET['sales_id']) ? (int)$_GET['sales_id'] : Auth::id();
        $year = isset($_GET['year']) ? $_GET['year'] : date('Y');
        $analysis = $model->getSalesPersonalAnalysis($salesId, $year, $branchIds);
        // Get sales list for dropdown
        $caseModel = new CaseModel();
        $salespeople = $caseModel->getSalespeople();

        $pageTitle = '業務個人分析';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/sales_personal.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 點工費月結 ----
    case 'inter_branch':
        $month = $_GET['month'] ?? date('Y-m');
        $data = $model->getInterBranchMonthlyReport($branchIds, $month);

        $pageTitle = '跨點點工費月結報表';
        $currentPage = 'reports';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/reports/inter_branch_monthly.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    default:
        redirect('/reports.php');
}
