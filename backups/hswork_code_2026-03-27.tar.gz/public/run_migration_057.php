<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
if (!Auth::hasPermission('admin') && !in_array(Auth::user()['role'], array('boss','manager'))) {
    die('需要管理員權限');
}

$db = Database::getInstance();
$results = array();

$cols = array(
    'report_period' => "VARCHAR(7) DEFAULT NULL COMMENT '申報年月 YYYY-MM'",
    'invoice_format' => "VARCHAR(5) DEFAULT NULL COMMENT '進項發票聯式 21/22/23/24/25'",
    'deduction_category' => "VARCHAR(30) DEFAULT NULL COMMENT '扣抵別'",
);

foreach ($cols as $name => $def) {
    try {
        $db->query("SELECT `$name` FROM purchase_invoices LIMIT 1");
        $results[] = "<li style='color:gray'>SKIP: $name 已存在</li>";
    } catch (Exception $e) {
        try {
            $db->exec("ALTER TABLE purchase_invoices ADD COLUMN `$name` $def");
            $results[] = "<li style='color:green'>OK: $name 已新增</li>";
        } catch (Exception $e2) {
            $results[] = "<li style='color:red'>ERROR: $name - " . htmlspecialchars($e2->getMessage()) . "</li>";
        }
    }
}

// sales_invoices 同樣欄位
$cols2 = array(
    'report_period' => "VARCHAR(7) DEFAULT NULL COMMENT '申報年月 YYYY-MM'",
    'invoice_format' => "VARCHAR(5) DEFAULT NULL COMMENT '發票聯式 31/32/33/34/35'",
    'deduction_category' => "VARCHAR(30) DEFAULT NULL COMMENT '扣抵別'",
);

foreach ($cols2 as $name => $def) {
    try {
        $db->query("SELECT `$name` FROM sales_invoices LIMIT 1");
        $results[] = "<li style='color:gray'>SKIP: sales_invoices.$name 已存在</li>";
    } catch (Exception $e) {
        try {
            $db->exec("ALTER TABLE sales_invoices ADD COLUMN `$name` $def");
            $results[] = "<li style='color:green'>OK: sales_invoices.$name 已新增</li>";
        } catch (Exception $e2) {
            $results[] = "<li style='color:red'>ERROR: sales_invoices.$name - " . htmlspecialchars($e2->getMessage()) . "</li>";
        }
    }
}

echo '<h1>Migration 057 結果</h1><ul>' . implode('', $results) . '</ul>';
echo '<p><a href="/accounting.php?tab=purchase">返回進項發票</a> | <a href="/accounting.php?tab=sales">返回銷項發票</a></p>';
