<?php
/**
 * Migration 053: 產品加 vendor_model + product_price_history 資料表
 */
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();

if (!Auth::hasPermission('admin')) {
    die('需要管理員權限');
}

$db = Database::getInstance();
$results = array();

// 1. vendor_model
try {
    $cols = $db->query("SHOW COLUMNS FROM products LIKE 'vendor_model'")->fetchAll();
    if (empty($cols)) {
        $db->exec("ALTER TABLE products ADD COLUMN vendor_model VARCHAR(200) DEFAULT NULL AFTER model");
        $results[] = 'OK: products.vendor_model 欄位已新增';
    } else {
        $results[] = 'SKIP: products.vendor_model 已存在';
    }
} catch (Exception $e) {
    $results[] = 'ERROR: ' . $e->getMessage();
}

// 2. product_price_history
try {
    $tables = $db->query("SHOW TABLES LIKE 'product_price_history'")->fetchAll();
    if (empty($tables)) {
        $db->exec("
            CREATE TABLE product_price_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                product_id INT NOT NULL,
                date_from DATE NOT NULL,
                date_to DATE DEFAULT NULL,
                cost INT NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_product_id (product_id),
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        $results[] = 'OK: product_price_history 資料表已建立';
    } else {
        $results[] = 'SKIP: product_price_history 已存在';
    }
} catch (Exception $e) {
    $results[] = 'ERROR: ' . $e->getMessage();
}

echo '<h2>Migration 053 結果</h2><ul>';
foreach ($results as $r) {
    $color = strpos($r, 'OK') === 0 ? 'green' : (strpos($r, 'ERROR') === 0 ? 'red' : 'gray');
    echo '<li style="color:' . $color . '">' . htmlspecialchars($r) . '</li>';
}
echo '</ul><p><a href="/products.php">返回產品目錄</a></p>';
