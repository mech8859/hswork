<?php
class CustomerModel
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * 建立搜尋 WHERE 條件
     */
    private function buildListWhere($filters, &$params)
    {
        $where = '1=1';
        $params = array();

        if (!empty($filters['keyword'])) {
            $kw = '%' . $filters['keyword'] . '%';
            $where .= " AND (c.name LIKE ? OR c.contact_person LIKE ? OR c.phone LIKE ? OR c.mobile LIKE ? OR c.tax_id LIKE ? OR c.customer_no LIKE ? OR c.legacy_customer_no LIKE ? OR c.note LIKE ? OR c.site_address LIKE ?)";
            $params = array_merge($params, array($kw, $kw, $kw, $kw, $kw, $kw, $kw, $kw, $kw));
        }
        if (!empty($filters['category'])) {
            $where .= " AND c.category = ?";
            $params[] = $filters['category'];
        }
        if (!empty($filters['sales_id'])) {
            $where .= " AND c.sales_id = ?";
            $params[] = $filters['sales_id'];
        }
        if (!empty($filters['import_source'])) {
            $where .= " AND c.import_source = ?";
            $params[] = $filters['import_source'];
        }
        if (!empty($filters['has_cases'])) {
            $where .= " AND c.id IN (SELECT DISTINCT customer_id FROM cases WHERE customer_id IS NOT NULL)";
        }
        if (isset($filters['is_active']) && $filters['is_active'] !== '') {
            $where .= " AND c.is_active = ?";
            $params[] = (int)$filters['is_active'];
        } else {
            $where .= " AND c.is_active = 1";
        }

        return $where;
    }

    /**
     * 客戶列表（分頁版）
     */
    public function getList($filters = array(), $limit = 100, $page = 1)
    {
        $params = array();
        $where = $this->buildListWhere($filters, $params);

        $offset = ($page - 1) * $limit;

        $sql = "SELECT c.*, u.real_name as sales_name,
                CONCAT(COALESCE(c.site_city,''), COALESCE(c.site_district,''), COALESCE(c.site_address,'')) as full_address,
                EXISTS(SELECT 1 FROM cases ca WHERE ca.customer_id = c.id) as has_cases,
                EXISTS(SELECT 1 FROM cases ca WHERE ca.customer_id = c.id AND (ca.status IN ('closed','unpaid','incomplete') OR ca.case_type IN ('old_repair','addition'))) as has_deal
                FROM customers c
                LEFT JOIN users u ON c.sales_id = u.id
                WHERE $where
                ORDER BY c.updated_at DESC
                LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 客戶搜尋結果總數
     */
    public function getListCount($filters = array())
    {
        $params = array();
        $where = $this->buildListWhere($filters, $params);

        $sql = "SELECT COUNT(*) FROM customers c WHERE $where";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    }

    /**
     * 客戶統計儀表板
     */
    public function getDashboardStats()
    {
        $stats = array();

        // 總客戶數
        $stats['total'] = (int)$this->db->query("SELECT COUNT(*) FROM customers WHERE is_active = 1")->fetchColumn();

        // 成交客戶 ID 子查詢
        $dealCustFilter = "c.id IN (SELECT DISTINCT customer_id FROM cases WHERE customer_id IS NOT NULL AND ( status IN ('closed','unpaid','incomplete') OR case_type IN ('old_repair','addition') ))";

        // 分類統計（僅成交客戶）
        $stmt = $this->db->query("SELECT category, COUNT(*) as cnt FROM customers c WHERE c.is_active = 1 AND {$dealCustFilter} AND category IS NOT NULL AND category != '' GROUP BY category ORDER BY cnt DESC");
        $stats['by_category'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 來源統計（僅成交客戶）
        $stmt = $this->db->query("SELECT COALESCE(import_source, '手動建立') as source, COUNT(*) as cnt FROM customers c WHERE c.is_active = 1 AND {$dealCustFilter} GROUP BY import_source ORDER BY cnt DESC");
        $stats['by_source'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 年度新增統計（僅成交客戶，近5年）
        $stmt = $this->db->query("SELECT YEAR(created_at) as yr, COUNT(*) as cnt FROM customers c WHERE c.is_active = 1 AND {$dealCustFilter} AND created_at IS NOT NULL GROUP BY YEAR(created_at) ORDER BY yr DESC LIMIT 5");
        $stats['by_year'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 有案件的客戶數
        $stats['with_cases'] = (int)$this->db->query("SELECT COUNT(DISTINCT customer_id) FROM cases WHERE customer_id IS NOT NULL")->fetchColumn();

        // 有成交的客戶數
        $stats['with_deals'] = (int)$this->db->query("SELECT COUNT(DISTINCT customer_id) FROM cases WHERE customer_id IS NOT NULL AND ( status IN ('closed','unpaid','incomplete') OR case_type IN ('old_repair','addition') )")->fetchColumn();

        // 黑名單客戶數
        $stats['blacklisted'] = (int)$this->db->query("SELECT COUNT(*) FROM customers WHERE is_active = 1 AND is_blacklisted = 1")->fetchColumn();

        // 最近成交客戶 (10筆)
        $stmt = $this->db->query("SELECT c.id, c.customer_no, c.name, c.category, c.created_at FROM customers c WHERE c.is_active = 1 AND {$dealCustFilter} ORDER BY c.created_at DESC LIMIT 10");
        $stats['recent'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $stats;
    }

    /**
     * 客戶詳情
     */
    public function getById($id)
    {
        $stmt = $this->db->prepare("SELECT c.*, u.real_name as sales_name FROM customers c LEFT JOIN users u ON c.sales_id = u.id WHERE c.id = ?");
        $stmt->execute(array($id));
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($customer) {
            $customer['contacts'] = $this->getContacts($id);
        }
        return $customer;
    }

    /**
     * 取得客戶聯絡人列表
     */
    public function getContacts($customerId)
    {
        try {
            $stmt = $this->db->prepare("SELECT id, contact_name, phone, mobile, role, note FROM customer_contacts WHERE customer_id = ? ORDER BY id");
            $stmt->execute(array($customerId));
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return array();
        }
    }

    /**
     * 儲存客戶聯絡人（刪除重建）
     */
    public function saveContacts($customerId, $contacts)
    {
        try {
            $this->db->prepare("DELETE FROM customer_contacts WHERE customer_id = ?")->execute(array($customerId));
            $stmt = $this->db->prepare("INSERT INTO customer_contacts (customer_id, contact_name, phone, mobile, role, note) VALUES (?, ?, ?, ?, ?, ?)");
            foreach ($contacts as $c) {
                if (empty($c['contact_name'])) continue;
                $stmt->execute(array(
                    $customerId,
                    $c['contact_name'],
                    isset($c['phone']) ? $c['phone'] : null,
                    isset($c['mobile']) ? $c['mobile'] : null,
                    isset($c['role']) ? $c['role'] : null,
                    isset($c['note']) ? $c['note'] : null,
                ));
            }
        } catch (Exception $e) {
            // customer_contacts 表不存在時不報錯
        }
    }

    /**
     * 新增客戶
     */
    public function create($data)
    {
        $no = $this->generateNumber();
        $stmt = $this->db->prepare("
            INSERT INTO customers (customer_no, name, category, contact_person, phone, mobile, fax, email,
                invoice_title, tax_id, invoice_email,
                billing_city, billing_district, billing_address,
                site_city, site_district, site_address,
                payment_method, payment_terms, sales_id, note, created_by,
                is_blacklisted, blacklist_reason)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute(array(
            $no,
            $data['name'],
            $data['category'] ?: null,
            $data['contact_person'] ?: null,
            $data['phone'] ?: null,
            $data['mobile'] ?: null,
            $data['fax'] ?: null,
            $data['email'] ?: null,
            $data['invoice_title'] ?: null,
            $data['tax_id'] ?: null,
            $data['invoice_email'] ?: null,
            $data['billing_city'] ?: null,
            $data['billing_district'] ?: null,
            $data['billing_address'] ?: null,
            $data['site_city'] ?: null,
            $data['site_district'] ?: null,
            $data['site_address'] ?: null,
            $data['payment_method'] ?: null,
            $data['payment_terms'] ?: null,
            $data['sales_id'] ?: null,
            $data['note'] ?: null,
            Auth::id(),
            !empty($data['is_blacklisted']) ? 1 : 0,
            !empty($data['blacklist_reason']) ? $data['blacklist_reason'] : null
        ));
        return $this->db->lastInsertId();
    }

    /**
     * 更新客戶
     */
    public function update($id, $data)
    {
        $stmt = $this->db->prepare("
            UPDATE customers SET
                name = ?, category = ?, contact_person = ?, phone = ?, mobile = ?, fax = ?, email = ?,
                invoice_title = ?, tax_id = ?, invoice_email = ?,
                billing_city = ?, billing_district = ?, billing_address = ?,
                site_city = ?, site_district = ?, site_address = ?,
                payment_method = ?, payment_terms = ?, sales_id = ?, note = ?,
                is_blacklisted = ?, blacklist_reason = ?
            WHERE id = ?
        ");
        $stmt->execute(array(
            $data['name'],
            $data['category'] ?: null,
            $data['contact_person'] ?: null,
            $data['phone'] ?: null,
            $data['mobile'] ?: null,
            $data['fax'] ?: null,
            $data['email'] ?: null,
            $data['invoice_title'] ?: null,
            $data['tax_id'] ?: null,
            $data['invoice_email'] ?: null,
            $data['billing_city'] ?: null,
            $data['billing_district'] ?: null,
            $data['billing_address'] ?: null,
            $data['site_city'] ?: null,
            $data['site_district'] ?: null,
            $data['site_address'] ?: null,
            $data['payment_method'] ?: null,
            $data['payment_terms'] ?: null,
            $data['sales_id'] ?: null,
            $data['note'] ?: null,
            !empty($data['is_blacklisted']) ? 1 : 0,
            !empty($data['blacklist_reason']) ? $data['blacklist_reason'] : null,
            $id
        ));
    }

    /**
     * 停用/啟用
     */
    public function toggleActive($id)
    {
        $this->db->prepare("UPDATE customers SET is_active = NOT is_active WHERE id = ?")->execute(array($id));
    }

    /**
     * 取得客戶的案件列表
     */
    public function getCases($customerId)
    {
        $stmt = $this->db->prepare("SELECT c.*, b.name as branch_name FROM cases c LEFT JOIN branches b ON c.branch_id = b.id WHERE c.customer_id = ? ORDER BY c.created_at DESC");
        $stmt->execute(array($customerId));
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 取得客戶的成交紀錄
     */
    public function getDeals($customerId)
    {
        $stmt = $this->db->prepare("SELECT cd.*, c.case_number, c.title as case_title FROM customer_deals cd LEFT JOIN cases c ON cd.case_id = c.id WHERE cd.customer_id = ? ORDER BY cd.completion_date DESC");
        $stmt->execute(array($customerId));
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 新增成交紀錄
     */
    public function addDeal($customerId, $data)
    {
        $stmt = $this->db->prepare("INSERT INTO customer_deals (customer_id, case_id, site_address, deal_amount, completion_date, warranty_date, note) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(array(
            $customerId,
            $data['case_id'] ?: null,
            $data['site_address'] ?: null,
            $data['deal_amount'] ?: null,
            $data['completion_date'] ?: null,
            $data['warranty_date'] ?: null,
            $data['note'] ?: null
        ));
    }

    /**
     * 取得客戶帳款交易
     */
    public function getTransactions($customerId)
    {
        $stmt = $this->db->prepare("SELECT * FROM customer_transactions WHERE customer_id = ? ORDER BY transaction_date DESC");
        $stmt->execute(array($customerId));
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 取得業務人員列表
     */
    public function getSalespeople()
    {
        $stmt = $this->db->query("SELECT id, real_name FROM users WHERE role IN ('sales','sales_manager','sales_assistant','boss','manager') AND is_active = 1 ORDER BY real_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 取得客戶分類選項
     */
    public static function categoryOptions()
    {
        return array(
            'residential'  => '住家',
            'commercial'   => '商辦',
            'industrial'   => '工廠',
            'government'   => '公家機關',
            'school'       => '學校',
            'hospital'     => '醫療',
            'self_pickup'  => '自取客戶',
            'vendor'       => '叫貨廠商',
            'security_co'  => '保全配合',
            'builder'      => '建商配合',
            'other'        => '其他',
        );
    }

    /**
     * 文件類型選項
     */
    public static function fileTypeOptions()
    {
        return array(
            'quotation' => '報價單',
            'contract'  => '合約書',
            'photo'     => '照片',
            'invoice'   => '發票',
            'other'     => '其他',
        );
    }

    /**
     * 產生客戶編號（使用統一自動編號系統）
     */
    private function generateNumber()
    {
        return generate_doc_number('customers');
    }

    /**
     * AJAX搜尋客戶（給案件表單用）
     */
    public function search($keyword, $limit = 10)
    {
        $kw = '%' . $keyword . '%';
        $stmt = $this->db->prepare("SELECT id, customer_no, name, phone, mobile, contact_person, site_address, invoice_title, tax_id, is_blacklisted, blacklist_reason FROM customers WHERE is_active = 1 AND (name LIKE ? OR phone LIKE ? OR mobile LIKE ? OR tax_id LIKE ?) ORDER BY name LIMIT ?");
        $stmt->execute(array($kw, $kw, $kw, $kw, $limit));
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // File management
    public function getFiles($customerId)
    {
        $stmt = $this->db->prepare("SELECT cf.*, u.real_name as uploader_name FROM customer_files cf LEFT JOIN users u ON cf.uploaded_by = u.id WHERE cf.customer_id = ? ORDER BY cf.created_at DESC");
        $stmt->execute(array($customerId));
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addFile($customerId, $data)
    {
        $stmt = $this->db->prepare("INSERT INTO customer_files (customer_id, file_type, file_name, file_path, file_size, note, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(array(
            $customerId,
            $data['file_type'] ?: 'other',
            $data['file_name'],
            $data['file_path'],
            $data['file_size'] ?: 0,
            $data['note'] ?: null,
            Auth::id()
        ));
        return $this->db->lastInsertId();
    }

    public function getFile($fileId)
    {
        $stmt = $this->db->prepare("SELECT * FROM customer_files WHERE id = ?");
        $stmt->execute(array($fileId));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function deleteFile($fileId)
    {
        $file = $this->getFile($fileId);
        if ($file) {
            $fullPath = __DIR__ . '/../../public' . $file['file_path'];
            if (file_exists($fullPath)) {
                unlink($fullPath);
            }
            $this->db->prepare("DELETE FROM customer_files WHERE id = ?")->execute(array($fileId));
        }
        return $file;
    }
}
