<h2><?= $customer ? '編輯客戶 - ' . e($customer['name']) : '新增客戶' ?></h2>

<form method="POST" class="mt-2" id="customerForm">
    <?= csrf_field() ?>

    <div class="card">
        <div class="card-header">客戶資訊</div>
        <?php if ($customer): ?>
        <div class="form-row">
            <div class="form-group">
                <label>客戶編號</label>
                <input type="text" class="form-control" value="<?= e($customer['customer_no'] ?? '') ?>" readonly style="background:#f5f5f5">
            </div>
            <?php if (!empty($customer['legacy_customer_no'])): ?>
            <div class="form-group">
                <label>原資料客戶編號</label>
                <input type="text" class="form-control" value="<?= e($customer['legacy_customer_no']) ?>" readonly style="background:#f5f5f5">
            </div>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <div class="form-row">
            <div class="form-group">
                <label>客戶編號</label>
                <input type="text" class="form-control" value="<?= peek_next_doc_number('customers') ?>" readonly style="background:#f5f5f5;color:#888">
                <small class="text-muted">系統自動產生</small>
            </div>
        </div>
        <?php endif; ?>
        <div class="form-row">
            <div class="form-group">
                <label>客戶名稱 *</label>
                <input type="text" name="name" class="form-control" value="<?= e($customer['name'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label>客戶分類</label>
                <select name="category" class="form-control">
                    <option value="">請選擇</option>
                    <?php foreach (CustomerModel::categoryOptions() as $key => $label): ?>
                    <option value="<?= e($key) ?>" <?= ($customer['category'] ?? '') === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <!-- 多筆聯絡人 -->
        <div style="border-top:1px solid var(--gray-200);padding-top:12px;margin-top:8px">
            <div class="d-flex justify-between align-center mb-1">
                <label style="font-weight:600;margin:0">聯絡人</label>
                <button type="button" class="btn btn-outline btn-sm" onclick="addCustContact()">+ 新增聯絡人</button>
            </div>
            <div id="custContactsContainer">
                <?php
                $custContacts = isset($customer['contacts']) ? $customer['contacts'] : array();
                // 向下相容：如果沒有 contacts 但有 contact_person，自動建一筆
                if (empty($custContacts) && !empty($customer['contact_person'])) {
                    $custContacts = array(array(
                        'contact_name' => $customer['contact_person'],
                        'phone' => $customer['phone'] ?? '',
                        'mobile' => $customer['mobile'] ?? '',
                        'role' => '',
                    ));
                }
                foreach ($custContacts as $ci => $cc):
                ?>
                <div class="cust-contact-row" data-index="<?= $ci ?>">
                    <div class="form-row">
                        <div class="form-group"><label>姓名</label><input type="text" name="contacts[<?= $ci ?>][contact_name]" class="form-control" value="<?= e($cc['contact_name'] ?? '') ?>"></div>
                        <div class="form-group"><label>電話</label><input type="text" name="contacts[<?= $ci ?>][phone]" class="form-control" value="<?= e($cc['phone'] ?? '') ?>"></div>
                        <div class="form-group"><label>手機</label><input type="text" name="contacts[<?= $ci ?>][mobile]" class="form-control" value="<?= e($cc['mobile'] ?? '') ?>"></div>
                        <div class="form-group"><label>角色</label><input type="text" name="contacts[<?= $ci ?>][role]" class="form-control" value="<?= e($cc['role'] ?? '') ?>" placeholder="屋主/管委會/總機"></div>
                        <div class="form-group" style="align-self:flex-end;flex:0 0 auto"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.cust-contact-row').remove()">刪除</button></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <!-- 保留舊欄位相容 -->
        <input type="hidden" name="contact_person" value="<?= e($customer['contact_person'] ?? '') ?>">
        <div class="form-row" style="margin-top:12px">
            <div class="form-group">
                <label>傳真</label>
                <input type="text" name="fax" class="form-control" value="<?= e($customer['fax'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?= e($customer['email'] ?? '') ?>">
            </div>
        </div>
        <div class="form-group">
            <label>LINE ID</label>
            <input type="text" name="line_id" class="form-control" value="<?= e($customer['line_id'] ?? '') ?>">
        </div>
    </div>

    <div class="card">
        <div class="card-header">發票資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>發票抬頭</label>
                <input type="text" name="invoice_title" class="form-control" value="<?= e($customer['invoice_title'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>統一編號</label>
                <input type="text" name="tax_id" class="form-control" value="<?= e($customer['tax_id'] ?? '') ?>" maxlength="8">
            </div>
        </div>
        <div class="form-group">
            <label>發票寄送 Email</label>
            <input type="email" name="invoice_email" class="form-control" value="<?= e($customer['invoice_email'] ?? '') ?>">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>付款方式</label>
                <input type="text" name="payment_method" class="form-control" value="<?= e($customer['payment_method'] ?? '') ?>" placeholder="例：匯款/支票/現金">
            </div>
            <div class="form-group">
                <label>付款條件</label>
                <input type="text" name="payment_terms" class="form-control" value="<?= e($customer['payment_terms'] ?? '') ?>" placeholder="例：月結30天">
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">帳單地址</div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 120px">
                <label>縣市</label>
                <input type="text" name="billing_city" id="billing_city" class="form-control" value="<?= e($customer['billing_city'] ?? '') ?>" placeholder="例：台中市">
            </div>
            <div class="form-group" style="flex:0 0 120px">
                <label>區域</label>
                <input type="text" name="billing_district" id="billing_district" class="form-control" value="<?= e($customer['billing_district'] ?? '') ?>" placeholder="例：西屯區">
            </div>
            <div class="form-group">
                <label>地址</label>
                <input type="text" name="billing_address" id="billing_address" class="form-control" value="<?= e($customer['billing_address'] ?? '') ?>">
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>施工地址</span>
            <button type="button" class="btn btn-outline btn-sm" onclick="copyBillingToSite()">同帳單地址</button>
        </div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 120px">
                <label>縣市</label>
                <input type="text" name="site_city" id="site_city" class="form-control" value="<?= e($customer['site_city'] ?? '') ?>" placeholder="例：台中市">
            </div>
            <div class="form-group" style="flex:0 0 120px">
                <label>區域</label>
                <input type="text" name="site_district" id="site_district" class="form-control" value="<?= e($customer['site_district'] ?? '') ?>" placeholder="例：西屯區">
            </div>
            <div class="form-group">
                <label>地址</label>
                <input type="text" name="site_address" id="site_address" class="form-control" value="<?= e($customer['site_address'] ?? '') ?>">
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">其他</div>
        <div class="form-group">
            <label>承辦業務</label>
            <select name="sales_id" class="form-control">
                <option value="">請選擇</option>
                <?php foreach ($salespeople as $sp): ?>
                <option value="<?= $sp['id'] ?>" <?= ($customer['sales_id'] ?? '') == $sp['id'] ? 'selected' : '' ?>><?= e($sp['real_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>備註</label>
            <textarea name="note" class="form-control" rows="3"><?= e($customer['note'] ?? '') ?></textarea>
        </div>
        <div style="border-top:1px solid var(--gray-200);padding-top:12px;margin-top:8px">
            <label class="checkbox-label" style="display:inline-flex;align-items:center;gap:6px;cursor:pointer">
                <input type="hidden" name="is_blacklisted" value="0">
                <input type="checkbox" name="is_blacklisted" value="1" id="chk_blacklist"
                    <?= !empty($customer['is_blacklisted']) ? 'checked' : '' ?>
                    onchange="document.getElementById('blacklist_reason_wrap').style.display = this.checked ? 'block' : 'none'">
                <span style="color:var(--danger);font-weight:600">⚠ 黑名單</span>
            </label>
            <div id="blacklist_reason_wrap" style="margin-top:8px;<?= empty($customer['is_blacklisted']) ? 'display:none' : '' ?>">
                <label>黑名單原因</label>
                <textarea name="blacklist_reason" class="form-control" rows="2" placeholder="請填寫列入黑名單的原因"><?= e($customer['blacklist_reason'] ?? '') ?></textarea>
            </div>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $customer ? '儲存變更' : '建立客戶' ?></button>
        <a href="/customers.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
function copyBillingToSite() {
    document.getElementById('site_city').value = document.getElementById('billing_city').value;
    document.getElementById('site_district').value = document.getElementById('billing_district').value;
    document.getElementById('site_address').value = document.getElementById('billing_address').value;
}

var custContactIdx = <?= count($custContacts) ?>;
function addCustContact() {
    var html = '<div class="cust-contact-row" data-index="' + custContactIdx + '">' +
        '<div class="form-row">' +
        '<div class="form-group"><label>姓名</label><input type="text" name="contacts[' + custContactIdx + '][contact_name]" class="form-control"></div>' +
        '<div class="form-group"><label>電話</label><input type="text" name="contacts[' + custContactIdx + '][phone]" class="form-control"></div>' +
        '<div class="form-group"><label>手機</label><input type="text" name="contacts[' + custContactIdx + '][mobile]" class="form-control"></div>' +
        '<div class="form-group"><label>角色</label><input type="text" name="contacts[' + custContactIdx + '][role]" class="form-control" placeholder="屋主/管委會/總機"></div>' +
        '<div class="form-group" style="align-self:flex-end;flex:0 0 auto"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest(\'.cust-contact-row\').remove()">刪除</button></div>' +
        '</div></div>';
    document.getElementById('custContactsContainer').insertAdjacentHTML('beforeend', html);
    custContactIdx++;
}

// 表單送出時，用第一筆聯絡人更新 hidden contact_person
document.getElementById('customerForm').addEventListener('submit', function() {
    var firstName = document.querySelector('#custContactsContainer input[name*="contact_name"]');
    var hidden = document.querySelector('input[name="contact_person"]');
    if (firstName && hidden) hidden.value = firstName.value;
});
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
</style>
