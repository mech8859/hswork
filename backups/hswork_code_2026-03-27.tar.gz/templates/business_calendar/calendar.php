<?php
// 計算月曆資料
$firstDay = mktime(0, 0, 0, $month, 1, $year);
$daysInMonth = (int)date('t', $firstDay);
$startWeekday = (int)date('w', $firstDay); // 0=Sun
$prevMonth = $month - 1; $prevYear = $year;
if ($prevMonth < 1) { $prevMonth = 12; $prevYear--; }
$nextMonth = $month + 1; $nextYear = $year;
if ($nextMonth > 12) { $nextMonth = 1; $nextYear++; }
$today = date('Y-m-d');

$activityTypes = BusinessCalendarModel::activityTypes();
$regionOptions = BusinessCalendarModel::regionOptions();
$currentRegion = isset($filters['region']) ? $filters['region'] : '';
$currentStaff = isset($filters['staff_id']) ? $filters['staff_id'] : '';
$currentKeyword = isset($filters['keyword']) ? $filters['keyword'] : '';
?>

<style>
/* 篩選列 */
.bc-filter-bar { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; justify-content: space-between; }
.bc-region-pills { display: flex; gap: 4px; flex-wrap: wrap; }
.bc-pill {
    display: inline-block; padding: 4px 12px; border-radius: 20px;
    font-size: .85rem; text-decoration: none; color: var(--gray-600);
    background: var(--gray-100); border: 1px solid var(--gray-200);
    transition: all .15s;
}
.bc-pill:hover { background: var(--gray-200); text-decoration: none; color: var(--gray-700); }
.bc-pill-active { background: var(--primary); color: #fff; border-color: var(--primary); }
.bc-pill-active:hover { background: var(--primary); color: #fff; }
.bc-dot { display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 4px; vertical-align: middle; }
.bc-calendar-grid {
    display: grid !important; grid-template-columns: repeat(7, 1fr) !important;
    border: 1px solid var(--gray-200); border-radius: var(--radius);
    background: #fff;
}
.bc-calendar-grid .cal-header {
    padding: 8px; text-align: center; font-weight: 600;
    background: var(--gray-100); border-bottom: 1px solid var(--gray-200);
    font-size: .85rem;
}
.bc-calendar-grid .cal-cell {
    min-height: 110px; padding: 4px; border-right: 1px solid var(--gray-200);
    border-bottom: 1px solid var(--gray-200); position: relative;
}
.bc-calendar-grid .cal-cell:nth-child(7n) { border-right: none; }
.bc-calendar-grid .cal-empty { background: var(--gray-50); }
.bc-calendar-grid .cal-today { background: #e8f0fe; }
.bc-calendar-grid .cal-date {
    display: flex; justify-content: space-between; align-items: center;
    font-size: .85rem; font-weight: 500; margin-bottom: 2px;
}
.bc-day-link { color: inherit; text-decoration: none; font-weight: 600; }
.bc-day-link:hover { color: var(--primary); text-decoration: none; }
.bc-calendar-grid .cal-date-actions { display: flex; gap: 2px; align-items: center; }
.bc-calendar-grid .cal-add {
    width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;
    background: var(--primary); color: #fff; border-radius: 50%;
    font-size: .8rem; text-decoration: none; opacity: 0;
    transition: opacity .15s;
}
.bc-calendar-grid .cal-cell:hover .cal-add { opacity: 1; }
.bc-event {
    display: block; padding: 3px 6px; margin-bottom: 2px;
    border-radius: 4px; font-size: .75rem; text-decoration: none;
    color: var(--gray-700); background: #f8f9fa;
    transition: background .15s;
}
.bc-event:hover { background: #eef1f5; text-decoration: none; }
.bc-event-title { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.bc-event-info { display: flex; gap: 4px; align-items: center; font-size: .7rem; color: var(--gray-500); }
.bc-event-staff { font-size: .65rem; color: var(--gray-400); }
.bc-type-dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }
.bc-leave-bar { margin-bottom: 3px; }
.bc-leave-tag {
    display: inline-block; font-size: .65rem; padding: 1px 5px;
    background: #e8f5e9; color: #2e7d32; border-radius: 3px;
    margin-right: 2px; margin-bottom: 1px;
}
.bc-calendar-grid .cal-more {
    display: block; font-size: .7rem; color: var(--primary); cursor: pointer;
    padding: 2px 6px; text-align: center; font-weight: 500; text-decoration: none;
}
.bc-calendar-grid .cal-more:hover { text-decoration: underline; }
.bc-badge-type {
    display: inline-block; font-size: .7rem; padding: 1px 6px;
    border-radius: 3px; color: #fff; font-weight: 500;
}
.calendar-mobile { display: flex; flex-direction: column; gap: 4px; }
.mobile-day { background: #fff; border-radius: var(--radius); padding: 10px; box-shadow: var(--shadow); }
.mobile-day-today { border-left: 3px solid var(--primary); }
.mobile-day-header { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; flex-wrap: wrap; }
.mobile-day-num { font-weight: 600; color: inherit; text-decoration: none; }
.mobile-day-num:hover { color: var(--primary); text-decoration: none; }
.mobile-schedule-card {
    display: block; border: 1px solid var(--gray-200); border-radius: var(--radius);
    padding: 8px; margin-bottom: 4px; text-decoration: none; color: inherit;
}
.mobile-schedule-card:hover { box-shadow: var(--shadow); text-decoration: none; }
.mobile-schedule-meta { font-size: .8rem; color: var(--gray-500); display: flex; gap: 8px; flex-wrap: wrap; margin-top: 2px; }
.calendar-mobile { display: none; }
.calendar-desktop { display: block; }
@media (max-width: 767px) {
    .calendar-mobile { display: flex !important; }
    .calendar-desktop { display: none !important; }
    .bc-filter-bar { flex-direction: column; align-items: stretch; }
}
</style>

<!-- 日期彈出視窗 -->
<div id="bcDayPopup" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;z-index:1000;background:rgba(0,0,0,.4)">
    <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:8px;box-shadow:0 8px 30px rgba(0,0,0,.2);min-width:360px;max-width:500px;max-height:80vh;overflow:hidden">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-bottom:1px solid #eee">
            <h3 id="bcPopupTitle" style="margin:0;font-size:1rem"></h3>
            <button onclick="closeDayPopup()" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#999">&times;</button>
        </div>
        <div id="bcPopupBody" style="padding:12px 16px;overflow-y:auto;max-height:60vh"></div>
    </div>
</div>
<script>
var bcAllEvents = <?php
    // 建立所有事件的 JSON 資料供 popup 使用
    $allEventsJson = array();
    foreach ($events as $dayNum => $dayEvs) {
        $dateKey = sprintf('%04d-%02d-%02d', $year, $month, $dayNum);
        $allEventsJson[$dateKey] = array();
        foreach ($dayEvs as $ev) {
            $allEventsJson[$dateKey][] = array(
                'id' => $ev['id'],
                'customer' => $ev['customer_name'],
                'staff' => $ev['staff_name'],
                'type' => isset($activityTypes[$ev['activity_type']]) ? $activityTypes[$ev['activity_type']] : $ev['activity_type'],
                'color' => BusinessCalendarModel::activityColor($ev['activity_type']),
                'phone' => $ev['phone'] ?: '',
            );
        }
    }
    echo json_encode($allEventsJson, JSON_UNESCAPED_UNICODE);
?>;
function showDayPopup(dateStr) {
    var items = bcAllEvents[dateStr];
    if (!items || items.length === 0) return;
    var d = new Date(dateStr);
    var weekdays = ['日','一','二','三','四','五','六'];
    document.getElementById('bcPopupTitle').textContent = (d.getMonth()+1) + '/' + d.getDate() + ' (' + weekdays[d.getDay()] + ') ' + items.length + ' 筆行程';
    var html = '';
    for (var i = 0; i < items.length; i++) {
        var it = items[i];
        html += '<a href="/business_calendar.php?action=edit&id=' + it.id + '" style="display:block;padding:10px 12px;margin-bottom:6px;border-left:4px solid ' + it.color + ';background:#f8f9fa;border-radius:6px;text-decoration:none;color:inherit;transition:background .15s"' +
            ' onmouseover="this.style.background=\'#eef1f5\'" onmouseout="this.style.background=\'#f8f9fa\'">' +
            '<div style="font-weight:600;font-size:.95rem">' + it.customer + '</div>' +
            '<div style="display:flex;gap:8px;font-size:.8rem;color:#888;margin-top:2px">' +
            '<span style="display:inline-block;padding:1px 6px;border-radius:3px;background:' + it.color + ';color:#fff;font-size:.7rem">' + it.type + '</span>' +
            '<span>' + it.staff + '</span>' +
            (it.phone ? '<span>' + it.phone + '</span>' : '') +
            '</div></a>';
    }
    document.getElementById('bcPopupBody').innerHTML = html;
    document.getElementById('bcDayPopup').style.display = 'block';
}
function closeDayPopup() { document.getElementById('bcDayPopup').style.display = 'none'; }
document.getElementById('bcDayPopup').addEventListener('click', function(e) { if (e.target === this) closeDayPopup(); });
</script>

<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>業務行事曆</h2>
    <div class="d-flex gap-1 align-center flex-wrap">
        <a href="/business_calendar.php?action=list" class="btn btn-outline btn-sm">列表檢視</a>
        <a href="/business_calendar.php?action=create" class="btn btn-primary btn-sm">+ 新增行程</a>
    </div>
</div>

<!-- 篩選列 -->
<div class="card mb-1">
    <div class="bc-filter-bar">
        <div class="bc-region-pills">
            <a href="/business_calendar.php?year=<?= $year ?>&month=<?= $month ?>&staff_id=<?= e($currentStaff) ?>&keyword=<?= urlencode($currentKeyword) ?>"
               class="bc-pill <?= $currentRegion === '' ? 'bc-pill-active' : '' ?>">全部</a>
            <?php foreach ($regionOptions as $regionKey => $regionLabel): ?>
            <a href="/business_calendar.php?year=<?= $year ?>&month=<?= $month ?>&region=<?= e($regionKey) ?>&staff_id=<?= e($currentStaff) ?>&keyword=<?= urlencode($currentKeyword) ?>"
               class="bc-pill <?= $currentRegion === $regionKey ? 'bc-pill-active' : '' ?>"><?= e($regionLabel) ?></a>
            <?php endforeach; ?>
        </div>
        <div class="d-flex gap-1 flex-wrap align-center">
            <select id="bcStaffFilter" class="form-control form-control-sm" onchange="bcApplyFilters()" style="min-width:120px">
                <option value="">全部業務</option>
                <?php foreach ($salespeople as $sp): ?>
                <option value="<?= $sp['id'] ?>" <?= $currentStaff == $sp['id'] ? 'selected' : '' ?>><?= e($sp['real_name']) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="text" id="bcKeywordFilter" class="form-control form-control-sm" placeholder="搜尋客戶/備註"
                   value="<?= e($currentKeyword) ?>" onkeydown="if(event.key==='Enter')bcApplyFilters()" style="min-width:120px;max-width:180px">
            <button type="button" class="btn btn-primary btn-sm" onclick="bcApplyFilters()">搜尋</button>
        </div>
    </div>
</div>

<!-- 月份切換 -->
<div class="d-flex justify-between align-center mb-1">
    <a href="/business_calendar.php?year=<?= $prevYear ?>&month=<?= $prevMonth ?>&region=<?= e($currentRegion) ?>&staff_id=<?= e($currentStaff) ?>&keyword=<?= urlencode($currentKeyword) ?>" class="btn btn-outline btn-sm">&laquo; 上月</a>
    <span style="font-weight:600;font-size:1.1rem"><?= $year ?> 年 <?= $month ?> 月</span>
    <a href="/business_calendar.php?year=<?= date('Y') ?>&month=<?= (int)date('m') ?>&region=<?= e($currentRegion) ?>&staff_id=<?= e($currentStaff) ?>&keyword=<?= urlencode($currentKeyword) ?>" class="btn btn-outline btn-sm">今日</a>
    <a href="/business_calendar.php?year=<?= $nextYear ?>&month=<?= $nextMonth ?>&region=<?= e($currentRegion) ?>&staff_id=<?= e($currentStaff) ?>&keyword=<?= urlencode($currentKeyword) ?>" class="btn btn-outline btn-sm">下月 &raquo;</a>
</div>

<!-- 圖例 -->
<div class="d-flex gap-2 flex-wrap mb-1" style="font-size:.8rem">
    <?php foreach ($activityTypes as $atKey => $atLabel): ?>
    <span><span class="bc-dot" style="background:<?= e(BusinessCalendarModel::activityColor($atKey)) ?>"></span> <?= e($atLabel) ?></span>
    <?php endforeach; ?>
    <span style="color:#2e7d32">&#9632; 休假</span>
</div>

<!-- 行事曆 - 桌面版 -->
<div class="calendar-desktop">
    <div class="bc-calendar-grid">
        <div class="cal-header">日</div>
        <div class="cal-header">一</div>
        <div class="cal-header">二</div>
        <div class="cal-header">三</div>
        <div class="cal-header">四</div>
        <div class="cal-header">五</div>
        <div class="cal-header">六</div>

        <?php for ($i = 0; $i < $startWeekday; $i++): ?>
        <div class="cal-cell cal-empty"></div>
        <?php endfor; ?>

        <?php for ($day = 1; $day <= $daysInMonth; $day++):
            $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $day);
            $dayEvents = isset($events[$day]) ? $events[$day] : array();
            $dayLeaves = isset($leaveByDate[$day]) ? $leaveByDate[$day] : array();
            $isToday = ($dateStr === $today);

            $maxShow = 3;
            $hasMore = count($dayEvents) > $maxShow;
        ?>
        <div class="cal-cell <?= $isToday ? 'cal-today' : '' ?>" data-date="<?= $dateStr ?>" onclick="showDayPopup('<?= $dateStr ?>')" style="cursor:pointer">
            <div class="cal-date">
                <span class="bc-day-link"><?= $day ?></span>
                <span class="cal-date-actions">
                    <a href="/business_calendar.php?action=create&event_date=<?= $dateStr ?>" class="cal-add" title="新增行程" onclick="event.stopPropagation()">+</a>
                </span>
            </div>
            <?php if (!empty($dayLeaves)): ?>
            <div class="bc-leave-bar">
                <?php foreach ($dayLeaves as $lv): ?>
                <span class="bc-leave-tag"><?= e($lv['real_name']) ?> <?= e($lv['leave_type_label']) ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php
            $shown = 0;
            foreach ($dayEvents as $ev):
                if ($shown >= $maxShow && $hasMore) break;
                $shown++;
                $evColor = BusinessCalendarModel::activityColor($ev['activity_type']);
                $evLabel = isset($activityTypes[$ev['activity_type']]) ? $activityTypes[$ev['activity_type']] : $ev['activity_type'];
            ?>
            <a href="/business_calendar.php?action=edit&id=<?= $ev['id'] ?>" class="bc-event" style="border-left:3px solid <?= e($evColor) ?>">
                <div class="bc-event-title"><?= e(mb_substr($ev['customer_name'], 0, 8)) ?></div>
                <div class="bc-event-staff"><?= e($ev['staff_name']) ?></div>
            </a>
            <?php endforeach; ?>
            <?php if ($hasMore): ?>
            <a href="javascript:void(0)" class="cal-more" onclick="showDayPopup('<?= $dateStr ?>')">+<?= count($dayEvents) - $maxShow ?> 更多</a>
            <?php endif; ?>
        </div>
        <?php endfor; ?>
    </div>
</div>

<!-- 行事曆 - 手機版列表 -->
<div class="calendar-mobile">
    <?php for ($day = 1; $day <= $daysInMonth; $day++):
        $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $day);
        $dayEvents = isset($events[$day]) ? $events[$day] : array();
        $dayLeaves = isset($leaveByDate[$day]) ? $leaveByDate[$day] : array();
        if (empty($dayEvents) && empty($dayLeaves) && $dateStr < $today) continue;
        $isToday = ($dateStr === $today);
        $weekdays = array('日','一','二','三','四','五','六');
        $wd = $weekdays[($startWeekday + $day - 1) % 7];
    ?>
    <div class="mobile-day <?= $isToday ? 'mobile-day-today' : '' ?>">
        <div class="mobile-day-header">
            <a href="/business_calendar.php?action=day&date=<?= $dateStr ?>" class="mobile-day-num"><?= $month ?>/<?= $day ?> (<?= $wd ?>)</a>
            <?php if ($isToday): ?><span class="badge badge-primary">今天</span><?php endif; ?>
            <?php if (!empty($dayEvents)): ?>
            <span class="badge badge-info"><?= count($dayEvents) ?> 筆</span>
            <?php endif; ?>
            <div style="margin-left:auto">
                <a href="/business_calendar.php?action=create&event_date=<?= $dateStr ?>" class="btn btn-outline btn-sm" style="padding:2px 6px">+ 行程</a>
            </div>
        </div>
        <?php if (!empty($dayLeaves)): ?>
        <div class="bc-leave-bar">
            <?php foreach ($dayLeaves as $lv): ?>
            <span class="bc-leave-tag"><?= e($lv['real_name']) ?> <?= e($lv['leave_type_label']) ?></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <?php if (empty($dayEvents) && empty($dayLeaves)): ?>
            <p class="text-muted" style="font-size:.85rem;padding:4px 0">無行程</p>
        <?php endif; ?>
        <?php foreach ($dayEvents as $ev):
            $evColor = BusinessCalendarModel::activityColor($ev['activity_type']);
            $evLabel = isset($activityTypes[$ev['activity_type']]) ? $activityTypes[$ev['activity_type']] : $ev['activity_type'];
        ?>
        <a href="/business_calendar.php?action=edit&id=<?= $ev['id'] ?>" class="mobile-schedule-card" style="border-left:3px solid <?= e($evColor) ?>">
            <div class="d-flex justify-between align-center">
                <strong><?= e($ev['customer_name']) ?></strong>
                <span class="bc-badge-type" style="background:<?= e($evColor) ?>"><?= e($evLabel) ?></span>
            </div>
            <div class="mobile-schedule-meta">
                <span><?= e($ev['staff_name']) ?></span>
                <?php if (!empty($ev['phone'])): ?><span><?= e($ev['phone']) ?></span><?php endif; ?>
                <?php if (!empty($ev['region'])): ?><span><?= e($ev['region']) ?></span><?php endif; ?>
                <?php if (!empty($ev['start_time'])): ?><span><?= e(substr($ev['start_time'], 0, 5)) ?></span><?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endfor; ?>
</div>

<script>
function bcApplyFilters() {
    var staff = document.getElementById('bcStaffFilter').value;
    var keyword = document.getElementById('bcKeywordFilter').value;
    var url = '/business_calendar.php?year=<?= $year ?>&month=<?= $month ?>';
    var region = '<?= e($currentRegion) ?>';
    if (region) url += '&region=' + encodeURIComponent(region);
    if (staff) url += '&staff_id=' + staff;
    if (keyword) url += '&keyword=' + encodeURIComponent(keyword);
    window.location.href = url;
}
</script>
