</main>

<script src="/js/app.js"></script>
<script>
// Enter 鍵跳下一格，不送出表單
document.addEventListener('keydown', function(e) {
    if (e.key !== 'Enter') return;
    var el = e.target;
    if (el.tagName === 'TEXTAREA') return; // textarea 允許換行
    if (el.tagName === 'BUTTON' || el.type === 'submit') return; // 按鈕允許送出
    if (el.tagName !== 'INPUT' && el.tagName !== 'SELECT') return;

    e.preventDefault();

    // 找同表單內的下一個可輸入元素
    var form = el.closest('form');
    if (!form) return;
    var inputs = Array.from(form.querySelectorAll('input:not([type="hidden"]):not([disabled]):not([readonly]), select:not([disabled]), textarea:not([disabled])'));
    var idx = inputs.indexOf(el);
    if (idx >= 0 && idx < inputs.length - 1) {
        inputs[idx + 1].focus();
    }
});
</script>
<script>
// ===== 通知系統 =====
var notifOpen = false;
function toggleNotifDropdown() {
    notifOpen = !notifOpen;
    document.getElementById('notifDropdown').style.display = notifOpen ? 'block' : 'none';
    if (notifOpen) loadNotifications();
}
function loadNotifications() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/notifications.php?action=unread');
    xhr.onload = function() {
        try {
            var res = JSON.parse(xhr.responseText);
            if (!res.success) return;
            updateNotifBadge(res.count);
            var list = document.getElementById('notifList');
            if (!res.data || res.data.length === 0) {
                list.innerHTML = '<div style="padding:20px;text-align:center;color:var(--gray-400)">沒有新通知</div>';
                return;
            }
            var html = '';
            for (var i = 0; i < res.data.length; i++) {
                var n = res.data[i];
                var timeAgo = formatTimeAgo(n.created_at);
                html += '<div class="notif-item" data-id="' + n.id + '" onclick="clickNotif(' + n.id + ',\'' + (n.link || '').replace(/'/g, "\\'") + '\')" style="padding:12px 16px;border-bottom:1px solid var(--gray-100);cursor:pointer;background:' + (n.is_read ? '#fff' : '#f0f7ff') + '">';
                html += '<div style="font-weight:' + (n.is_read ? 'normal' : '600') + ';font-size:.9rem">' + escHtml(n.title) + '</div>';
                if (n.message) html += '<div style="color:var(--gray-500);font-size:.8rem;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + escHtml(n.message) + '</div>';
                html += '<div style="color:var(--gray-400);font-size:.75rem;margin-top:4px">' + timeAgo + (n.sender_name ? ' · ' + escHtml(n.sender_name) : '') + '</div>';
                html += '</div>';
            }
            list.innerHTML = html;
        } catch(e) {}
    };
    xhr.send();
}
function clickNotif(id, link) {
    var fd = new FormData();
    fd.append('id', id);
    fd.append('csrf_token', getCSRF());
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/notifications.php?action=read');
    xhr.onload = function() {
        if (link) window.location = link;
        else { loadNotifications(); refreshNotifCount(); }
    };
    xhr.send(fd);
}
function markAllNotifRead() {
    var fd = new FormData();
    fd.append('csrf_token', getCSRF());
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/notifications.php?action=read_all');
    xhr.onload = function() { loadNotifications(); refreshNotifCount(); };
    xhr.send(fd);
}
function refreshNotifCount() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/notifications.php?action=unread');
    xhr.onload = function() {
        try {
            var res = JSON.parse(xhr.responseText);
            if (res.success) updateNotifBadge(res.count);
        } catch(e) {}
    };
    xhr.send();
}
function updateNotifBadge(count) {
    var badge = document.getElementById('notifBadge');
    if (count > 0) {
        badge.textContent = count > 99 ? '99+' : count;
        badge.style.display = 'inline-block';
    } else {
        badge.style.display = 'none';
    }
}
function getCSRF() {
    var el = document.querySelector('input[name="csrf_token"]');
    return el ? el.value : '';
}
function escHtml(s) {
    var d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
}
function formatTimeAgo(dateStr) {
    var d = new Date(dateStr.replace(/-/g, '/'));
    var now = new Date();
    var diff = Math.floor((now - d) / 1000);
    if (diff < 60) return '剛剛';
    if (diff < 3600) return Math.floor(diff / 60) + ' 分鐘前';
    if (diff < 86400) return Math.floor(diff / 3600) + ' 小時前';
    if (diff < 604800) return Math.floor(diff / 86400) + ' 天前';
    return dateStr.substring(0, 10);
}
// 頁面載入和定時刷新
if (document.getElementById('notifBadge')) {
    refreshNotifCount();
    setInterval(refreshNotifCount, 60000);
}
// 點外面關閉
document.addEventListener('click', function(e) {
    if (notifOpen && !e.target.closest('#notifBell') && !e.target.closest('#notifDropdown')) {
        notifOpen = false;
        document.getElementById('notifDropdown').style.display = 'none';
    }
});
</script>
<?php if (!empty($extraJs)): ?>
    <?php foreach ($extraJs as $js): ?>
        <script src="<?= e($js) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>
