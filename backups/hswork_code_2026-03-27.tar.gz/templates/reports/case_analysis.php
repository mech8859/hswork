<?php
$months = isset($analysis['months']) ? $analysis['months'] : array();
$nm = count($months);
$closedStatuses = array('已成交', '跨月成交', '現簽', '電話報價成交');
$progressLabels = CaseModel::progressOptions();

// Helper: pivot 表行合計
function pivotRowTotal($data, $months) {
    $t = 0;
    foreach ($months as $m) { $t += isset($data[$m]) ? $data[$m] : 0; }
    return $t;
}
?>

<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>📊 案件綜合分析</h2>
    <form method="GET" class="d-flex gap-1 align-center">
        <input type="hidden" name="action" value="case_analysis">
        <select name="year" class="form-control" style="width:auto" onchange="this.form.submit()">
            <?php for ($y = (int)date('Y'); $y >= 2024; $y--): ?>
            <option value="<?= $y ?>" <?= $analysis['year'] == $y ? 'selected' : '' ?>><?= ($y - 1911) ?>年 (<?= $y ?>)</option>
            <?php endfor; ?>
        </select>
        <a href="/reports.php" class="btn btn-outline btn-sm">返回報表</a>
    </form>
</div>

<?php if (empty($months)): ?>
<div class="card"><p class="text-muted text-center mt-2">該年度無案件資料</p></div>
<?php else: ?>

<div class="analysis-summary mb-1">
    <span>資料來源：案件管理</span>
    <span>總案件：<b><?= number_format($analysis['total_cases']) ?></b> 筆</span>
    <span>分析月份：<?= $months[0] ?> ～ <?= $months[$nm-1] ?></span>
</div>

<!-- 一、新案 各月數量統計 -->
<?php
$caseTypeLabels = CaseModel::caseTypeOptions();
$caseTypeMonthly = isset($analysis['case_type_monthly']) ? $analysis['case_type_monthly'] : array();
$caseTypeClosedMonthly = isset($analysis['case_type_closed_monthly']) ? $analysis['case_type_closed_monthly'] : array();
$otherTypes = array('addition','old_repair','new_repair','maintenance');
$niData = isset($caseTypeMonthly['new_install']) ? $caseTypeMonthly['new_install'] : array();
$niClosed = isset($caseTypeClosedMonthly['new_install']) ? $caseTypeClosedMonthly['new_install'] : array();
$newEntry = 0; $newClosed = 0;
?>
<div class="card">
    <div class="card-header analysis-header">一、新案 各月數量統計</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>統計項目</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <tr>
                    <td>進件數</td>
                    <?php foreach ($months as $m): $v = isset($niData[$m]) ? $niData[$m] : 0; $newEntry += $v; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($newEntry) ?></td>
                </tr>
                <tr>
                    <td>成交數</td>
                    <?php foreach ($months as $m): $v = isset($niClosed[$m]) ? $niClosed[$m] : 0; $newClosed += $v; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($newClosed) ?></td>
                </tr>
                <tr class="row-highlight">
                    <td>成交率</td>
                    <?php foreach ($months as $m):
                        $e = isset($niData[$m]) ? $niData[$m] : 0;
                        $c = isset($niClosed[$m]) ? $niClosed[$m] : 0;
                    ?>
                    <td><?= $e > 0 ? round($c / $e * 100, 1) . '%' : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= $newEntry > 0 ? round($newClosed / $newEntry * 100, 1) . '%' : '' ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- 二、其他案別 各月數量統計 -->
<div class="card">
    <div class="card-header analysis-header">二、其他案別 各月數量統計</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>統計項目</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <!-- 其他案別進件合計 -->
                <?php $otherEntry = 0; ?>
                <tr style="font-weight:bold; background:#f8f9fa;">
                    <td>進件數（合計）</td>
                    <?php foreach ($months as $m):
                        $v = 0;
                        foreach ($otherTypes as $ot) { $v += isset($caseTypeMonthly[$ot][$m]) ? $caseTypeMonthly[$ot][$m] : 0; }
                        $otherEntry += $v;
                    ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($otherEntry) ?></td>
                </tr>
                <?php foreach ($otherTypes as $ct):
                    $label = isset($caseTypeLabels[$ct]) ? $caseTypeLabels[$ct] : $ct;
                    $data = isset($caseTypeMonthly[$ct]) ? $caseTypeMonthly[$ct] : array();
                    $rowTotal = 0;
                ?>
                <tr>
                    <td style="padding-left:24px; color:#666;">└ <?= e($label) ?></td>
                    <?php foreach ($months as $m): $v = isset($data[$m]) ? $data[$m] : 0; $rowTotal += $v; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= $rowTotal ?: '' ?></td>
                </tr>
                <?php endforeach; ?>

                <!-- 其他案別成交合計 -->
                <?php $otherClosed = 0; ?>
                <tr style="font-weight:bold; background:#f8f9fa;">
                    <td>成交數（合計）</td>
                    <?php foreach ($months as $m):
                        $v = 0;
                        foreach ($otherTypes as $ot) { $v += isset($caseTypeClosedMonthly[$ot][$m]) ? $caseTypeClosedMonthly[$ot][$m] : 0; }
                        $otherClosed += $v;
                    ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($otherClosed) ?></td>
                </tr>
                <?php foreach ($otherTypes as $ct):
                    $label = isset($caseTypeLabels[$ct]) ? $caseTypeLabels[$ct] : $ct;
                    $data = isset($caseTypeClosedMonthly[$ct]) ? $caseTypeClosedMonthly[$ct] : array();
                    $rowTotal = 0;
                ?>
                <tr>
                    <td style="padding-left:24px; color:#666;">└ <?= e($label) ?></td>
                    <?php foreach ($months as $m): $v = isset($data[$m]) ? $data[$m] : 0; $rowTotal += $v; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= $rowTotal ?: '' ?></td>
                </tr>
                <?php endforeach; ?>

                <tr class="row-highlight">
                    <td>成交率</td>
                    <?php foreach ($months as $m):
                        $oE = 0; $oC = 0;
                        foreach ($otherTypes as $ot) {
                            $oE += isset($caseTypeMonthly[$ot][$m]) ? $caseTypeMonthly[$ot][$m] : 0;
                            $oC += isset($caseTypeClosedMonthly[$ot][$m]) ? $caseTypeClosedMonthly[$ot][$m] : 0;
                        }
                    ?>
                    <td><?= $oE > 0 ? round($oC / $oE * 100, 1) . '%' : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= $otherEntry > 0 ? round($otherClosed / $otherEntry * 100, 1) . '%' : '' ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- 三、全部案件 各月數量統計 -->
<div class="card">
    <div class="card-header analysis-header">三、全部案件 各月數量統計</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>統計項目</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <tr>
                    <td>進件數</td>
                    <?php $totalEntry = 0; foreach ($months as $m): $v = isset($analysis['monthly_entry'][$m]) ? $analysis['monthly_entry'][$m] : 0; $totalEntry += $v; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($totalEntry) ?></td>
                </tr>
                <tr>
                    <td>成交數</td>
                    <?php $totalClosed = 0; foreach ($months as $m): $v = isset($analysis['monthly_closed'][$m]) ? $analysis['monthly_closed'][$m] : 0; $totalClosed += $v; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($totalClosed) ?></td>
                </tr>
                <tr class="row-highlight">
                    <td>成交率</td>
                    <?php foreach ($months as $m):
                        $e = isset($analysis['monthly_entry'][$m]) ? $analysis['monthly_entry'][$m] : 0;
                        $c = isset($analysis['monthly_closed'][$m]) ? $analysis['monthly_closed'][$m] : 0;
                    ?>
                    <td><?= $e > 0 ? round($c / $e * 100, 1) . '%' : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= $totalEntry > 0 ? round($totalClosed / $totalEntry * 100, 1) . '%' : '' ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- 二、各月金額統計 -->
<div class="card">
    <div class="card-header analysis-header">四、各月金額統計（元）</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>統計項目</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <?php
                $amtLabels = array(
                    'total_amount' => '含稅成交金額',
                    'quote_amount' => '報價金額',
                    'deposit_amount' => '訂金金額',
                    'completion_amount' => '完工金額(含稅)',
                    'balance_amount' => '尾款',
                    'total_collected' => '總收款金額',
                );
                foreach ($amtLabels as $key => $label):
                    $rowTotal = 0;
                ?>
                <tr>
                    <td><?= $label ?></td>
                    <?php foreach ($months as $m):
                        $v = isset($analysis['monthly_amounts'][$m][$key]) ? $analysis['monthly_amounts'][$m][$key] : 0;
                        $rowTotal += $v;
                    ?>
                    <td><?= $v > 0 ? number_format($v) : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= $rowTotal > 0 ? number_format($rowTotal) : '' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- 三、分公司 × 月份 -->
<?php if (!empty($analysis['branch_monthly'])): ?>
<div class="card">
    <div class="card-header analysis-header">五、分公司 × 月份 進件數</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>分公司</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
                <th>佔比</th>
            </tr></thead>
            <tbody>
                <?php
                $grandTotal = $analysis['total_cases'];
                foreach ($analysis['branch_monthly'] as $name => $mdata):
                    $rt = pivotRowTotal($mdata, $months);
                ?>
                <tr>
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                    <td><?= $grandTotal > 0 ? round($rt / $grandTotal * 100, 1) . '%' : '' ?></td>
                </tr>
                <?php endforeach; ?>
                <tr class="row-total">
                    <td>合計</td>
                    <?php foreach ($months as $m): $ct = 0; foreach ($analysis['branch_monthly'] as $d) { $ct += isset($d[$m]) ? $d[$m] : 0; } ?>
                    <td><?= $ct ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($grandTotal) ?></td>
                    <td>100%</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 三b、分公司 × 月份 成交金額 -->
<?php if (!empty($analysis['branch_monthly_amounts'])): ?>
<div class="card">
    <div class="card-header analysis-header">五b、分公司 × 月份 成交金額（元）</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>分公司</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <?php
                $amtGrandTotals = array();
                foreach ($analysis['branch_monthly_amounts'] as $name => $mdata):
                    $rt = 0;
                    foreach ($months as $m) { $v = isset($mdata[$m]) ? $mdata[$m] : 0; $rt += $v; if (!isset($amtGrandTotals[$m])) $amtGrandTotals[$m] = 0; $amtGrandTotals[$m] += $v; }
                    if ($rt == 0) continue; // 無成交金額的分公司不顯示
                ?>
                <tr>
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v > 0 ? number_format($v) : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                </tr>
                <?php endforeach; ?>
                <tr class="row-total">
                    <td>合計</td>
                    <?php $amtGrand = 0; foreach ($months as $m): $ct = isset($amtGrandTotals[$m]) ? $amtGrandTotals[$m] : 0; $amtGrand += $ct; ?>
                    <td><?= $ct > 0 ? number_format($ct) : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($amtGrand) ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 四、案件狀態(sub_status) × 月份 -->
<?php if (!empty($analysis['status_monthly'])): ?>
<div class="card">
    <div class="card-header analysis-header">六、案件狀態 × 月份</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>狀態</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
                <th>佔比</th>
            </tr></thead>
            <tbody>
                <?php
                $statusGrand = 0;
                foreach ($analysis['status_monthly'] as $d) { foreach ($months as $m) { $statusGrand += isset($d[$m]) ? $d[$m] : 0; } }
                foreach ($analysis['status_monthly'] as $name => $mdata):
                    $rt = pivotRowTotal($mdata, $months);
                    $rowClass = in_array($name, $closedStatuses) ? 'row-ok' : (in_array($name, array('無效','客戶毀約','已報價無意願')) ? 'row-bad' : '');
                ?>
                <tr class="<?= $rowClass ?>">
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                    <td><?= $statusGrand > 0 ? round($rt / $statusGrand * 100, 1) . '%' : '' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 五、案件進度 × 月份 -->
<?php if (!empty($analysis['progress_monthly'])): ?>
<div class="card">
    <div class="card-header analysis-header">七、案件進度 × 月份</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>進度</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
                <th>佔比</th>
            </tr></thead>
            <tbody>
                <?php
                foreach ($analysis['progress_monthly'] as $key => $mdata):
                    $rt = pivotRowTotal($mdata, $months);
                    $label = isset($progressLabels[$key]) ? $progressLabels[$key] : $key;
                ?>
                <tr>
                    <td><?= e($label) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                    <td><?= $grandTotal > 0 ? round($rt / $grandTotal * 100, 1) . '%' : '' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 六、案件來源 × 月份 -->
<?php if (!empty($analysis['source_monthly'])): ?>
<div class="card">
    <div class="card-header analysis-header">八、案件來源 × 月份</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>來源</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <?php foreach ($analysis['source_monthly'] as $name => $mdata): $rt = pivotRowTotal($mdata, $months); ?>
                <tr>
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 七、業務進件數 × 月份 -->
<?php if (!empty($analysis['sales_cases'])): ?>
<div class="card">
    <div class="card-header analysis-header">九、業務人員 × 月份 進件數</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>業務</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <?php foreach ($analysis['sales_cases'] as $name => $mdata): $rt = pivotRowTotal($mdata, $months); ?>
                <tr>
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 八、業務成交金額 × 月份 -->
<?php if (!empty($analysis['sales_amount'])): ?>
<div class="card">
    <div class="card-header analysis-header">十、業務人員 × 月份 含稅成交金額（元）</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>業務</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <?php foreach ($analysis['sales_amount'] as $name => $mdata): $rt = pivotRowTotal($mdata, $months); ?>
                <tr>
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v > 0 ? number_format($v) : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 九、業務成交件數 × 月份 -->
<?php if (!empty($analysis['sales_closed'])): ?>
<div class="card">
    <div class="card-header analysis-header">十一、業務人員 × 月份 成交案件數</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>業務</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <?php foreach ($analysis['sales_closed'] as $name => $mdata): $rt = pivotRowTotal($mdata, $months); ?>
                <tr>
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 十、業務績效排名 -->
<?php if (!empty($analysis['sales_ranking'])): ?>
<div class="card">
    <div class="card-header analysis-header">十二、業務人員績效排名</div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>排名</th><th>業務</th><th>分公司</th><th>進件數</th><th>成交數</th><th>成交率</th><th>含稅金額合計</th><th>平均成交金額</th>
            </tr></thead>
            <tbody>
                <?php
                $rank = 0;
                $gtTotal = 0; $gtClosed = 0; $gtAmt = 0;
                foreach ($analysis['sales_ranking'] as $name => $s):
                    $rank++;
                    $rate = $s['total'] > 0 ? round($s['closed'] / $s['total'] * 100, 1) : 0;
                    $avg = $s['closed'] > 0 ? round($s['amount'] / $s['closed']) : 0;
                    $medalClass = $rank <= 3 ? 'rank-' . $rank : '';
                    $gtTotal += $s['total']; $gtClosed += $s['closed']; $gtAmt += $s['amount'];
                ?>
                <tr class="<?= $medalClass ?>">
                    <td><?= $rank ?></td>
                    <td><?= e($name) ?></td>
                    <td><?= e($s['branch'] ?: '') ?></td>
                    <td><?= number_format($s['total']) ?></td>
                    <td><?= number_format($s['closed']) ?></td>
                    <td><?= $rate ?>%</td>
                    <td><?= number_format($s['amount']) ?></td>
                    <td><?= number_format($avg) ?></td>
                </tr>
                <?php endforeach; ?>
                <tr class="row-total">
                    <td></td><td>合計</td><td></td>
                    <td><?= number_format($gtTotal) ?></td>
                    <td><?= number_format($gtClosed) ?></td>
                    <td><?= $gtTotal > 0 ? round($gtClosed / $gtTotal * 100, 1) : 0 ?>%</td>
                    <td><?= number_format($gtAmt) ?></td>
                    <td><?= $gtClosed > 0 ? number_format(round($gtAmt / $gtClosed)) : '' ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 十一、業務各月收款金額（收款單） -->
<?php if (!empty($analysis['sales_receipt'])): ?>
<div class="card">
    <div class="card-header analysis-header">十三、業務人員 × 月份 收款金額（元）<small style="opacity:.8;margin-left:8px">資料來源：收款單</small></div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>業務</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <?php
                $receiptGrandTotals = array();
                foreach ($analysis['sales_receipt'] as $name => $mdata):
                    $rt = pivotRowTotal($mdata, $months);
                    foreach ($months as $m) {
                        $v = isset($mdata[$m]) ? $mdata[$m] : 0;
                        if (!isset($receiptGrandTotals[$m])) $receiptGrandTotals[$m] = 0;
                        $receiptGrandTotals[$m] += $v;
                    }
                ?>
                <tr>
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v > 0 ? number_format($v) : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                </tr>
                <?php endforeach; ?>
                <tr class="row-total">
                    <td>合計</td>
                    <?php $receiptGrand = 0; foreach ($months as $m): $ct = isset($receiptGrandTotals[$m]) ? $receiptGrandTotals[$m] : 0; $receiptGrand += $ct; ?>
                    <td><?= $ct > 0 ? number_format($ct) : '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($receiptGrand) ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 十二、業務各月收款筆數（收款單） -->
<?php if (!empty($analysis['sales_receipt_count'])): ?>
<div class="card">
    <div class="card-header analysis-header">十四、業務人員 × 月份 收款筆數<small style="opacity:.8;margin-left:8px">資料來源：收款單</small></div>
    <div class="table-responsive">
        <table class="table table-sm analysis-table">
            <thead><tr>
                <th>業務</th>
                <?php foreach ($months as $m): ?><th><?= substr($m, 5) ?>月</th><?php endforeach; ?>
                <th class="col-total">合計</th>
            </tr></thead>
            <tbody>
                <?php
                $cntGrandTotals = array();
                foreach ($analysis['sales_receipt_count'] as $name => $mdata):
                    $rt = pivotRowTotal($mdata, $months);
                    foreach ($months as $m) {
                        $v = isset($mdata[$m]) ? $mdata[$m] : 0;
                        if (!isset($cntGrandTotals[$m])) $cntGrandTotals[$m] = 0;
                        $cntGrandTotals[$m] += $v;
                    }
                ?>
                <tr>
                    <td><?= e($name) ?></td>
                    <?php foreach ($months as $m): $v = isset($mdata[$m]) ? $mdata[$m] : 0; ?>
                    <td><?= $v ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($rt) ?></td>
                </tr>
                <?php endforeach; ?>
                <tr class="row-total">
                    <td>合計</td>
                    <?php $cntGrand = 0; foreach ($months as $m): $ct = isset($cntGrandTotals[$m]) ? $cntGrandTotals[$m] : 0; $cntGrand += $ct; ?>
                    <td><?= $ct ?: '' ?></td>
                    <?php endforeach; ?>
                    <td class="col-total"><?= number_format($cntGrand) ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php endif; ?>

<style>
.analysis-summary { font-size: .85rem; color: var(--gray-500); display: flex; gap: 16px; flex-wrap: wrap; }
.analysis-header { background: var(--primary); color: #fff; font-weight: 600; }
.analysis-table { font-size: .8rem; white-space: nowrap; }
.analysis-table th { background: var(--gray-100); font-weight: 600; text-align: center; padding: 6px 8px; }
.analysis-table td { text-align: center; padding: 4px 8px; }
.analysis-table td:first-child, .analysis-table th:first-child { text-align: left; position: sticky; left: 0; background: #fff; z-index: 1; }
.analysis-table thead th:first-child { background: var(--gray-100); z-index: 2; }
.col-total { font-weight: 600; background: #fef3e2 !important; }
.row-total td { font-weight: 600; background: #fef3e2 !important; border-top: 2px solid var(--gray-300); }
.row-highlight td { background: #e8f5e9; font-weight: 600; }
.row-ok td { background: #e8f5e9; }
.row-bad td { background: #fce4ec; }
.rank-1 td { background: #fff8e1; }
.rank-2 td { background: #f5f5f5; }
.rank-3 td { background: #fbe9e7; }
</style>
