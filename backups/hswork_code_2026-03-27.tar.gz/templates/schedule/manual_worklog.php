<?php
    $isEdit = !empty($isEditMode) && !empty($editWorklog);
    $ewl = $isEdit ? $editWorklog : array();
    $ewlPhotos = array();
    if ($isEdit && !empty($ewl['photo_paths'])) {
        $decoded = json_decode($ewl['photo_paths'], true);
        if (is_array($decoded)) $ewlPhotos = $decoded;
    }
?>
<div class="d-flex justify-between align-center mb-2">
    <h2><?= $isEdit ? '編輯施工回報' : '手動施工回報' ?></h2>
    <a href="/cases.php?action=edit&id=<?= $caseId ?>#sec-worklog" class="btn btn-outline btn-sm">← 返回案件</a>
</div>

<div class="card mb-2">
    <div class="card-header">案件資訊</div>
    <div style="padding:12px">
        <strong><?= e($caseData['customer_name'] ?? '') ?></strong>
        <span class="text-muted" style="margin-left:8px"><?= e($caseData['title'] ?? '') ?></span>
    </div>
</div>

<form method="POST" action="/worklog.php?action=<?= $isEdit ? 'update_manual_report' : 'save_manual_report' ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="case_id" value="<?= $caseId ?>">
    <?php if ($isEdit): ?><input type="hidden" name="worklog_id" value="<?= $ewl['id'] ?>"><?php endif; ?>

    <div class="card mb-2">
        <div class="card-header">施工時間</div>
        <div style="padding:12px">
            <div class="form-row" style="display:flex;gap:12px;flex-wrap:wrap">
                <div class="form-group" style="flex:1;min-width:140px">
                    <label>施工日期 *</label>
                    <input type="date" name="work_date" class="form-control" value="<?= $isEdit ? e($ewl['work_date']) : date('Y-m-d') ?>" required>
                </div>
                <div class="form-group" style="flex:1;min-width:120px">
                    <label>上工時間</label>
                    <input type="time" name="arrival_time" class="form-control">
                </div>
                <div class="form-group" style="flex:1;min-width:120px">
                    <label>下工時間</label>
                    <input type="time" name="departure_time" class="form-control">
                </div>
            </div>
        </div>
    </div>

    <div class="card mb-2">
        <div class="card-header">施作說明</div>
        <div style="padding:12px">
            <div class="form-group">
                <label>施工內容 *</label>
                <textarea name="work_content" class="form-control" rows="4" placeholder="施工項目、使用設備等" required><?= $isEdit ? e($ewl['work_content']) : '' ?></textarea>
            </div>
            <div class="form-group">
                <label>問題/異常</label>
                <textarea name="issues" class="form-control" rows="3" placeholder="如有遇到問題或異常請填寫"><?= $isEdit ? e($ewl['equipment_used'] ?? '') : '' ?></textarea>
            </div>
            <div style="margin:12px 0">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;color:var(--success)">
                    <input type="checkbox" name="is_completed" value="1"> 已完工
                </label>
            </div>
            <div style="margin:12px 0">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                    <input type="checkbox" name="next_visit_needed" value="1" onchange="document.getElementById('nextVisitOpts').style.display=this.checked?'block':'none'"> 需要再次施工
                </label>
                <div id="nextVisitOpts" style="display:none;margin-top:8px;padding-left:24px">
                    <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
                        <label><input type="radio" name="next_visit_type" value="scheduled"> 預計日期：</label>
                        <input type="date" name="next_visit_date" class="form-control" style="width:auto">
                        <label><input type="radio" name="next_visit_type" value="pending" checked> 待安排</label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mb-2">
        <div class="card-header">施工照片</div>
        <div style="padding:12px">
            <?php if ($isEdit && !empty($ewlPhotos)): ?>
            <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px">
                <?php foreach ($ewlPhotos as $pp): ?>
                <img src="<?= e($pp) ?>" style="width:100px;height:100px;object-fit:cover;border-radius:6px;cursor:pointer" onclick="window.open('<?= e($pp) ?>')">
                <?php endforeach; ?>
            </div>
            <small class="text-muted" style="display:block;margin-bottom:8px">上方為現有照片，下方可追加新照片</small>
            <?php endif; ?>
            <input type="file" name="photos[]" multiple accept="image/*" class="form-control">
            <small class="text-muted">可選擇多張照片（支援 JPG/PNG/GIF/WebP）</small>
        </div>
    </div>

    <div class="card mb-2">
        <div class="card-header">收款資訊</div>
        <div style="padding:12px">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                <input type="checkbox" name="payment_collected" value="1" onchange="document.getElementById('paymentFields').style.display=this.checked?'flex':'none'"> 本次有收款
            </label>
            <div id="paymentFields" style="display:none;margin-top:8px;gap:12px;flex-wrap:wrap">
                <div class="form-group" style="flex:1;min-width:120px">
                    <label>收款金額</label>
                    <input type="number" name="payment_amount" class="form-control" min="0">
                </div>
                <div class="form-group" style="flex:1;min-width:120px">
                    <label>收款方式</label>
                    <select name="payment_method" class="form-control">
                        <option value="cash">現金</option>
                        <option value="transfer">匯款</option>
                        <option value="check">支票</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary" style="width:100%;padding:12px;font-size:1.1rem"><?= $isEdit ? '更新回報' : '儲存回報' ?></button>
</form>
