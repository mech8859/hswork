<?php
$isEdit = !empty($record);
$statusOptions = InvoiceModel::invoiceStatusOptions();
$typeOptions = InvoiceModel::salesInvoiceTypeOptions();
$refOptions = InvoiceModel::salesReferenceTypeOptions();
?>

<h2><?= $isEdit ? '編輯銷項發票 - ' . e($record['invoice_number']) : '新增銷項發票' ?></h2>

<form method="POST" class="mt-2" id="salesInvoiceForm">
    <?= csrf_field() ?>

    <!-- 發票資訊 -->
    <div class="card">
        <div class="card-header">發票資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>申報年月</label>
                <input type="month" name="report_period" class="form-control"
                       value="<?= e($isEdit && !empty($record['report_period']) ? $record['report_period'] : date('Y-m')) ?>">
            </div>
            <div class="form-group">
                <label>銷項發票聯式</label>
                <select name="invoice_format" class="form-control">
                    <option value="">請選擇</option>
                    <option value="31" <?= ($isEdit && !empty($record['invoice_format']) && $record['invoice_format'] === '31') ? 'selected' : '' ?>>31：銷項三聯式、電子計算機統一發票</option>
                    <option value="32" <?= ($isEdit && !empty($record['invoice_format']) && $record['invoice_format'] === '32') ? 'selected' : '' ?>>32：銷項二聯式、二聯式收銀機統一發票</option>
                    <option value="33" <?= ($isEdit && !empty($record['invoice_format']) && $record['invoice_format'] === '33') ? 'selected' : '' ?>>33：三聯式銷貨退回或折讓證明單</option>
                    <option value="34" <?= ($isEdit && !empty($record['invoice_format']) && $record['invoice_format'] === '34') ? 'selected' : '' ?>>34：二聯式銷貨退回或折讓證明單</option>
                    <option value="35" <?= ($isEdit && !empty($record['invoice_format']) && $record['invoice_format'] === '35') ? 'selected' : '' ?>>35：銷項三聯式收銀機統一發票、電子發票</option>
                </select>
            </div>
            <div class="form-group">
                <label>扣抵別</label>
                <select name="deduction_category" class="form-control">
                    <option value="">請選擇</option>
                    <option value="deductible_purchase" <?= ($isEdit && !empty($record['deduction_category']) && $record['deduction_category'] === 'deductible_purchase') ? 'selected' : '' ?>>可扣抵之進貨及費用</option>
                    <option value="deductible_asset" <?= ($isEdit && !empty($record['deduction_category']) && $record['deduction_category'] === 'deductible_asset') ? 'selected' : '' ?>>可扣抵之固定資產</option>
                    <option value="non_deductible" <?= ($isEdit && !empty($record['deduction_category']) && $record['deduction_category'] === 'non_deductible') ? 'selected' : '' ?>>不可扣抵之進貨及費用</option>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>發票號碼 *</label>
                <input type="text" name="invoice_number" class="form-control"
                       value="<?= e($isEdit && !empty($record['invoice_number']) ? $record['invoice_number'] : '') ?>"
                       required placeholder="例: AB-12345678">
            </div>
            <div class="form-group">
                <label>發票日期 *</label>
                <input type="date" max="2099-12-31" name="invoice_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['invoice_date']) ? $record['invoice_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>發票類型</label>
                <select name="invoice_type" id="fldInvoiceType" class="form-control" onchange="onTypeChange()">
                    <?php foreach ($typeOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && !empty($record['invoice_type']) ? $record['invoice_type'] : '三聯式') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($isEdit): ?>
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <?php foreach ($statusOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= (!empty($record['status']) ? $record['status'] : 'pending') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- 客戶資訊 -->
    <div class="card">
        <div class="card-header">客戶資訊</div>
        <!-- 隱藏的客戶資料供 JS 查詢 -->
        <script>
        var customerData = [
            <?php foreach ($customers as $c): ?>
            {taxId: <?= json_encode(!empty($c['tax_id']) ? trim($c['tax_id']) : '') ?>, title: <?= json_encode(!empty($c['invoice_title']) ? trim($c['invoice_title']) : (!empty($c['name']) ? trim($c['name']) : '')) ?>},
            <?php endforeach; ?>
        ];
        console.log('customerData loaded:', customerData.length, 'records');
        function onSalesTaxIdInput(el) {
            var taxId = el.value.trim();
            if (taxId.length === 8) {
                for (var i = 0; i < customerData.length; i++) {
                    if (customerData[i].taxId === taxId) {
                        document.getElementById('fldCustomerName').value = customerData[i].title;
                        return;
                    }
                }
            }
        }
        </script>
        <div class="form-row">
            <div class="form-group">
                <label>統一編號 *</label>
                <input type="text" name="customer_tax_id" id="fldCustomerTaxId" class="form-control"
                       value="<?= e($isEdit && !empty($record['customer_tax_id']) ? $record['customer_tax_id'] : '') ?>"
                       maxlength="8" placeholder="8碼統編" required oninput="onSalesTaxIdInput(this)">
            </div>
            <div class="form-group">
                <label>發票抬頭 *</label>
                <input type="text" name="customer_name" id="fldCustomerName" class="form-control"
                       value="<?= e($isEdit && !empty($record['customer_name']) ? $record['customer_name'] : '') ?>" required>
            </div>
        </div>
    </div>

    <!-- 金額 -->
    <div class="card">
        <div class="card-header">金額</div>
        <div class="form-row">
            <div class="form-group">
                <label>未稅金額 *</label>
                <input type="number" name="amount_untaxed" id="fldUntaxed" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['amount_untaxed']) ? (int)$record['amount_untaxed'] : '' ?>"
                       oninput="calcTax()" required>
            </div>
            <div class="form-group">
                <label>稅額</label>
                <input type="number" name="tax_amount" id="fldTaxAmt" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['tax_amount']) ? (int)$record['tax_amount'] : '' ?>"
                       oninput="calcTotal()">
            </div>
            <div class="form-group">
                <label>含稅金額</label>
                <input type="number" name="total_amount" id="fldTotal" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['total_amount']) ? (int)$record['total_amount'] : '' ?>" readonly>
            </div>
            <input type="hidden" name="tax_rate" id="fldTaxRate" value="<?= $isEdit && isset($record['tax_rate']) ? $record['tax_rate'] : 5 ?>">
        </div>
    </div>

    <!-- 關聯單據 -->
    <div class="card">
        <div class="card-header">關聯單據</div>
        <div class="form-row">
            <div class="form-group">
                <label>關聯類型</label>
                <select name="reference_type" class="form-control">
                    <?php foreach ($refOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && (!empty($record['reference_type']) ? $record['reference_type'] : '') === $k) ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>關聯單據編號</label>
                <input type="text" name="reference_id" class="form-control"
                       value="<?= e($isEdit && !empty($record['reference_id']) ? $record['reference_id'] : '') ?>"
                       placeholder="選填">
            </div>
        </div>
    </div>

    <!-- 備註 -->
    <div class="card">
        <div class="card-header">備註</div>
        <div class="form-group">
            <textarea name="note" class="form-control" rows="3"><?= e($isEdit && !empty($record['note']) ? $record['note'] : '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '新增銷項發票' ?></button>
        <a href="/sales_invoices.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
// onCustomerSelect removed - replaced by onSalesTaxIdInput

function onTypeChange() {
    var type = document.getElementById('fldInvoiceType').value;
    if (type === '免稅') {
        document.getElementById('fldTaxAmt').value = 0;
        document.getElementById('fldTaxRate').value = 0;
    } else {
        document.getElementById('fldTaxRate').value = 5;
    }
    calcTax();
}

function calcTax() {
    var untaxed = parseInt(document.getElementById('fldUntaxed').value) || 0;
    var type = document.getElementById('fldInvoiceType').value;
    var tax = 0;
    if (type !== '免稅' && type !== '零稅率') {
        tax = Math.round(untaxed * 0.05);
    }
    document.getElementById('fldTaxAmt').value = tax || '';
    calcTotal();
}

function calcTotal() {
    var untaxed = parseInt(document.getElementById('fldUntaxed').value) || 0;
    var tax = parseInt(document.getElementById('fldTaxAmt').value) || 0;
    document.getElementById('fldTotal').value = (untaxed + tax) || '';
}
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
</style>
