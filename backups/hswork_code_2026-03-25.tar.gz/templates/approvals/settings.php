<div class="d-flex justify-between align-center mb-2">
    <h2>簽核設定</h2>
    <a href="/approvals.php" class="btn btn-outline btn-sm">← 待簽核清單</a>
</div>

<!-- 新增規則 -->
<div class="card mb-2">
    <div class="card-header">新增簽核規則</div>
    <form method="POST" action="/approvals.php?action=save_rule">
        <?= csrf_field() ?>
        <div class="form-row">
            <div class="form-group">
                <label>模組 *</label>
                <select name="module" class="form-control" required>
                    <option value="quotations">報價單</option>
                    <option value="expenses">支出單</option>
                    <option value="purchases">請購單</option>
                    <option value="leaves">請假單</option>
                    <option value="overtime">加班單</option>
                    <option value="case_completion">完工簽核</option>
                </select>
            </div>
            <div class="form-group" style="flex:2">
                <label>規則名稱 *</label>
                <input type="text" name="rule_name" class="form-control" placeholder="例：10萬以下免簽核、30萬以上需經理簽核" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>最低金額</label>
                <input type="number" name="min_amount" class="form-control" value="0" min="0">
            </div>
            <div class="form-group">
                <label>最高金額（空=無上限）</label>
                <input type="number" name="max_amount" class="form-control" min="0">
            </div>
            <div class="form-group">
                <label>最低利潤率 %（選填）</label>
                <input type="number" name="min_profit_rate" class="form-control" step="0.1" min="0" max="100">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>簽核人角色</label>
                <select name="approver_role" class="form-control">
                    <option value="">不指定角色</option>
                    <option value="boss">老闆/總經理</option>
                    <option value="sales_manager">業務經理</option>
                    <option value="eng_manager">工程主管</option>
                    <option value="eng_deputy">工程副主管</option>
                    <option value="admin_staff">行政人員(會計)</option>
                </select>
            </div>
            <div class="form-group">
                <label>或指定簽核人</label>
                <select name="approver_id" class="form-control">
                    <option value="">不指定人</option>
                    <?php foreach ($approvers as $ap): ?>
                    <option value="<?= $ap['id'] ?>"><?= e($ap['real_name']) ?> (<?= e(ApprovalModel::roleLabel($ap['role'])) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="flex:0 0 100px">
                <label>簽核順序</label>
                <input type="number" name="level_order" class="form-control" value="1" min="1" max="10">
            </div>
        </div>
        <button type="submit" class="btn btn-primary">新增規則</button>
    </form>
</div>

<!-- 現有規則 -->
<div class="card">
    <div class="card-header">現有規則</div>
    <?php if (empty($rules)): ?>
    <p class="text-muted text-center" style="padding:20px">尚未設定簽核規則。未設定規則的模組，送簽核將自動通過。</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table" style="font-size:.85rem">
            <thead>
                <tr>
                    <th>模組</th>
                    <th>規則名稱</th>
                    <th>金額區間</th>
                    <th>利潤率</th>
                    <th>簽核人</th>
                    <th>順序</th>
                    <th>狀態</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rules as $rule): ?>
                <tr>
                    <td><span class="badge badge-primary"><?= e(ApprovalModel::moduleLabel($rule['module'])) ?></span></td>
                    <td><?= e($rule['rule_name']) ?></td>
                    <td>
                        $<?= number_format($rule['min_amount']) ?>
                        ~ <?= $rule['max_amount'] !== null ? '$' . number_format($rule['max_amount']) : '無上限' ?>
                    </td>
                    <td><?= $rule['min_profit_rate'] !== null ? $rule['min_profit_rate'] . '%' : '-' ?></td>
                    <td>
                        <?php if ($rule['approver_name']): ?>
                            <?= e($rule['approver_name']) ?>
                        <?php elseif ($rule['approver_role']): ?>
                            <?= e(ApprovalModel::roleLabel($rule['approver_role'])) ?>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><?= $rule['level_order'] ?></td>
                    <td><?= $rule['is_active'] ? '<span style="color:green">啟用</span>' : '<span style="color:#999">停用</span>' ?></td>
                    <td>
                        <a href="/approvals.php?action=delete_rule&id=<?= $rule['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>"
                           class="btn btn-danger btn-sm" onclick="return confirm('確定刪除此規則？')">刪除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
</style>
