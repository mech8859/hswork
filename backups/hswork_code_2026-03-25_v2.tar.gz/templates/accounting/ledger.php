<div class="page-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
    <h1>總帳查詢</h1>
    <div style="display:flex;gap:8px">
        <a href="/accounting.php?action=journals" class="btn btn-secondary">傳票管理</a>
        <a href="/accounting.php?action=trial_balance" class="btn btn-secondary">試算表</a>
    </div>
</div>

<!-- Query Form -->
<div class="card" style="padding:16px;margin-bottom:16px">
    <form method="get" action="/accounting.php" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
        <input type="hidden" name="action" value="ledger">
        <div>
            <label style="font-size:0.85em">會計科目</label>
            <select name="account_id" class="form-control" style="width:250px" required>
                <option value="">-- 選擇科目 --</option>
                <?php foreach ($accounts as $a): ?>
                <option value="<?= $a['id'] ?>" <?= $accountId == $a['id'] ? 'selected' : '' ?>><?= e($a['code']) ?> <?= e($a['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label style="font-size:0.85em">起始日期</label>
            <input type="date" name="start_date" value="<?= e($startDate) ?>" class="form-control" style="width:140px" required>
        </div>
        <div>
            <label style="font-size:0.85em">結束日期</label>
            <input type="date" name="end_date" value="<?= e($endDate) ?>" class="form-control" style="width:140px" required>
        </div>
        <div>
            <label style="font-size:0.85em">成本中心</label>
            <select name="cost_center_id" class="form-control" style="width:150px">
                <option value="">全部</option>
                <?php foreach ($costCenters as $cc): ?>
                <option value="<?= $cc['id'] ?>" <?= $costCenterId == $cc['id'] ? 'selected' : '' ?>><?= e($cc['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">查詢</button>
    </form>
</div>

<?php if ($accountId && $selectedAccount): ?>
<!-- Account Info -->
<div class="card" style="padding:12px;margin-bottom:16px;background:#f8f9fa">
    <strong><?= e($selectedAccount['code']) ?> <?= e($selectedAccount['name']) ?></strong>
    <span style="margin-left:12px;color:#666">
        正常餘額: <?= $selectedAccount['normal_balance'] === 'debit' ? '借方' : '貸方' ?>
    </span>
    <span style="margin-left:12px;color:#666">
        期間: <?= e(format_date($startDate)) ?> ~ <?= e(format_date($endDate)) ?>
    </span>
</div>

<!-- Ledger Table -->
<div class="card" style="overflow-x:auto">
    <table class="data-table" style="width:100%">
        <thead>
            <tr>
                <th style="width:100px">日期</th>
                <th style="width:120px">傳票號碼</th>
                <th>摘要</th>
                <th>成本中心</th>
                <th style="width:110px;text-align:right">借方</th>
                <th style="width:110px;text-align:right">貸方</th>
                <th style="width:120px;text-align:right">餘額</th>
            </tr>
        </thead>
        <tbody>
            <!-- Opening Balance -->
            <tr style="background:#f0f0f0;font-weight:bold">
                <td colspan="4">期初餘額</td>
                <td style="text-align:right"></td>
                <td style="text-align:right"></td>
                <td style="text-align:right"><?= number_format($openingBalance, 2) ?></td>
            </tr>
            <?php
            $runningBalance = $openingBalance;
            $periodDebit = 0;
            $periodCredit = 0;
            foreach ($ledgerEntries as $le):
                $debit = (float)$le['debit_amount'];
                $credit = (float)$le['credit_amount'];
                $periodDebit += $debit;
                $periodCredit += $credit;
                if ($selectedAccount['normal_balance'] === 'debit') {
                    $runningBalance += $debit - $credit;
                } else {
                    $runningBalance += $credit - $debit;
                }
            ?>
            <tr>
                <td><?= e(format_date($le['voucher_date'])) ?></td>
                <td><a href="/accounting.php?action=journal_view&id=<?= $le['journal_entry_id'] ?>"><?= e($le['voucher_number']) ?></a></td>
                <td><?= e($le['description'] ?: $le['je_description']) ?></td>
                <td style="font-size:0.9em"><?= e($le['cost_center_name']) ?></td>
                <td style="text-align:right"><?= $debit > 0 ? number_format($debit, 2) : '' ?></td>
                <td style="text-align:right"><?= $credit > 0 ? number_format($credit, 2) : '' ?></td>
                <td style="text-align:right;font-weight:bold;<?= $runningBalance < 0 ? 'color:red' : '' ?>"><?= number_format($runningBalance, 2) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($ledgerEntries)): ?>
            <tr><td colspan="7" style="text-align:center;padding:20px;color:#999">此期間無異動記錄</td></tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr style="font-weight:bold;background:#f8f9fa">
                <td colspan="4" style="text-align:right">本期合計</td>
                <td style="text-align:right"><?= number_format($periodDebit, 2) ?></td>
                <td style="text-align:right"><?= number_format($periodCredit, 2) ?></td>
                <td style="text-align:right;<?= $runningBalance < 0 ? 'color:red' : '' ?>"><?= number_format($runningBalance, 2) ?></td>
            </tr>
        </tfoot>
    </table>
</div>
<?php elseif ($accountId): ?>
<div class="card" style="padding:20px;text-align:center;color:#999">找不到該科目</div>
<?php endif; ?>
