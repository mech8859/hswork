<div class="page-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
    <h1><?= $entry ? '編輯傳票 - ' . e($entry['voucher_number']) : '新增傳票' ?></h1>
    <a href="/accounting.php?action=journals" class="btn btn-secondary">返回列表</a>
</div>

<form method="post" id="journalForm">
    <?= csrf_field() ?>

    <div class="card" style="padding:16px;margin-bottom:16px">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
            <div>
                <label>傳票號碼</label>
                <input type="text" class="form-control" value="<?= $entry ? e($entry['voucher_number']) : e($nextNumber) ?>" readonly style="background:#f5f5f5">
            </div>
            <div>
                <label>傳票日期 <span style="color:red">*</span></label>
                <input type="date" name="voucher_date" class="form-control" value="<?= $entry ? e($entry['voucher_date']) : date('Y-m-d') ?>" required>
            </div>
            <div>
                <label>傳票類型</label>
                <select name="voucher_type" class="form-control">
                    <?php foreach ($voucherTypeOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($entry && $entry['voucher_type'] === $k) ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div style="margin-top:12px">
            <label>摘要</label>
            <input type="text" name="description" class="form-control" value="<?= $entry ? e($entry['description']) : '' ?>" placeholder="傳票摘要說明">
        </div>
    </div>

    <!-- Journal Lines -->
    <div class="card" style="padding:16px;margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
            <h3 style="margin:0">分錄明細</h3>
            <button type="button" class="btn btn-primary btn-sm" onclick="addLine()">+ 新增行</button>
        </div>
        <div style="overflow-x:auto">
            <table class="data-table" style="width:100%" id="linesTable">
                <thead>
                    <tr>
                        <th style="width:40px">#</th>
                        <th style="min-width:220px">會計科目 <span style="color:red">*</span></th>
                        <th style="width:150px">成本中心</th>
                        <th style="width:130px;text-align:right">借方金額</th>
                        <th style="width:130px;text-align:right">貸方金額</th>
                        <th style="min-width:150px">摘要</th>
                        <th style="width:40px"></th>
                    </tr>
                </thead>
                <tbody id="linesBody">
                </tbody>
                <tfoot>
                    <tr style="font-weight:bold;background:#f8f9fa">
                        <td colspan="3" style="text-align:right">合計</td>
                        <td style="text-align:right" id="totalDebit">0.00</td>
                        <td style="text-align:right" id="totalCredit">0.00</td>
                        <td colspan="2">
                            <span id="balanceStatus" style="font-size:0.9em"></span>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <div style="display:flex;justify-content:flex-end;gap:8px">
        <a href="/accounting.php?action=journals" class="btn btn-secondary">取消</a>
        <button type="submit" class="btn btn-primary" id="submitBtn">儲存傳票</button>
    </div>
</form>

<script>
var accounts = <?= json_encode($accounts, JSON_UNESCAPED_UNICODE) ?>;
var costCenters = <?= json_encode($costCenters, JSON_UNESCAPED_UNICODE) ?>;
var lineIndex = 0;

function buildAccountSelect(name, selectedId) {
    var html = '<select name="' + name + '" class="form-control" style="width:100%" required>';
    html += '<option value="">-- 選擇科目 --</option>';
    for (var i = 0; i < accounts.length; i++) {
        var a = accounts[i];
        var sel = (selectedId && a.id == selectedId) ? ' selected' : '';
        html += '<option value="' + a.id + '"' + sel + '>' + a.code + ' ' + a.name + '</option>';
    }
    html += '</select>';
    return html;
}

function buildCcSelect(name, selectedId) {
    var html = '<select name="' + name + '" class="form-control" style="width:100%">';
    html += '<option value="">--</option>';
    for (var i = 0; i < costCenters.length; i++) {
        var c = costCenters[i];
        var sel = (selectedId && c.id == selectedId) ? ' selected' : '';
        html += '<option value="' + c.id + '"' + sel + '>' + c.name + '</option>';
    }
    html += '</select>';
    return html;
}

function addLine(data) {
    var idx = lineIndex++;
    var accountId = data ? data.account_id : '';
    var ccId = data ? data.cost_center_id : '';
    var debit = data ? parseFloat(data.debit_amount || 0).toFixed(2) : '';
    var credit = data ? parseFloat(data.credit_amount || 0).toFixed(2) : '';
    var desc = data ? (data.description || '') : '';

    var tr = document.createElement('tr');
    tr.id = 'line_' + idx;
    tr.innerHTML = '<td>' + (idx + 1) + '</td>' +
        '<td>' + buildAccountSelect('lines[' + idx + '][account_id]', accountId) + '</td>' +
        '<td>' + buildCcSelect('lines[' + idx + '][cost_center_id]', ccId) + '</td>' +
        '<td><input type="number" name="lines[' + idx + '][debit_amount]" class="form-control debit-input" style="text-align:right" step="0.01" min="0" value="' + debit + '" onchange="calcTotals()" onfocus="this.select()"></td>' +
        '<td><input type="number" name="lines[' + idx + '][credit_amount]" class="form-control credit-input" style="text-align:right" step="0.01" min="0" value="' + credit + '" onchange="calcTotals()" onfocus="this.select()"></td>' +
        '<td><input type="text" name="lines[' + idx + '][description]" class="form-control" value="' + desc.replace(/"/g, '&quot;') + '"></td>' +
        '<td><button type="button" class="btn btn-sm btn-danger" onclick="removeLine(' + idx + ')" title="刪除">&times;</button></td>';
    document.getElementById('linesBody').appendChild(tr);
    calcTotals();
}

function removeLine(idx) {
    var row = document.getElementById('line_' + idx);
    if (row) row.remove();
    calcTotals();
}

function calcTotals() {
    var debits = document.querySelectorAll('.debit-input');
    var credits = document.querySelectorAll('.credit-input');
    var totalD = 0, totalC = 0;
    for (var i = 0; i < debits.length; i++) totalD += parseFloat(debits[i].value || 0);
    for (var i = 0; i < credits.length; i++) totalC += parseFloat(credits[i].value || 0);

    document.getElementById('totalDebit').textContent = totalD.toFixed(2);
    document.getElementById('totalCredit').textContent = totalC.toFixed(2);

    var diff = Math.abs(totalD - totalC);
    var status = document.getElementById('balanceStatus');
    if (diff < 0.01 && totalD > 0) {
        status.innerHTML = '<span style="color:green">&#10003; 借貸平衡</span>';
        document.getElementById('submitBtn').disabled = false;
    } else if (totalD === 0 && totalC === 0) {
        status.innerHTML = '';
        document.getElementById('submitBtn').disabled = true;
    } else {
        status.innerHTML = '<span style="color:red">&#10007; 差額: ' + diff.toFixed(2) + '</span>';
        document.getElementById('submitBtn').disabled = true;
    }
}

// Initialize with existing lines or empty rows
<?php if ($entry && !empty($entry['lines'])): ?>
<?php foreach ($entry['lines'] as $line): ?>
addLine(<?= json_encode($line, JSON_UNESCAPED_UNICODE) ?>);
<?php endforeach; ?>
<?php else: ?>
addLine();
addLine();
<?php endif; ?>

document.getElementById('journalForm').addEventListener('submit', function(ev) {
    // Re-check balance
    var totalD = 0, totalC = 0;
    var debits = document.querySelectorAll('.debit-input');
    var credits = document.querySelectorAll('.credit-input');
    for (var i = 0; i < debits.length; i++) totalD += parseFloat(debits[i].value || 0);
    for (var i = 0; i < credits.length; i++) totalC += parseFloat(credits[i].value || 0);
    if (Math.abs(totalD - totalC) > 0.01) {
        ev.preventDefault();
        alert('借方合計與貸方合計不相等，請修正後再儲存');
        return false;
    }
    if (totalD <= 0) {
        ev.preventDefault();
        alert('請至少輸入一筆金額');
        return false;
    }
});
</script>
