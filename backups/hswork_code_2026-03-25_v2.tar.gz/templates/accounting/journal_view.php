<div class="page-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
    <h1>傳票 <?= e($entry['voucher_number']) ?></h1>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a href="/accounting.php?action=journals" class="btn btn-secondary">返回列表</a>
        <?php if ($canManage && $entry['status'] === 'draft'): ?>
        <a href="/accounting.php?action=journal_edit&id=<?= $entry['id'] ?>" class="btn btn-secondary">編輯</a>
        <?php endif; ?>
    </div>
</div>

<?php
$statusColors = array('draft' => '#f0ad4e', 'posted' => '#5cb85c', 'voided' => '#d9534f');
$statusColor = isset($statusColors[$entry['status']]) ? $statusColors[$entry['status']] : '#999';
?>

<!-- Header Info -->
<div class="card" style="padding:16px;margin-bottom:16px">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px">
        <div>
            <div style="font-size:0.85em;color:#666">傳票號碼</div>
            <div style="font-weight:bold;font-size:1.1em"><?= e($entry['voucher_number']) ?></div>
        </div>
        <div>
            <div style="font-size:0.85em;color:#666">傳票日期</div>
            <div><?= e(format_date($entry['voucher_date'])) ?></div>
        </div>
        <div>
            <div style="font-size:0.85em;color:#666">類型</div>
            <div><?= isset($voucherTypeOptions[$entry['voucher_type']]) ? e($voucherTypeOptions[$entry['voucher_type']]) : e($entry['voucher_type']) ?></div>
        </div>
        <div>
            <div style="font-size:0.85em;color:#666">狀態</div>
            <div><span style="color:<?= $statusColor ?>;font-weight:bold;font-size:1.1em"><?= isset($statusOptions[$entry['status']]) ? e($statusOptions[$entry['status']]) : e($entry['status']) ?></span></div>
        </div>
        <div>
            <div style="font-size:0.85em;color:#666">建立者</div>
            <div><?= e($entry['created_by_name']) ?></div>
        </div>
        <?php if ($entry['posted_by_name']): ?>
        <div>
            <div style="font-size:0.85em;color:#666">過帳者</div>
            <div><?= e($entry['posted_by_name']) ?> (<?= e(format_datetime($entry['posted_at'])) ?>)</div>
        </div>
        <?php endif; ?>
    </div>
    <?php if ($entry['description']): ?>
    <div style="margin-top:12px;padding-top:12px;border-top:1px solid #eee">
        <div style="font-size:0.85em;color:#666">摘要</div>
        <div><?= e($entry['description']) ?></div>
    </div>
    <?php endif; ?>
    <?php if ($entry['status'] === 'voided' && $entry['void_reason']): ?>
    <div style="margin-top:12px;padding:8px;background:#fff3cd;border-radius:4px">
        <strong>作廢原因：</strong><?= e($entry['void_reason']) ?>
        <?php if ($entry['voided_by_name']): ?>
        <br><small>作廢者: <?= e($entry['voided_by_name']) ?> (<?= e(format_datetime($entry['voided_at'])) ?>)</small>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<!-- Lines -->
<div class="card" style="padding:16px;margin-bottom:16px;overflow-x:auto">
    <h3 style="margin-top:0">分錄明細</h3>
    <table class="data-table" style="width:100%">
        <thead>
            <tr>
                <th style="width:40px">#</th>
                <th style="width:100px">科目編號</th>
                <th>科目名稱</th>
                <th>成本中心</th>
                <th style="width:120px;text-align:right">借方金額</th>
                <th style="width:120px;text-align:right">貸方金額</th>
                <th>摘要</th>
            </tr>
        </thead>
        <tbody>
            <?php $n = 1; foreach ($entry['lines'] as $line): ?>
            <tr>
                <td><?= $n++ ?></td>
                <td><strong><?= e($line['account_code']) ?></strong></td>
                <td><?= e($line['account_name']) ?></td>
                <td><?= e($line['cost_center_name']) ?></td>
                <td style="text-align:right"><?= $line['debit_amount'] > 0 ? number_format($line['debit_amount'], 2) : '' ?></td>
                <td style="text-align:right"><?= $line['credit_amount'] > 0 ? number_format($line['credit_amount'], 2) : '' ?></td>
                <td style="font-size:0.9em;color:#666"><?= e($line['description']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr style="font-weight:bold;background:#f8f9fa">
                <td colspan="4" style="text-align:right">合計</td>
                <td style="text-align:right"><?= number_format($entry['total_debit'], 2) ?></td>
                <td style="text-align:right"><?= number_format($entry['total_credit'], 2) ?></td>
                <td></td>
            </tr>
        </tfoot>
    </table>
</div>

<!-- Actions -->
<?php if ($canManage): ?>
<div class="card" style="padding:16px;display:flex;gap:8px;flex-wrap:wrap">
    <?php if ($entry['status'] === 'draft'): ?>
    <form method="post" action="/accounting.php?action=journal_post" onsubmit="return confirm('確定要過帳此傳票嗎？過帳後將無法編輯。')">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= $entry['id'] ?>">
        <button type="submit" class="btn btn-primary">過帳</button>
    </form>
    <form method="post" action="/accounting.php?action=journal_delete" onsubmit="return confirm('確定要刪除此傳票嗎？此操作無法復原。')">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= $entry['id'] ?>">
        <button type="submit" class="btn btn-danger">刪除</button>
    </form>
    <?php endif; ?>

    <?php if ($entry['status'] === 'posted'): ?>
    <button type="button" class="btn btn-danger" onclick="document.getElementById('voidModal').style.display='flex'">作廢</button>
    <?php endif; ?>
</div>

<!-- Void Modal -->
<?php if ($entry['status'] === 'posted'): ?>
<div id="voidModal" class="modal" style="display:none">
    <div class="modal-overlay" onclick="document.getElementById('voidModal').style.display='none'"></div>
    <div class="modal-content" style="max-width:400px">
        <div class="modal-header">
            <h3>作廢傳票</h3>
            <button class="modal-close" onclick="document.getElementById('voidModal').style.display='none'">&times;</button>
        </div>
        <form method="post" action="/accounting.php?action=journal_void">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= $entry['id'] ?>">
            <div class="modal-body">
                <p>確定要作廢傳票 <strong><?= e($entry['voucher_number']) ?></strong> 嗎？</p>
                <p style="color:#666;font-size:0.9em">系統將自動建立沖回傳票。</p>
                <label>作廢原因</label>
                <textarea name="reason" class="form-control" rows="3" placeholder="請輸入作廢原因"></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('voidModal').style.display='none'">取消</button>
                <button type="submit" class="btn btn-danger">確定作廢</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>

<style>
.modal { position:fixed;top:0;left:0;right:0;bottom:0;z-index:1000;display:flex;align-items:center;justify-content:center }
.modal-overlay { position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5) }
.modal-content { position:relative;background:#fff;border-radius:8px;width:90%;max-height:90vh;overflow-y:auto }
.modal-header { display:flex;justify-content:space-between;align-items:center;padding:16px;border-bottom:1px solid #eee }
.modal-header h3 { margin:0 }
.modal-close { background:none;border:none;font-size:24px;cursor:pointer }
.modal-body { padding:16px }
.modal-footer { padding:16px;border-top:1px solid #eee;display:flex;justify-content:flex-end;gap:8px }
</style>
