<div class="page-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
    <h1>會計科目管理</h1>
    <?php if ($canManage): ?>
    <button class="btn btn-primary" onclick="openAccountModal()">+ 新增科目</button>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:16px;padding:12px">
    <form method="get" action="/accounting.php" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <input type="hidden" name="action" value="accounts">
        <input type="text" name="keyword" value="<?= e($keyword) ?>" placeholder="搜尋科目編號/名稱" class="form-control" style="width:200px">
        <select name="type" class="form-control" style="width:150px">
            <option value="">全部類型</option>
            <?php foreach ($accountTypeOptions as $k => $v): ?>
            <option value="<?= e($k) ?>" <?= $typeFilter === $k ? 'selected' : '' ?>><?= e($v) ?></option>
            <?php endforeach; ?>
        </select>
        <label style="display:flex;align-items:center;gap:4px">
            <input type="checkbox" name="show_inactive" value="1" <?= $showInactive ? 'checked' : '' ?>> 顯示停用
        </label>
        <button type="submit" class="btn btn-secondary">篩選</button>
    </form>
</div>

<!-- Accounts Table -->
<div class="card" style="overflow-x:auto">
    <p style="padding:8px 12px;margin:0;color:#666;font-size:.85rem">共 <?= count($allAccounts) ?> 筆科目</p>
    <table class="table" style="width:100%;font-size:.8rem;white-space:nowrap">
        <thead>
            <tr style="background:#f5f5f5">
                <th>科目編號</th>
                <th>科目名稱</th>
                <th>立沖屬性</th>
                <th>交易科目</th>
                <th>隸屬科目</th>
                <th>科目總類</th>
                <th>總類名稱</th>
                <th>科目類別</th>
                <th>類別名稱</th>
                <th>科目屬性</th>
                <th>專案核算</th>
                <th>餘額方向</th>
                <th>部門核算</th>
                <th>往來類型</th>
                <th>內部往來</th>
                <th>狀態</th>
                <?php if ($canManage): ?><th>操作</th><?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($allAccounts)): ?>
            <tr><td colspan="17" style="text-align:center;padding:20px;color:#999">尚無科目資料</td></tr>
            <?php endif; ?>
            <?php foreach ($allAccounts as $acc): ?>
            <tr style="<?= !$acc['is_active'] ? 'opacity:0.5' : '' ?>">
                <td><strong><?= e($acc['code']) ?></strong></td>
                <td><?= e($acc['name']) ?></td>
                <td><?= e($acc['offset_type'] ?? '') ?></td>
                <td><?= e($acc['tx_type'] ?? '') ?></td>
                <td><?= e($acc['parent_id'] ? $acc['code'] : '') ?></td>
                <td><?= e($acc['type_num'] ?? '') ?></td>
                <td><?= e($acc['type_name_full'] ?? '') ?></td>
                <td><?= e($acc['cat_code'] ?? '') ?></td>
                <td><?= e($acc['cat_name'] ?? '') ?></td>
                <td><?= e($acc['attr'] ?? '') ?></td>
                <td><?= e($acc['project_calc'] ?? '') ?></td>
                <td><?= $acc['normal_balance'] === 'debit' ? '借方' : '貸方' ?></td>
                <td><?= e($acc['dept_calc'] ?? '') ?></td>
                <td><?= e($acc['relate_type'] ?? '') ?></td>
                <td><?= e($acc['internal_flag'] ?? '') ?></td>
                <td><?= $acc['is_active'] ? '<span style="color:green">啟用</span>' : '<span style="color:red">停用</span>' ?></td>
                <?php if ($canManage): ?>
                <td>
                    <button class="btn btn-sm btn-secondary" onclick='openAccountModal(<?= json_encode($acc, JSON_UNESCAPED_UNICODE) ?>)'>編輯</button>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($canManage): ?>
<!-- Account Modal -->
<div id="accountModal" class="modal" style="display:none">
    <div class="modal-overlay" onclick="closeAccountModal()"></div>
    <div class="modal-content" style="max-width:600px">
        <div class="modal-header">
            <h3 id="accountModalTitle">新增科目</h3>
            <button class="modal-close" onclick="closeAccountModal()">&times;</button>
        </div>
        <form method="post" action="/accounting.php?action=account_save">
            <?= csrf_field() ?>
            <input type="hidden" name="id" id="acc_id" value="">
            <div class="modal-body" style="display:grid;gap:12px">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                    <div>
                        <label>科目編號 <span style="color:red">*</span></label>
                        <input type="text" name="code" id="acc_code" class="form-control" required>
                    </div>
                    <div>
                        <label>科目名稱 <span style="color:red">*</span></label>
                        <input type="text" name="name" id="acc_name" class="form-control" required>
                    </div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
                    <div>
                        <label>科目類型 <span style="color:red">*</span></label>
                        <select name="account_type" id="acc_type" class="form-control" required onchange="autoSetNormalBalance()">
                            <option value="">請選擇</option>
                            <?php foreach ($accountTypeOptions as $k => $v): ?>
                            <option value="<?= e($k) ?>"><?= e($v) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label>正常餘額</label>
                        <select name="normal_balance" id="acc_normal" class="form-control">
                            <option value="debit">借方</option>
                            <option value="credit">貸方</option>
                        </select>
                    </div>
                    <div>
                        <label>一階分類</label>
                        <input type="text" name="level1" id="acc_level1" class="form-control" placeholder="如：資產、負債">
                    </div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
                    <div>
                        <label>層級</label>
                        <input type="number" name="level" id="acc_level" class="form-control" value="1" min="1" max="4">
                    </div>
                    <div>
                        <label>排序</label>
                        <input type="number" name="sort_order" id="acc_sort" class="form-control" value="0">
                    </div>
                    <div style="display:flex;align-items:end;gap:8px">
                        <label style="display:flex;align-items:center;gap:4px">
                            <input type="checkbox" name="is_detail" id="acc_detail" value="1" checked> 可記帳(明細科目)
                        </label>
                    </div>
                </div>
                <div>
                    <label>說明</label>
                    <textarea name="description" id="acc_desc" class="form-control" rows="2"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeAccountModal()">取消</button>
                <button type="submit" class="btn btn-primary">儲存</button>
            </div>
        </form>
    </div>
</div>

<script>
function openAccountModal(acc) {
    document.getElementById('accountModal').style.display = 'flex';
    if (acc) {
        document.getElementById('accountModalTitle').textContent = '編輯科目';
        document.getElementById('acc_id').value = acc.id || '';
        document.getElementById('acc_code').value = acc.code || '';
        document.getElementById('acc_name').value = acc.name || '';
        document.getElementById('acc_type').value = acc.account_type || '';
        document.getElementById('acc_normal').value = acc.normal_balance || 'debit';
        document.getElementById('acc_level1').value = acc.level1 || '';
        document.getElementById('acc_level').value = acc.level || 1;
        document.getElementById('acc_sort').value = acc.sort_order || 0;
        document.getElementById('acc_detail').checked = acc.is_detail == 1;
        document.getElementById('acc_desc').value = acc.description || '';
    } else {
        document.getElementById('accountModalTitle').textContent = '新增科目';
        document.getElementById('acc_id').value = '';
        document.getElementById('acc_code').value = '';
        document.getElementById('acc_name').value = '';
        document.getElementById('acc_type').value = '';
        document.getElementById('acc_normal').value = 'debit';
        document.getElementById('acc_level1').value = '';
        document.getElementById('acc_level').value = 1;
        document.getElementById('acc_sort').value = 0;
        document.getElementById('acc_detail').checked = true;
        document.getElementById('acc_desc').value = '';
    }
}
function closeAccountModal() {
    document.getElementById('accountModal').style.display = 'none';
}
function autoSetNormalBalance() {
    var t = document.getElementById('acc_type').value;
    if (t === 'asset' || t === 'expense') {
        document.getElementById('acc_normal').value = 'debit';
    } else {
        document.getElementById('acc_normal').value = 'credit';
    }
}
</script>

<style>
.modal { position:fixed;top:0;left:0;right:0;bottom:0;z-index:1000;display:flex;align-items:center;justify-content:center }
.modal-overlay { position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5) }
.modal-content { position:relative;background:#fff;border-radius:8px;width:90%;max-height:90vh;overflow-y:auto }
.modal-header { display:flex;justify-content:space-between;align-items:center;padding:16px;border-bottom:1px solid #eee }
.modal-header h3 { margin:0 }
.modal-close { background:none;border:none;font-size:24px;cursor:pointer }
.modal-body { padding:16px }
.modal-footer { padding:16px;border-top:1px solid #eee;display:flex;justify-content:flex-end;gap:8px }
</style>
<?php endif; ?>
