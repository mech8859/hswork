<?php
$isEdit = !empty($record);
$statusOptions = InvoiceModel::invoiceStatusOptions();
$typeOptions = InvoiceModel::purchaseInvoiceTypeOptions();
$deductionOptions = InvoiceModel::deductionTypeOptions();
$refOptions = InvoiceModel::referenceTypeOptions();
?>

<h2><?= $isEdit ? '編輯進項發票 - ' . e($record['invoice_number']) : '新增進項發票' ?></h2>

<form method="POST" class="mt-2" id="purchaseInvoiceForm">
    <?= csrf_field() ?>

    <!-- 基本資訊 -->
    <div class="card">
        <div class="card-header">發票資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>發票號碼 *</label>
                <input type="text" name="invoice_number" class="form-control"
                       value="<?= e($isEdit && !empty($record['invoice_number']) ? $record['invoice_number'] : '') ?>"
                       required placeholder="例: AB-12345678">
            </div>
            <div class="form-group">
                <label>發票日期 *</label>
                <input type="date" max="2099-12-31" name="invoice_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['invoice_date']) ? $record['invoice_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>發票類型</label>
                <select name="invoice_type" id="fldInvoiceType" class="form-control" onchange="onTypeChange()">
                    <?php foreach ($typeOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && !empty($record['invoice_type']) ? $record['invoice_type'] : '應稅') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($isEdit): ?>
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <?php foreach ($statusOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= (!empty($record['status']) ? $record['status'] : 'pending') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- 供應商 -->
    <div class="card">
        <div class="card-header">供應商資訊</div>
        <div class="form-row">
            <div class="form-group">
                <label>供應商</label>
                <select id="vendorSelect" class="form-control" onchange="onVendorSelect()">
                    <option value="">-- 手動輸入 --</option>
                    <?php foreach ($vendors as $v): ?>
                    <option value="<?= e(!empty($v['id']) ? $v['id'] : '') ?>"
                            data-name="<?= e(!empty($v['name']) ? $v['name'] : '') ?>"
                            data-taxid="<?= e(!empty($v['tax_id']) ? $v['tax_id'] : '') ?>"
                            <?= ($isEdit && !empty($record['vendor_id']) && !empty($v['id']) && $record['vendor_id'] == $v['id']) ? 'selected' : '' ?>>
                        <?= e(!empty($v['name']) ? $v['name'] : '') ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <input type="hidden" name="vendor_id" id="fldVendorId" value="<?= e($isEdit && !empty($record['vendor_id']) ? $record['vendor_id'] : '') ?>">
            </div>
            <div class="form-group">
                <label>供應商名稱 *</label>
                <input type="text" name="vendor_name" id="fldVendorName" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_name']) ? $record['vendor_name'] : '') ?>" required>
            </div>
            <div class="form-group">
                <label>統一編號</label>
                <input type="text" name="vendor_tax_id" id="fldVendorTaxId" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_tax_id']) ? $record['vendor_tax_id'] : '') ?>"
                       maxlength="8" placeholder="8碼統編">
            </div>
        </div>
    </div>

    <!-- 金額 -->
    <div class="card">
        <div class="card-header">金額</div>
        <div class="form-row">
            <div class="form-group">
                <label>未稅金額 *</label>
                <input type="number" name="amount_untaxed" id="fldUntaxed" class="form-control" step="1" min="0"
                       value="<?= $isEdit && isset($record['amount_untaxed']) ? (int)$record['amount_untaxed'] : 0 ?>"
                       oninput="calcTax()" required>
            </div>
            <div class="form-group">
                <label>稅額 (5%)</label>
                <input type="number" name="tax_amount" id="fldTaxAmt" class="form-control" step="1" min="0"
                       value="<?= $isEdit && isset($record['tax_amount']) ? (int)$record['tax_amount'] : 0 ?>">
            </div>
            <div class="form-group">
                <label>含稅金額</label>
                <input type="number" name="total_amount" id="fldTotal" class="form-control" step="1" min="0"
                       value="<?= $isEdit && isset($record['total_amount']) ? (int)$record['total_amount'] : 0 ?>" readonly>
            </div>
            <input type="hidden" name="tax_rate" id="fldTaxRate" value="<?= $isEdit && isset($record['tax_rate']) ? $record['tax_rate'] : 5 ?>">
        </div>
    </div>

    <!-- 扣抵 & 關聯 -->
    <div class="card">
        <div class="card-header">扣抵與關聯</div>
        <div class="form-row">
            <div class="form-group">
                <label>可扣抵</label>
                <div style="display:flex;gap:16px;padding-top:8px">
                    <label style="display:flex;align-items:center;gap:4px;font-weight:normal">
                        <input type="radio" name="deduction_type" value="deductible"
                            <?= (!$isEdit || (isset($record['deduction_type']) && $record['deduction_type'] === 'deductible') || empty($record['deduction_type'])) ? 'checked' : '' ?>>
                        可扣抵
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-weight:normal">
                        <input type="radio" name="deduction_type" value="non_deductible"
                            <?= ($isEdit && !empty($record['deduction_type']) && $record['deduction_type'] === 'non_deductible') ? 'checked' : '' ?>>
                        不可扣抵
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label>關聯單據類型</label>
                <select name="reference_type" class="form-control">
                    <?php foreach ($refOptions as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && (!empty($record['reference_type']) ? $record['reference_type'] : '') === $k) ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>關聯單據編號</label>
                <input type="text" name="reference_id" class="form-control"
                       value="<?= e($isEdit && !empty($record['reference_id']) ? $record['reference_id'] : '') ?>"
                       placeholder="選填">
            </div>
        </div>
    </div>

    <!-- 備註 -->
    <div class="card">
        <div class="card-header">備註</div>
        <div class="form-group">
            <textarea name="note" class="form-control" rows="3"><?= e($isEdit && !empty($record['note']) ? $record['note'] : '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '新增進項發票' ?></button>
        <a href="/purchase_invoices.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
function onVendorSelect() {
    var sel = document.getElementById('vendorSelect');
    var opt = sel.options[sel.selectedIndex];
    document.getElementById('fldVendorId').value = sel.value;
    if (sel.value) {
        document.getElementById('fldVendorName').value = opt.getAttribute('data-name') || '';
        document.getElementById('fldVendorTaxId').value = opt.getAttribute('data-taxid') || '';
    }
}

function onTypeChange() {
    var type = document.getElementById('fldInvoiceType').value;
    if (type === '免稅' || type === '零稅率') {
        document.getElementById('fldTaxAmt').value = 0;
        document.getElementById('fldTaxRate').value = 0;
    } else {
        document.getElementById('fldTaxRate').value = 5;
    }
    calcTax();
}

function calcTax() {
    var untaxed = parseInt(document.getElementById('fldUntaxed').value) || 0;
    var type = document.getElementById('fldInvoiceType').value;
    var tax = 0;
    if (type !== '免稅' && type !== '零稅率') {
        tax = Math.round(untaxed * 0.05);
    }
    document.getElementById('fldTaxAmt').value = tax;
    document.getElementById('fldTotal').value = untaxed + tax;
}

// 初始計算
calcTax();
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
</style>
