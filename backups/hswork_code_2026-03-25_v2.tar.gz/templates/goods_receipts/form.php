<?php $isEdit = !empty($record) && !empty($record['id']); ?>

<h2><?= $isEdit ? '編輯進貨單 - ' . e($record['gr_number']) : '新增進貨單' ?></h2>

<form method="POST" class="mt-2" id="grForm">
    <?= csrf_field() ?>

    <!-- 進貨單資訊 -->
    <div class="card">
        <div class="card-header">進貨單資訊</div>
        <div class="form-row">
            <div class="form-group" style="flex:0 0 auto;min-width:200px">
                <label>進貨單號</label>
                <input type="text" class="form-control" value="<?= e($isEdit ? $record['gr_number'] : peek_next_doc_number('goods_receipts')) ?>" readonly style="background:#f0f7ff;font-weight:600;color:var(--primary)">
            </div>
            <div class="form-group">
                <label>進貨日期 *</label>
                <input type="date" max="2099-12-31" name="gr_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['gr_date']) ? $record['gr_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>狀態</label>
                <select name="status" class="form-control">
                    <?php foreach (GoodsReceiptModel::statusOptions() as $k => $v): ?>
                    <?php if ($k === '已確認') continue; ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && !empty($record['status']) ? $record['status'] : '草稿') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>關聯採購單</label>
                <select name="po_id" id="poSelect" class="form-control" onchange="onPOSelect(this)">
                    <option value="">-- 無 --</option>
                    <?php if (!empty($pendingPOs)): ?>
                    <?php foreach ($pendingPOs as $po): ?>
                    <option value="<?= $po['id'] ?>"
                            data-number="<?= e($po['po_number']) ?>"
                            data-vendor="<?= e(!empty($po['vendor_name']) ? $po['vendor_name'] : '') ?>"
                            <?= ($isEdit && !empty($record['po_id']) ? $record['po_id'] : (!empty($record['po_id']) ? $record['po_id'] : '')) == $po['id'] ? 'selected' : '' ?>>
                        <?= e($po['po_number']) ?> - <?= e(!empty($po['vendor_name']) ? $po['vendor_name'] : '') ?> ($<?= number_format($po['total_amount']) ?>)
                    </option>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </select>
                <input type="hidden" name="po_number" id="po_number" value="<?= e($isEdit && !empty($record['po_number']) ? $record['po_number'] : (!empty($record['po_number']) ? $record['po_number'] : '')) ?>">
            </div>
            <div class="form-group">
                <label>倉庫 *</label>
                <select name="warehouse_id" class="form-control" required>
                    <option value="">請選擇</option>
                    <?php foreach ($warehouses as $wh): ?>
                    <option value="<?= $wh['id'] ?>" <?= ($isEdit && !empty($record['warehouse_id']) ? $record['warehouse_id'] : (!empty($record['warehouse_id']) ? $record['warehouse_id'] : '')) == $wh['id'] ? 'selected' : '' ?>><?= e($wh['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>廠商名稱</label>
                <input type="text" name="vendor_name" id="vendor_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_name']) ? $record['vendor_name'] : (!empty($record['vendor_name']) ? $record['vendor_name'] : '')) ?>">
                <input type="hidden" name="vendor_id" id="vendor_id"
                       value="<?= e($isEdit && !empty($record['vendor_id']) ? $record['vendor_id'] : (!empty($record['vendor_id']) ? $record['vendor_id'] : '')) ?>">
            </div>
            <div class="form-group">
                <label>收貨人</label>
                <input type="text" name="receiver_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['receiver_name']) ? $record['receiver_name'] : '') ?>">
            </div>
        </div>
    </div>

    <!-- 進貨明細 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>進貨明細</span>
            <button type="button" class="btn btn-primary btn-sm" onclick="addItemRow()">+ 新增</button>
        </div>
        <div class="table-responsive">
            <table class="table" id="itemTable">
                <thead>
                    <tr>
                        <th style="width:40px">#</th>
                        <th>型號</th>
                        <th>品名</th>
                        <th>規格</th>
                        <th>單位</th>
                        <th style="width:80px">採購數量</th>
                        <th style="width:80px">收貨數量</th>
                        <th style="width:100px">單價</th>
                        <th style="width:100px">金額</th>
                        <th style="width:40px"></th>
                    </tr>
                </thead>
                <tbody id="itemBody">
                    <?php if (!empty($items)): ?>
                        <?php foreach ($items as $idx => $item): ?>
                        <tr>
                            <td class="item-seq"><?= $idx + 1 ?></td>
                            <td>
                                <input type="hidden" name="items[<?= $idx ?>][product_id]" value="<?= e(!empty($item['product_id']) ? $item['product_id'] : '') ?>">
                                <input type="text" name="items[<?= $idx ?>][model]" class="form-control" value="<?= e(!empty($item['model']) ? $item['model'] : '') ?>">
                            </td>
                            <td><input type="text" name="items[<?= $idx ?>][product_name]" class="form-control" value="<?= e(!empty($item['product_name']) ? $item['product_name'] : '') ?>"></td>
                            <td><input type="text" name="items[<?= $idx ?>][spec]" class="form-control" value="<?= e(!empty($item['spec']) ? $item['spec'] : '') ?>"></td>
                            <td><input type="text" name="items[<?= $idx ?>][unit]" class="form-control" value="<?= e(!empty($item['unit']) ? $item['unit'] : '') ?>" style="width:60px"></td>
                            <td><input type="number" name="items[<?= $idx ?>][po_qty]" class="form-control" step="1" min="0" value="<?= !empty($item['po_qty']) ? (int)$item['po_qty'] : 0 ?>" readonly></td>
                            <td><input type="number" name="items[<?= $idx ?>][received_qty]" class="form-control item-qty" step="1" min="0" value="<?= !empty($item['received_qty']) ? (int)$item['received_qty'] : 0 ?>" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[<?= $idx ?>][unit_price]" class="form-control item-price" step="1" min="0" value="<?= !empty($item['unit_price']) ? (int)$item['unit_price'] : 0 ?>" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[<?= $idx ?>][amount]" class="form-control item-amount" step="1" min="0" value="<?= !empty($item['amount']) ? (int)$item['amount'] : 0 ?>" readonly></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td class="item-seq">1</td>
                            <td>
                                <input type="hidden" name="items[0][product_id]" value="">
                                <input type="text" name="items[0][model]" class="form-control" value="">
                            </td>
                            <td><input type="text" name="items[0][product_name]" class="form-control" value=""></td>
                            <td><input type="text" name="items[0][spec]" class="form-control" value=""></td>
                            <td><input type="text" name="items[0][unit]" class="form-control" value="" style="width:60px"></td>
                            <td><input type="number" name="items[0][po_qty]" class="form-control" step="1" min="0" value="0" readonly></td>
                            <td><input type="number" name="items[0][received_qty]" class="form-control item-qty" step="1" min="0" value="0" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[0][unit_price]" class="form-control item-price" step="1" min="0" value="0" oninput="calcRowAmount(this.closest('tr'))"></td>
                            <td><input type="number" name="items[0][amount]" class="form-control item-amount" step="1" min="0" value="0" readonly></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 合計 -->
    <div class="card">
        <div class="card-header">合計</div>
        <div class="form-row">
            <div class="form-group">
                <label>總數量</label>
                <input type="number" name="total_qty" id="total_qty" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['total_qty']) ? (int)$record['total_qty'] : 0 ?>" readonly>
            </div>
            <div class="form-group">
                <label>總金額</label>
                <input type="number" name="total_amount" id="total_amount" class="form-control" step="1" min="0"
                       value="<?= $isEdit && !empty($record['total_amount']) ? (int)$record['total_amount'] : 0 ?>" readonly>
            </div>
        </div>
    </div>

    <!-- 備註 -->
    <div class="card">
        <div class="card-header">備註</div>
        <div class="form-group">
            <textarea name="note" class="form-control" rows="3"><?= e($isEdit && !empty($record['note']) ? $record['note'] : '') ?></textarea>
        </div>
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $isEdit ? '儲存變更' : '建立進貨單' ?></button>
        <a href="/goods_receipts.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
var itemIdx = <?= !empty($items) ? count($items) : 1 ?>;

function addItemRow() {
    var tbody = document.getElementById('itemBody');
    var tr = document.createElement('tr');
    var seq = tbody.querySelectorAll('tr').length + 1;
    tr.innerHTML = '<td class="item-seq">' + seq + '</td>'
        + '<td><input type="hidden" name="items['+itemIdx+'][product_id]" value="">'
        + '<input type="text" name="items['+itemIdx+'][model]" class="form-control" value=""></td>'
        + '<td><input type="text" name="items['+itemIdx+'][product_name]" class="form-control" value=""></td>'
        + '<td><input type="text" name="items['+itemIdx+'][spec]" class="form-control" value=""></td>'
        + '<td><input type="text" name="items['+itemIdx+'][unit]" class="form-control" value="" style="width:60px"></td>'
        + '<td><input type="number" name="items['+itemIdx+'][po_qty]" class="form-control" step="1" min="0" value="0" readonly></td>'
        + '<td><input type="number" name="items['+itemIdx+'][received_qty]" class="form-control item-qty" step="1" min="0" value="0" oninput="calcRowAmount(this.closest(\'tr\'))"></td>'
        + '<td><input type="number" name="items['+itemIdx+'][unit_price]" class="form-control item-price" step="1" min="0" value="0" oninput="calcRowAmount(this.closest(\'tr\'))"></td>'
        + '<td><input type="number" name="items['+itemIdx+'][amount]" class="form-control item-amount" step="1" min="0" value="0" readonly></td>'
        + '<td><button type="button" class="btn btn-danger btn-sm" onclick="removeItemRow(this)">X</button></td>';
    tbody.appendChild(tr);
    itemIdx++;
}

function removeItemRow(btn) {
    btn.closest('tr').remove();
    reindexItems();
    calcTotals();
}

function reindexItems() {
    var rows = document.querySelectorAll('#itemBody tr');
    for (var i = 0; i < rows.length; i++) {
        rows[i].querySelector('.item-seq').textContent = i + 1;
    }
}

function calcRowAmount(row) {
    var qty = parseFloat(row.querySelector('.item-qty').value) || 0;
    var price = parseFloat(row.querySelector('.item-price').value) || 0;
    row.querySelector('.item-amount').value = Math.round(qty * price);
    calcTotals();
}

function calcTotals() {
    var totalQty = 0;
    var totalAmount = 0;
    document.querySelectorAll('.item-qty').forEach(function(el) {
        totalQty += parseFloat(el.value) || 0;
    });
    document.querySelectorAll('.item-amount').forEach(function(el) {
        totalAmount += parseFloat(el.value) || 0;
    });
    document.getElementById('total_qty').value = totalQty;
    document.getElementById('total_amount').value = totalAmount;
}

function onPOSelect(sel) {
    var opt = sel.options[sel.selectedIndex];
    if (opt.value) {
        document.getElementById('po_number').value = opt.getAttribute('data-number') || '';
        document.getElementById('vendor_name').value = opt.getAttribute('data-vendor') || '';
        // Redirect to create_from_po to load items
        if (!<?= $isEdit ? 'true' : 'false' ?>) {
            location.href = '/goods_receipts.php?action=create&from_po=' + opt.value;
        }
    } else {
        document.getElementById('po_number').value = '';
    }
}

calcTotals();
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
</style>
