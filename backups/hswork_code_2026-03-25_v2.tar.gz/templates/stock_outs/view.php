<?php
$canManage = Auth::hasPermission('inventory.manage');
$soNum = isset($record['stockout_number']) ? $record['stockout_number'] : (isset($record['so_number']) ? $record['so_number'] : '-');
$soDate = isset($record['stockout_date']) ? $record['stockout_date'] : (isset($record['so_date']) ? $record['so_date'] : '-');
$refType = isset($record['reference_type']) ? $record['reference_type'] : (isset($record['source_type']) ? $record['source_type'] : '');
$refId = isset($record['reference_id']) ? $record['reference_id'] : (isset($record['source_id']) ? $record['source_id'] : '');
$creatorName = isset($record['creator_name']) ? $record['creator_name'] : (isset($record['created_by_name']) ? $record['created_by_name'] : '-');
$confirmedName = isset($record['confirmed_by_name']) ? $record['confirmed_by_name'] : '-';
$isPending = ($record['status'] === 'pending' || $record['status'] === '待確認');
?>

<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <h2>出庫單 <?= e($soNum) ?></h2>
    <div class="d-flex gap-1 flex-wrap">
        <?php if ($canManage && $isPending): ?>
        <a href="/stock_outs.php?action=confirm&id=<?= $record['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>" class="btn btn-sm" style="background:var(--success);color:#fff" onclick="return confirm('確認出庫？將從倉庫扣減庫存。')">確認出庫</a>
        <?php endif; ?>
        <a href="/stock_outs.php" class="btn btn-outline btn-sm">返回列表</a>
    </div>
</div>

<!-- 基本資訊 -->
<div class="card">
    <div class="card-header d-flex justify-between align-center">
        <span>出庫單資訊</span>
        <span class="badge badge-<?= StockModel::statusBadge($record['status']) ?>"><?= e(StockModel::statusLabel($record['status'])) ?></span>
    </div>
    <div class="form-row">
        <div class="form-group">
            <label>出庫單號</label>
            <div class="form-static"><?= e($soNum) ?></div>
        </div>
        <div class="form-group">
            <label>出庫日期</label>
            <div class="form-static"><?= e($soDate) ?></div>
        </div>
        <div class="form-group">
            <label>倉庫</label>
            <div class="form-static"><?= e(isset($record['warehouse_name']) ? $record['warehouse_name'] : '-') ?></div>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group">
            <label>來源類型</label>
            <div class="form-static"><?= $refType ? e(StockModel::referenceTypeLabel($refType)) : '-' ?></div>
        </div>
        <div class="form-group">
            <label>來源單據</label>
            <div class="form-static">
                <?php if ($refType === 'delivery_order' && $refId): ?>
                <a href="/delivery_orders.php?action=view&id=<?= (int)$refId ?>">出貨單 #<?= (int)$refId ?></a>
                <?php elseif ($refId): ?>
                #<?= (int)$refId ?>
                <?php else: ?>
                -
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group">
            <label>建立者</label>
            <div class="form-static"><?= e($creatorName) ?></div>
        </div>
    </div>
    <?php if (!empty($record['note'])): ?>
    <div class="form-group">
        <label>備註</label>
        <div class="form-static"><?= nl2br(e($record['note'])) ?></div>
    </div>
    <?php endif; ?>
    <?php if ($record['status'] === 'confirmed' || $record['status'] === '已確認'): ?>
    <div class="form-row" style="margin-top:8px">
        <div class="form-group">
            <label>確認者</label>
            <div class="form-static"><?= e($confirmedName) ?></div>
        </div>
        <div class="form-group">
            <label>確認時間</label>
            <div class="form-static"><?= e(isset($record['confirmed_at']) ? $record['confirmed_at'] : '-') ?></div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- 出庫明細 -->
<div class="card">
    <div class="card-header">出庫明細</div>
    <?php
    $items = isset($record['items']) ? $record['items'] : array();
    ?>
    <?php if (empty($items)): ?>
        <p class="text-muted text-center mt-2">無明細</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th style="width:40px">#</th><th>品名</th><th>型號</th><th>單位</th><th class="text-right">數量</th><th class="text-right">單位成本</th><th class="text-right">成本小計</th>
            </tr></thead>
            <tbody>
                <?php $totalCost = 0; ?>
                <?php foreach ($items as $idx => $item):
                    $productName = isset($item['product_name']) ? $item['product_name'] : (isset($item['db_product_name']) ? $item['db_product_name'] : '-');
                    $productModel = isset($item['product_model']) ? $item['product_model'] : (isset($item['db_model']) ? $item['db_model'] : (isset($item['model']) ? $item['model'] : '-'));
                    $unitDisplay = isset($item['unit']) ? $item['unit'] : '-';
                    $qty = (int)(isset($item['quantity']) ? $item['quantity'] : 0);
                    $unitCost = (int)(isset($item['unit_cost']) ? $item['unit_cost'] : (isset($item['unit_price']) ? $item['unit_price'] : 0));
                    $subtotal = $qty * $unitCost;
                ?>
                <tr>
                    <td><?= $idx + 1 ?></td>
                    <td><?= e($productName) ?></td>
                    <td><?= e($productModel) ?></td>
                    <td><?= e($unitDisplay) ?></td>
                    <td class="text-right"><?= $qty ?></td>
                    <td class="text-right">$<?= number_format($unitCost) ?></td>
                    <td class="text-right">$<?= number_format($subtotal) ?></td>
                </tr>
                <?php $totalCost += $subtotal; ?>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="6" class="text-right"><strong>合計</strong></td>
                    <td class="text-right"><strong>$<?= number_format($totalCost) ?></strong></td>
                </tr>
            </tfoot>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
.form-static { padding: 6px 0; color: var(--gray-700); }
</style>
