<?php $isEdit = !empty($record); ?>

<h2><?= $isEdit ? '編輯退貨單 - ' . e($record['return_number']) : '新增退貨單' ?></h2>

<form method="POST" class="mt-2" id="returnForm">
    <?= csrf_field() ?>

    <!-- 退貨單資訊 -->
    <div class="card">
        <div class="card-header">退貨單資訊</div>
        <div class="form-row">
            <?php if ($isEdit): ?>
            <div class="form-group" style="flex:0 0 auto;min-width:200px">
                <label>退貨單號</label>
                <input type="text" class="form-control" value="<?= e($record['return_number']) ?>" readonly style="background:#f0f7ff;font-weight:600;color:var(--primary)">
            </div>
            <?php endif; ?>
            <div class="form-group">
                <label>退貨日期 *</label>
                <input type="date" max="2099-12-31" name="return_date" class="form-control"
                       value="<?= e($isEdit && !empty($record['return_date']) ? $record['return_date'] : date('Y-m-d')) ?>" required>
            </div>
            <div class="form-group">
                <label>退貨類型 *</label>
                <select name="return_type" id="returnType" class="form-control" required>
                    <?php foreach (ReturnModel::returnTypeOptions() as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= ($isEdit && !empty($record['return_type']) ? $record['return_type'] : 'customer_return') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>倉庫 *</label>
                <select name="warehouse_id" class="form-control" required>
                    <option value="">請選擇</option>
                    <?php foreach ($warehouses as $wh): ?>
                    <option value="<?= $wh['id'] ?>" <?= ($isEdit && !empty($record['warehouse_id']) ? $record['warehouse_id'] : '') == $wh['id'] ? 'selected' : '' ?>><?= e($wh['name']) ?><?= !empty($wh['branch_name']) ? ' (' . e($wh['branch_name']) . ')' : '' ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group customer-field" id="customerField">
                <label>客戶名稱</label>
                <input type="text" name="customer_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['customer_name']) ? $record['customer_name'] : '') ?>">
            </div>
            <div class="form-group vendor-field" id="vendorField">
                <label>廠商名稱</label>
                <input type="text" name="vendor_name" class="form-control"
                       value="<?= e($isEdit && !empty($record['vendor_name']) ? $record['vendor_name'] : '') ?>">
            </div>
            <div class="form-group">
                <label>來源單據類型</label>
                <input type="text" name="reference_type" class="form-control"
                       value="<?= e($isEdit && !empty($record['reference_type']) ? $record['reference_type'] : '') ?>" placeholder="如: delivery_order, purchase_order">
            </div>
            <div class="form-group">
                <label>來源單據ID</label>
                <input type="text" name="reference_id" class="form-control"
                       value="<?= e($isEdit && !empty($record['reference_id']) ? $record['reference_id'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group" style="flex:2">
                <label>退貨原因</label>
                <input type="text" name="reason" class="form-control"
                       value="<?= e($isEdit && !empty($record['reason']) ? $record['reason'] : '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group" style="flex:2">
                <label>備註</label>
                <textarea name="note" class="form-control" rows="2"><?= e($isEdit && !empty($record['note']) ? $record['note'] : '') ?></textarea>
            </div>
        </div>
    </div>

    <!-- 退貨明細 -->
    <div class="card">
        <div class="card-header d-flex justify-between align-center">
            <span>退貨明細</span>
            <button type="button" class="btn btn-primary btn-sm" onclick="addItem()">+ 新增品項</button>
        </div>
        <div class="table-responsive">
            <table class="table" id="itemsTable">
                <thead>
                    <tr>
                        <th style="min-width:60px">#</th>
                        <th style="min-width:200px">品名</th>
                        <th style="min-width:100px">數量</th>
                        <th style="min-width:120px">單價</th>
                        <th style="min-width:120px">金額</th>
                        <th style="min-width:150px">原因</th>
                        <th style="min-width:60px"></th>
                    </tr>
                </thead>
                <tbody id="itemsBody">
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4" class="text-right"><strong>合計</strong></td>
                        <td><strong id="totalDisplay">$0</strong></td>
                        <td colspan="2"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <input type="hidden" name="total_amount" id="totalAmount" value="<?= e($isEdit && !empty($record['total_amount']) ? $record['total_amount'] : '0') ?>">
    </div>

    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary">儲存</button>
        <a href="/returns.php" class="btn btn-outline">取消</a>
    </div>
</form>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 12px; }
.form-row .form-group { flex: 1; min-width: 180px; margin-bottom: 0; }
.vendor-field { display: none; }
</style>

<script>
var existingItems = <?= json_encode(!empty($items) ? $items : array()) ?>;
var rowIndex = 0;

function toggleTypeFields() {
    var type = document.getElementById('returnType').value;
    var cFields = document.querySelectorAll('.customer-field');
    var vFields = document.querySelectorAll('.vendor-field');
    var i;
    for (i = 0; i < cFields.length; i++) {
        cFields[i].style.display = (type === 'customer_return') ? '' : 'none';
    }
    for (i = 0; i < vFields.length; i++) {
        vFields[i].style.display = (type === 'vendor_return') ? '' : 'none';
    }
}

function addItem(data) {
    var tbody = document.getElementById('itemsBody');
    var tr = document.createElement('tr');
    var idx = rowIndex++;
    var productId = (data && data.product_id) ? data.product_id : '';
    var productName = (data && data.product_name) ? data.product_name : '';
    var qty = (data && data.quantity) ? data.quantity : '';
    var price = (data && data.unit_price) ? data.unit_price : '';
    var amount = (data && data.amount) ? data.amount : '';
    var reason = (data && data.reason) ? data.reason : '';

    tr.innerHTML = '<td>' + (idx + 1) + '</td>' +
        '<td><input type="hidden" name="items[' + idx + '][product_id]" value="' + escHtml(productId) + '"><input type="text" name="items[' + idx + '][product_name]" class="form-control" value="' + escHtml(productName) + '" placeholder="品名"></td>' +
        '<td><input type="number" name="items[' + idx + '][quantity]" class="form-control item-qty" value="' + escHtml(qty) + '" min="0" step="1" onchange="calcRow(this)"></td>' +
        '<td><input type="number" name="items[' + idx + '][unit_price]" class="form-control item-price" value="' + escHtml(price) + '" min="0" step="0.01" onchange="calcRow(this)"></td>' +
        '<td><input type="number" name="items[' + idx + '][amount]" class="form-control item-amount" value="' + escHtml(amount) + '" min="0" step="0.01"></td>' +
        '<td><input type="text" name="items[' + idx + '][reason]" class="form-control" value="' + escHtml(reason) + '" placeholder="原因"></td>' +
        '<td><button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">&times;</button></td>';
    tbody.appendChild(tr);
    calcTotal();
}

function removeItem(btn) {
    btn.closest('tr').remove();
    calcTotal();
}

function calcRow(el) {
    var tr = el.closest('tr');
    var qty = parseFloat(tr.querySelector('.item-qty').value) || 0;
    var price = parseFloat(tr.querySelector('.item-price').value) || 0;
    tr.querySelector('.item-amount').value = (qty * price).toFixed(2);
    calcTotal();
}

function calcTotal() {
    var amounts = document.querySelectorAll('.item-amount');
    var total = 0;
    for (var i = 0; i < amounts.length; i++) {
        total += parseFloat(amounts[i].value) || 0;
    }
    document.getElementById('totalAmount').value = total.toFixed(2);
    document.getElementById('totalDisplay').textContent = '$' + Math.round(total).toLocaleString();
}

function escHtml(str) {
    if (!str && str !== 0) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Init
document.getElementById('returnType').addEventListener('change', toggleTypeFields);
toggleTypeFields();

if (existingItems.length > 0) {
    for (var i = 0; i < existingItems.length; i++) {
        addItem(existingItems[i]);
    }
} else {
    addItem();
}
</script>
