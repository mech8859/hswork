<h2><?= $user ? '編輯人員 - ' . e($user['real_name']) : '新增人員' ?></h2>

<form method="POST" class="mt-2">
    <?= csrf_field() ?>

    <div class="card">
        <div class="card-header">帳號資料</div>
        <div class="form-row">
            <div class="form-group">
                <label>帳號 *</label>
                <?php if ($user): ?>
                    <?php if (Auth::user()['role'] === 'boss'): ?>
                        <input type="text" name="username" class="form-control" value="<?= e($user['username']) ?>" required>
                    <?php else: ?>
                        <input type="text" class="form-control" value="<?= e($user['username']) ?>" disabled>
                    <?php endif; ?>
                <?php else: ?>
                    <input type="text" name="username" class="form-control" value="<?= e($_POST['username'] ?? '') ?>" required>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label><?= $user ? '新密碼 (留空不修改)' : '密碼 *' ?></label>
                <div style="position:relative">
                    <input type="password" name="password" id="pwField" class="form-control" style="padding-right:40px" <?= $user ? '' : 'required' ?>>
                    <span onclick="togglePw()" id="pwEye" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);cursor:pointer;font-size:1.1rem;color:var(--gray-500);user-select:none">&#128065;</span>
                </div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>真實姓名 *</label>
                <input type="text" name="real_name" class="form-control" value="<?= e($user['real_name'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label>據點 *</label>
                <select name="branch_id" class="form-control" required>
                    <option value="">請選擇</option>
                    <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= ($user['branch_id'] ?? '') == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>角色 *</label>
                <select name="role" class="form-control" required>
                    <?php
                    $dynamicRoles = get_dynamic_roles();
                    foreach ($dynamicRoles as $v => $l):
                    ?>
                    <option value="<?= $v ?>" <?= ($user['role'] ?? '') === $v ? 'selected' : '' ?>><?= e($l) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>電話</label>
                <input type="text" name="phone" class="form-control" value="<?= e($user['phone'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?= e($user['email'] ?? '') ?>">
            </div>
        </div>
        <div class="checkbox-row mt-1">
            <label class="checkbox-label">
                <input type="hidden" name="is_engineer" value="0">
                <input type="checkbox" name="is_engineer" value="1" <?= !empty($user['is_engineer']) ? 'checked' : '' ?>>
                <span>工程師 (可排工)</span>
            </label>
            <label class="checkbox-label">
                <input type="hidden" name="is_mobile" value="0">
                <input type="checkbox" name="is_mobile" value="1" <?= ($user['is_mobile'] ?? 1) ? 'checked' : '' ?>>
                <span>手機介面</span>
            </label>
        </div>

        <!-- 可查看分公司 -->
        <div class="form-group mt-1">
            <label>可查看分公司</label>
            <div class="checkbox-row">
                <label class="checkbox-label">
                    <input type="checkbox" id="viewAllBranches" onchange="toggleAllBranches(this)" <?= !empty($user['can_view_all_branches']) ? 'checked' : '' ?>>
                    <span style="font-weight:600">全部分公司</span>
                </label>
                <input type="hidden" name="can_view_all_branches" value="0" id="viewAllHidden">
            </div>
            <div class="checkbox-row mt-1" id="branchCheckboxes" style="<?= !empty($user['can_view_all_branches']) ? 'opacity:.4;pointer-events:none' : '' ?>">
                <?php
                $viewableBranches = array();
                if (!empty($user['viewable_branches'])) {
                    $viewableBranches = is_array($user['viewable_branches']) ? $user['viewable_branches'] : json_decode($user['viewable_branches'], true);
                    if (!is_array($viewableBranches)) $viewableBranches = array();
                }
                foreach ($branches as $b):
                    $isOwn = ($user['branch_id'] ?? 0) == $b['id'];
                ?>
                <label class="checkbox-label">
                    <input type="checkbox" name="viewable_branch_ids[]" value="<?= $b['id'] ?>"
                           <?= $isOwn ? 'checked disabled' : '' ?>
                           <?= in_array($b['id'], $viewableBranches) ? 'checked' : '' ?>>
                    <span><?= e($b['name']) ?><?= $isOwn ? ' (所屬)' : '' ?></span>
                </label>
                <?php if ($isOwn): ?>
                <input type="hidden" name="viewable_branch_ids[]" value="<?= $b['id'] ?>">
                <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <small class="text-muted">所屬分公司預設可查看，勾選其他分公司開放查看權限</small>
        </div>
    </div>

    <div class="card">
        <div class="card-header">施工配合度</div>
        <div class="form-row">
            <div class="form-group">
                <label>假日施工配合度</label>
                <select name="holiday_availability" class="form-control">
                    <option value="high" <?= ($user['holiday_availability'] ?? 'medium') === 'high' ? 'selected' : '' ?>>高</option>
                    <option value="medium" <?= ($user['holiday_availability'] ?? 'medium') === 'medium' ? 'selected' : '' ?>>中</option>
                    <option value="low" <?= ($user['holiday_availability'] ?? 'medium') === 'low' ? 'selected' : '' ?>>低</option>
                </select>
            </div>
            <div class="form-group">
                <label>夜間施工配合度</label>
                <select name="night_availability" class="form-control">
                    <option value="high" <?= ($user['night_availability'] ?? 'medium') === 'high' ? 'selected' : '' ?>>高</option>
                    <option value="medium" <?= ($user['night_availability'] ?? 'medium') === 'medium' ? 'selected' : '' ?>>中</option>
                    <option value="low" <?= ($user['night_availability'] ?? 'medium') === 'low' ? 'selected' : '' ?>>低</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>注意事項</label>
            <textarea name="caution_notes" class="form-control" rows="2" placeholder="如：懼高症、色弱、不可夜間施工等"><?= e($user['caution_notes'] ?? '') ?></textarea>
        </div>
    </div>


    <div class="d-flex gap-1 mt-2">
        <button type="submit" class="btn btn-primary"><?= $user ? '儲存變更' : '建立人員' ?></button>
        <a href="/staff.php" class="btn btn-outline">取消</a>
    </div>
</form>

<script>
function togglePw() {
    var f = document.getElementById('pwField');
    var e = document.getElementById('pwEye');
    if (f.type === 'password') { f.type = 'text'; e.style.opacity = '1'; }
    else { f.type = 'password'; e.style.opacity = '0.5'; }
}
</script>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
.checkbox-row { display: flex; flex-wrap: wrap; gap: 16px; }
.checkbox-label { display: flex; align-items: center; gap: 6px; cursor: pointer; }
.checkbox-label input[type="checkbox"] { width: 18px; height: 18px; }
</style>

<script>
function toggleAllBranches(cb) {
    var container = document.getElementById('branchCheckboxes');
    var hidden = document.getElementById('viewAllHidden');
    if (cb.checked) {
        container.style.opacity = '.4';
        container.style.pointerEvents = 'none';
        hidden.value = '1';
    } else {
        container.style.opacity = '1';
        container.style.pointerEvents = 'auto';
        hidden.value = '0';
    }
}
</script>
