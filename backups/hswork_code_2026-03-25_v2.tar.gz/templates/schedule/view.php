<?php
$statusLabels = array('planned'=>'已規劃','confirmed'=>'已確認','in_progress'=>'施工中','completed'=>'已完工','cancelled'=>'已取消');
$statusBadge = array('planned'=>'primary','confirmed'=>'info','in_progress'=>'warning','completed'=>'success','cancelled'=>'danger');

// 取得案件相關資訊
$caseNote = '';
$casePhotos = array();
$caseDrawings = array();
$customerPhone = '';
$customerMobile = '';
$customerContact = '';
$caseQuote = null;
if ($schedule['case_id']) {
    $db = Database::getInstance();
    $nStmt = $db->prepare("
        SELECT c.notes, c.description, c.customer_name, c.construction_note,
               c.planned_start_date, c.planned_end_date, c.urgency,
               c.work_time_start, c.work_time_end, c.customer_break_time,
               c.has_time_restriction, c.allow_night_work, c.is_flexible, c.is_large_project,
               cu.phone as cu_phone, cu.mobile as cu_mobile, cu.contact_person as cu_contact, cu.fax
        FROM cases c
        LEFT JOIN customers cu ON c.customer_id = cu.id
        WHERE c.id = ?
    ");
    $nStmt->execute(array($schedule['case_id']));
    $caseInfo = $nStmt->fetch(PDO::FETCH_ASSOC);
    $constructionNote = '';
    // 從 case_contacts 取聯絡人（第一筆）
    $ccStmt = $db->prepare("SELECT contact_name, contact_phone FROM case_contacts WHERE case_id = ? LIMIT 1");
    $ccStmt->execute(array($schedule['case_id']));
    $caseContact = $ccStmt->fetch(PDO::FETCH_ASSOC);
    if ($caseInfo) {
        $caseNote = $caseInfo['notes'] ?: $caseInfo['description'] ?: '';
        $customerPhone = $caseInfo['cu_phone'] ?: ($caseContact ? $caseContact['contact_phone'] : '') ?: '';
        $customerMobile = $caseInfo['cu_mobile'] ?: '';
        $customerContact = $caseInfo['cu_contact'] ?: ($caseContact ? $caseContact['contact_name'] : '') ?: '';
        $constructionNote = $caseInfo['construction_note'] ?: '';
    }
    // 現場照片
    $pStmt = $db->prepare("SELECT file_path, file_name FROM case_attachments WHERE case_id = ? AND file_type = 'site_photo' LIMIT 8");
    $pStmt->execute(array($schedule['case_id']));
    $casePhotos = $pStmt->fetchAll(PDO::FETCH_ASSOC);
    // 施工圖
    $dStmt = $db->prepare("SELECT file_path, file_name FROM case_attachments WHERE case_id = ? AND file_type = 'drawing' LIMIT 8");
    $dStmt->execute(array($schedule['case_id']));
    $caseDrawings = $dStmt->fetchAll(PDO::FETCH_ASSOC);
    // 報價單
    $qStmt = $db->prepare("SELECT quotation_number, total_amount, status FROM quotations WHERE case_id = ? ORDER BY id DESC LIMIT 1");
    $qStmt->execute(array($schedule['case_id']));
    $caseQuote = $qStmt->fetch(PDO::FETCH_ASSOC);
}
?>

<div class="d-flex justify-between align-center flex-wrap gap-1 mb-2">
    <div>
        <h2>排工詳情</h2>
        <span class="badge badge-<?= $statusBadge[$schedule['status']] ?? 'primary' ?>"><?= e($statusLabels[$schedule['status']] ?? $schedule['status']) ?></span>
    </div>
    <div class="d-flex gap-1">
        <a href="/worklog.php?action=report&id=<?= $myWorklog['id'] ?>&from_schedule=<?= $schedule['id'] ?>" class="btn btn-sm" style="background:#FF9800;color:#fff">📝 施工回報</a>
        <?php if (Auth::hasPermission('schedule.manage')): ?>
        <a href="/schedule.php?action=edit&id=<?= $schedule['id'] ?>" class="btn btn-primary btn-sm">編輯</a>
        <a href="/schedule.php?action=delete&id=<?= $schedule['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>"
           class="btn btn-danger btn-sm" onclick="return confirm('確定刪除此排工?')">刪除</a>
        <?php endif; ?>
        <a href="/schedule.php" class="btn btn-outline btn-sm">返回行事曆</a>
    </div>
</div>

<!-- 排工資料 -->
<div class="card">
    <div class="card-header">排工資料</div>
    <div class="detail-grid">
        <div class="detail-item">
            <span class="detail-label">案件</span>
            <span class="detail-value"><a href="/cases.php?action=edit&id=<?= $schedule['case_id'] ?>&from=schedule"><?= e($schedule['case_number']) ?> - <?= e($schedule['case_title']) ?></a></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">施工日期</span>
            <span class="detail-value"><?= format_date($schedule['schedule_date']) ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">施工地址</span>
            <span class="detail-value"><?= e($schedule['address'] ?: '-') ?></span>
        </div>
        <?php if (!empty($schedule['address'])): ?>
        <div class="detail-item" style="grid-column: span 2">
            <span class="detail-label">地圖</span>
            <a href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($schedule['address']) ?>" target="_blank" style="font-size:.8rem;margin-bottom:4px">Google 地圖 ↗</a>
            <iframe src="https://maps.google.com/maps?q=<?= urlencode($schedule['address']) ?>&output=embed&hl=zh-TW" style="width:100%;max-width:480px;height:200px;border:1px solid var(--gray-200);border-radius:6px" allowfullscreen loading="lazy"></iframe>
        </div>
        <?php endif; ?>
        <div class="detail-item">
            <span class="detail-label">第幾次施工</span>
            <span class="detail-value"><?= $schedule['visit_number'] ?> / <?= $schedule['total_visits'] ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">車輛</span>
            <span class="detail-value"><?= $schedule['plate_number'] ? e($schedule['plate_number']) . ' (' . e($schedule['vehicle_type']) . ')' : '未指派' ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">據點</span>
            <span class="detail-value"><?= e($schedule['branch_name']) ?></span>
        </div>
    </div>
    <?php if ($schedule['note']): ?>
    <div style="padding:8px 12px"><span class="detail-label">備註</span><p style="margin:2px 0"><?= nl2br(e($schedule['note'])) ?></p></div>
    <?php endif; ?>
</div>

<!-- 客戶/聯絡資訊 -->
<div class="card">
    <div class="card-header">客戶資訊</div>
    <div class="detail-grid">
        <div class="detail-item">
            <span class="detail-label">客戶名稱</span>
            <span class="detail-value"><?= e($schedule['case_title'] ?: '-') ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">聯絡人</span>
            <span class="detail-value"><?= e($customerContact ?: '-') ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">電話</span>
            <span class="detail-value"><?php if ($customerPhone): ?><a href="tel:<?= e($customerPhone) ?>"><?= e($customerPhone) ?></a><?php else: ?>-<?php endif; ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">手機</span>
            <span class="detail-value"><?php if ($customerMobile): ?><a href="tel:<?= e($customerMobile) ?>"><?= e($customerMobile) ?></a><?php else: ?>-<?php endif; ?></span>
        </div>
    </div>
    <?php if ($caseNote): ?>
    <div style="padding:8px 12px;border-top:1px solid var(--gray-100)">
        <span class="detail-label">業務備註</span>
        <p style="margin:4px 0;white-space:pre-line"><?= nl2br(e($caseNote)) ?></p>
    </div>
    <?php endif; ?>
    <?php if ($caseQuote): ?>
    <div style="padding:8px 12px;border-top:1px solid var(--gray-100)">
        <span class="detail-label">報價單</span>
        <span><?= e($caseQuote['quotation_number']) ?> — $<?= number_format($caseQuote['total_amount']) ?></span>
    </div>
    <?php endif; ?>
</div>

<!-- 施工時程與條件 -->
<?php if ($caseInfo): ?>
<div class="card">
    <div class="card-header">施工時程與條件</div>
    <div class="detail-grid">
        <div class="detail-item">
            <span class="detail-label">預計施工日</span>
            <span class="detail-value"><?= !empty($caseInfo['planned_start_date']) ? format_date($caseInfo['planned_start_date']) : '-' ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">預計完工日</span>
            <span class="detail-value"><?= !empty($caseInfo['planned_end_date']) ? format_date($caseInfo['planned_end_date']) : '-' ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">急迫性</span>
            <span class="detail-value"><?= (int)($caseInfo['urgency'] ?? 3) ?> <?= (int)($caseInfo['urgency'] ?? 3) >= 4 ? '<span style="color:var(--danger)">(高)</span>' : '' ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">施工時間</span>
            <span class="detail-value">
                <?php if (!empty($caseInfo['work_time_start']) && !empty($caseInfo['work_time_end'])): ?>
                <?= e($caseInfo['work_time_start']) ?> ~ <?= e($caseInfo['work_time_end']) ?>
                <?php else: ?>-<?php endif; ?>
            </span>
        </div>
        <?php if (!empty($caseInfo['customer_break_time'])): ?>
        <div class="detail-item">
            <span class="detail-label">客戶休息時間</span>
            <span class="detail-value"><?= e($caseInfo['customer_break_time']) ?></span>
        </div>
        <?php endif; ?>
        <div class="detail-item">
            <span class="detail-label">條件</span>
            <span class="detail-value">
                <?php
                $tags = array();
                if (!empty($caseInfo['has_time_restriction'])) $tags[] = '有施工時間限制';
                if (!empty($caseInfo['allow_night_work'])) $tags[] = '可夜間加班';
                if (!empty($caseInfo['is_flexible'])) $tags[] = '可隨時安排';
                if (!empty($caseInfo['is_large_project'])) $tags[] = '大型案件';
                echo !empty($tags) ? implode('、', $tags) : '-';
                ?>
            </span>
        </div>
    </div>
    <?php if ($constructionNote): ?>
    <div style="padding:8px 12px;border-top:1px solid var(--gray-100);background:#fff8e1">
        <span class="detail-label" style="color:#e65100">⚠ 施工注意事項</span>
        <p style="margin:4px 0;white-space:pre-line;color:#bf360c;font-weight:500"><?= nl2br(e($constructionNote)) ?></p>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- 施工人員 -->
<div class="card">
    <div class="card-header">施工人員</div>
    <?php if (empty($schedule['engineers'])): ?>
        <p class="text-muted" style="padding:12px">未指派工程師</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>姓名</th><th>電話</th><th>主工程師</th><th>強制加入</th></tr></thead>
            <tbody>
                <?php foreach ($schedule['engineers'] as $eng): ?>
                <tr>
                    <td><a href="/staff.php?action=view&id=<?= $eng['user_id'] ?>"><?= e($eng['real_name']) ?></a></td>
                    <td><a href="tel:<?= e($eng['phone'] ?? '') ?>"><?= e($eng['phone'] ?? '-') ?></a></td>
                    <td><?= $eng['is_lead'] ? '<span class="badge badge-primary">主工程師</span>' : '-' ?></td>
                    <td>
                        <?php if ($eng['is_override']): ?>
                        <span class="badge badge-warning">強制加入</span>
                        <?php if ($eng['override_reason']): ?><br><small><?= e($eng['override_reason']) ?></small><?php endif; ?>
                        <?php else: ?>-<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php if (!empty($schedule['dispatch_workers'])): ?>
<div class="card">
    <div class="card-header">點工人員</div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>姓名</th><th>電話</th><th>所屬廠商</th></tr></thead>
            <tbody>
                <?php foreach ($schedule['dispatch_workers'] as $dw): ?>
                <tr>
                    <td><?= e($dw['name']) ?></td>
                    <td><a href="tel:<?= e($dw['phone'] ?? '') ?>"><?= e($dw['phone'] ?? '-') ?></a></td>
                    <td><?= e($dw['vendor'] ?? '-') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- 現場照片 + 施工圖 -->
<?php if (!empty($casePhotos) || !empty($caseDrawings)): ?>
<div class="card">
    <div class="card-header">現場資料</div>
    <?php if (!empty($casePhotos)): ?>
    <div style="padding:12px;border-bottom:1px solid var(--gray-100)">
        <span class="detail-label">現場照片</span>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
            <?php foreach ($casePhotos as $cp): ?>
            <img src="<?= e($cp['file_path']) ?>" style="width:80px;height:80px;object-fit:cover;border-radius:4px;cursor:pointer;border:1px solid var(--gray-200)" onclick="window.open('<?= e($cp['file_path']) ?>','_blank')" alt="<?= e($cp['file_name']) ?>">
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($caseDrawings)): ?>
    <div style="padding:12px">
        <span class="detail-label">施工圖</span>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
            <?php foreach ($caseDrawings as $cd):
                $ext = strtolower(pathinfo($cd['file_name'], PATHINFO_EXTENSION));
                $isImg = in_array($ext, array('jpg','jpeg','png','gif','webp'));
            ?>
            <?php if ($isImg): ?>
            <img src="<?= e($cd['file_path']) ?>" style="width:80px;height:80px;object-fit:cover;border-radius:4px;cursor:pointer;border:1px solid var(--gray-200)" onclick="window.open('<?= e($cd['file_path']) ?>','_blank')" alt="<?= e($cd['file_name']) ?>">
            <?php else: ?>
            <a href="<?= e($cd['file_path']) ?>" target="_blank" style="display:flex;align-items:center;gap:4px;padding:6px 10px;background:var(--gray-50);border-radius:4px;font-size:.8rem">📄 <?= e($cd['file_name']) ?></a>
            <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- 施工回報紀錄 -->
<div class="card">
    <div class="card-header d-flex justify-between align-center">
        <span>施工回報紀錄</span>
        <a href="/worklog.php?action=report&id=<?= $myWorklog['id'] ?>&from_schedule=<?= $schedule['id'] ?>" class="btn btn-sm" style="background:#FF9800;color:#fff">📝 填寫回報</a>
    </div>
    <?php
    // 顯示所有有內容的回報
    $filledWorklogs = array();
    foreach ($worklogs as $wl) {
        if (!empty($wl['work_description'])) $filledWorklogs[] = $wl;
    }
    ?>
    <?php if (empty($filledWorklogs)): ?>
        <p class="text-muted" style="padding:16px">尚無施工回報</p>
    <?php else: ?>
        <?php foreach ($filledWorklogs as $wl): ?>
        <div style="padding:12px;border-bottom:1px solid var(--gray-100)">
            <div class="d-flex justify-between align-center mb-1">
                <div>
                    <strong><?= e($wl['real_name']) ?></strong>
                    <?php if ($wl['arrival_time'] && $wl['departure_time']): ?>
                    <span class="text-muted" style="font-size:.8rem;margin-left:8px">
                        <?= date('H:i', strtotime($wl['arrival_time'])) ?> ~ <?= date('H:i', strtotime($wl['departure_time'])) ?>
                        <?php $dur = strtotime($wl['departure_time']) - strtotime($wl['arrival_time']); if ($dur > 0) echo ' (' . round($dur/3600, 1) . 'h)'; ?>
                    </span>
                    <?php endif; ?>
                    <?php if (!empty($wl['is_completed'])): ?>
                    <span class="badge badge-success" style="margin-left:4px">已完工</span>
                    <?php endif; ?>
                    <?php if (!empty($wl['next_visit_needed'])): ?>
                    <span class="badge badge-warning" style="margin-left:4px">需再施工</span>
                    <?php endif; ?>
                </div>
                <a href="/worklog.php?action=report&id=<?= $wl['id'] ?>&from_schedule=<?= $schedule['id'] ?>" class="btn btn-outline btn-sm" style="font-size:.75rem">編輯</a>
            </div>
            <div style="margin-bottom:4px"><p style="margin:2px 0;white-space:pre-line"><?= e($wl['work_description']) ?></p></div>
            <?php if ($wl['issues']): ?>
            <div style="margin-bottom:4px"><span style="font-size:.8rem;color:var(--danger)">問題：</span><span style="font-size:.9rem"><?= e($wl['issues']) ?></span></div>
            <?php endif; ?>
            <?php if (!empty($wl['photos'])): ?>
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin:4px 0">
                <?php foreach ($wl['photos'] as $p): ?>
                <a href="<?= e($p['file_path']) ?>" target="_blank"><img src="<?= e($p['file_path']) ?>" style="width:60px;height:60px;object-fit:cover;border-radius:4px;border:1px solid var(--gray-200)"></a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php if ($wl['payment_collected']): ?>
            <div><span class="badge badge-success">收款</span> $<?= number_format($wl['payment_amount']) ?> (<?= e($wl['payment_method'] ?: '-') ?>)</div>
            <?php endif; ?>
            <?php if (!empty($wl['next_visit_needed'])): ?>
            <div style="color:#e65100;font-size:.85rem">
                ⚠ 需再次施工
                <?php if (!empty($wl['next_visit_date'])): ?> — 預計 <?= e($wl['next_visit_date']) ?><?php endif; ?>
                <?php if ($wl['next_visit_note']): ?><?= e($wl['next_visit_note']) ?><?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
    <?php if ($schedule['case_id']): ?>
    <div style="padding:8px;text-align:center">
        <a href="/cases.php?action=edit&id=<?= $schedule['case_id'] ?>&from=schedule#sec-worklog" class="btn btn-outline btn-sm">查看完整回報紀錄</a>
    </div>
    <?php endif; ?>
</div>

<style>
.detail-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; padding: 12px; }
.detail-item { display: flex; flex-direction: column; }
.detail-label { font-size: .8rem; color: var(--gray-500); }
@media (max-width: 767px) { .detail-grid { grid-template-columns: 1fr; } }
</style>
