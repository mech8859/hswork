<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= e($pageTitle ?? '弱電工程排程系統') ?></title>
    <link rel="stylesheet" href="/css/style.css">
    <?php if (!empty($extraCss)): ?>
        <?php foreach ($extraCss as $css): ?>
            <link rel="stylesheet" href="<?= e($css) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
<?php if (Session::isLoggedIn()): ?>
<nav class="navbar">
    <div class="navbar-brand">
        <button class="menu-toggle" id="menuToggle" aria-label="選單">&#9776;</button>
        <span class="navbar-title">弱電排程</span>
    </div>
    <div class="navbar-user">
        <span class="user-branch"><?= e(Session::getUser()['branch_name'] ?? '') ?></span>
        <span class="user-name"><?= e(Session::getUser()['real_name'] ?? '') ?></span>
        <span class="user-role"><?= e(role_name(Session::getUser()['role'] ?? '')) ?></span>
    </div>
</nav>
<aside class="sidebar" id="sidebar">
    <ul class="nav-menu">
        <?php $cp = Session::get('custom_permissions'); ?>
        <li><a href="/index.php" class="<?= ($currentPage ?? '') === 'dashboard' ? 'active' : '' ?>">🏠 儀表板</a></li>

        <?php if (Auth::hasPermission('cases.manage') || Auth::hasPermission('cases.view') || Auth::hasPermission('cases.own')): ?>
        <li><a href="/cases.php" class="<?= ($currentPage ?? '') === 'cases' ? 'active' : '' ?>">📋 案件管理</a></li>
        <?php endif; ?>

        <!-- 工程管理 -->
        <li class="nav-section">工程管理</li>
        <?php if (Auth::hasPermission('engineering_tracking.manage') || Auth::hasPermission('engineering_tracking.view') || Auth::hasPermission('engineering_tracking.own')): ?>
        <li><a href="/engineering_tracking.php" class="<?= ($currentPage ?? '') === 'engineering_tracking' ? 'active' : '' ?>">🔧 工程追蹤</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('schedule.manage') || Auth::hasPermission('schedule.view')): ?>
        <li><a href="/schedule.php" class="<?= ($currentPage ?? '') === 'schedule' ? 'active' : '' ?>">📅 工程行事曆</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('repairs.manage') || Auth::hasPermission('repairs.view') || Auth::hasPermission('repairs.own')): ?>
        <li><a href="/repairs.php" class="<?= ($currentPage ?? '') === 'repairs' ? 'active' : '' ?>">🔧 維修單</a></li>
        <?php endif; ?>
        <?php if (Auth::canEditSection('worklog')): ?>
        <li><a href="/worklog.php" class="<?= ($currentPage ?? '') === 'worklog' ? 'active' : '' ?>">📝 施工回報</a></li>
        <?php endif; ?>
        <?php if ((Auth::hasPermission('schedule.manage') || Auth::hasPermission('schedule.view')) && (!is_array($cp) || !isset($cp['attendance']) || $cp['attendance'])): ?>
        <li><a href="/attendance.php" class="<?= ($currentPage ?? '') === 'attendance' ? 'active' : '' ?>">📊 出勤狀況表</a></li>
        <?php endif; ?>

        <!-- 業務管理 -->
        <li class="nav-section">業務管理</li>
        <?php if (Auth::hasPermission('business_tracking.manage') || Auth::hasPermission('business_tracking.view') || Auth::hasPermission('business_tracking.own')): ?>
        <li><a href="/business_tracking.php" class="<?= ($currentPage ?? '') === 'business_tracking' ? 'active' : '' ?>">📊 業務追蹤表</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('quotations.manage') || Auth::hasPermission('quotations.view') || Auth::hasPermission('quotations.own')): ?>
        <li><a href="/quotations.php" class="<?= ($currentPage ?? '') === 'quotations' ? 'active' : '' ?>">💲 報價管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('business_calendar.manage') || Auth::hasPermission('business_calendar.view')): ?>
        <li><a href="/business_calendar.php" class="<?= ($currentPage ?? '') === 'business_calendar' ? 'active' : '' ?>">📅 業務行事曆</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('customers.manage') || Auth::hasPermission('customers.view')): ?>
        <li><a href="/customers.php" class="<?= ($currentPage ?? '') === 'customers' ? 'active' : '' ?>">👤 客戶管理</a></li>
        <?php endif; ?>

        <!-- 簽核管理 -->
        <?php
        $pendingApprovalCount = 0;
        try {
            require_once __DIR__ . '/../../modules/approvals/ApprovalModel.php';
            $tmpApproval = new ApprovalModel();
            $pendingApprovalCount = $tmpApproval->getPendingCount(Auth::id());
        } catch (Exception $e) {}
        $showApprovalMenu = $pendingApprovalCount > 0 || Auth::hasPermission('all') || in_array(Session::getUser()['role'], array('boss', 'sales_manager', 'eng_manager'));
        ?>
        <?php if ($showApprovalMenu): ?>
        <li class="nav-section">簽核管理</li>
        <li><a href="/approvals.php" class="<?= ($currentPage ?? '') === 'approvals' ? 'active' : '' ?>">✅ 待簽核<?php if ($pendingApprovalCount > 0): ?> <span class="badge" style="background:var(--danger);color:#fff;font-size:.7rem"><?= $pendingApprovalCount ?></span><?php endif; ?></a></li>
        <?php if (Auth::hasPermission('all') || in_array(Session::getUser()['role'], array('boss', 'sales_manager'))): ?>
        <li><a href="/approvals.php?action=settings" class="<?= ($currentPage ?? '') === 'approval_settings' ? 'active' : '' ?>">⚙️ 簽核設定</a></li>
        <?php endif; ?>
        <?php endif; ?>

        <!-- 產品庫存 -->
        <?php if (!is_array($cp) || !isset($cp['products']) || $cp['products']): ?>
        <li class="nav-section">產品庫存</li>
        <li><a href="/products.php" class="<?= ($currentPage ?? '') === 'products' ? 'active' : '' ?>">📦 產品目錄</a></li>
        <?php endif; ?>

        <!-- 財務會計 -->
        <?php if (Auth::hasPermission('finance.manage') || Auth::hasPermission('finance.view')): ?>
        <li class="nav-section">財務會計</li>
        <li><a href="/receivables.php" class="<?= ($currentPage ?? '') === 'receivables' ? 'active' : '' ?>">📄 應收帳款</a></li>
        <li><a href="/receipts.php" class="<?= ($currentPage ?? '') === 'receipts' ? 'active' : '' ?>">💰 收款單</a></li>
        <li><a href="/payables.php" class="<?= ($currentPage ?? '') === 'payables' ? 'active' : '' ?>">📋 應付帳款單</a></li>
        <li><a href="/payments_out.php" class="<?= ($currentPage ?? '') === 'payments_out' ? 'active' : '' ?>">💸 付款單</a></li>
        <li><a href="/bank_transactions.php" class="<?= ($currentPage ?? '') === 'bank_transactions' ? 'active' : '' ?>">🏦 銀行帳戶明細</a></li>
        <li><a href="/petty_cash.php" class="<?= ($currentPage ?? '') === 'petty_cash' ? 'active' : '' ?>">🪙 零用金管理</a></li>
        <li><a href="/reserve_fund.php" class="<?= ($currentPage ?? '') === 'reserve_fund' ? 'active' : '' ?>">💵 備用金管理</a></li>
        <li><a href="/cash_details.php" class="<?= ($currentPage ?? '') === 'cash_details' ? 'active' : '' ?>">📝 現金明細</a></li>
        <li><a href="/purchase_invoices.php" class="<?= ($currentPage ?? '') === 'purchase_invoices' ? 'active' : '' ?>">📥 進項發票</a></li>
        <li><a href="/sales_invoices.php" class="<?= ($currentPage ?? '') === 'sales_invoices' ? 'active' : '' ?>">📤 銷項發票</a></li>
        <li><a href="/tax_report.php" class="<?= ($currentPage ?? '') === 'tax_report' ? 'active' : '' ?>">📊 401營業稅申報</a></li>
        <?php endif; ?>

        <!-- 會計管理 -->
        <?php if (Auth::hasPermission('accounting.manage') || Auth::hasPermission('accounting.view') || Auth::hasPermission('finance.manage') || Auth::hasPermission('finance.view')): ?>
        <li class="nav-section">會計管理</li>
        <li><a href="/accounting.php?action=journals" class="<?= ($currentPage ?? '') === 'accounting' && !in_array(($action ?? ''), array('accounts','cost_centers','ledger','trial_balance','income_statement','balance_sheet','reconciliation')) ? 'active' : '' ?>">📋 傳票管理</a></li>
        <li><a href="/accounting.php?action=accounts" class="<?= ($currentPage ?? '') === 'accounting' && ($action ?? '') === 'accounts' ? 'active' : '' ?>">📊 會計科目</a></li>
        <li><a href="/accounting.php?action=cost_centers" class="<?= ($currentPage ?? '') === 'accounting' && ($action ?? '') === 'cost_centers' ? 'active' : '' ?>">🏢 成本中心</a></li>
        <li><a href="/accounting.php?action=ledger" class="<?= ($currentPage ?? '') === 'accounting' && ($action ?? '') === 'ledger' ? 'active' : '' ?>">📖 總帳查詢</a></li>
        <li><a href="/accounting.php?action=trial_balance" class="<?= ($currentPage ?? '') === 'accounting' && ($action ?? '') === 'trial_balance' ? 'active' : '' ?>">📑 試算表</a></li>
        <li><a href="/accounting.php?action=income_statement" class="<?= ($currentPage ?? '') === 'accounting' && ($action ?? '') === 'income_statement' ? 'active' : '' ?>">📈 損益表</a></li>
        <li><a href="/accounting.php?action=balance_sheet" class="<?= ($currentPage ?? '') === 'accounting' && ($action ?? '') === 'balance_sheet' ? 'active' : '' ?>">📊 資產負債表</a></li>
        <li><a href="/accounting.php?action=reconciliation" class="<?= ($currentPage ?? '') === 'accounting' && ($action ?? '') === 'reconciliation' ? 'active' : '' ?>">🏦 銀行對帳</a></li>
        <?php endif; ?>

        <!-- 採購庫存 -->
        <?php if (Auth::hasPermission('inventory.manage') || Auth::hasPermission('inventory.view') || Auth::hasPermission('procurement.manage') || Auth::hasPermission('procurement.view')): ?>
        <li class="nav-section">採購庫存</li>
        <li><a href="/inventory.php" class="<?= ($currentPage ?? '') === 'inventory' ? 'active' : '' ?>">📦 庫存管理</a></li>
        <li><a href="/requisitions.php" class="<?= ($currentPage ?? '') === 'requisitions' ? 'active' : '' ?>">📋 請購單</a></li>
        <li><a href="/purchase_orders.php" class="<?= ($currentPage ?? '') === 'purchase_orders' ? 'active' : '' ?>">🛒 採購單</a></li>
        <li><a href="/goods_receipts.php" class="<?= ($currentPage ?? '') === 'goods_receipts' ? 'active' : '' ?>">📥 進貨單</a></li>
        <li><a href="/stock_ins.php" class="<?= ($currentPage ?? '') === 'stock_ins' ? 'active' : '' ?>">📦 入庫單</a></li>
        <li><a href="/warehouse_transfers.php" class="<?= ($currentPage ?? '') === 'warehouse_transfers' ? 'active' : '' ?>">🔄 倉庫調撥</a></li>
        <li><a href="/vendors.php" class="<?= ($currentPage ?? '') === 'vendors' ? 'active' : '' ?>">🏭 廠商管理</a></li>
        <?php endif; ?>

        <!-- 進銷存管理 -->
        <?php if (Auth::hasPermission('inventory.manage') || Auth::hasPermission('inventory.view')): ?>
        <li class="nav-section">進銷存管理</li>
        <li><a href="/delivery_orders.php" class="<?= ($currentPage ?? '') === 'delivery_orders' ? 'active' : '' ?>">📤 出貨單</a></li>
        <li><a href="/stock_outs.php" class="<?= ($currentPage ?? '') === 'stock_outs' ? 'active' : '' ?>">📦 出庫單</a></li>
        <li><a href="/goods_receipts.php" class="<?= ($currentPage ?? '') === 'goods_receipts' ? 'active' : '' ?>">📥 進貨單</a></li>
        <li><a href="/stock_ins.php" class="<?= ($currentPage ?? '') === 'stock_ins' ? 'active' : '' ?>">📦 入庫單</a></li>
        <li><a href="/returns.php" class="<?= ($currentPage ?? '') === 'returns' ? 'active' : '' ?>">🔄 退貨單</a></li>
        <li><a href="/warehouse_transfers.php" class="<?= ($currentPage ?? '') === 'warehouse_transfers' ? 'active' : '' ?>">🔀 調撥單</a></li>
        <li><a href="/inventory.php?action=stocktake_list" class="<?= ($currentPage ?? '') === 'stocktake' ? 'active' : '' ?>">📋 盤點單</a></li>
        <?php endif; ?>

        <!-- 人事行政 -->
        <li class="nav-section">人事行政</li>
        <?php if (Auth::hasPermission('staff.manage') || Auth::hasPermission('staff.view')): ?>
        <li><a href="/staff.php" class="<?= ($currentPage ?? '') === 'staff' ? 'active' : '' ?>">👥 人員管理</a></li>
        <?php endif; ?>
        <?php if (!is_array($cp) || !isset($cp['vehicles']) || $cp['vehicles']): ?>
        <li><a href="/vehicles.php" class="<?= ($currentPage ?? '') === 'vehicles' ? 'active' : '' ?>">🚗 車輛管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('leaves.manage') || Auth::hasPermission('leaves.own') || Auth::hasPermission('leaves.view')): ?>
        <li><a href="/leaves.php" class="<?= ($currentPage ?? '') === 'leaves' ? 'active' : '' ?>">🏖 請假管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('inter_branch.manage') || Auth::hasPermission('inter_branch.view')): ?>
        <li><a href="/inter_branch.php" class="<?= ($currentPage ?? '') === 'inter_branch' ? 'active' : '' ?>">💰 點工費管理</a></li>
        <?php endif; ?>
        <?php if (Auth::hasPermission('reports.view')): ?>
        <li><a href="/reports.php" class="<?= ($currentPage ?? '') === 'reports' ? 'active' : '' ?>">📈 報表</a></li>
        <?php endif; ?>

        <?php if (Auth::hasPermission('settings.manage')): ?>
        <!-- 系統設定 -->
        <li class="nav-section">系統設定</li>
        <li><a href="/dropdown_options.php" class="<?= ($currentPage ?? '') === 'dropdown_options' ? 'active' : '' ?>">⚙ 選單管理</a></li>
        <li><a href="/engineering_items.php" class="<?= ($currentPage ?? '') === 'engineering_items' ? 'active' : '' ?>">🔧 工程項次</a></li>
        <li><a href="/audit_logs.php" class="<?= ($currentPage ?? '') === 'audit_logs' ? 'active' : '' ?>">📋 操作日誌</a></li>
        <?php endif; ?>

        <li class="nav-divider"></li>
        <li><a href="/logout.php">🚪 登出</a></li>
    </ul>
</aside>
<script>
(function(){
    var el = document.querySelector('.sidebar a.active');
    if (el) el.scrollIntoView({block:'center',behavior:'auto'});
})();
</script>
<main class="content" id="mainContent">
<?php else: ?>
<main class="content content-full">
<?php endif; ?>

<?php
// Flash 訊息
$flashSuccess = Session::getFlash('success');
$flashError = Session::getFlash('error');
if ($flashSuccess): ?>
    <div class="alert alert-success"><?= e($flashSuccess) ?></div>
<?php endif; ?>
<?php if ($flashError): ?>
    <div class="alert alert-error"><?= e($flashError) ?></div>
<?php endif; ?>
