<div class="d-flex justify-between align-center mb-2">
    <h2>簽核設定</h2>
    <a href="/approvals.php" class="btn btn-outline btn-sm">← 待簽核清單</a>
</div>

<!-- 新增規則 -->
<div class="card mb-2">
    <div class="card-header">新增簽核規則</div>
    <form method="POST" action="/approvals.php?action=save_rule">
        <?= csrf_field() ?>
        <div class="form-row">
            <div class="form-group">
                <label>模組 *</label>
                <select name="module" class="form-control" required>
                    <option value="quotations">報價單</option>
                    <option value="expenses">支出單</option>
                    <option value="purchases">請購單</option>
                    <option value="leaves">請假單</option>
                    <option value="overtime">加班單</option>
                    <option value="case_completion">完工簽核</option>
                </select>
            </div>
            <div class="form-group" style="flex:2">
                <label>規則名稱 *</label>
                <input type="text" name="rule_name" class="form-control" placeholder="例：10萬以下免簽核、30萬以上需經理簽核" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>最低金額</label>
                <input type="number" name="min_amount" class="form-control" value="0" min="0">
            </div>
            <div class="form-group">
                <label>最高金額（空=無上限）</label>
                <input type="number" name="max_amount" class="form-control" min="0">
            </div>
            <div class="form-group">
                <label>最低利潤率 %（選填）</label>
                <input type="number" name="min_profit_rate" class="form-control" step="0.1" min="0" max="100">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>簽核人角色</label>
                <select name="approver_role" class="form-control" onchange="toggleApproverFields(this)">
                    <option value="">不指定角色</option>
                    <option value="auto_approve">免簽核（自動通過）</option>
                    <option value="boss">老闆/總經理</option>
                    <option value="sales_manager">業務經理</option>
                    <option value="eng_manager">工程主管</option>
                    <option value="eng_deputy">工程副主管</option>
                    <option value="admin_staff">行政人員(會計)</option>
                </select>
            </div>
            <div class="form-group" id="approver-id-group">
                <label>或指定簽核人</label>
                <select name="approver_id" class="form-control">
                    <option value="">不指定人</option>
                    <?php foreach ($approvers as $ap): ?>
                    <option value="<?= $ap['id'] ?>"><?= e($ap['real_name']) ?> (<?= e(ApprovalModel::roleLabel($ap['role'])) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="flex:0 0 100px">
                <label>簽核順序</label>
                <input type="number" name="level_order" class="form-control" value="1" min="1" max="10">
            </div>
        </div>
        <button type="submit" class="btn btn-primary">新增規則</button>
    </form>
</div>

<!-- 現有規則 -->
<div class="card">
    <div class="card-header">現有規則</div>
    <?php if (empty($rules)): ?>
    <p class="text-muted text-center" style="padding:20px">尚未設定簽核規則。未設定規則的模組，送簽核將自動通過。</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table" style="font-size:.85rem">
            <thead>
                <tr>
                    <th>模組</th>
                    <th>規則名稱</th>
                    <th>金額區間</th>
                    <th>利潤率</th>
                    <th>簽核人</th>
                    <th>順序</th>
                    <th>狀態</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rules as $rule): ?>
                <tr id="rule-row-<?= $rule['id'] ?>">
                    <td><span class="badge badge-primary"><?= e(ApprovalModel::moduleLabel($rule['module'])) ?></span></td>
                    <td><?= e($rule['rule_name']) ?></td>
                    <td>
                        $<?= number_format($rule['min_amount']) ?>
                        ~ <?= $rule['max_amount'] !== null ? '$' . number_format($rule['max_amount']) : '無上限' ?>
                    </td>
                    <td><?= $rule['min_profit_rate'] !== null ? $rule['min_profit_rate'] . '%' : '-' ?></td>
                    <td>
                        <?php if ($rule['approver_role'] === 'auto_approve'): ?>
                            <span style="color:#e67e22;font-weight:bold">免簽核（自動通過）</span>
                        <?php elseif ($rule['approver_name']): ?>
                            <?= e($rule['approver_name']) ?>
                        <?php elseif ($rule['approver_role']): ?>
                            <?= e(ApprovalModel::roleLabel($rule['approver_role'])) ?>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><?= $rule['level_order'] ?></td>
                    <td><?= $rule['is_active'] ? '<span style="color:green">啟用</span>' : '<span style="color:#999">停用</span>' ?></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-outline" onclick="toggleEditForm(<?= $rule['id'] ?>)">編輯</button>
                        <a href="/approvals.php?action=delete_rule&id=<?= $rule['id'] ?>&csrf_token=<?= e(Session::getCsrfToken()) ?>"
                           class="btn btn-danger btn-sm" onclick="return confirm('確定刪除此規則？')">刪除</a>
                    </td>
                </tr>
                <!-- 內嵌編輯表單 -->
                <tr id="edit-row-<?= $rule['id'] ?>" style="display:none; background:#f8f9fa;">
                    <td colspan="8" style="padding:12px 16px;">
                        <form method="POST" action="/approvals.php?action=save_rule" class="edit-rule-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= $rule['id'] ?>">
                            <input type="hidden" name="module" value="<?= e($rule['module']) ?>">
                            <div class="form-row">
                                <div class="form-group" style="flex:2">
                                    <label>規則名稱 *</label>
                                    <input type="text" name="rule_name" class="form-control" value="<?= e($rule['rule_name']) ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>最低金額</label>
                                    <input type="number" name="min_amount" class="form-control" value="<?= $rule['min_amount'] ?>" min="0">
                                </div>
                                <div class="form-group">
                                    <label>最高金額（空=無上限）</label>
                                    <input type="number" name="max_amount" class="form-control" value="<?= $rule['max_amount'] !== null ? $rule['max_amount'] : '' ?>" min="0">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label>最低利潤率 %</label>
                                    <input type="number" name="min_profit_rate" class="form-control" step="0.1" min="0" max="100" value="<?= $rule['min_profit_rate'] !== null ? $rule['min_profit_rate'] : '' ?>">
                                </div>
                                <div class="form-group">
                                    <label>簽核人角色</label>
                                    <select name="approver_role" class="form-control" onchange="toggleEditApproverFields(this, <?= $rule['id'] ?>)">
                                        <option value="">不指定角色</option>
                                        <option value="auto_approve" <?= $rule['approver_role'] === 'auto_approve' ? 'selected' : '' ?>>免簽核（自動通過）</option>
                                        <option value="boss" <?= $rule['approver_role'] === 'boss' ? 'selected' : '' ?>>老闆/總經理</option>
                                        <option value="sales_manager" <?= $rule['approver_role'] === 'sales_manager' ? 'selected' : '' ?>>業務經理</option>
                                        <option value="eng_manager" <?= $rule['approver_role'] === 'eng_manager' ? 'selected' : '' ?>>工程主管</option>
                                        <option value="eng_deputy" <?= $rule['approver_role'] === 'eng_deputy' ? 'selected' : '' ?>>工程副主管</option>
                                        <option value="admin_staff" <?= $rule['approver_role'] === 'admin_staff' ? 'selected' : '' ?>>行政人員(會計)</option>
                                    </select>
                                </div>
                                <div class="form-group" id="edit-approver-id-group-<?= $rule['id'] ?>" <?= $rule['approver_role'] === 'auto_approve' ? 'style="display:none"' : '' ?>>
                                    <label>或指定簽核人</label>
                                    <select name="approver_id" class="form-control">
                                        <option value="">不指定人</option>
                                        <?php foreach ($approvers as $ap): ?>
                                        <option value="<?= $ap['id'] ?>" <?= (string)$rule['approver_id'] === (string)$ap['id'] ? 'selected' : '' ?>><?= e($ap['real_name']) ?> (<?= e(ApprovalModel::roleLabel($ap['role'])) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group" style="flex:0 0 100px">
                                    <label>順序</label>
                                    <input type="number" name="level_order" class="form-control" value="<?= $rule['level_order'] ?>" min="1" max="10">
                                </div>
                                <div class="form-group" style="flex:0 0 100px">
                                    <label>狀態</label>
                                    <select name="is_active" class="form-control">
                                        <option value="1" <?= $rule['is_active'] ? 'selected' : '' ?>>啟用</option>
                                        <option value="0" <?= !$rule['is_active'] ? 'selected' : '' ?>>停用</option>
                                    </select>
                                </div>
                            </div>
                            <div style="display:flex;gap:8px;">
                                <button type="submit" class="btn btn-primary btn-sm">儲存</button>
                                <button type="button" class="btn btn-outline btn-sm" onclick="toggleEditForm(<?= $rule['id'] ?>)">取消</button>
                            </div>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
.form-row { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 12px; }
.form-row .form-group { flex: 1; min-width: 150px; }
.edit-rule-form { max-width: 100%; }
.edit-rule-form .form-row { margin-bottom: 8px; }
.edit-rule-form .form-group { min-width: 120px; }
</style>

<script>
function toggleEditForm(id) {
    var row = document.getElementById('edit-row-' + id);
    if (row.style.display === 'none') {
        // 先關閉其他已開啟的編輯表單
        var allEditRows = document.querySelectorAll('[id^="edit-row-"]');
        for (var i = 0; i < allEditRows.length; i++) {
            allEditRows[i].style.display = 'none';
        }
        row.style.display = '';
    } else {
        row.style.display = 'none';
    }
}

function toggleApproverFields(select) {
    var group = document.getElementById('approver-id-group');
    if (select.value === 'auto_approve') {
        group.style.display = 'none';
        group.querySelector('select').value = '';
    } else {
        group.style.display = '';
    }
}

function toggleEditApproverFields(select, ruleId) {
    var group = document.getElementById('edit-approver-id-group-' + ruleId);
    if (select.value === 'auto_approve') {
        group.style.display = 'none';
        group.querySelector('select').value = '';
    } else {
        group.style.display = '';
    }
}
</script>
