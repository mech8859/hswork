<?php
/**
 * 進貨單資料模型
 * 進貨單 CRUD、從採購單建立、確認進貨 → 自動建立入庫單
 */
class GoodsReceiptModel
{
    /** @var PDO */
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ============================================================
    // 靜態選項
    // ============================================================

    public static function statusOptions()
    {
        return array(
            '草稿'   => '草稿',
            '待確認' => '待確認',
            '已確認' => '已確認',
            '已取消' => '已取消',
        );
    }

    public static function statusBadgeColor($status)
    {
        $map = array(
            '草稿'   => 'gray',
            '待確認' => 'orange',
            '已確認' => 'green',
            '已取消' => 'gray',
        );
        return isset($map[$status]) ? $map[$status] : 'gray';
    }

    // ============================================================
    // 編號生成
    // ============================================================

    public function generateNumber()
    {
        return generate_doc_number('goods_receipts');
    }

    // ============================================================
    // 列表查詢
    // ============================================================

    /**
     * 進貨單列表（含篩選）
     * @param array $filters  status, vendor_name, keyword, date_from, date_to, warehouse_id
     * @return array
     */
    public function getList($filters = array())
    {
        $where = '1=1';
        $params = array();

        if (!empty($filters['status'])) {
            $where .= ' AND gr.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['vendor_name'])) {
            $where .= ' AND gr.vendor_name LIKE ?';
            $params[] = '%' . $filters['vendor_name'] . '%';
        }
        if (!empty($filters['keyword'])) {
            $where .= ' AND (gr.gr_number LIKE ? OR gr.vendor_name LIKE ? OR gr.po_number LIKE ?)';
            $kw = '%' . $filters['keyword'] . '%';
            $params[] = $kw;
            $params[] = $kw;
            $params[] = $kw;
        }
        if (!empty($filters['date_from'])) {
            $where .= ' AND gr.gr_date >= ?';
            $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where .= ' AND gr.gr_date <= ?';
            $params[] = $filters['date_to'];
        }
        if (!empty($filters['warehouse_id'])) {
            $where .= ' AND gr.warehouse_id = ?';
            $params[] = $filters['warehouse_id'];
        }

        $stmt = $this->db->prepare("
            SELECT gr.*, w.name AS warehouse_name,
                   u.real_name AS created_by_name
            FROM goods_receipts gr
            LEFT JOIN warehouses w ON gr.warehouse_id = w.id
            LEFT JOIN users u ON gr.created_by = u.id
            WHERE {$where}
            ORDER BY gr.id DESC
        ");
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ============================================================
    // 單筆查詢
    // ============================================================

    /**
     * 取得進貨單（含明細）
     * @param int $id
     * @return array|null
     */
    public function getById($id)
    {
        $stmt = $this->db->prepare("
            SELECT gr.*, w.name AS warehouse_name,
                   u.real_name AS created_by_name,
                   cu.real_name AS confirmed_by_name
            FROM goods_receipts gr
            LEFT JOIN warehouses w ON gr.warehouse_id = w.id
            LEFT JOIN users u ON gr.created_by = u.id
            LEFT JOIN users cu ON gr.confirmed_by = cu.id
            WHERE gr.id = ?
        ");
        $stmt->execute(array($id));
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
        return $record ? $record : null;
    }

    /**
     * 取得進貨單明細
     */
    public function getItems($goodsReceiptId)
    {
        $stmt = $this->db->prepare("
            SELECT gi.*, p.name AS db_product_name, p.model AS db_model
            FROM goods_receipt_items gi
            LEFT JOIN products p ON gi.product_id = p.id
            WHERE gi.goods_receipt_id = ?
            ORDER BY gi.sort_order, gi.id
        ");
        $stmt->execute(array($goodsReceiptId));
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ============================================================
    // 新增
    // ============================================================

    /**
     * 建立進貨單
     * @param array $data
     * @return int  新建 ID
     */
    public function create($data)
    {
        $number = $this->generateNumber();
        $stmt = $this->db->prepare("
            INSERT INTO goods_receipts
                (gr_number, gr_date, status, po_id, po_number, vendor_id, vendor_name,
                 warehouse_id, receiver_name, note, total_qty, total_amount,
                 created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute(array(
            $number,
            !empty($data['gr_date']) ? $data['gr_date'] : date('Y-m-d'),
            !empty($data['status']) ? $data['status'] : '草稿',
            !empty($data['po_id']) ? $data['po_id'] : null,
            !empty($data['po_number']) ? $data['po_number'] : null,
            !empty($data['vendor_id']) ? $data['vendor_id'] : null,
            !empty($data['vendor_name']) ? $data['vendor_name'] : null,
            !empty($data['warehouse_id']) ? $data['warehouse_id'] : null,
            !empty($data['receiver_name']) ? $data['receiver_name'] : null,
            !empty($data['note']) ? $data['note'] : null,
            !empty($data['total_qty']) ? $data['total_qty'] : 0,
            !empty($data['total_amount']) ? $data['total_amount'] : 0,
            $data['created_by'],
        ));
        $grId = $this->db->lastInsertId();

        // 儲存明細
        if (!empty($data['items'])) {
            $this->saveItems($grId, $data['items']);
        }

        return $grId;
    }

    // ============================================================
    // 更新
    // ============================================================

    /**
     * 更新進貨單
     * @param int $id
     * @param array $data
     */
    public function update($id, $data)
    {
        $stmt = $this->db->prepare("
            UPDATE goods_receipts SET
                gr_date = ?, status = ?, po_id = ?, po_number = ?,
                vendor_id = ?, vendor_name = ?, warehouse_id = ?,
                receiver_name = ?, note = ?, total_qty = ?, total_amount = ?,
                updated_by = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute(array(
            !empty($data['gr_date']) ? $data['gr_date'] : date('Y-m-d'),
            !empty($data['status']) ? $data['status'] : '草稿',
            !empty($data['po_id']) ? $data['po_id'] : null,
            !empty($data['po_number']) ? $data['po_number'] : null,
            !empty($data['vendor_id']) ? $data['vendor_id'] : null,
            !empty($data['vendor_name']) ? $data['vendor_name'] : null,
            !empty($data['warehouse_id']) ? $data['warehouse_id'] : null,
            !empty($data['receiver_name']) ? $data['receiver_name'] : null,
            !empty($data['note']) ? $data['note'] : null,
            !empty($data['total_qty']) ? $data['total_qty'] : 0,
            !empty($data['total_amount']) ? $data['total_amount'] : 0,
            !empty($data['updated_by']) ? $data['updated_by'] : null,
            $id,
        ));

        // 重新儲存明細
        if (isset($data['items'])) {
            $this->saveItems($id, $data['items']);
        }
    }

    /**
     * 儲存進貨單明細（先刪後插）
     */
    public function saveItems($goodsReceiptId, $items)
    {
        $this->db->prepare("DELETE FROM goods_receipt_items WHERE goods_receipt_id = ?")
            ->execute(array($goodsReceiptId));

        if (empty($items)) return;

        $stmt = $this->db->prepare("
            INSERT INTO goods_receipt_items
                (goods_receipt_id, product_id, model, product_name, spec, unit,
                 po_qty, received_qty, unit_price, amount, note, sort_order)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $sort = 0;
        foreach ($items as $item) {
            if (empty($item['product_name']) && empty($item['model'])) continue;
            $receivedQty = !empty($item['received_qty']) ? $item['received_qty'] : 0;
            $unitPrice = !empty($item['unit_price']) ? $item['unit_price'] : 0;
            $stmt->execute(array(
                $goodsReceiptId,
                !empty($item['product_id']) ? $item['product_id'] : null,
                !empty($item['model']) ? $item['model'] : null,
                !empty($item['product_name']) ? $item['product_name'] : null,
                !empty($item['spec']) ? $item['spec'] : null,
                !empty($item['unit']) ? $item['unit'] : null,
                !empty($item['po_qty']) ? $item['po_qty'] : 0,
                $receivedQty,
                $unitPrice,
                round($receivedQty * $unitPrice),
                !empty($item['note']) ? $item['note'] : null,
                $sort++,
            ));
        }
    }

    // ============================================================
    // 狀態變更
    // ============================================================

    /**
     * 更新狀態
     */
    public function updateStatus($id, $status)
    {
        $stmt = $this->db->prepare("UPDATE goods_receipts SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute(array($status, $id));
    }

    /**
     * 確認進貨單 → 自動建立入庫單 → 更新庫存
     * @param int $id
     * @param int $userId
     * @return int|false  stock_in ID or false
     */
    public function confirm($id, $userId)
    {
        $record = $this->getById($id);
        if (!$record || $record['status'] === '已確認') {
            return false;
        }

        $items = $this->getItems($id);
        if (empty($items)) {
            return false;
        }

        $this->db->beginTransaction();
        try {
            // 更新進貨單狀態
            $stmt = $this->db->prepare("
                UPDATE goods_receipts SET status = '已確認', confirmed_by = ?, confirmed_at = NOW(), updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute(array($userId, $id));

            // 建立入庫單
            require_once __DIR__ . '/../inventory/StockModel.php';
            $stockModel = new StockModel();

            $siData = array(
                'si_date'       => date('Y-m-d'),
                'source_type'   => 'goods_receipt',
                'source_id'     => $id,
                'source_number' => $record['gr_number'],
                'warehouse_id'  => $record['warehouse_id'],
                'note'          => '由進貨單 ' . $record['gr_number'] . ' 自動建立',
                'created_by'    => $userId,
                'items'         => array(),
            );

            $totalQty = 0;
            foreach ($items as $item) {
                if ($item['received_qty'] > 0) {
                    $siData['items'][] = array(
                        'product_id'   => $item['product_id'],
                        'model'        => $item['model'],
                        'product_name' => $item['product_name'],
                        'spec'         => $item['spec'],
                        'unit'         => $item['unit'],
                        'quantity'     => $item['received_qty'],
                        'unit_price'   => $item['unit_price'],
                    );
                    $totalQty += $item['received_qty'];
                }
            }
            $siData['total_qty'] = $totalQty;

            $stockInId = $stockModel->createStockIn($siData);

            // 自動確認入庫單（更新庫存）
            $stockModel->confirmStockIn($stockInId, $userId);

            $this->db->commit();
            return $stockInId;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    // ============================================================
    // 刪除
    // ============================================================

    /**
     * 刪除進貨單（僅草稿狀態可刪除）
     */
    public function delete($id)
    {
        $record = $this->getById($id);
        if (!$record || $record['status'] !== '草稿') {
            return false;
        }
        $this->db->prepare("DELETE FROM goods_receipt_items WHERE goods_receipt_id = ?")->execute(array($id));
        $this->db->prepare("DELETE FROM goods_receipts WHERE id = ?")->execute(array($id));
        return true;
    }

    // ============================================================
    // 從採購單建立
    // ============================================================

    /**
     * 從採購單預填進貨單資料
     * @param int $poId
     * @return array  header + items
     */
    public function createFromPO($poId)
    {
        require_once __DIR__ . '/ProcurementModel.php';
        $procModel = new ProcurementModel();
        $po = $procModel->getPurchaseOrder($poId);
        if (!$po) return null;

        $poItems = $procModel->getPurchaseOrderItems($poId);

        // Determine warehouse from branch
        $warehouseId = null;
        if (!empty($po['branch_id'])) {
            require_once __DIR__ . '/../inventory/InventoryModel.php';
            $invModel = new InventoryModel();
            $whs = $invModel->getWarehouses();
            foreach ($whs as $wh) {
                if ($wh['branch_id'] == $po['branch_id']) {
                    $warehouseId = $wh['id'];
                    break;
                }
            }
        }

        $header = array(
            'po_id'         => $po['id'],
            'po_number'     => $po['po_number'],
            'vendor_id'     => $po['vendor_id'],
            'vendor_name'   => $po['vendor_name'],
            'warehouse_id'  => $warehouseId,
        );

        $items = array();
        foreach ($poItems as $item) {
            $items[] = array(
                'product_id'   => !empty($item['product_id']) ? $item['product_id'] : null,
                'model'        => !empty($item['model']) ? $item['model'] : '',
                'product_name' => !empty($item['product_name']) ? $item['product_name'] : '',
                'spec'         => !empty($item['spec']) ? $item['spec'] : '',
                'unit'         => !empty($item['unit']) ? $item['unit'] : '',
                'po_qty'       => !empty($item['quantity']) ? $item['quantity'] : 0,
                'received_qty' => !empty($item['quantity']) ? $item['quantity'] : 0,
                'unit_price'   => !empty($item['unit_price']) ? $item['unit_price'] : 0,
                'amount'       => !empty($item['amount']) ? $item['amount'] : 0,
            );
        }

        return array('header' => $header, 'items' => $items);
    }

    // ============================================================
    // 輔助
    // ============================================================

    /**
     * 取得未完成的採購單（for 下拉選擇）
     */
    public function getPendingPOs()
    {
        $stmt = $this->db->query("
            SELECT id, po_number, po_date, vendor_name, total_amount
            FROM purchase_orders
            WHERE status = '尚未進貨' AND is_cancelled = 0
            ORDER BY id DESC
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
