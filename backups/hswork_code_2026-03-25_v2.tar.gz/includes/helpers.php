<?php
/**
 * 共用輔助函式
 */

/**
 * HTML 跳脫輸出
 */
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/**
 * 產生 CSRF hidden input
 */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(Session::getCsrfToken()) . '">';
}

/**
 * 驗證 CSRF token
 */
function verify_csrf(): bool
{
    $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    return Session::verifyCsrf($token);
}

/**
 * 重導向
 */
function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/**
 * JSON 回應
 */
function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * 取得所有角色（優先從 DB，fallback 到 config）
 * @return array  role_key => role_label
 */
function get_dynamic_roles()
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    try {
        $db = Database::getInstance();
        $stmt = $db->query('SELECT role_key, role_label FROM system_roles WHERE is_active = 1 ORDER BY sort_order, role_key');
        $roles = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $roles[$row['role_key']] = $row['role_label'];
        }
        if (!empty($roles)) {
            $cache = $roles;
            return $cache;
        }
    } catch (Exception $e) {
        // table might not exist yet
    }
    $config = require __DIR__ . '/../config/app.php';
    $cache = $config['roles'];
    return $cache;
}

/**
 * 取得角色中文名稱
 */
function role_name(string $role): string
{
    $roles = get_dynamic_roles();
    return isset($roles[$role]) ? $roles[$role] : $role;
}

/**
 * 格式化日期
 */
function format_date(?string $date, string $format = 'Y/m/d'): string
{
    if (!$date) return '';
    return date($format, strtotime($date));
}

/**
 * 格式化日期時間
 */
function format_datetime(?string $datetime, string $format = 'Y/m/d H:i'): string
{
    if (!$datetime) return '';
    return date($format, strtotime($datetime));
}

/**
 * 檢查是否為 AJAX 請求
 */
function is_ajax(): bool
{
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
        && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * 取得排工條件缺少項目的提示訊息
 */
function get_readiness_warnings(array $readiness): array
{
    $warnings = [];
    if (empty($readiness['has_quotation']))        $warnings[] = '缺少報價單';
    if (empty($readiness['has_site_photos']) && empty($readiness['no_photo_allowed']))
        $warnings[] = '缺少現場照片';
    if (empty($readiness['has_amount_confirmed']))  $warnings[] = '金額尚未確認';
    if (empty($readiness['has_site_info']))         $warnings[] = '現場資料未備齊';
    return $warnings;
}

/**
 * 產生案件編號
 */
function generate_case_number(string $branchCode): string
{
    return $branchCode . '-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));
}

/**
 * 統一自動編號產生
 * 格式: {prefix}{sep}{date}{sep}{sequence}
 * 支援: 純數字, 含年份, 含年月, 含年月日, 含前綴
 *
 * @param string $module 模組 key (cases, quotations, receivables 等)
 * @return string 產生的編號
 */
function generate_doc_number($module)
{
    $db = Database::getInstance();

    // 取得設定（使用 FOR UPDATE 鎖定避免併發）
    $db->beginTransaction();
    try {
        $stmt = $db->prepare("SELECT * FROM number_sequences WHERE module = ? FOR UPDATE");
        $stmt->execute(array($module));
        $seq = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$seq) {
            $db->rollBack();
            // 沒設定就用 fallback
            return strtoupper($module) . '-' . date('Ymd') . '-' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
        }

        $prefix = $seq['prefix'];
        $dateFormat = $seq['date_format'];
        $sep = $seq['separator'];
        $digits = (int)$seq['seq_digits'];

        // 計算 reset key（依日期格式）
        $resetKey = '';
        if (!empty($dateFormat)) {
            $resetKey = date($dateFormat);
        } else {
            $resetKey = 'ALL'; // 無日期 → 永不重設
        }

        // 判斷是否需要重設序號
        if ($seq['last_reset_key'] !== $resetKey) {
            $nextSeq = 1;
        } else {
            $nextSeq = (int)$seq['last_sequence'] + 1;
        }

        // 更新序列
        $db->prepare("UPDATE number_sequences SET last_sequence = ?, last_reset_key = ?, updated_at = NOW() WHERE id = ?")
           ->execute(array($nextSeq, $resetKey, $seq['id']));

        $db->commit();

        // 組合編號
        $parts = array();
        if ($prefix !== '') {
            $parts[] = $prefix;
        }
        if (!empty($dateFormat)) {
            $parts[] = date($dateFormat);
        }
        $parts[] = str_pad($nextSeq, $digits, '0', STR_PAD_LEFT);

        return implode($sep, $parts);

    } catch (Exception $e) {
        $db->rollBack();
        // fallback
        return strtoupper($module) . '-' . date('Ymd') . '-' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
    }
}

/**
 * 預覽編號格式（不真的產生序號）
 */
function preview_doc_number($prefix, $dateFormat, $sep, $digits)
{
    $parts = array();
    if ($prefix !== '') {
        $parts[] = $prefix;
    }
    if (!empty($dateFormat)) {
        $parts[] = date($dateFormat);
    }
    $parts[] = str_pad(1, (int)$digits, '0', STR_PAD_LEFT);
    return implode($sep, $parts);
}

/**
 * 查看下一個編號（不消耗序號）
 */
function peek_next_doc_number($module)
{
    $db = Database::getInstance();
    $stmt = $db->prepare("SELECT * FROM number_sequences WHERE module = ?");
    $stmt->execute(array($module));
    $seq = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$seq) return '';

    $prefix = $seq['prefix'];
    $dateFormat = $seq['date_format'];
    $sep = $seq['separator'];
    $digits = (int)$seq['seq_digits'];

    $resetKey = !empty($dateFormat) ? date($dateFormat) : 'ALL';
    $nextSeq = ($seq['last_reset_key'] !== $resetKey) ? 1 : (int)$seq['last_sequence'] + 1;

    $parts = array();
    if ($prefix !== '') $parts[] = $prefix;
    if (!empty($dateFormat)) $parts[] = date($dateFormat);
    $parts[] = str_pad($nextSeq, $digits, '0', STR_PAD_LEFT);
    return implode($sep, $parts);
}
