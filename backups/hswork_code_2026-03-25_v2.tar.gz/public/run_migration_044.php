<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
$db = Database::getInstance();
$results = array();

// 1. Add option_key and is_system columns to dropdown_options if not exist
$columnsToAdd = array(
    'option_key' => "ADD COLUMN `option_key` VARCHAR(100) DEFAULT NULL AFTER `category`",
    'is_system'  => "ADD COLUMN `is_system` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_active`",
);

foreach ($columnsToAdd as $colName => $alterSql) {
    try {
        $db->exec("ALTER TABLE `dropdown_options` {$alterSql}");
        $results[] = "欄位 {$colName} 已新增";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate') !== false) {
            $results[] = "欄位 {$colName} 已存在，跳過";
        } else {
            $results[] = "錯誤({$colName}): " . $e->getMessage();
        }
    }
}

// 2. Seed case_type options
$caseTypes = array(
    array('new_install',  '新案',          1),
    array('addition',     '老客戶追加',    2),
    array('old_repair',   '舊客戶維修案',  3),
    array('new_repair',   '新客戶維修案',  4),
    array('maintenance',  '維護保養',      5),
);

$caseProgress = array(
    array('tracking',          '待追蹤',              1),
    array('incomplete',        '未完工',              2),
    array('unpaid',            '完工未收款',          3),
    array('completed_pending', '已完工待簽核',        4),
    array('closed',            '已完工結案',          5),
    array('lost',              '未成交',              6),
    array('maint_case',        '保養案件',            7),
    array('breach',            '毀約',                8),
    array('scheduled',         '已排工/已排行事曆',   9),
    array('needs_reschedule',  '已進場/需再安排',     10),
    array('awaiting_dispatch', '待安排派工查修',      11),
    array('customer_cancel',   '客戶取消',            12),
);

$caseStatus = array(
    array('未指派',           '未指派',           1),
    array('待聯絡',           '待聯絡',           2),
    array('電話不通或未接',   '電話不通或未接',   3),
    array('待場勘',           '待場勘',           4),
    array('已聯絡安排場勘',   '已聯絡安排場勘',   5),
    array('已聯絡電話報價',   '已聯絡電話報價',   6),
    array('已會勘未報價',     '已會勘未報價',     7),
    array('已報價待追蹤',     '已報價待追蹤',     8),
    array('規劃或預算案',     '規劃或預算案',     9),
    array('電話報價成交',     '電話報價成交',     10),
    array('已成交',           '已成交',           11),
    array('跨月成交',         '跨月成交',         12),
    array('現簽',             '現簽',             13),
    array('已報價無意願',     '已報價無意願',     14),
    array('報價無下文',       '報價無下文',       15),
    array('無效',             '無效',             16),
    array('客戶毀約',         '客戶毀約',         17),
);

$seedSets = array(
    'case_type'     => $caseTypes,
    'case_progress' => $caseProgress,
    'case_status'   => $caseStatus,
);

$insertStmt = $db->prepare(
    'INSERT INTO dropdown_options (category, option_key, label, sort_order, is_active, is_system) VALUES (?, ?, ?, ?, 1, 1)'
);

foreach ($seedSets as $cat => $rows) {
    // Check if this category already has data
    $check = $db->prepare('SELECT COUNT(*) FROM dropdown_options WHERE category = ?');
    $check->execute(array($cat));
    $existing = (int)$check->fetchColumn();

    if ($existing > 0) {
        $results[] = "分類 {$cat} 已有 {$existing} 筆資料，跳過";
        continue;
    }

    $count = 0;
    foreach ($rows as $row) {
        $insertStmt->execute(array($cat, $row[0], $row[1], $row[2]));
        $count++;
    }
    $results[] = "分類 {$cat} 已新增 {$count} 筆選項";
}

echo "<h2>Migration 044 - 案件下拉選項（案別/進度/狀態）</h2><ul>";
foreach ($results as $r) {
    echo "<li style='color:green'>" . htmlspecialchars($r) . "</li>";
}
echo "</ul>";

// Show totals
$total = $db->query("SELECT COUNT(*) FROM dropdown_options")->fetchColumn();
echo "<p><b>dropdown_options 共 {$total} 筆</b></p>";
echo "<p><a href='/dropdown_options.php'>← 選單管理</a> | <a href='/cases.php'>案件管理</a></p>";
