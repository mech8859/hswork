<?php
/**
 * 出庫單管理
 */
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/inventory/StockModel.php';

$canManage = Auth::hasPermission('inventory.manage');
$canView = Auth::hasPermission('inventory.view');
if (!$canManage && !$canView) {
    Session::flash('error', '無權限');
    redirect('/index.php');
}

$model = new StockModel();
$action = isset($_GET['action']) ? $_GET['action'] : 'list';

switch ($action) {
    case 'list':
        $filters = array(
            'month'        => isset($_GET['month']) ? $_GET['month'] : date('Y-m'),
            'status'       => isset($_GET['status']) ? $_GET['status'] : '',
            'keyword'      => isset($_GET['keyword']) ? $_GET['keyword'] : '',
            'warehouse_id' => isset($_GET['warehouse_id']) ? $_GET['warehouse_id'] : '',
        );
        $records = $model->getStockOuts($filters);
        $warehouses = $model->getWarehouses();
        $pageTitle = '出庫單管理';
        $currentPage = 'stock_outs';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/stock_outs/list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'view':
        $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
        $record = $model->getStockOutById($id);
        if (!$record) { Session::flash('error', '出庫單不存在'); redirect('/stock_outs.php'); }
        $soNumber = isset($record['stockout_number']) ? $record['stockout_number'] : (isset($record['so_number']) ? $record['so_number'] : '');
        $pageTitle = '出庫單 ' . $soNumber;
        $currentPage = 'stock_outs';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/stock_outs/view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'confirm':
        if (!$canManage) { Session::flash('error', '無權限'); redirect('/stock_outs.php'); }
        if (verify_csrf()) {
            $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
            try {
                if ($model->confirmStockOut($id, Auth::id())) {
                    // Auto-journal on stock-out confirm
                    try {
                        require_once __DIR__ . '/../modules/accounting/AutoJournalService.php';
                        AutoJournalService::onStockOutConfirmed($id);
                    } catch (Exception $autoJournalEx) {
                        error_log('AutoJournal stock_out error: ' . $autoJournalEx->getMessage());
                    }
                    AuditLog::log('stock_outs', 'confirm', $id, '出庫確認，已扣減庫存');
                    Session::flash('success', '出庫單已確認，庫存已扣減');
                } else {
                    Session::flash('error', '確認失敗，請確認狀態是否正確');
                }
            } catch (Exception $e) {
                Session::flash('error', '確認失敗：' . $e->getMessage());
            }
        }
        redirect('/stock_outs.php?action=view&id=' . (int)(isset($_GET['id']) ? $_GET['id'] : 0));
        break;

    default:
        redirect('/stock_outs.php');
        break;
}
