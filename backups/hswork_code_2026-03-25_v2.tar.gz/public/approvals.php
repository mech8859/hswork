<?php
/**
 * 簽核管理
 */
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
require_once __DIR__ . '/../modules/approvals/ApprovalModel.php';

$model = new ApprovalModel();
$action = $_GET['action'] ?? 'pending';

$canManageRules = Auth::hasPermission('all') || in_array(Session::getUser()['role'], array('boss', 'sales_manager'));

switch ($action) {
    // ---- 待簽核清單 ----
    case 'pending':
        $pendingList = $model->getPendingList(Auth::id());
        $pageTitle = '待簽核';
        $currentPage = 'approvals';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/approvals/pending.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 簽核設定 ----
    case 'settings':
        if (!$canManageRules) { Session::flash('error', '無權限'); redirect('/approvals.php'); }
        $rules = $model->getRules();
        $approvers = $model->getApprovers();
        $pageTitle = '簽核設定';
        $currentPage = 'approvals';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/approvals/settings.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ---- 儲存規則 ----
    case 'save_rule':
        if (!$canManageRules) { Session::flash('error', '無權限'); redirect('/approvals.php?action=settings'); }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) { Session::flash('error', '安全驗證失敗'); redirect('/approvals.php?action=settings'); }
            $model->saveRule($_POST);
            Session::flash('success', '簽核規則已儲存');
        }
        redirect('/approvals.php?action=settings');
        break;

    // ---- 刪除規則 ----
    case 'delete_rule':
        if (!$canManageRules) { Session::flash('error', '無權限'); redirect('/approvals.php?action=settings'); }
        if (verify_csrf()) {
            $model->deleteRule((int)$_GET['id']);
            Session::flash('success', '規則已刪除');
        }
        redirect('/approvals.php?action=settings');
        break;

    // ---- 核准 ----
    case 'approve':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $flowId = (int)$_POST['flow_id'];
            $comment = $_POST['comment'] ?? '';
            if ($model->approve($flowId, Auth::id(), $comment)) {
                $module = $_POST['module'] ?? '';
                $targetId = (int)($_POST['target_id'] ?? 0);

                if ($module === 'case_completion' && $targetId) {
                    // 完工簽核多關流程
                    $stillPending = $model->advanceCaseCompletion($targetId);
                    if (!$stillPending) {
                        // 全部簽完 → 案件結案
                        $db = Database::getInstance();
                        $db->prepare("UPDATE cases SET progress = 'completed' WHERE id = ?")->execute(array($targetId));
                        Session::flash('success', '已核准，案件已完工結案');
                    } else {
                        Session::flash('success', '已核准，已送下一關簽核');
                    }
                } elseif ($module && $targetId && $model->isFullyApproved($module, $targetId)) {
                    // 其他模組：自動更新單據狀態
                    if ($module === 'quotations') {
                        require_once __DIR__ . '/../modules/quotations/QuotationModel.php';
                        $qm = new QuotationModel();
                        $qm->updateStatus($targetId, 'approved');
                    }
                    Session::flash('success', '已核准');
                } else {
                    Session::flash('success', '已核准');
                }
                AuditLog::log('approvals', 'approve', $flowId, $module . ' #' . $targetId);
            } else {
                Session::flash('error', '核准失敗');
            }
        }
        // 導回來源頁
        $redirect = $_POST['redirect'] ?? '/approvals.php';
        redirect($redirect);
        break;

    // ---- 退回 ----
    case 'reject':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
            $flowId = (int)$_POST['flow_id'];
            $comment = $_POST['comment'] ?? '';
            $module = $_POST['module'] ?? '';
            $targetId = (int)($_POST['target_id'] ?? 0);
            if ($model->reject($flowId, Auth::id(), $comment)) {
                if ($module === 'case_completion' && $targetId) {
                    // 完工簽核退回 → 案件回到施工中
                    $model->rejectCaseCompletion($targetId);
                    AuditLog::log('approvals', 'reject', $flowId, '完工簽核退回 案件#' . $targetId . ' - ' . $comment);
                    Session::flash('success', '已退回，案件進度已改回施工中');
                } else {
                    // 其他模組退回
                    if ($module === 'quotations' && $targetId) {
                        require_once __DIR__ . '/../modules/quotations/QuotationModel.php';
                        $qm = new QuotationModel();
                        $qm->updateStatus($targetId, 'rejected_internal');
                    }
                    AuditLog::log('approvals', 'reject', $flowId, $module . ' #' . $targetId . ' - ' . $comment);
                    Session::flash('success', '已退回');
                }
            } else {
                Session::flash('error', '退回失敗');
            }
        }
        $redirect = $_POST['redirect'] ?? '/approvals.php';
        redirect($redirect);
        break;

    default:
        redirect('/approvals.php');
}
