<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
if (!Auth::hasPermission('accounting.manage') && !Auth::hasPermission('accounting.view') && !Auth::hasPermission('finance.manage') && !Auth::hasPermission('finance.view') && !in_array(Auth::user()['role'], array('boss','manager'))) {
    Session::flash('error', '無權限查看此頁面');
    redirect('/');
}
require_once __DIR__ . '/../modules/accounting/AccountingModel.php';

$model = new AccountingModel();
$action = !empty($_GET['action']) ? $_GET['action'] : 'journals';
$canManage = Auth::hasPermission('accounting.manage') || Auth::hasPermission('finance.manage') || in_array(Auth::user()['role'], array('boss','manager'));

switch ($action) {

    // ============================================================
    // 會計科目管理
    // ============================================================
    case 'accounts':
        $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
        $typeFilter = isset($_GET['type']) ? $_GET['type'] : '';
        $showInactive = !empty($_GET['show_inactive']);

        $allAccounts = $model->getAccountsTree($showInactive);

        // Filter
        if ($keyword || $typeFilter) {
            $filtered = array();
            foreach ($allAccounts as $acc) {
                $match = true;
                if ($keyword && stripos($acc['code'] . $acc['name'], $keyword) === false) {
                    $match = false;
                }
                if ($typeFilter && $acc['account_type'] !== $typeFilter) {
                    $match = false;
                }
                if ($match) $filtered[] = $acc;
            }
            $allAccounts = $filtered;
        }

        $accountTypeOptions = AccountingModel::accountTypeOptions();
        $pageTitle = '會計科目管理';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/accounts.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'account_save':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=accounts');
        }
        verify_csrf();
        $id = !empty($_POST['id']) ? (int)$_POST['id'] : 0;
        $data = array(
            'code' => trim($_POST['code']),
            'name' => trim($_POST['name']),
            'account_type' => $_POST['account_type'],
            'parent_id' => !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null,
            'level' => !empty($_POST['level']) ? (int)$_POST['level'] : 1,
            'is_detail' => isset($_POST['is_detail']) ? 1 : 0,
            'normal_balance' => $_POST['normal_balance'],
            'description' => isset($_POST['description']) ? trim($_POST['description']) : '',
            'sort_order' => !empty($_POST['sort_order']) ? (int)$_POST['sort_order'] : 0,
            'level1' => isset($_POST['level1']) ? trim($_POST['level1']) : '',
        );

        if (!$data['code'] || !$data['name'] || !$data['account_type']) {
            Session::flash('error', '請填寫必要欄位');
            redirect('/accounting.php?action=accounts');
        }

        try {
            if ($id) {
                $model->updateAccount($id, $data);
                Session::flash('success', '科目已更新');
            } else {
                $model->createAccount($data);
                Session::flash('success', '科目已新增');
            }
        } catch (Exception $e) {
            Session::flash('error', '操作失敗: ' . $e->getMessage());
        }
        redirect('/accounting.php?action=accounts');
        break;

    case 'account_toggle':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=accounts');
        }
        verify_csrf();
        $id = (int)$_POST['id'];
        $model->toggleAccount($id);
        Session::flash('success', '科目狀態已變更');
        redirect('/accounting.php?action=accounts');
        break;

    // ============================================================
    // 成本中心管理
    // ============================================================
    case 'cost_centers':
        $costCenters = $model->getAllCostCenters();
        $branches = $model->getBranches();
        $typeOptions = AccountingModel::costCenterTypeOptions();

        $pageTitle = '成本中心管理';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/cost_centers.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'cost_center_save':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=cost_centers');
        }
        verify_csrf();
        $id = !empty($_POST['id']) ? (int)$_POST['id'] : 0;
        $data = array(
            'code' => trim($_POST['code']),
            'name' => trim($_POST['name']),
            'type' => $_POST['type'],
            'branch_id' => !empty($_POST['branch_id']) ? (int)$_POST['branch_id'] : null,
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
        );

        if (!$data['code'] || !$data['name']) {
            Session::flash('error', '請填寫必要欄位');
            redirect('/accounting.php?action=cost_centers');
        }

        try {
            if ($id) {
                $model->updateCostCenter($id, $data);
                Session::flash('success', '成本中心已更新');
            } else {
                $model->createCostCenter($data);
                Session::flash('success', '成本中心已新增');
            }
        } catch (Exception $e) {
            Session::flash('error', '操作失敗: ' . $e->getMessage());
        }
        redirect('/accounting.php?action=cost_centers');
        break;

    // ============================================================
    // 傳票列表
    // ============================================================
    case 'journals':
        $filters = array(
            'status'       => isset($_GET['status']) ? $_GET['status'] : '',
            'voucher_type' => isset($_GET['voucher_type']) ? $_GET['voucher_type'] : '',
            'date_from'    => isset($_GET['date_from']) ? $_GET['date_from'] : '',
            'date_to'      => isset($_GET['date_to']) ? $_GET['date_to'] : '',
            'keyword'      => isset($_GET['keyword']) ? $_GET['keyword'] : '',
        );
        $entries = $model->getJournalEntries($filters);
        $stats = $model->getJournalStats();
        $voucherTypeOptions = AccountingModel::voucherTypeOptions();
        $statusOptions = AccountingModel::statusOptions();

        $pageTitle = '傳票管理';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/journal_list.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ============================================================
    // 傳票新增/編輯
    // ============================================================
    case 'journal_create':
    case 'journal_edit':
        if (!$canManage) {
            Session::flash('error', '無權限');
            redirect('/accounting.php?action=journals');
        }

        $entry = null;
        if ($action === 'journal_edit') {
            $id = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
            $entry = $model->getJournalEntryById($id);
            if (!$entry) {
                Session::flash('error', '找不到傳票');
                redirect('/accounting.php?action=journals');
            }
            if ($entry['status'] !== 'draft') {
                Session::flash('error', '僅草稿傳票可編輯');
                redirect('/accounting.php?action=journal_view&id=' . $id);
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf();

            $lines = array();
            if (!empty($_POST['lines']) && is_array($_POST['lines'])) {
                foreach ($_POST['lines'] as $line) {
                    if (empty($line['account_id'])) continue;
                    $lines[] = array(
                        'account_id'     => (int)$line['account_id'],
                        'cost_center_id' => !empty($line['cost_center_id']) ? (int)$line['cost_center_id'] : null,
                        'debit_amount'   => isset($line['debit_amount']) ? (float)$line['debit_amount'] : 0,
                        'credit_amount'  => isset($line['credit_amount']) ? (float)$line['credit_amount'] : 0,
                        'description'    => isset($line['description']) ? trim($line['description']) : '',
                    );
                }
            }

            $data = array(
                'voucher_date' => $_POST['voucher_date'],
                'voucher_type' => $_POST['voucher_type'],
                'description'  => isset($_POST['description']) ? trim($_POST['description']) : '',
                'lines'        => $lines,
            );

            try {
                if ($entry) {
                    $data['updated_by'] = Auth::id();
                    $model->updateJournalEntry($entry['id'], $data);
                    Session::flash('success', '傳票已更新');
                    redirect('/accounting.php?action=journal_view&id=' . $entry['id']);
                } else {
                    $data['created_by'] = Auth::id();
                    $newId = $model->createJournalEntry($data);
                    Session::flash('success', '傳票已建立');
                    redirect('/accounting.php?action=journal_view&id=' . $newId);
                }
            } catch (Exception $e) {
                Session::flash('error', $e->getMessage());
                // Stay on form
            }
        }

        $accounts = $model->getAccountsFlat();
        $costCenters = $model->getCostCenters();
        $voucherTypeOptions = AccountingModel::voucherTypeOptions();
        $nextNumber = $model->generateVoucherNumber();

        $pageTitle = $entry ? '編輯傳票 - ' . $entry['voucher_number'] : '新增傳票';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/journal_form.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ============================================================
    // 傳票檢視
    // ============================================================
    case 'journal_view':
        $id = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
        $entry = $model->getJournalEntryById($id);
        if (!$entry) {
            Session::flash('error', '找不到傳票');
            redirect('/accounting.php?action=journals');
        }

        $voucherTypeOptions = AccountingModel::voucherTypeOptions();
        $statusOptions = AccountingModel::statusOptions();

        $pageTitle = '傳票 ' . $entry['voucher_number'];
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/journal_view.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ============================================================
    // 傳票過帳
    // ============================================================
    case 'journal_post':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=journals');
        }
        verify_csrf();
        $id = (int)$_POST['id'];
        try {
            $model->postJournalEntry($id, Auth::id());
            Session::flash('success', '傳票已過帳');
        } catch (Exception $e) {
            Session::flash('error', '過帳失敗: ' . $e->getMessage());
        }
        redirect('/accounting.php?action=journal_view&id=' . $id);
        break;

    // ============================================================
    // 傳票作廢
    // ============================================================
    case 'journal_void':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=journals');
        }
        verify_csrf();
        $id = (int)$_POST['id'];
        $reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';
        try {
            $reverseId = $model->voidJournalEntry($id, Auth::id(), $reason);
            Session::flash('success', '傳票已作廢，沖回傳票已建立');
        } catch (Exception $e) {
            Session::flash('error', '作廢失敗: ' . $e->getMessage());
        }
        redirect('/accounting.php?action=journal_view&id=' . $id);
        break;

    // ============================================================
    // 傳票刪除
    // ============================================================
    case 'journal_delete':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=journals');
        }
        verify_csrf();
        $id = (int)$_POST['id'];
        try {
            $model->deleteJournalEntry($id);
            Session::flash('success', '傳票已刪除');
        } catch (Exception $e) {
            Session::flash('error', '刪除失敗: ' . $e->getMessage());
        }
        redirect('/accounting.php?action=journals');
        break;

    // ============================================================
    // 總帳查詢
    // ============================================================
    case 'ledger':
        $accountId = isset($_GET['account_id']) ? (int)$_GET['account_id'] : 0;
        $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
        $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
        $costCenterId = !empty($_GET['cost_center_id']) ? (int)$_GET['cost_center_id'] : null;

        $accounts = $model->getAccountsFlat(false);
        $costCenters = $model->getCostCenters();
        $ledgerEntries = array();
        $openingBalance = 0;
        $selectedAccount = null;

        if ($accountId) {
            $selectedAccount = $model->getAccountById($accountId);
            $openingBalance = $model->getOpeningBalance($accountId, $startDate, $costCenterId);
            $ledgerEntries = $model->getLedger($accountId, $startDate, $endDate, $costCenterId);
        }

        $pageTitle = '總帳查詢';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/ledger.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ============================================================
    // 試算表
    // ============================================================
    case 'trial_balance':
        $asOfDate = isset($_GET['as_of_date']) ? $_GET['as_of_date'] : date('Y-m-d');
        $costCenterId = !empty($_GET['cost_center_id']) ? (int)$_GET['cost_center_id'] : null;
        $costCenters = $model->getCostCenters();
        $trialBalance = $model->getTrialBalance($asOfDate, $costCenterId);

        $pageTitle = '試算表';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/trial_balance.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ============================================================
    // AJAX: 取得科目資訊
    // ============================================================
    case 'ajax_account_info':
        header('Content-Type: application/json');
        $accountId = (int)(!empty($_GET['id']) ? $_GET['id'] : 0);
        $account = $model->getAccountById($accountId);
        echo json_encode($account ? $account : array());
        exit;

    // ============================================================
    // 銀行對帳
    // ============================================================
    case 'reconciliation':
        require_once __DIR__ . '/../modules/accounting/ReconciliationModel.php';
        $reconModel = new ReconciliationModel();

        $filters = array(
            'bank_account' => isset($_GET['bank_account']) ? $_GET['bank_account'] : '',
            'date_from'    => isset($_GET['date_from']) ? $_GET['date_from'] : '',
            'date_to'      => isset($_GET['date_to']) ? $_GET['date_to'] : '',
            'keyword'      => isset($_GET['keyword']) ? $_GET['keyword'] : '',
        );

        $bankTxs = $reconModel->getUnreconciledBankTransactions($filters);
        $sysTxs = $reconModel->getUnreconciledSystemTransactions($filters);
        $summary = $reconModel->getReconciliationSummary(
            $filters['bank_account'],
            !empty($filters['date_to']) ? $filters['date_to'] : date('Y-m-d')
        );
        $bankAccounts = $reconModel->getBankAccountNames();

        $pageTitle = '銀行對帳';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/reconciliation.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    case 'reconciliation_auto_match':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=reconciliation');
        }
        verify_csrf();
        require_once __DIR__ . '/../modules/accounting/ReconciliationModel.php';
        $reconModel = new ReconciliationModel();
        $matchCount = $reconModel->autoMatch();
        Session::flash('success', "自動對帳完成，成功配對 {$matchCount} 筆");
        redirect('/accounting.php?action=reconciliation');
        break;

    case 'reconciliation_manual_match':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=reconciliation');
        }
        verify_csrf();
        require_once __DIR__ . '/../modules/accounting/ReconciliationModel.php';
        $reconModel = new ReconciliationModel();
        $bankTxId = (int)(!empty($_POST['bank_tx_id']) ? $_POST['bank_tx_id'] : 0);
        $sysType = !empty($_POST['sys_type']) ? $_POST['sys_type'] : '';
        $sysId = (int)(!empty($_POST['sys_id']) ? $_POST['sys_id'] : 0);
        if ($bankTxId && $sysType && $sysId) {
            $reconModel->manualMatch($bankTxId, $sysType, $sysId);
            Session::flash('success', '手動對帳成功');
        } else {
            Session::flash('error', '請選擇銀行交易與系統交易');
        }
        redirect('/accounting.php?action=reconciliation');
        break;

    case 'reconciliation_unmatch':
        if (!$canManage || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/accounting.php?action=reconciliation');
        }
        verify_csrf();
        require_once __DIR__ . '/../modules/accounting/ReconciliationModel.php';
        $reconModel = new ReconciliationModel();
        $bankTxId = (int)(!empty($_POST['bank_tx_id']) ? $_POST['bank_tx_id'] : 0);
        if ($bankTxId) {
            $reconModel->unmatch($bankTxId);
            Session::flash('success', '已取消對帳配對');
        }
        redirect('/accounting.php?action=reconciliation');
        break;

    // ============================================================
    // 損益表
    // ============================================================
    case 'income_statement':
        require_once __DIR__ . '/../modules/accounting/ReportModel.php';
        $reportModel = new ReportModel();
        $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-01-01');
        $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
        $costCenterId = !empty($_GET['cost_center_id']) ? (int)$_GET['cost_center_id'] : null;
        $costCenters = $model->getCostCenters();

        $report = $reportModel->getIncomeStatement($startDate, $endDate, $costCenterId);

        $pageTitle = '損益表';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/income_statement.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    // ============================================================
    // 資產負債表
    // ============================================================
    case 'balance_sheet':
        require_once __DIR__ . '/../modules/accounting/ReportModel.php';
        $reportModel = new ReportModel();
        $asOfDate = isset($_GET['as_of_date']) ? $_GET['as_of_date'] : date('Y-m-d');
        $costCenterId = !empty($_GET['cost_center_id']) ? (int)$_GET['cost_center_id'] : null;
        $costCenters = $model->getCostCenters();

        $report = $reportModel->getBalanceSheet($asOfDate, $costCenterId);

        $pageTitle = '資產負債表';
        $currentPage = 'accounting';
        require __DIR__ . '/../templates/layouts/header.php';
        require __DIR__ . '/../templates/accounting/balance_sheet.php';
        require __DIR__ . '/../templates/layouts/footer.php';
        break;

    default:
        redirect('/accounting.php?action=journals');
        break;
}
