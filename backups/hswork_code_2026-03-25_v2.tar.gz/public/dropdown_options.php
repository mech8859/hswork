<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requirePermission('settings.manage');
require_once __DIR__ . '/../modules/settings/DropdownModel.php';

$model = new DropdownModel();
$action = isset($_GET['action']) ? $_GET['action'] : 'list';

switch ($action) {
    case 'list':
        $tab = isset($_GET['tab']) ? $_GET['tab'] : 'dropdown';

        if ($tab === 'numbering') {
            $sequences = $model->getNumberSequences();
            $pageTitle = '選單管理 - 單號設定';
            $currentPage = 'dropdown_options';
            require __DIR__ . '/../templates/layouts/header.php';
            require __DIR__ . '/../templates/settings/numbering.php';
            require __DIR__ . '/../templates/layouts/footer.php';
        } elseif ($tab === 'roles') {
            $roles = $model->getAllRoles();
            // 取得每個角色的使用人數
            $roleUserCounts = array();
            foreach ($roles as $r) {
                $roleUserCounts[$r['role_key']] = $model->getRoleUserCount($r['role_key']);
            }
            $pageTitle = '選單管理 - 人員角色';
            $currentPage = 'dropdown_options';
            require __DIR__ . '/../templates/layouts/header.php';
            require __DIR__ . '/../templates/settings/roles_list.php';
            require __DIR__ . '/../templates/layouts/footer.php';
        } else {
            $category = isset($_GET['category']) ? $_GET['category'] : 'customer_demand';
            $categories = $model->getCategories();
            if (!isset($categories[$category])) {
                $category = 'customer_demand';
            }
            $options = $model->getAllOptions($category);
            $pageTitle = '選單管理 - 下拉選項';
            $currentPage = 'dropdown_options';
            require __DIR__ . '/../templates/layouts/header.php';
            require __DIR__ . '/../templates/settings/dropdown_list.php';
            require __DIR__ . '/../templates/layouts/footer.php';
        }
        break;

    case 'add':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/dropdown_options.php');
        }
        if (!verify_csrf()) {
            Session::flash('error', '安全驗證失敗');
            redirect('/dropdown_options.php');
        }
        $category = isset($_POST['category']) ? $_POST['category'] : '';
        $label = isset($_POST['label']) ? trim($_POST['label']) : '';
        $optionKey = isset($_POST['option_key']) ? trim($_POST['option_key']) : '';
        if ($category && $label) {
            if ($model->isKeyedCategory($category) && $optionKey) {
                $model->addKeyedOption($category, $optionKey, $label);
            } else {
                $model->addOption($category, $label);
            }
            Session::flash('success', '已新增選項');
        }
        redirect('/dropdown_options.php?category=' . urlencode($category));
        break;

    case 'update':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $label = isset($_POST['label']) ? trim($_POST['label']) : '';
        if ($id && $label) {
            $model->updateOption($id, $label);
            json_response(array('success' => true));
        }
        json_response(array('error' => '缺少參數'));
        break;

    case 'toggle':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $active = isset($_POST['active']) ? (int)$_POST['active'] : 0;
        if ($id) {
            if ($active) {
                $model->activateOption($id);
            } else {
                $model->deactivateOption($id);
            }
            json_response(array('success' => true));
        }
        json_response(array('error' => '缺少參數'));
        break;

    // ============ 角色管理 ============
    case 'add_role':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/dropdown_options.php?tab=roles');
        }
        if (!verify_csrf()) {
            Session::flash('error', '安全驗證失敗');
            redirect('/dropdown_options.php?tab=roles');
        }
        // 只有 boss 可管理角色
        if (Auth::user()['role'] !== 'boss') {
            Session::flash('error', '權限不足');
            redirect('/dropdown_options.php?tab=roles');
        }
        $roleKey = isset($_POST['role_key']) ? trim($_POST['role_key']) : '';
        $roleLabel = isset($_POST['role_label']) ? trim($_POST['role_label']) : '';
        // 驗證 role_key 格式（小寫英文+底線）
        if ($roleKey && $roleLabel && preg_match('/^[a-z][a-z0-9_]{1,48}$/', $roleKey)) {
            if ($model->roleKeyExists($roleKey)) {
                Session::flash('error', '角色代碼已存在');
            } else {
                $model->addRole($roleKey, $roleLabel);
                Session::flash('success', '已新增角色「' . $roleLabel . '」');
            }
        } else {
            Session::flash('error', '角色代碼須為小寫英文開頭，僅可含小寫英文、數字、底線，2~49字元');
        }
        redirect('/dropdown_options.php?tab=roles');
        break;

    case 'update_role':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        if (Auth::user()['role'] !== 'boss') {
            json_response(array('error' => '權限不足'), 403);
        }
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $roleLabel = isset($_POST['role_label']) ? trim($_POST['role_label']) : '';
        $roleKey = isset($_POST['role_key']) ? trim($_POST['role_key']) : '';
        if ($id && $roleLabel) {
            $existing = $model->getRoleById($id);
            if (!$existing) {
                json_response(array('error' => '角色不存在'));
            }
            // 如果有傳 role_key 且不同，檢查是否重複，並更新使用者
            if ($roleKey && $roleKey !== $existing['role_key']) {
                if (!preg_match('/^[a-z][a-z0-9_]{1,48}$/', $roleKey)) {
                    json_response(array('error' => '角色代碼格式錯誤'));
                }
                if ($model->roleKeyExists($roleKey, $id)) {
                    json_response(array('error' => '角色代碼已存在'));
                }
                // 更新 users 表中的 role 值
                $db = Database::getInstance();
                $db->prepare('UPDATE users SET role = ? WHERE role = ?')
                   ->execute(array($roleKey, $existing['role_key']));
                $model->updateRoleFull($id, $roleKey, $roleLabel);
            } else {
                $model->updateRole($id, $roleLabel);
            }
            json_response(array('success' => true));
        }
        json_response(array('error' => '缺少參數'));
        break;

    case 'toggle_role':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(array('error' => '方法不允許'), 405);
        }
        if (Auth::user()['role'] !== 'boss') {
            json_response(array('error' => '權限不足'), 403);
        }
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $active = isset($_POST['active']) ? (int)$_POST['active'] : 0;
        if ($id) {
            $existing = $model->getRoleById($id);
            if (!$existing) {
                json_response(array('error' => '角色不存在'));
            }
            // 不能停用有使用者的角色
            if (!$active) {
                $userCount = $model->getRoleUserCount($existing['role_key']);
                if ($userCount > 0) {
                    json_response(array('error' => '此角色尚有 ' . $userCount . ' 位使用者，無法停用'));
                }
                // 不能停用系統內建角色 boss
                if ($existing['role_key'] === 'boss') {
                    json_response(array('error' => '系統管理者角色無法停用'));
                }
                $model->deactivateRole($id);
            } else {
                $model->activateRole($id);
            }
            json_response(array('success' => true));
        }
        json_response(array('error' => '缺少參數'));
        break;

    case 'save_numbering':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
            Session::flash('error', '安全驗證失敗');
            redirect('/dropdown_options.php?tab=numbering');
        }
        $ids = isset($_POST['seq_id']) ? $_POST['seq_id'] : array();
        $prefixes = isset($_POST['seq_prefix']) ? $_POST['seq_prefix'] : array();
        $dateFormats = isset($_POST['seq_date_format']) ? $_POST['seq_date_format'] : array();
        $separators = isset($_POST['seq_separator']) ? $_POST['seq_separator'] : array();
        $digits = isset($_POST['seq_digits']) ? $_POST['seq_digits'] : array();

        foreach ($ids as $i => $id) {
            $model->updateNumberSequence((int)$id, array(
                'prefix'      => isset($prefixes[$i]) ? $prefixes[$i] : '',
                'date_format' => isset($dateFormats[$i]) ? $dateFormats[$i] : '',
                'separator'   => isset($separators[$i]) ? $separators[$i] : '-',
                'seq_digits'  => isset($digits[$i]) ? (int)$digits[$i] : 3,
            ));
        }
        Session::flash('success', '單號設定已儲存');
        redirect('/dropdown_options.php?tab=numbering');
        break;

    default:
        redirect('/dropdown_options.php');
}
