<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
$db = Database::getInstance();
$results = array();

// ============================================================
// 1. bank_transactions - Add reconciliation columns
// ============================================================
$btColumns = array(
    array('reconciled', "TINYINT(1) DEFAULT 0"),
    array('reconciled_type', "VARCHAR(30) DEFAULT NULL COMMENT 'receipt/payment_out/journal'"),
    array('reconciled_id', "INT UNSIGNED DEFAULT NULL"),
    array('reconciled_at', "DATETIME DEFAULT NULL"),
);
foreach ($btColumns as $col) {
    try {
        $db->exec("ALTER TABLE bank_transactions ADD COLUMN {$col[0]} {$col[1]}");
        $results[] = "bank_transactions.{$col[0]} added";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate') !== false) {
            $results[] = "bank_transactions.{$col[0]} exists, skip";
        } else {
            $results[] = "bank_transactions.{$col[0]} error: " . $e->getMessage();
        }
    }
}

// Index on reconciled
try {
    $db->exec("ALTER TABLE bank_transactions ADD INDEX idx_reconciled (reconciled)");
    $results[] = "bank_transactions idx_reconciled added";
} catch (PDOException $e) {
    $results[] = "bank_transactions idx_reconciled: " . (strpos($e->getMessage(), 'Duplicate') !== false ? 'exists, skip' : $e->getMessage());
}

// ============================================================
// 2. Ensure tax account codes exist in chart_of_accounts
// ============================================================
$taxAccounts = array(
    array('2401', '銷項稅額', 'liability', 'credit', '銷項稅額'),
    array('1301', '進項稅額', 'asset', 'debit', '進項稅額'),
);
foreach ($taxAccounts as $ta) {
    $check = $db->prepare("SELECT id FROM chart_of_accounts WHERE code = ?");
    $check->execute(array($ta[0]));
    if (!$check->fetch()) {
        try {
            $stmt = $db->prepare("INSERT INTO chart_of_accounts (code, name, account_type, normal_balance, is_detail, is_active, account_code, account_name, level1, level, sort_order) VALUES (?,?,?,?,1,1,?,?,?,1,0)");
            $stmt->execute(array($ta[0], $ta[1], $ta[2], $ta[3], $ta[0], $ta[1], $ta[4]));
            $results[] = "chart_of_accounts {$ta[0]} {$ta[1]} created";
        } catch (PDOException $e) {
            $results[] = "chart_of_accounts {$ta[0]} error: " . $e->getMessage();
        }
    } else {
        $results[] = "chart_of_accounts {$ta[0]} exists, skip";
    }
}

// ============================================================
// 3. Ensure other key account codes exist
// ============================================================
$keyAccounts = array(
    array('1100', '現金', 'asset', 'debit', '現金'),
    array('1102', '銀行存款', 'asset', 'debit', '銀行存款'),
    array('1103', '零用金', 'asset', 'debit', '零用金'),
    array('1131', '應收帳款', 'asset', 'debit', '應收帳款'),
    array('1151', '存貨', 'asset', 'debit', '存貨'),
    array('2101', '應付帳款', 'liability', 'credit', '應付帳款'),
    array('4101', '工程收入', 'revenue', 'credit', '工程收入'),
    array('5101', '工程成本', 'expense', 'debit', '工程成本'),
);
foreach ($keyAccounts as $ka) {
    $check = $db->prepare("SELECT id FROM chart_of_accounts WHERE code = ?");
    $check->execute(array($ka[0]));
    if (!$check->fetch()) {
        try {
            $stmt = $db->prepare("INSERT INTO chart_of_accounts (code, name, account_type, normal_balance, is_detail, is_active, account_code, account_name, level1, level, sort_order) VALUES (?,?,?,?,1,1,?,?,?,1,0)");
            $stmt->execute(array($ka[0], $ka[1], $ka[2], $ka[3], $ka[0], $ka[1], $ka[4]));
            $results[] = "chart_of_accounts {$ka[0]} {$ka[1]} created";
        } catch (PDOException $e) {
            $results[] = "chart_of_accounts {$ka[0]} error: " . $e->getMessage();
        }
    } else {
        $results[] = "chart_of_accounts {$ka[0]} exists, skip";
    }
}

// Output results
echo "<h2>Migration 050 - Auto-Journal & Reconciliation</h2>";
echo "<ul>";
foreach ($results as $r) {
    echo "<li>" . htmlspecialchars($r) . "</li>";
}
echo "</ul>";
echo "<p><strong>Done.</strong></p>";
